import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
//        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
//        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay12 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime1.withYear(28378000);
//        int int15 = dateTime1.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(timeOfDay12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 825 + "'", int15 == 825);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 1);
        long long13 = offsetDateTimeField9.roundHalfEven(0L);
        long long16 = offsetDateTimeField9.add((long) 1969, (-39600000));
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField9.getMaximumShortTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "101" + "'", str11.equals("101"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-3421439999998031L) + "'", long16 == (-3421439999998031L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
//        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
//        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
//        int int15 = property14.getMaximumValueOverall();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property14.getAsText(locale16);
//        java.lang.String str18 = property14.getAsString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        int int10 = skipDateTimeField3.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology11);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.parse("");
        boolean boolean15 = monthDay12.isBefore((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        boolean boolean17 = monthDay12.isSupported(dateTimeFieldType16);
        org.joda.time.Instant instant19 = org.joda.time.Instant.parse("1");
        long long20 = instant19.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder31 = dateTimeZoneBuilder23.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean32 = iSOChronology21.equals((java.lang.Object) dateTimeZoneBuilder31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology21.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime34 = instant19.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime dateTime35 = monthDay12.toDateTime((org.joda.time.ReadableInstant) mutableDateTime34);
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.plus(readablePeriod37);
        boolean boolean39 = monthDay12.isBefore((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.Chronology chronology40 = monthDay36.getChronology();
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay36, 99, locale42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62135568422000L) + "'", long20 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "99" + "'", str43.equals("99"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        int int15 = offsetDateTimeField9.getMaximumValue();
        long long17 = offsetDateTimeField9.roundFloor((long) (byte) 10);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField9.getAsText((long) '4', locale19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 131 + "'", int15 == 131);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "101" + "'", str20.equals("101"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withDayOfMonth(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = fixedDateTimeZone4.nextTransition((long) (byte) 10);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay1.withPeriodAdded(readablePeriod7, (int) (byte) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(monthDay9);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560631530160L + "'", long0 == 1560631530160L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        org.joda.time.Instant instant12 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        boolean boolean15 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology17 = instant14.getChronology();
        org.joda.time.Instant instant18 = instant14.toInstant();
        org.joda.time.Instant instant20 = instant18.plus((long) 110);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = instant20.toDateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, 0L, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.hourOfDay();
        org.joda.time.DateTime dateTime30 = dateTime24.toDateTime((org.joda.time.Chronology) gJChronology28);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        boolean boolean4 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant1.plus(readableDuration5);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (byte) -1);
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendCenturyOfEra(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendHourOfHalfday(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendLiteral(' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder2.appendDayOfWeek((-11));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(3);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), dateTimeZone14);
        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (byte) 1);
        int int21 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property22 = dateTime15.era();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        try {
            long long8 = julianChronology0.getDateTimeMillis(131, (int) (short) 10, (-2), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
//        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
//        java.util.Date date10 = dateTime1.toDate();
//        org.joda.time.DateTime dateTime12 = dateTime1.minusSeconds(0);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
//        int int15 = dateTime12.getDayOfWeek();
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        boolean boolean6 = property4.equals((java.lang.Object) 0.0f);
        org.joda.time.Interval interval7 = property4.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
        long long11 = instant10.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        boolean boolean27 = mutableDateTime25.isSupported(dateTimeFieldType26);
        int int30 = dateTimeFormatter8.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime25, "UTC", (int) (byte) 10);
        boolean boolean31 = mutableDateTime25.isAfterNow();
        long long32 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime33 = property4.getDateTime();
        java.util.Locale locale34 = null;
        int int35 = property4.getMaximumTextLength(locale34);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-11) + "'", int30 == (-11));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1968L + "'", long32 == 1968L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int16 = dividedDateTimeField13.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology18, dateTimeField20, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), dateTimeZone24);
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType28, 100);
        int int32 = dividedDateTimeField30.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = dividedDateTimeField30.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13, dateTimeFieldType33);
        try {
            long long37 = remainderDateTimeField34.set((long) 9, 131);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 131 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.previousTransition((long) 0);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = buddhistChronology0.equals((java.lang.Object) fixedDateTimeZone5);
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(1L, false);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField3);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay6, locale7);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, (int) (short) 100);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumTextLength(locale11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 31, locale14);
        boolean boolean17 = offsetDateTimeField10.isLeap((long) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) offsetDateTimeField10);
        long long20 = skipDateTimeField18.remainder((long) '#');
        int int22 = skipDateTimeField18.get(0L);
        long long24 = skipDateTimeField18.roundHalfFloor((-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62135596800000L) + "'", long24 == (-62135596800000L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue();
        long long62 = zeroIsMaxDateTimeField55.getDifferenceAsLong(10L, (long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "����-W��");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumTextLength(locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField9.getAsShortText((long) 31, locale13);
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant18 = instant16.minus(readableDuration17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField21);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText((org.joda.time.ReadablePartial) monthDay24, locale25);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, (int) (short) 100);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField28.getAsShortText((int) (short) 1, locale30);
        boolean boolean33 = offsetDateTimeField28.isLeap(100L);
        java.lang.String str35 = offsetDateTimeField28.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField28.getType();
        boolean boolean37 = instant18.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType36, (int) ' ', 0, 0);
        long long43 = offsetDateTimeField41.remainder(97L);
        try {
            long long46 = offsetDateTimeField41.add((long) 100, (long) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 133 for dayOfMonth must be in the range [133,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "101" + "'", str14.equals("101"));
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "101" + "'", str35.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 97L + "'", long43 == 97L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        int int15 = offsetDateTimeField9.getMaximumValue();
        long long17 = offsetDateTimeField9.roundFloor((long) (byte) 10);
        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getLeapDurationField();
        long long20 = offsetDateTimeField9.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 131 + "'", int15 == 131);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        long long12 = delegatedDateTimeField9.add(86400000000L, (long) 6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86918400000L + "'", long12 == 86918400000L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134440.771-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("134426.828-0700");
        boolean boolean9 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField13);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay16, locale17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, (int) (short) 100);
        int int21 = offsetDateTimeField20.getMinimumValue();
        boolean boolean22 = offsetDateTimeField20.isLenient();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay.Property property25 = monthDay24.monthOfYear();
        java.lang.String str26 = property25.toString();
        org.joda.time.MonthDay monthDay28 = property25.addToCopy(0);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology29, dateTimeField31);
        int int34 = skipDateTimeField32.get((long) (byte) -1);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipDateTimeField32.getAsShortText((int) (short) 0, locale36);
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay();
        int[] intArray40 = new int[] { (short) 10 };
        int int41 = skipDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray40);
        int int42 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) monthDay28, intArray40);
        boolean boolean43 = jodaTimePermission1.equals((java.lang.Object) intArray40);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 101 + "'", int21 == 101);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[monthOfYear]" + "'", str26.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 131 + "'", int42 == 131);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 8640000010L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int16 = dividedDateTimeField13.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology18, dateTimeField20, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), dateTimeZone24);
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType28, 100);
        int int32 = dividedDateTimeField30.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = dividedDateTimeField30.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13, dateTimeFieldType33);
        long long36 = remainderDateTimeField34.roundCeiling(1000L);
        int int38 = remainderDateTimeField34.get((long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 86400000L + "'", long36 == 86400000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology14 = zonedChronology7.withZone(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long17 = cachedDateTimeZone15.nextTransition(1000L);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone15.getUncachedZone();
        long long20 = cachedDateTimeZone15.nextTransition((long) (-11));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1000L + "'", long17 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-11L) + "'", long20 == (-11L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra((int) '4', 825);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int3 = delegatedDateTimeField2.getMaximumValue();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(1000L, (org.joda.time.Chronology) iSOChronology5);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) monthDay6, 110, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 110");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        boolean boolean14 = dividedDateTimeField13.isLenient();
        long long16 = dividedDateTimeField13.remainder((long) 'a');
        long long18 = dividedDateTimeField13.remainder(52L);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
        long long9 = instant8.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
        java.lang.Class<?> wildcardClass25 = mutableDateTime23.getClass();
        org.joda.time.Chronology chronology26 = mutableDateTime23.getChronology();
        long long27 = mutableDateTime23.getMillis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62135568422000L) + "'", long27 == (-62135568422000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = dividedDateTimeField13.getType();
        java.lang.String str20 = dividedDateTimeField13.getAsShortText((long) 131);
        int int21 = dividedDateTimeField13.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
//        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
//        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.JodaTimePermission jodaTimePermission17 = new org.joda.time.JodaTimePermission("134426.828-0700");
//        org.joda.time.JodaTimePermission jodaTimePermission19 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
//        boolean boolean20 = jodaTimePermission17.implies((java.security.Permission) jodaTimePermission19);
//        boolean boolean21 = property14.equals((java.lang.Object) jodaTimePermission17);
//        java.lang.String str22 = property14.getAsShortText();
//        try {
//            org.joda.time.MonthDay monthDay24 = property14.setCopy("Coordinated Universal Time");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Jun" + "'", str22.equals("Jun"));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField9.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(12);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withDurationAdded(readableDuration16, 3);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology20, dateTimeField22, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (-1), dateTimeZone26);
        org.joda.time.Chronology chronology28 = dateTime27.getChronology();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType30, 100);
        java.util.Locale locale33 = null;
        int int34 = dividedDateTimeField32.getMaximumTextLength(locale33);
        int int36 = dividedDateTimeField32.get((long) 3);
        org.joda.time.DateTimeField dateTimeField37 = dividedDateTimeField32.getWrappedField();
        boolean boolean38 = dateTime18.equals((java.lang.Object) dateTimeField37);
        boolean boolean39 = dateTime18.isEqualNow();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(0, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
//        boolean boolean6 = monthDay3.isBefore((org.joda.time.ReadablePartial) monthDay5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
//        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
//        long long11 = instant10.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime26 = monthDay3.toDateTime((org.joda.time.ReadableInstant) mutableDateTime25);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(100);
//        int int29 = dateTime26.getWeekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), dateTimeZone31);
//        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
//        org.joda.time.DateTime.Property property34 = dateTime32.year();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime32.minus(readablePeriod35);
//        org.joda.time.DateTime dateTime37 = dateTime32.toDateTime();
//        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime32);
//        org.joda.time.Chronology chronology39 = limitChronology38.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(instant10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 22 + "'", int29 == 22);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(limitChronology38);
//        org.junit.Assert.assertNotNull(chronology39);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        long long10 = skipDateTimeField3.roundHalfFloor((long) 100);
        long long12 = skipDateTimeField3.roundCeiling((long) (-11));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        int int5 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property4.addToCopy(52L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology14 = zonedChronology7.withZone(dateTimeZone10);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DurationField durationField17 = julianChronology15.eras();
        java.lang.String str18 = julianChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), dateTimeZone20);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology15, dateTimeZone20);
        boolean boolean24 = zonedChronology22.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology29 = zonedChronology22.withZone(dateTimeZone25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
        org.joda.time.Chronology chronology31 = zonedChronology7.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str18.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        long long58 = zeroIsMaxDateTimeField55.set(0L, (int) (short) 1);
        int int60 = zeroIsMaxDateTimeField55.getLeapAmount((long) 110);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
//        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
//        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
//        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusDays((-2));
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560631535010L + "'", long15 == 1560631535010L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(366, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        int int11 = gJChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology7.monthOfYear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        java.lang.String str16 = offsetDateTimeField9.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField9.getAsText(3, locale19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "3" + "'", str20.equals("3"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology58);
        org.joda.time.MonthDay.Property property60 = monthDay59.monthOfYear();
        int int61 = property60.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay62 = property60.getMonthDay();
        org.joda.time.MonthDay monthDay64 = monthDay62.minusMonths(0);
        int int65 = zeroIsMaxDateTimeField55.getMaximumValue((org.joda.time.ReadablePartial) monthDay64);
        try {
            long long67 = zeroIsMaxDateTimeField55.roundHalfCeiling(49484068L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone0);
        int int4 = monthDay3.size();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay12);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField3.getMaximumShortTextLength(locale14);
        java.lang.String str16 = skipDateTimeField3.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str16.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-2678400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear(1969);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.eras();
        java.lang.String str4 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology1, dateTimeZone6);
        boolean boolean10 = zonedChronology8.equals((java.lang.Object) (short) 10);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) 3, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology8.weekyear();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology8.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str4.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        int int10 = skipDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray13 = new int[] {};
        java.util.Locale locale15 = null;
        try {
            int[] intArray16 = skipDateTimeField3.set(readablePartial11, 3, intArray13, "Jun", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(1L, false);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey((long) 131);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (byte) 1);
        int int8 = dateTime2.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1439 + "'", int8 == 1439);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
        org.joda.time.Instant instant3 = instant1.plus((long) 131);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int56 = dividedDateTimeField13.getMinimumValue();
        try {
            long long59 = dividedDateTimeField13.set(86918400000L, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for yearOfCentury must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969365T160000-0800" + "'", str2.equals("1969365T160000-0800"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField5);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay8, locale9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (int) (short) 100);
        int int13 = offsetDateTimeField12.getMinimumValue();
        boolean boolean14 = offsetDateTimeField12.isLenient();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.toString();
        org.joda.time.MonthDay monthDay20 = property17.addToCopy(0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology21, dateTimeField23);
        int int26 = skipDateTimeField24.get((long) (byte) -1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipDateTimeField24.getAsShortText((int) (short) 0, locale28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay();
        int[] intArray32 = new int[] { (short) 10 };
        int int33 = skipDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay30, intArray32);
        int int34 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay20, intArray32);
        int[] intArray36 = null;
        int[] intArray38 = delegatedDateTimeField2.addWrapPartial((org.joda.time.ReadablePartial) monthDay20, 110, intArray36, 0);
        boolean boolean40 = delegatedDateTimeField2.isLeap((long) (byte) 1);
        long long42 = delegatedDateTimeField2.remainder(1L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 101 + "'", int13 == 101);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[monthOfYear]" + "'", str18.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 131 + "'", int34 == 131);
        org.junit.Assert.assertNull(intArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatterBuilder18.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendFractionOfDay((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendYearOfEra(100, 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatterBuilder34.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder40.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatterBuilder40.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder46.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatterBuilder46.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder52.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser57 = dateTimeFormatterBuilder52.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder58.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser63 = dateTimeFormatterBuilder58.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray64 = new org.joda.time.format.DateTimeParser[] { dateTimeParser39, dateTimeParser45, dateTimeParser51, dateTimeParser57, dateTimeParser63 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder29.append(dateTimePrinter33, dateTimeParserArray64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder15.append(dateTimePrinter24, dateTimeParserArray64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder2.append(dateTimePrinter14, dateTimeParserArray64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimePrinter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeParser57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeParser63);
        org.junit.Assert.assertNotNull(dateTimeParserArray64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) 2019);
        try {
            org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 1969, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(3, 59, 825, 2, 30, 6, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.minus(readablePeriod5);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.withDurationAdded(readableDuration8, 57600);
        org.joda.time.DateTime.Property property11 = dateTime2.dayOfYear();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.DateTime dateTime14 = property11.setCopy("�, June 2, ���� �:��:�� � ", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"�, June 2, ���� �:��:�� � \" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology1.getZone();
        int int8 = dateTimeZone6.getOffsetFromLocal((long) '#');
        boolean boolean10 = dateTimeZone6.isStandardOffset((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134426.828-0700");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean7 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("134426.828-0700");
        boolean boolean10 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission9);
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission9);
        java.lang.Object obj12 = null;
        boolean boolean13 = jodaTimePermission1.equals(obj12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "134426.828-0700" + "'", str2.equals("134426.828-0700"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField15);
        java.lang.Object obj17 = null;
        boolean boolean18 = iSOChronology13.equals(obj17);
        org.joda.time.DateTime dateTime19 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology13);
        boolean boolean21 = dateTime19.equals((java.lang.Object) "97");
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.String str2 = dateTimeFormatter0.print((long) 57600);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        org.joda.time.DateTime dateTime11 = dateTime6.toDateTime();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.withDurationAdded(readableDuration12, 57600);
        org.joda.time.DateTime.Property property15 = dateTime6.dayOfYear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        java.lang.String str17 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16:00" + "'", str2.equals("16:00"));
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "23:59" + "'", str17.equals("23:59"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DurationField durationField5 = property4.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        boolean boolean6 = property4.equals((java.lang.Object) 0.0f);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField9 = property4.getField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        long long7 = skipDateTimeField5.roundCeiling((long) (byte) 10);
        int int9 = skipDateTimeField5.getMinimumValue(0L);
        long long12 = skipDateTimeField5.set(1968L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = skipDateTimeField5.getType();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1968L + "'", long12 == 1968L);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (byte) 1);
        int int8 = dateTime7.getYearOfEra();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
        org.joda.time.Instant instant12 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        boolean boolean15 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) instant14);
        org.joda.time.DateTime dateTime18 = dateTime10.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        int int21 = dateTime18.getSecondOfDay();
        org.joda.time.DateTime dateTime23 = dateTime18.plusWeeks((int) (short) -1);
        boolean boolean24 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime23);
        int int25 = dateTime23.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57600 + "'", int21 == 57600);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 57600000 + "'", int25 == 57600000);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        java.lang.String str16 = offsetDateTimeField9.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        int int19 = offsetDateTimeField9.getMinimumValue(52L);
        long long22 = offsetDateTimeField9.add(1L, (int) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-86399999L) + "'", long22 == (-86399999L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        java.lang.Class<?> wildcardClass8 = julianChronology0.getClass();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        long long7 = skipDateTimeField5.roundCeiling((long) (byte) 10);
        org.joda.time.DurationField durationField8 = skipDateTimeField5.getDurationField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipDateTimeField5.getAsText(0L, locale10);
        org.joda.time.DurationField durationField12 = skipDateTimeField5.getDurationField();
        int int14 = skipDateTimeField5.getLeapAmount((long) 825);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
//        int int5 = skipDateTimeField3.get((long) (byte) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
//        int[] intArray11 = new int[] { (short) 10 };
//        int int12 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay9, intArray11);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology13, dateTimeField15);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.parse("");
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay18, locale19);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, (int) (short) 100);
//        java.util.Locale locale23 = null;
//        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField22.getAsShortText((long) 31, locale26);
//        org.joda.time.Instant instant29 = org.joda.time.Instant.parse("1");
//        org.joda.time.ReadableDuration readableDuration30 = null;
//        org.joda.time.Instant instant31 = instant29.minus(readableDuration30);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology32, dateTimeField34);
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.parse("");
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = skipDateTimeField35.getAsText((org.joda.time.ReadablePartial) monthDay37, locale38);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField35, (int) (short) 100);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField41.getAsShortText((int) (short) 1, locale43);
//        boolean boolean46 = offsetDateTimeField41.isLeap(100L);
//        java.lang.String str48 = offsetDateTimeField41.getAsText(365L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = offsetDateTimeField41.getType();
//        boolean boolean50 = instant31.isSupported(dateTimeFieldType49);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField22, dateTimeFieldType49, (int) ' ', 0, 0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) (-3421439999998031L), "");
//        int int58 = monthDay9.get(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "101" + "'", str27.equals("101"));
//        org.junit.Assert.assertNotNull(instant29);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "101" + "'", str48.equals("101"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 15 + "'", int58 == 15);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-3421440000000000L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-119750400000000000L) + "'", long2 == (-119750400000000000L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(365, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        int int5 = property4.getLeapAmount();
        int int6 = property4.getLeapAmount();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("+00:00", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.dayOfWeek();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = dividedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "69");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 259200010L, "134426.828-0700");
        org.joda.time.DurationFieldType durationFieldType22 = illegalFieldValueException21.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = illegalFieldValueException21.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(durationFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        java.lang.String str16 = offsetDateTimeField9.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField9.getType();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology18, dateTimeField20);
        int int23 = skipDateTimeField21.get((long) (byte) -1);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField21.getAsShortText((int) (short) 0, locale25);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology27);
        org.joda.time.MonthDay monthDay30 = monthDay28.plusMonths((int) (short) 0);
        int int31 = skipDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone37);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology38, dateTimeField40, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (-1), dateTimeZone44);
        org.joda.time.Chronology chronology46 = dateTime45.getChronology();
        org.joda.time.DateTime.Property property47 = dateTime45.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property47.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField40, dateTimeFieldType48, 100);
        int int52 = dividedDateTimeField50.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = dividedDateTimeField50.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder34.appendShortText(dateTimeFieldType53);
        int int55 = monthDay30.indexOf(dateTimeFieldType53);
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay30, 110, locale57);
        boolean boolean59 = offsetDateTimeField9.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "110" + "'", str58.equals("110"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        boolean boolean5 = skipDateTimeField3.isLeap((long) 31);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '#', 259200010L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 259200045L + "'", long2 == 259200045L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
        long long9 = instant8.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
        java.util.Locale locale25 = null;
        java.util.Calendar calendar26 = mutableDateTime23.toCalendar(locale25);
        org.joda.time.MutableDateTime mutableDateTime27 = mutableDateTime23.toMutableDateTime();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(calendar26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        int int13 = dateTime11.getWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(readableDuration14, (int) '#');
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant18 = org.joda.time.Instant.parse("1");
        boolean boolean19 = instant16.isBefore((org.joda.time.ReadableInstant) instant18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) instant18);
        org.joda.time.DateTime dateTime22 = dateTime14.withMillis(0L);
        boolean boolean24 = dateTime22.isAfter((long) 100);
        boolean boolean25 = dateTime11.equals((java.lang.Object) 100);
        org.joda.time.DateTime dateTime27 = dateTime11.plusMinutes((int) ' ');
        try {
            org.joda.time.DateTime dateTime29 = dateTime11.withMonthOfYear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = monthDay8.getFieldTypes();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay8, 101, locale11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology14, dateTimeField16, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), dateTimeZone20);
        org.joda.time.Chronology chronology22 = dateTime21.getChronology();
        org.joda.time.DateTime.Property property23 = dateTime21.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType24, 100);
        boolean boolean27 = monthDay8.isSupported(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 100.0f, "����-W��");
        illegalFieldValueException30.prependMessage("June");
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "101" + "'", str12.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(31, 28378000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28378031 + "'", int2 == 28378031);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks(366);
        int int6 = dateTime2.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = dividedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "69");
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 259200010L, "134426.828-0700");
        java.lang.Number number22 = illegalFieldValueException21.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder18.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean27 = iSOChronology16.equals((java.lang.Object) dateTimeZoneBuilder26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long36 = fixedDateTimeZone34.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology40 = gJChronology37.withZone(dateTimeZone39);
        org.joda.time.Chronology chronology41 = gJChronology37.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology42, dateTimeField44);
        int int47 = skipDateTimeField45.get((long) (byte) -1);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipDateTimeField45.getAsShortText((int) (short) 0, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology51);
        org.joda.time.MonthDay monthDay54 = monthDay52.plusMonths((int) (short) 0);
        int int55 = skipDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder56.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone61);
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology62, dateTimeField64, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) (-1), dateTimeZone68);
        org.joda.time.Chronology chronology70 = dateTime69.getChronology();
        org.joda.time.DateTime.Property property71 = dateTime69.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property71.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField(dateTimeField64, dateTimeFieldType72, 100);
        int int76 = dividedDateTimeField74.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = dividedDateTimeField74.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder58.appendShortText(dateTimeFieldType77);
        int int79 = monthDay54.indexOf(dateTimeFieldType77);
        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField82 = iSOChronology81.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField83 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology80, dateTimeField82);
        int int85 = skipDateTimeField83.get((long) (byte) -1);
        java.util.Locale locale87 = null;
        java.lang.String str88 = skipDateTimeField83.getAsShortText((int) (short) 0, locale87);
        org.joda.time.chrono.JulianChronology julianChronology89 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay90 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology89);
        org.joda.time.MonthDay monthDay92 = monthDay90.plusMonths((int) (short) 0);
        int int93 = skipDateTimeField83.getMinimumValue((org.joda.time.ReadablePartial) monthDay92);
        org.joda.time.MonthDay monthDay95 = monthDay92.minusDays(131);
        int[] intArray96 = monthDay92.getValues();
        gJChronology37.validate((org.joda.time.ReadablePartial) monthDay54, intArray96);
        try {
            int[] intArray99 = dividedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay28, 1, intArray96, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 31 + "'", int47 == 31);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology80);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 31 + "'", int85 == 31);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "0" + "'", str88.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology89);
        org.junit.Assert.assertNotNull(monthDay92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertNotNull(monthDay95);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyearOfCentury();
        try {
            long long10 = iSOChronology0.getDateTimeMillis(6, 0, 292278993, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long16 = fixedDateTimeZone14.previousTransition((long) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plus(0L);
        boolean boolean10 = dateTime6.isEqual(49484068L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology10);
        org.joda.time.MonthDay.Property property12 = monthDay11.monthOfYear();
        int int13 = property12.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay14 = property12.getMonthDay();
        org.joda.time.MonthDay monthDay16 = monthDay14.minusMonths(0);
        int[] intArray18 = null;
        try {
            int[] intArray20 = delegatedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) monthDay16, 1969, intArray18, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        boolean boolean6 = property4.equals((java.lang.Object) 0.0f);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((int) (byte) -1);
        org.joda.time.DateTime dateTime10 = property4.addToCopy((long) (byte) 10);
        org.joda.time.DateTime dateTime11 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
//        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
//        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology14);
//        boolean boolean16 = monthDay6.isAfter((org.joda.time.ReadablePartial) monthDay15);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology18, dateTimeField20, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), dateTimeZone24);
//        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType28, 100);
//        int int32 = dividedDateTimeField30.getLeapAmount((long) (-1));
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = dividedDateTimeField30.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "69");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 259200010L, "134426.828-0700");
//        int int39 = monthDay15.indexOf(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        org.joda.time.Instant instant12 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        boolean boolean15 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology17 = instant14.getChronology();
        org.joda.time.Instant instant18 = instant14.toInstant();
        org.joda.time.Instant instant20 = instant18.plus((long) 110);
        java.lang.Class<?> wildcardClass21 = instant18.getClass();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        int int11 = skipDateTimeField3.getMinimumValue(1000L);
        int int12 = skipDateTimeField3.getMaximumValue();
        java.lang.String str13 = skipDateTimeField3.toString();
        int int14 = skipDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str13.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
//        long long11 = fixedDateTimeZone9.previousTransition((long) 0);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forID("-11");
//        org.joda.time.Chronology chronology15 = gJChronology12.withZone(dateTimeZone14);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant19 = org.joda.time.Instant.parse("1");
//        boolean boolean20 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Chronology chronology22 = instant19.getChronology();
//        boolean boolean23 = dateTime2.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.DateTime.Property property24 = dateTime2.year();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology25);
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.parse("");
//        boolean boolean29 = monthDay26.isBefore((org.joda.time.ReadablePartial) monthDay28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        boolean boolean31 = monthDay26.isSupported(dateTimeFieldType30);
//        org.joda.time.Instant instant33 = org.joda.time.Instant.parse("1");
//        long long34 = instant33.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder37 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder45 = dateTimeZoneBuilder37.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean46 = iSOChronology35.equals((java.lang.Object) dateTimeZoneBuilder45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology35.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime48 = instant33.toMutableDateTime((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.DateTime dateTime49 = monthDay26.toDateTime((org.joda.time.ReadableInstant) mutableDateTime48);
//        org.joda.time.DateTime dateTime51 = dateTime49.minusMinutes(100);
//        int int52 = dateTime49.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime54 = dateTime49.plusWeeks((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime49.minus(readableDuration55);
//        int int57 = property24.compareTo((org.joda.time.ReadableInstant) dateTime56);
//        org.joda.time.Interval interval58 = property24.toInterval();
//        org.joda.time.ReadableInterval readableInterval59 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval58);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(instant33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62135568422000L) + "'", long34 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 22 + "'", int52 == 22);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(interval58);
//        org.junit.Assert.assertNotNull(readableInterval59);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeZoneBuilder10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder10.toDateTimeZone("110", false);
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder10.writeTo("ISOChronology[UTC]", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology5);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("");
        boolean boolean9 = monthDay6.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = monthDay6.isSupported(dateTimeFieldType10);
        org.joda.time.Instant instant13 = org.joda.time.Instant.parse("1");
        long long14 = instant13.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder17.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean26 = iSOChronology15.equals((java.lang.Object) dateTimeZoneBuilder25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology15.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime28 = instant13.toMutableDateTime((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTime dateTime29 = monthDay6.toDateTime((org.joda.time.ReadableInstant) mutableDateTime28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology30, dateTimeField32);
        int int35 = skipDateTimeField33.get((long) (byte) -1);
        java.lang.String str37 = skipDateTimeField33.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, dateTimeFieldType38);
        int int41 = skipDateTimeField33.getMinimumValue(1000L);
        long long44 = skipDateTimeField33.add((long) (short) 10, 0L);
        int int47 = skipDateTimeField33.getDifference(100L, (long) 0);
        int int48 = mutableDateTime28.get((org.joda.time.DateTimeField) skipDateTimeField33);
        jodaTimePermission1.checkGuard((java.lang.Object) skipDateTimeField33);
        java.lang.String str50 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62135568422000L) + "'", long14 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 31 + "'", int35 == 31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"134426.828-0700\")" + "'", str50.equals("(\"org.joda.time.JodaTimePermission\" \"134426.828-0700\")"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay12);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField3.getMaximumShortTextLength(locale14);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology17 = julianChronology16.withUTC();
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) locale14, chronology17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay.Property property7 = monthDay1.dayOfMonth();
        java.lang.Object obj8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj8);
        org.joda.time.Instant instant11 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant13 = org.joda.time.Instant.parse("1");
        boolean boolean14 = instant11.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) instant13);
        org.joda.time.DateTime dateTime17 = dateTime9.withMillis(0L);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks(3);
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
        boolean boolean21 = property20.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        try {
            int int23 = monthDay1.get(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue();
        int int62 = zeroIsMaxDateTimeField55.getDifference(0L, (long) 12);
        long long65 = zeroIsMaxDateTimeField55.set(31L, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 31L + "'", long65 == 31L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134440.771-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("134426.828-0700");
        boolean boolean9 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.Object obj11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj11);
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) instant16);
        org.joda.time.DateTime dateTime20 = dateTime12.withMillis(0L);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks(3);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), dateTimeZone25);
        org.joda.time.Chronology chronology27 = dateTime26.getChronology();
        org.joda.time.DateTime.Property property28 = dateTime26.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime31 = dateTime26.withDurationAdded(readableDuration29, (int) (byte) 1);
        int int32 = property23.getDifference((org.joda.time.ReadableInstant) dateTime26);
        boolean boolean33 = jodaTimePermission1.equals((java.lang.Object) dateTime26);
        boolean boolean35 = jodaTimePermission1.equals((java.lang.Object) "52");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("10", "15", 0, 59);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        int int11 = gJChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = gJChronology7.equals((java.lang.Object) 100);
        java.lang.Object obj22 = null;
        boolean boolean23 = gJChronology7.equals(obj22);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology20, dateTimeField22, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (-1), dateTimeZone26);
        org.joda.time.Chronology chronology28 = dateTime27.getChronology();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType30, 100);
        int int34 = dividedDateTimeField32.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = dividedDateTimeField32.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType35);
        int int37 = monthDay12.indexOf(dateTimeFieldType35);
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
//        long long9 = instant8.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusMinutes(100);
//        int int27 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = dateTime24.plusWeeks((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime24.minus(readableDuration30);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), dateTimeZone33);
//        org.joda.time.Chronology chronology35 = dateTime34.getChronology();
//        org.joda.time.DateTime.Property property36 = dateTime34.yearOfCentury();
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withDurationAdded(readableDuration37, (int) (byte) 1);
//        boolean boolean40 = dateTime31.isAfter((org.joda.time.ReadableInstant) dateTime39);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 22 + "'", int27 == 22);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long7 = fixedDateTimeZone5.previousTransition((long) 0);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = buddhistChronology0.equals((java.lang.Object) fixedDateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology10);
        org.joda.time.DurationField durationField12 = julianChronology10.eras();
        java.lang.String str13 = julianChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology10, dateTimeZone15);
        boolean boolean19 = zonedChronology17.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology24 = zonedChronology17.withZone(dateTimeZone20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        long long27 = cachedDateTimeZone25.nextTransition(1000L);
        long long29 = cachedDateTimeZone25.nextTransition((-62135568422000L));
        long long31 = cachedDateTimeZone25.nextTransition((long) 31);
        org.joda.time.Chronology chronology32 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone25);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str13.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1000L + "'", long27 == 1000L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62135568422000L) + "'", long29 == (-62135568422000L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31L + "'", long31 == 31L);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "2071-166", "-11");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "1", "JulianChronology[America/Los_Angeles]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "year", "����-W��");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDate(0, 1969, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        int int15 = offsetDateTimeField9.getMaximumValue();
        long long17 = offsetDateTimeField9.roundFloor((long) (byte) 10);
        int int18 = offsetDateTimeField9.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 131 + "'", int15 == 131);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.getLeapAmount((long) (-1));
        org.joda.time.DurationField durationField16 = dividedDateTimeField13.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = dividedDateTimeField13.getAsText(15, locale18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "15" + "'", str19.equals("15"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology14 = zonedChronology7.withZone(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        long long17 = cachedDateTimeZone15.nextTransition(1000L);
        java.lang.String str19 = cachedDateTimeZone15.getNameKey(97L);
        java.lang.Object obj20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(obj20);
        org.joda.time.Instant instant23 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant25 = org.joda.time.Instant.parse("1");
        boolean boolean26 = instant23.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) instant25);
        org.joda.time.DateTime dateTime29 = dateTime21.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
        int int32 = dateTime29.getSecondOfDay();
        org.joda.time.DateTime dateTime34 = dateTime29.plusWeeks((int) (short) -1);
        boolean boolean35 = cachedDateTimeZone15.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1000L + "'", long17 == 1000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 57600 + "'", int32 == 57600);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeZoneBuilder10);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology13);
        org.joda.time.DurationField durationField15 = julianChronology13.eras();
        java.lang.String str16 = julianChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology13, dateTimeZone18);
        boolean boolean22 = zonedChronology20.equals((java.lang.Object) (short) 10);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) 3, (org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology20.getZone();
        boolean boolean26 = dateTimeZone24.isStandardOffset((long) 3);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(zonedChronology27);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime2.minusWeeks(366);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.centuries();
        long long4 = durationField1.subtract((-11L), 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-11L) + "'", long4 == (-11L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
        org.joda.time.Instant instant4 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant6 = org.joda.time.Instant.parse("1");
        boolean boolean7 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) instant6);
        org.joda.time.DateTime dateTime10 = dateTime2.withMillis(0L);
        org.joda.time.DateTime dateTime12 = dateTime2.withMillisOfSecond((int) (byte) 10);
        boolean boolean13 = buddhistChronology0.equals((java.lang.Object) (byte) 10);
        org.joda.time.DurationField durationField14 = buddhistChronology0.hours();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.minus(readablePeriod2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = monthDay8.getFieldTypes();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay8, 101, locale11);
        long long15 = skipDateTimeField5.add((-1L), 259200045L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "101" + "'", str12.equals("101"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 22394883887999999L + "'", long15 == 22394883887999999L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        java.lang.String str6 = property4.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "69" + "'", str6.equals("69"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(3);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        boolean boolean13 = property12.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        java.util.Locale locale15 = null;
        int int16 = property12.getMaximumShortTextLength(locale15);
        java.lang.String str17 = property12.getAsShortText();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "70" + "'", str17.equals("70"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.get(86400000L);
        boolean boolean16 = dividedDateTimeField13.isLenient();
        int int19 = dividedDateTimeField13.getDifference((long) 6, 1560631530160L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-180) + "'", int19 == (-180));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField5);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay8, locale9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField6, (int) (short) 100);
        int int13 = offsetDateTimeField12.getMinimumValue();
        boolean boolean14 = offsetDateTimeField12.isLenient();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay.Property property17 = monthDay16.monthOfYear();
        java.lang.String str18 = property17.toString();
        org.joda.time.MonthDay monthDay20 = property17.addToCopy(0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology21, dateTimeField23);
        int int26 = skipDateTimeField24.get((long) (byte) -1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipDateTimeField24.getAsShortText((int) (short) 0, locale28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay();
        int[] intArray32 = new int[] { (short) 10 };
        int int33 = skipDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay30, intArray32);
        int int34 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay20, intArray32);
        int[] intArray36 = null;
        int[] intArray38 = delegatedDateTimeField2.addWrapPartial((org.joda.time.ReadablePartial) monthDay20, 110, intArray36, 0);
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay41 = monthDay39.plus(readablePeriod40);
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology42);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.parse("");
        boolean boolean46 = monthDay43.isBefore((org.joda.time.ReadablePartial) monthDay45);
        org.joda.time.MonthDay monthDay48 = monthDay43.withDayOfMonth((int) (byte) 10);
        boolean boolean49 = monthDay39.isEqual((org.joda.time.ReadablePartial) monthDay48);
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) monthDay48, 2000, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 101 + "'", int13 == 101);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[monthOfYear]" + "'", str18.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 31 + "'", int26 == 31);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 131 + "'", int34 == 131);
        org.junit.Assert.assertNull(intArray38);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        org.joda.time.DurationField durationField6 = skipDateTimeField3.getDurationField();
        long long9 = skipDateTimeField3.getDifferenceAsLong((long) 57600000, 35L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
//        long long9 = instant8.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusMinutes(100);
//        int int27 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = dateTime24.plusWeeks((int) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
//        long long36 = fixedDateTimeZone34.previousTransition((long) (byte) 100);
//        int int38 = fixedDateTimeZone34.getOffset((long) 131);
//        org.joda.time.DateTime dateTime39 = dateTime24.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 22 + "'", int27 == 22);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTime39);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
//        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
//        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
//        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
//        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
//        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
//        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
//        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
//        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
//        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay60 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology59);
//        org.joda.time.MonthDay monthDay62 = org.joda.time.MonthDay.parse("");
//        boolean boolean63 = monthDay60.isBefore((org.joda.time.ReadablePartial) monthDay62);
//        org.joda.time.MonthDay monthDay65 = monthDay60.withDayOfMonth((int) (byte) 10);
//        org.joda.time.MonthDay monthDay67 = monthDay65.minusMonths(131);
//        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay69 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology68);
//        org.joda.time.MonthDay monthDay71 = monthDay69.plusMonths((int) (short) 0);
//        int int72 = monthDay65.compareTo((org.joda.time.ReadablePartial) monthDay71);
//        org.joda.time.MonthDay.Property property73 = monthDay71.monthOfYear();
//        int int74 = property73.getMaximumValueOverall();
//        org.joda.time.MonthDay monthDay76 = property73.addToCopy(2);
//        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField81 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology78, dateTimeField80);
//        int int83 = skipDateTimeField81.get((long) (byte) -1);
//        java.util.Locale locale85 = null;
//        java.lang.String str86 = skipDateTimeField81.getAsShortText((int) (short) 0, locale85);
//        org.joda.time.chrono.JulianChronology julianChronology87 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay88 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology87);
//        org.joda.time.MonthDay monthDay90 = monthDay88.plusMonths((int) (short) 0);
//        int int91 = skipDateTimeField81.getMinimumValue((org.joda.time.ReadablePartial) monthDay90);
//        org.joda.time.MonthDay monthDay93 = monthDay90.minusDays(131);
//        int[] intArray94 = monthDay90.getValues();
//        try {
//            int[] intArray96 = zeroIsMaxDateTimeField55.addWrapField((org.joda.time.ReadablePartial) monthDay76, 1970, intArray94, 15);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1970");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(copticChronology41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNull(durationField58);
//        org.junit.Assert.assertNotNull(julianChronology59);
//        org.junit.Assert.assertNotNull(monthDay62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(julianChronology68);
//        org.junit.Assert.assertNotNull(monthDay71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertNotNull(iSOChronology78);
//        org.junit.Assert.assertNotNull(iSOChronology79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "0" + "'", str86.equals("0"));
//        org.junit.Assert.assertNotNull(julianChronology87);
//        org.junit.Assert.assertNotNull(monthDay90);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(intArray94);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.Instant instant3 = instant1.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        long long15 = zonedChronology7.getDateTimeMillis(0L, 0, 0, (int) (short) 1, (int) (byte) 0);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DurationField durationField18 = julianChronology16.eras();
        java.lang.String str19 = julianChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), dateTimeZone21);
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology16, dateTimeZone21);
        org.joda.time.Chronology chronology24 = zonedChronology7.withZone(dateTimeZone21);
        java.lang.String str25 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1000L + "'", long15 == 1000L);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str19.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str25.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(3);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder0.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("99");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.DateTimeField dateTimeField17 = dividedDateTimeField13.getWrappedField();
        long long20 = dividedDateTimeField13.add(0L, 100L);
        org.joda.time.DurationField durationField21 = dividedDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 864000000000L + "'", long20 == 864000000000L);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        long long2 = instant1.getMillis();
        org.joda.time.ReadableInstant readableInstant3 = null;
        boolean boolean4 = instant1.isEqual(readableInstant3);
        org.joda.time.Instant instant6 = instant1.withMillis(0L);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135568422000L) + "'", long2 == (-62135568422000L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.MonthDay monthDay3 = monthDay0.withFieldAdded(durationFieldType1, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfDay(110);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendCenturyOfEra(59, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology3);
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.parse("");
//        boolean boolean7 = monthDay4.isBefore((org.joda.time.ReadablePartial) monthDay6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = monthDay4.isSupported(dateTimeFieldType8);
//        org.joda.time.Instant instant11 = org.joda.time.Instant.parse("1");
//        long long12 = instant11.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder15.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean24 = iSOChronology13.equals((java.lang.Object) dateTimeZoneBuilder23);
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology13.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime26 = instant11.toMutableDateTime((org.joda.time.Chronology) iSOChronology13);
//        org.joda.time.DateTime dateTime27 = monthDay4.toDateTime((org.joda.time.ReadableInstant) mutableDateTime26);
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
//        boolean boolean31 = monthDay4.isBefore((org.joda.time.ReadablePartial) monthDay28);
//        java.lang.String str32 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimePrinter2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62135568422000L) + "'", long12 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "�, June 15, ���� �:��:�� � " + "'", str32.equals("�, June 15, ���� �:��:�� � "));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField8);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay11, locale12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField9, (int) (short) 100);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsShortText((int) (short) 1, locale17);
        boolean boolean20 = offsetDateTimeField15.isLeap(100L);
        java.lang.String str22 = offsetDateTimeField15.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField15.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType23, 57600000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear((int) 'a', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder25.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "101" + "'", str22.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) 2019);
        java.lang.String str11 = fixedDateTimeZone4.getShortName((long) 365);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        int int14 = offsetDateTimeField9.getMaximumValue(10L);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay monthDay18 = monthDay16.plusMonths((int) (short) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long26 = fixedDateTimeZone24.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology30 = gJChronology27.withZone(dateTimeZone29);
        org.joda.time.Chronology chronology31 = gJChronology27.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology32, dateTimeField34);
        int int37 = skipDateTimeField35.get((long) (byte) -1);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField35.getAsShortText((int) (short) 0, locale39);
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology41);
        org.joda.time.MonthDay monthDay44 = monthDay42.plusMonths((int) (short) 0);
        int int45 = skipDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder46.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone51);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology53.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology52, dateTimeField54, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) (-1), dateTimeZone58);
        org.joda.time.Chronology chronology60 = dateTime59.getChronology();
        org.joda.time.DateTime.Property property61 = dateTime59.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField64 = new org.joda.time.field.DividedDateTimeField(dateTimeField54, dateTimeFieldType62, 100);
        int int66 = dividedDateTimeField64.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = dividedDateTimeField64.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder48.appendShortText(dateTimeFieldType67);
        int int69 = monthDay44.indexOf(dateTimeFieldType67);
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField73 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology70, dateTimeField72);
        int int75 = skipDateTimeField73.get((long) (byte) -1);
        java.util.Locale locale77 = null;
        java.lang.String str78 = skipDateTimeField73.getAsShortText((int) (short) 0, locale77);
        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay80 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology79);
        org.joda.time.MonthDay monthDay82 = monthDay80.plusMonths((int) (short) 0);
        int int83 = skipDateTimeField73.getMinimumValue((org.joda.time.ReadablePartial) monthDay82);
        org.joda.time.MonthDay monthDay85 = monthDay82.minusDays(131);
        int[] intArray86 = monthDay82.getValues();
        gJChronology27.validate((org.joda.time.ReadablePartial) monthDay44, intArray86);
        int[] intArray89 = offsetDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) monthDay18, 1439, intArray86, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 131 + "'", int14 == 131);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 31 + "'", int75 == 31);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "0" + "'", str78.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology79);
        org.junit.Assert.assertNotNull(monthDay82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(monthDay85);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray89);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.year();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology7);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.parse("");
//        boolean boolean11 = monthDay8.isBefore((org.joda.time.ReadablePartial) monthDay10);
//        org.joda.time.MonthDay monthDay13 = monthDay8.withDayOfMonth((int) (byte) 10);
//        org.joda.time.MonthDay monthDay15 = monthDay13.minusMonths(131);
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology16);
//        org.joda.time.MonthDay monthDay19 = monthDay17.plusMonths((int) (short) 0);
//        int int20 = monthDay13.compareTo((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.MonthDay.Property property21 = monthDay19.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.MonthDay monthDay24 = property21.addToCopy(0);
//        long long26 = copticChronology5.set((org.joda.time.ReadablePartial) monthDay24, (long) 110);
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology5.year();
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 3369600110L + "'", long26 == 3369600110L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
//        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
//        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
//        long long9 = instant8.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
//        org.joda.time.DateTime dateTime26 = dateTime24.minusMinutes(100);
//        int int27 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = dateTime24.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMinutes((-2));
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(instant8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 22 + "'", int27 == 22);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        org.joda.time.Instant instant12 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        boolean boolean15 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) instant14);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant18 = instant14.plus(readableDuration17);
        org.joda.time.Instant instant19 = instant18.toInstant();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant19);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(obj1);
//        org.joda.time.Instant instant4 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant6 = org.joda.time.Instant.parse("1");
//        boolean boolean7 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) instant6);
//        org.joda.time.DateTime dateTime10 = dateTime2.withMillis(0L);
//        org.joda.time.DateTime dateTime12 = dateTime2.withMillisOfSecond((int) (byte) 10);
//        boolean boolean13 = buddhistChronology0.equals((java.lang.Object) (byte) 10);
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj14);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant19 = org.joda.time.Instant.parse("1");
//        boolean boolean20 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) instant19);
//        org.joda.time.DateTime dateTime23 = dateTime15.withMillis(0L);
//        org.joda.time.DateTime dateTime25 = dateTime15.withMillisOfSecond((int) (byte) 10);
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime15.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), dateTimeZone28);
//        org.joda.time.Chronology chronology30 = dateTime29.getChronology();
//        org.joda.time.DateTime.Property property31 = dateTime29.yearOfCentury();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime29.toTimeOfDay();
//        int int33 = timeOfDay26.compareTo((org.joda.time.ReadablePartial) timeOfDay32);
//        long long35 = buddhistChronology0.set((org.joda.time.ReadablePartial) timeOfDay26, (long) 100);
//        try {
//            long long43 = buddhistChronology0.getDateTimeMillis((int) (short) 100, 0, (-39600000), 2000, (int) '4', (int) (short) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 49547227L + "'", long35 == 49547227L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(31);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder4.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMonthOfYear(110);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeekShortText();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology15, dateTimeField17);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipDateTimeField18.getAsText((org.joda.time.ReadablePartial) monthDay20, locale21);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, (int) (short) 100);
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField24.getMaximumTextLength(locale25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField24.getAsShortText((long) 31, locale28);
        org.joda.time.Instant instant31 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.Instant instant33 = instant31.minus(readableDuration32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology34, dateTimeField36);
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay39, locale40);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, (int) (short) 100);
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField43.getAsShortText((int) (short) 1, locale45);
        boolean boolean48 = offsetDateTimeField43.isLeap(100L);
        java.lang.String str50 = offsetDateTimeField43.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = offsetDateTimeField43.getType();
        boolean boolean52 = instant33.isSupported(dateTimeFieldType51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType51, (int) ' ', 0, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType51, 57600000, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType51, (int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "101" + "'", str29.equals("101"));
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(instant33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "101" + "'", str50.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.eras();
        java.lang.String str4 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology1, dateTimeZone6);
        boolean boolean10 = zonedChronology8.equals((java.lang.Object) (short) 10);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) 3, (org.joda.time.Chronology) zonedChronology8);
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.MonthDay monthDay14 = monthDay11.plusMonths(1439);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str4.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) -1);
        org.joda.time.DateTime.Property property9 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (byte) 1);
        int int8 = dateTime7.getYearOfEra();
        int int9 = dateTime7.getMillisOfSecond();
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 999 + "'", int9 == 999);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
        org.joda.time.MonthDay monthDay6 = monthDay4.minusMonths(0);
        int int7 = monthDay6.size();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
//        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
//        long long11 = fixedDateTimeZone9.previousTransition((long) 0);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forID("-11");
//        org.joda.time.Chronology chronology15 = gJChronology12.withZone(dateTimeZone14);
//        org.joda.time.Instant instant17 = org.joda.time.Instant.parse("1");
//        org.joda.time.Instant instant19 = org.joda.time.Instant.parse("1");
//        boolean boolean20 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Chronology chronology22 = instant19.getChronology();
//        boolean boolean23 = dateTime2.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.DateTime.Property property24 = dateTime2.year();
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology25);
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.parse("");
//        boolean boolean29 = monthDay26.isBefore((org.joda.time.ReadablePartial) monthDay28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        boolean boolean31 = monthDay26.isSupported(dateTimeFieldType30);
//        org.joda.time.Instant instant33 = org.joda.time.Instant.parse("1");
//        long long34 = instant33.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder37 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder45 = dateTimeZoneBuilder37.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean46 = iSOChronology35.equals((java.lang.Object) dateTimeZoneBuilder45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology35.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime48 = instant33.toMutableDateTime((org.joda.time.Chronology) iSOChronology35);
//        org.joda.time.DateTime dateTime49 = monthDay26.toDateTime((org.joda.time.ReadableInstant) mutableDateTime48);
//        org.joda.time.DateTime dateTime51 = dateTime49.minusMinutes(100);
//        int int52 = dateTime49.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime54 = dateTime49.plusWeeks((int) (short) -1);
//        org.joda.time.ReadableDuration readableDuration55 = null;
//        org.joda.time.DateTime dateTime56 = dateTime49.minus(readableDuration55);
//        int int57 = property24.compareTo((org.joda.time.ReadableInstant) dateTime56);
//        java.lang.String str58 = property24.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(instant17);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(instant33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62135568422000L) + "'", long34 == (-62135568422000L));
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 22 + "'", int52 == 22);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1969" + "'", str58.equals("1969"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        java.lang.String str10 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        int int15 = offsetDateTimeField9.getMaximumValue();
        long long17 = offsetDateTimeField9.roundFloor((long) (byte) 10);
        org.joda.time.DurationField durationField18 = offsetDateTimeField9.getLeapDurationField();
        org.joda.time.DurationField durationField19 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 131 + "'", int15 == 131);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134440.771-0700");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField4);
        int int7 = skipDateTimeField5.get((long) (byte) -1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = skipDateTimeField5.getAsShortText((int) (short) 0, locale9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology11);
        org.joda.time.MonthDay monthDay14 = monthDay12.plusMonths((int) (short) 0);
        int int15 = skipDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay monthDay17 = monthDay14.minusDays(131);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay14.withPeriodAdded(readablePeriod18, 59);
        boolean boolean21 = jodaTimePermission1.equals((java.lang.Object) monthDay14);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        long long8 = fixedDateTimeZone4.previousTransition(2764800012L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2764800012L + "'", long8 == 2764800012L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = dividedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "69");
        java.lang.String str19 = illegalFieldValueException18.getIllegalStringValue();
        java.lang.Number number20 = illegalFieldValueException18.getIllegalNumberValue();
        java.lang.String str21 = illegalFieldValueException18.getIllegalStringValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "69" + "'", str19.equals("69"));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "69" + "'", str21.equals("69"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        int int11 = gJChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = gJChronology7.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology7.weekyearOfCentury();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int16 = dividedDateTimeField13.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology18, dateTimeField20, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), dateTimeZone24);
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType28, 100);
        int int32 = dividedDateTimeField30.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = dividedDateTimeField30.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13, dateTimeFieldType33);
        long long36 = dividedDateTimeField13.remainder((long) (short) 1);
        try {
            long long38 = dividedDateTimeField13.roundCeiling((long) 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DurationField durationField8 = julianChronology6.eras();
        java.lang.String str9 = julianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology6, dateTimeZone11);
        long long16 = dateTimeZone11.adjustOffset((long) 0, false);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(365, 57600000, 2, (-39600000), 6, (int) '4', dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -39600000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str9.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = julianChronology0.add(readablePeriod3, 365L, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 365L + "'", long6 == 365L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(3);
        int int12 = dateTime9.getCenturyOfEra();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
        org.joda.time.MonthDay monthDay6 = monthDay4.minusMonths(0);
        int[] intArray7 = monthDay6.getValues();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        long long7 = skipDateTimeField5.roundCeiling((long) (byte) 10);
        long long10 = skipDateTimeField5.getDifferenceAsLong(31L, (long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        long long58 = zeroIsMaxDateTimeField55.set(0L, (int) (short) 1);
        long long61 = zeroIsMaxDateTimeField55.getDifferenceAsLong((long) 3, 0L);
        org.joda.time.chrono.JulianChronology julianChronology62 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology62);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.parse("");
        boolean boolean66 = monthDay63.isBefore((org.joda.time.ReadablePartial) monthDay65);
        org.joda.time.MonthDay monthDay68 = monthDay63.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay70 = monthDay68.minusMonths(131);
        int[] intArray72 = new int[] { 31 };
        int int73 = zeroIsMaxDateTimeField55.getMaximumValue((org.joda.time.ReadablePartial) monthDay70, intArray72);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(julianChronology62);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 1439);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        boolean boolean6 = monthDay3.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
        long long11 = instant10.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime26 = monthDay3.toDateTime((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(100);
        int int29 = dateTime26.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime.Property property34 = dateTime32.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = dateTime32.toDateTime();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime32);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long45 = fixedDateTimeZone43.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology49 = gJChronology46.withZone(dateTimeZone48);
        org.joda.time.DateTimeZone dateTimeZone50 = gJChronology46.getZone();
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
        org.joda.time.Chronology chronology52 = limitChronology38.withZone(dateTimeZone50);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long59 = fixedDateTimeZone57.previousTransition((long) 0);
        java.util.TimeZone timeZone60 = fixedDateTimeZone57.toTimeZone();
        java.lang.String str62 = fixedDateTimeZone57.getNameKey((long) 2019);
        org.joda.time.Chronology chronology63 = limitChronology38.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone57);
        org.joda.time.Chronology chronology64 = limitChronology38.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 51 + "'", int29 == 51);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(chronology64);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2678400001L), (long) 999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2678399002L) + "'", long2 == (-2678399002L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 49484068L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "160001.439-0800" + "'", str2.equals("160001.439-0800"));
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        boolean boolean14 = dividedDateTimeField13.isLenient();
        long long16 = dividedDateTimeField13.remainder((long) 'a');
        try {
            long long18 = dividedDateTimeField13.roundCeiling((-11L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime16 = dateTime1.withTime(28378031, 57600, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28378031 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.DurationField durationField18 = dividedDateTimeField13.getLeapDurationField();
        java.lang.String str20 = dividedDateTimeField13.getAsText(22394883887999999L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 1);
        long long13 = offsetDateTimeField9.roundHalfEven(0L);
        long long16 = offsetDateTimeField9.add((long) 1969, (-39600000));
        int int17 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "101" + "'", str11.equals("101"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-3421439999998031L) + "'", long16 == (-3421439999998031L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 101 + "'", int17 == 101);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("year", 15, 1439, 51);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for year must be in the range [1439,51]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        boolean boolean14 = dividedDateTimeField13.isLenient();
        long long16 = dividedDateTimeField13.remainder((long) 'a');
        java.lang.String str18 = dividedDateTimeField13.getAsShortText((long) 57600);
        org.joda.time.DurationField durationField19 = dividedDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        boolean boolean6 = monthDay3.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
        long long11 = instant10.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime26 = monthDay3.toDateTime((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(100);
        int int29 = dateTime26.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime.Property property34 = dateTime32.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = dateTime32.toDateTime();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        boolean boolean40 = limitChronology38.equals((java.lang.Object) dateTimeFormatter39);
        org.joda.time.DateTime dateTime41 = limitChronology38.getLowerLimit();
        long long42 = dateTime41.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 51 + "'", int29 == 51);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62105242022000L) + "'", long42 == (-62105242022000L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        long long58 = zeroIsMaxDateTimeField55.add((long) (byte) 10, (long) 10);
        boolean boolean60 = zeroIsMaxDateTimeField55.isLeap((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 86400000010L + "'", long58 == 86400000010L);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay12);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField3.getMaximumShortTextLength(locale14);
        long long18 = skipDateTimeField3.getDifferenceAsLong((long) (byte) 10, 31L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.DurationField durationField18 = dividedDateTimeField13.getLeapDurationField();
        int int21 = dividedDateTimeField13.getDifference((long) 28378000, (long) 19);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.DurationField durationField18 = dividedDateTimeField13.getLeapDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay();
        int[] intArray11 = new int[] { (short) 10 };
        int int12 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay9, intArray11);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField3.getMaximumTextLength(locale13);
        long long17 = skipDateTimeField3.set(10L, (int) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 777600010L + "'", long17 == 777600010L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(3);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), dateTimeZone14);
        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, (int) (byte) 1);
        int int21 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime23 = dateTime15.plus(1000L);
        int int24 = dateTime15.getMillisOfDay();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 86399999 + "'", int24 == 86399999);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.secondOfMinute();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.eras();
        java.lang.String str5 = julianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology2, dateTimeZone7);
        boolean boolean11 = zonedChronology9.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology16 = zonedChronology9.withZone(dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        long long19 = cachedDateTimeZone17.nextTransition(1000L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str5.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1000L + "'", long19 == 1000L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 10, locale7);
        boolean boolean9 = skipDateTimeField3.isLenient();
        boolean boolean10 = skipDateTimeField3.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName(1560631535010L, locale2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PDT" + "'", str3.equals("PDT"));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1439, (int) (short) 0, 22, 31, 12, 999, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("(\"org.joda.time.JodaTimePermission\" \"0001-01-01T07:52:58.000Z\")", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"0001-01-01T07:52:58.000Z\")\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        int int10 = skipDateTimeField3.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField3.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, 57600);
        long long15 = skipDateTimeField3.roundHalfEven(864000000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 864000000000L + "'", long15 == 864000000000L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "365" + "'", str14.equals("365"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 69, 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 74 + "'", int3 == 74);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        boolean boolean6 = monthDay3.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
        long long11 = instant10.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime26 = monthDay3.toDateTime((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(100);
        int int29 = dateTime26.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime.Property property34 = dateTime32.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = dateTime32.toDateTime();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime32);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.Chronology chronology40 = limitChronology38.withZone(dateTimeZone39);
        org.joda.time.DurationField durationField41 = limitChronology38.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 51 + "'", int29 == 51);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumTextLength(locale10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField9.getAsShortText((long) 31, locale13);
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant18 = instant16.minus(readableDuration17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField21);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField22.getAsText((org.joda.time.ReadablePartial) monthDay24, locale25);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, (int) (short) 100);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField28.getAsShortText((int) (short) 1, locale30);
        boolean boolean33 = offsetDateTimeField28.isLeap(100L);
        java.lang.String str35 = offsetDateTimeField28.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField28.getType();
        boolean boolean37 = instant18.isSupported(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType36, (int) ' ', 0, 0);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField9.getAsText(57600000, locale43);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "101" + "'", str14.equals("101"));
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "101" + "'", str35.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "57600000" + "'", str44.equals("57600000"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "1");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        long long2 = instant1.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder5.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean14 = iSOChronology3.equals((java.lang.Object) dateTimeZoneBuilder13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology3.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime16 = instant1.toMutableDateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology3.hourOfDay();
        long long21 = iSOChronology3.add((long) 0, (long) 28378031, 86399999);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135568422000L) + "'", long2 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2451861850021969L + "'", long21 == 2451861850021969L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean17 = iSOChronology6.equals((java.lang.Object) dateTimeZoneBuilder16);
        try {
            org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) dateTimeField5, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.field.RemainderDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        java.util.Date date10 = dateTime1.toDate();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.fromDateFields(date10);
        org.joda.time.LocalDate localDate13 = monthDay11.toLocalDate(12);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMonthOfYear(110);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendCenturyOfEra(0, 365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(6);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology16, dateTimeField18, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), dateTimeZone22);
        org.joda.time.Chronology chronology24 = dateTime23.getChronology();
        org.joda.time.DateTime.Property property25 = dateTime23.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField18, dateTimeFieldType26, 100);
        java.util.Locale locale29 = null;
        int int30 = dividedDateTimeField28.getMaximumTextLength(locale29);
        int int31 = dividedDateTimeField28.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology33, dateTimeField35, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (-1), dateTimeZone39);
        org.joda.time.Chronology chronology41 = dateTime40.getChronology();
        org.joda.time.DateTime.Property property42 = dateTime40.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, dateTimeFieldType43, 100);
        int int47 = dividedDateTimeField45.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = dividedDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType48, (int) (short) 10, 57600000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder4.toParser();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology6);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.parse("");
        boolean boolean10 = monthDay7.isBefore((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.MonthDay monthDay12 = monthDay7.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.MonthDay monthDay18 = monthDay16.plusMonths((int) (short) 0);
        int int19 = monthDay12.compareTo((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.MonthDay.Property property20 = monthDay18.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue();
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology60);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.parse("");
        boolean boolean64 = monthDay61.isBefore((org.joda.time.ReadablePartial) monthDay63);
        org.joda.time.MonthDay monthDay66 = monthDay61.minusMonths((int) (byte) 10);
        org.joda.time.MonthDay.Property property67 = monthDay61.monthOfYear();
        int int68 = zeroIsMaxDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) monthDay61);
        int int69 = zeroIsMaxDateTimeField55.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        boolean boolean6 = monthDay3.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = monthDay3.isSupported(dateTimeFieldType7);
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("1");
        long long11 = instant10.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder14.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean23 = iSOChronology12.equals((java.lang.Object) dateTimeZoneBuilder22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology12.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = instant10.toMutableDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime26 = monthDay3.toDateTime((org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMinutes(100);
        int int29 = dateTime26.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
        org.joda.time.DateTime.Property property34 = dateTime32.year();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = dateTime32.toDateTime();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime32);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.Chronology chronology40 = limitChronology38.withZone(dateTimeZone39);
        org.joda.time.DateTime dateTime41 = limitChronology38.getUpperLimit();
        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135568422000L) + "'", long11 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 51 + "'", int29 == 51);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
//        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeZoneBuilder10);
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology15 = gregorianChronology13.withZone(dateTimeZone14);
//        boolean boolean16 = iSOChronology0.equals((java.lang.Object) gregorianChronology13);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forID("-11");
//        int int20 = dateTimeZone18.getOffsetFromLocal(1000L);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone22.getName((long) 100, locale25);
//        org.joda.time.Chronology chronology27 = iSOChronology21.withZone(dateTimeZone22);
//        boolean boolean28 = iSOChronology0.equals((java.lang.Object) iSOChronology21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-39600000) + "'", int20 == (-39600000));
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordinated Universal Time" + "'", str26.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology18);
        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
        java.lang.String str21 = property20.toString();
        org.joda.time.MonthDay monthDay23 = property20.addToCopy(0);
        java.util.Locale locale25 = null;
        java.lang.String str26 = dividedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay23, (int) (byte) 10, locale25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.halfdayOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField29.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField31 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13, dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Property[monthOfYear]" + "'", str21.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.DateTimeField dateTimeField17 = dividedDateTimeField13.getWrappedField();
        try {
            long long20 = dividedDateTimeField13.addWrapField(3369600110L, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMinuteOfDay(99);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        boolean boolean4 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant6 = instant3.plus((long) 4);
        org.joda.time.Instant instant9 = instant6.withDurationAdded((long) (byte) 0, 22);
        org.joda.time.Instant instant11 = instant9.plus((-3421439999998031L));
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue();
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology60);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.parse("");
        boolean boolean64 = monthDay61.isBefore((org.joda.time.ReadablePartial) monthDay63);
        org.joda.time.MonthDay monthDay66 = monthDay61.minusMonths((int) (byte) 10);
        org.joda.time.MonthDay.Property property67 = monthDay61.monthOfYear();
        int int68 = zeroIsMaxDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) monthDay61);
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = iSOChronology70.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField72 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology69, dateTimeField71);
        int int74 = skipDateTimeField72.get((long) (byte) -1);
        java.util.Locale locale76 = null;
        java.lang.String str77 = skipDateTimeField72.getAsShortText((int) (short) 0, locale76);
        org.joda.time.chrono.JulianChronology julianChronology78 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology78);
        org.joda.time.MonthDay monthDay81 = monthDay79.plusMonths((int) (short) 0);
        int int82 = skipDateTimeField72.getMinimumValue((org.joda.time.ReadablePartial) monthDay81);
        org.joda.time.MonthDay monthDay84 = monthDay81.minusDays(131);
        org.joda.time.ReadablePeriod readablePeriod85 = null;
        org.joda.time.MonthDay monthDay87 = monthDay81.withPeriodAdded(readablePeriod85, 59);
        java.util.Locale locale88 = null;
        try {
            java.lang.String str89 = zeroIsMaxDateTimeField55.getAsShortText((org.joda.time.ReadablePartial) monthDay81, locale88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 31 + "'", int74 == 31);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "0" + "'", str77.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology78);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(monthDay84);
        org.junit.Assert.assertNotNull(monthDay87);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.year();
        java.lang.String str7 = copticChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.DurationField durationField12 = copticChronology5.hours();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CopticChronology[1969365T160000-0800]" + "'", str7.equals("CopticChronology[1969365T160000-0800]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = skipDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay12);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField3.getMaximumShortTextLength(locale14);
        long long17 = skipDateTimeField3.roundFloor(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        boolean boolean6 = property4.equals((java.lang.Object) 0.0f);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((int) (byte) -1);
        org.joda.time.DateTime dateTime10 = property4.addToCopy((long) (byte) 10);
        org.joda.time.DateTime dateTime11 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long11 = fixedDateTimeZone9.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology15 = gJChronology12.withZone(dateTimeZone14);
        org.joda.time.Instant instant17 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant19 = org.joda.time.Instant.parse("1");
        boolean boolean20 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) instant19);
        org.joda.time.Chronology chronology22 = instant19.getChronology();
        boolean boolean23 = dateTime2.isBefore((org.joda.time.ReadableInstant) instant19);
        org.joda.time.DateTime.Property property24 = dateTime2.year();
        org.joda.time.DateTime dateTime25 = property24.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        java.lang.String str4 = iSOChronology2.toString();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology2.equals(obj5);
        long long10 = iSOChronology2.add((long) 365, 0L, 131);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.secondOfDay();
        try {
            org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(110, 2, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 365L + "'", long10 == 365L);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), dateTimeZone9);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime13.centuryOfEra();
        boolean boolean18 = monthDay5.equals((java.lang.Object) dateTime13);
        org.joda.time.MonthDay monthDay20 = monthDay5.minusMonths(110);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
        long long9 = instant8.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.minusMinutes(100);
        int int27 = dateTime24.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime29 = dateTime24.minusHours(0);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime29);
        int int31 = dateTime29.getMillisOfSecond();
        int int32 = dateTime29.getDayOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 51 + "'", int27 == 51);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 352 + "'", int32 == 352);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        long long58 = zeroIsMaxDateTimeField55.add((long) (byte) 10, (long) 10);
        long long60 = zeroIsMaxDateTimeField55.remainder((long) 292278993);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 86400000010L + "'", long58 == 86400000010L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 292278993L + "'", long60 == 292278993L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder3.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeZoneBuilder11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-99L), (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean7 = jodaTimePermission4.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        boolean boolean12 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = monthDay9.isSupported(dateTimeFieldType13);
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        long long17 = instant16.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder20.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean29 = iSOChronology18.equals((java.lang.Object) dateTimeZoneBuilder28);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology18.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime31 = instant16.toMutableDateTime((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DateTime dateTime32 = monthDay9.toDateTime((org.joda.time.ReadableInstant) mutableDateTime31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology33, dateTimeField35);
        int int38 = skipDateTimeField36.get((long) (byte) -1);
        java.lang.String str40 = skipDateTimeField36.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType41);
        int int44 = skipDateTimeField36.getMinimumValue(1000L);
        long long47 = skipDateTimeField36.add((long) (short) 10, 0L);
        int int50 = skipDateTimeField36.getDifference(100L, (long) 0);
        int int51 = mutableDateTime31.get((org.joda.time.DateTimeField) skipDateTimeField36);
        jodaTimePermission4.checkGuard((java.lang.Object) skipDateTimeField36);
        boolean boolean53 = property2.equals((java.lang.Object) jodaTimePermission4);
        int int54 = property2.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135568422000L) + "'", long17 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1" + "'", str40.equals("1"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        java.lang.String str2 = iSOChronology0.toString();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology0.equals(obj3);
        long long8 = iSOChronology0.add((long) 365, 0L, 131);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 365L + "'", long8 == 365L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
        int int15 = property14.getMaximumValueOverall();
        org.joda.time.DurationField durationField16 = property14.getRangeDurationField();
        java.util.Locale locale17 = null;
        int int18 = property14.getMaximumTextLength(locale17);
        java.lang.String str19 = property14.getAsShortText();
        int int20 = property14.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Dec" + "'", str19.equals("Dec"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant7 = org.joda.time.Instant.parse("1");
        boolean boolean8 = instant5.isBefore((org.joda.time.ReadableInstant) instant7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) instant7);
        org.joda.time.DateTime dateTime11 = dateTime3.withMillis(0L);
        org.joda.time.DateTime dateTime13 = dateTime3.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime13.minusDays((-2));
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology17);
        org.joda.time.DurationField durationField19 = julianChronology17.eras();
        java.lang.String str20 = julianChronology17.toString();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), dateTimeZone22);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology17, dateTimeZone22);
        boolean boolean26 = zonedChronology24.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology31 = zonedChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime32 = dateTime16.toDateTime(chronology31);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), dateTimeZone34);
        org.joda.time.Chronology chronology36 = dateTime35.getChronology();
        org.joda.time.DateTime.Property property37 = dateTime35.yearOfCentury();
        boolean boolean39 = property37.equals((java.lang.Object) 0.0f);
        org.joda.time.Interval interval40 = property37.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Instant instant43 = org.joda.time.Instant.parse("1");
        long long44 = instant43.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder47 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder55 = dateTimeZoneBuilder47.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean56 = iSOChronology45.equals((java.lang.Object) dateTimeZoneBuilder55);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology45.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime58 = instant43.toMutableDateTime((org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = null;
        boolean boolean60 = mutableDateTime58.isSupported(dateTimeFieldType59);
        int int63 = dateTimeFormatter41.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime58, "UTC", (int) (byte) 10);
        boolean boolean64 = mutableDateTime58.isAfterNow();
        long long65 = property37.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime58);
        try {
            org.joda.time.chrono.LimitChronology limitChronology66 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) mutableDateTime58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str20.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(interval40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(instant43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62135568422000L) + "'", long44 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-11) + "'", int63 == (-11));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1968L + "'", long65 == 1968L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.DateTimeField dateTimeField18 = dividedDateTimeField13.getWrappedField();
        long long21 = dividedDateTimeField13.add((long) 74, (-11));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-95039999926L) + "'", long21 == (-95039999926L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.MonthDay monthDay17 = property14.addToCopy(0);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology18);
        org.joda.time.DurationField durationField20 = julianChronology18.eras();
        java.lang.String str21 = julianChronology18.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology18, dateTimeZone23);
        long long28 = dateTimeZone23.adjustOffset((long) 0, false);
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23);
        boolean boolean30 = property14.equals((java.lang.Object) dateTimeZone23);
        int int31 = property14.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str21.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology4, dateTimeField6);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay9, locale10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, (int) (short) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField13.getAsShortText((int) (short) 1, locale15);
        boolean boolean18 = offsetDateTimeField13.isLeap(100L);
        java.lang.String str20 = offsetDateTimeField13.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        boolean boolean22 = instant3.isSupported(dateTimeFieldType21);
        org.joda.time.Instant instant23 = instant3.toInstant();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "101" + "'", str20.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(instant23);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.centuryOfEra();
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getMaximumValue((long) (short) 1);
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue((long) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"dayOfMonth/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (byte) -1);
        boolean boolean5 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendCenturyOfEra(0, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendHourOfDay(9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime11.minusDays((-2));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withChronology(chronology15);
        boolean boolean17 = dateTime16.isBeforeNow();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(101);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("134440.771-0700", 0, 110, 22, 'a', (int) (byte) 0, 0, 131, true, 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder0.addRecurringSavings("101", (-1), 0, 292278993, 'a', 0, (int) (byte) 0, 30, true, 352);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.minuteOfDay();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        boolean boolean12 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime13 = dateTime1.withFields((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime15 = dateTime1.withMillisOfDay(30);
        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-57599970L) + "'", long17 == (-57599970L));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime13.plus((long) 69);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatterBuilder9.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder3.append(dateTimeParser14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatterBuilder23.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.append(dateTimeParser28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser28);
        org.joda.time.format.DateTimeParser dateTimeParser31 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay.Property property7 = monthDay1.dayOfMonth();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31T23:52:58-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31T23:52:58-08:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        boolean boolean14 = dividedDateTimeField13.isLenient();
        long long16 = dividedDateTimeField13.remainder((long) 'a');
        long long18 = dividedDateTimeField13.remainder(52L);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay();
        org.joda.time.DateTimeField[] dateTimeFieldArray20 = monthDay19.getFields();
        java.lang.String str22 = monthDay19.toString("1");
        int int23 = dividedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(dateTimeFieldArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime11.minusDays((-2));
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology15);
        org.joda.time.DurationField durationField17 = julianChronology15.eras();
        java.lang.String str18 = julianChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), dateTimeZone20);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology15, dateTimeZone20);
        boolean boolean24 = zonedChronology22.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology29 = zonedChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime30 = dateTime14.toDateTime(chronology29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.DateTime dateTime33 = dateTime30.minusHours(0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str18.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1010 + "'", int31 == 1010);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(74);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-74) + "'", int1 == (-74));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfYear(31);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneShortName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology15, dateTimeField17, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), dateTimeZone21);
        org.joda.time.Chronology chronology23 = dateTime22.getChronology();
        org.joda.time.DateTime.Property property24 = dateTime22.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType25, 100);
        int int29 = dividedDateTimeField27.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = dividedDateTimeField27.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType30);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType30, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.String str15 = dateTimeFormatter13.print((long) 57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.append(dateTimeFormatter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(366);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.appendHourOfDay(57600000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16:00" + "'", str15.equals("16:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFractionOfDay((int) '#', 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(100, 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatterBuilder9.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatterBuilder15.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatterBuilder21.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatterBuilder27.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatterBuilder33.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray39 = new org.joda.time.format.DateTimeParser[] { dateTimeParser14, dateTimeParser20, dateTimeParser26, dateTimeParser32, dateTimeParser38 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder4.append(dateTimePrinter8, dateTimeParserArray39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMinuteOfHour(57600000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeParserArray39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField3);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay6, locale7);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, (int) (short) 100);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField10.getMaximumTextLength(locale11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 31, locale14);
        org.joda.time.Instant instant17 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Instant instant19 = instant17.minus(readableDuration18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology20, dateTimeField22);
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField23.getAsText((org.joda.time.ReadablePartial) monthDay25, locale26);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, (int) (short) 100);
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField29.getAsShortText((int) (short) 1, locale31);
        boolean boolean34 = offsetDateTimeField29.isLeap(100L);
        java.lang.String str36 = offsetDateTimeField29.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField29.getType();
        boolean boolean38 = instant19.isSupported(dateTimeFieldType37);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType37, (int) ' ', 0, 0);
        long long44 = offsetDateTimeField42.remainder(97L);
        int int45 = dateTime0.get((org.joda.time.DateTimeField) offsetDateTimeField42);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "101" + "'", str15.equals("101"));
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "101" + "'", str36.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 97L + "'", long44 == 97L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 133 + "'", int45 == 133);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        int int4 = dateTime2.getDayOfYear();
        int int5 = dateTime2.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1439 + "'", int5 == 1439);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), dateTimeZone9);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfCentury();
        org.joda.time.DateTime dateTime13 = property12.roundFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime13.centuryOfEra();
        boolean boolean18 = monthDay5.equals((java.lang.Object) dateTime13);
        org.joda.time.DateTime.Property property19 = dateTime13.weekyear();
        org.joda.time.DateTime dateTime20 = property19.getDateTime();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        int int10 = offsetDateTimeField9.getMinimumValue();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField9.getAsShortText((-11), locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 101 + "'", int10 == 101);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-11" + "'", str13.equals("-11"));
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
        int int15 = property14.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay17 = property14.addToCopy(2);
        java.lang.String str18 = property14.getAsString();
        java.lang.String str19 = property14.getAsShortText();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12" + "'", str18.equals("12"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Dec" + "'", str19.equals("Dec"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        int int15 = dividedDateTimeField13.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = dividedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "69");
        java.lang.Throwable[] throwableArray19 = illegalFieldValueException18.getSuppressed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        boolean boolean4 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField8, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), dateTimeZone12);
        org.joda.time.Chronology chronology14 = dateTime13.getChronology();
        org.joda.time.DateTime.Property property15 = dateTime13.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType16, 100);
        int int20 = dividedDateTimeField18.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = dividedDateTimeField18.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "69");
        int int24 = instant3.get(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withLocale(locale5);
        java.io.Writer writer7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.year();
        int int13 = dateTime10.getYearOfCentury();
        try {
            dateTimeFormatter6.printTo(writer7, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 1);
        int int12 = offsetDateTimeField9.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "101" + "'", str11.equals("101"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 131 + "'", int12 == 131);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
        long long9 = instant8.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
        org.joda.time.DateTime dateTime26 = dateTime24.minusMinutes(100);
        int int27 = dateTime24.getWeekOfWeekyear();
        int int28 = dateTime24.getMonthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135568422000L) + "'", long9 == (-62135568422000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 51 + "'", int27 == 51);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        int int10 = skipDateTimeField3.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField3.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, 57600);
        java.lang.String str14 = offsetDateTimeField13.getName();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology16, dateTimeField18, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), dateTimeZone22);
        org.joda.time.Chronology chronology24 = dateTime23.getChronology();
        org.joda.time.DateTime.Property property25 = dateTime23.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField18, dateTimeFieldType26, 100);
        java.util.Locale locale29 = null;
        int int30 = dividedDateTimeField28.getMaximumTextLength(locale29);
        int int32 = dividedDateTimeField28.get((long) 3);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology33);
        org.joda.time.MonthDay.Property property35 = monthDay34.monthOfYear();
        java.lang.String str36 = property35.toString();
        org.joda.time.MonthDay monthDay38 = property35.addToCopy(0);
        java.util.Locale locale40 = null;
        java.lang.String str41 = dividedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) monthDay38, (int) (byte) 10, locale40);
        int[] intArray42 = null;
        int int43 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Property[monthOfYear]" + "'", str36.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10" + "'", str41.equals("10"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 57601 + "'", int43 == 57601);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int17 = dividedDateTimeField13.get((long) 3);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField18 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology9, dateTimeField11, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), dateTimeZone15);
        org.joda.time.Chronology chronology17 = dateTime16.getChronology();
        org.joda.time.DateTime.Property property18 = dateTime16.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType19, 100);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField21.getAsShortText((long) 'a', locale23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone30);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology31, dateTimeField33, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), dateTimeZone37);
        org.joda.time.Chronology chronology39 = dateTime38.getChronology();
        org.joda.time.DateTime.Property property40 = dateTime38.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(dateTimeField33, dateTimeFieldType41, 100);
        int int45 = dividedDateTimeField43.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = dividedDateTimeField43.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder27.appendShortText(dateTimeFieldType46);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone48);
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology50.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology49, dateTimeField51, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (-1), dateTimeZone55);
        org.joda.time.Chronology chronology57 = dateTime56.getChronology();
        org.joda.time.DateTime.Property property58 = dateTime56.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField(dateTimeField51, dateTimeFieldType59, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder27.appendText(dateTimeFieldType59);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField63 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField21, dateTimeFieldType59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        long long57 = zeroIsMaxDateTimeField55.remainder((-57599970L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-57599970L) + "'", long57 == (-57599970L));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        boolean boolean6 = property4.equals((java.lang.Object) 0.0f);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField11);
        int int14 = skipDateTimeField12.get((long) (byte) -1);
        java.lang.String str16 = skipDateTimeField12.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType17);
        int int19 = skipDateTimeField12.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField20 = skipDateTimeField12.getWrappedField();
        boolean boolean21 = property4.equals((java.lang.Object) dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumShortTextLength(locale4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond(825);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendPattern("(\"org.joda.time.JodaTimePermission\" \"134426.828-0700\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfMonth();
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField8);
        int int11 = fixedDateTimeZone4.getOffset((long) 1970);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Coordinated Universal Time", 365, 69, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for Coordinated Universal Time must be in the range [69,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        long long2 = instant1.getMillis();
        org.joda.time.ReadableInstant readableInstant3 = null;
        boolean boolean4 = instant1.isEqual(readableInstant3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant1.minus(readableDuration5);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135596800000L) + "'", long2 == (-62135596800000L));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfCeilingCopy();
        int int7 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        java.lang.String str3 = property2.toString();
        org.joda.time.MonthDay monthDay5 = property2.addToCopy(0);
        int int6 = property2.getMaximumValue();
        org.joda.time.DurationField durationField7 = property2.getDurationField();
        org.joda.time.MonthDay monthDay9 = property2.addToCopy(57600);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[monthOfYear]" + "'", str3.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        java.lang.String str16 = offsetDateTimeField9.getAsText(365L);
        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 10);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone19);
        int int23 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay22);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "101" + "'", str18.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 131 + "'", int23 == 131);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeZoneBuilder10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder10.toDateTimeZone("110", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder10.setFixedSavings("CopticChronology[1969365T160000-0800]", 3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forID("-11");
        org.joda.time.Chronology chronology10 = gJChronology7.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology7.getZone();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.weekyear();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        java.lang.String str8 = zonedChronology7.toString();
        java.lang.String str9 = zonedChronology7.toString();
        try {
            long long15 = zonedChronology7.getDateTimeMillis(86400000L, 999, 131, 15, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[1969365T160000-0800]" + "'", str3.equals("JulianChronology[1969365T160000-0800]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str8.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str9.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        int int15 = offsetDateTimeField9.getMaximumValue();
        long long17 = offsetDateTimeField9.roundFloor((long) (byte) 10);
        int int19 = offsetDateTimeField9.getMaximumValue((long) (short) 0);
        int int20 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 131 + "'", int15 == 131);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 131 + "'", int19 == 131);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 101 + "'", int20 == 101);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 100);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(57600);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001T000000Z" + "'", str2.equals("1970001T000000Z"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        boolean boolean9 = zonedChronology7.equals((java.lang.Object) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, 0L, (int) (byte) 1);
        org.joda.time.Chronology chronology14 = zonedChronology7.withZone(dateTimeZone10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        int int17 = dateTimeZone10.getOffsetFromLocal((long) 31);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[1969365T160000-0800]" + "'", str3.equals("JulianChronology[1969365T160000-0800]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTimeZoneBuilder10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder10.toDateTimeZone("110", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder10.setFixedSavings("-11:00", (-2));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.Instant instant6 = org.joda.time.Instant.parse("1");
        org.joda.time.Chronology chronology7 = instant6.getChronology();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) instant6);
        int int9 = dateTime2.getDayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime2.plusWeeks(3);
        org.joda.time.DateTime dateTime13 = dateTime2.minusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        boolean boolean12 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime13 = dateTime1.withFields((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime15 = dateTime1.withMillisOfDay(30);
        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
        org.joda.time.DateTime dateTime17 = property16.getDateTime();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.ReadableInstant readableInstant2 = null;
        java.lang.String str3 = dateTimeFormatter1.print(readableInstant2);
        org.joda.time.Chronology chronology4 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("2", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "000001.439Z" + "'", str3.equals("000001.439Z"));
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        int int5 = property4.getLeapAmount();
        int int6 = property4.getLeapAmount();
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy("�, June 15, ���� �:��:�� � ");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"�, June 15, ���� �:��:�� � \" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(86400000010L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400000010L + "'", long2 == 86400000010L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumShortTextLength(locale10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        long long7 = skipDateTimeField5.roundCeiling((long) (byte) 10);
        int int9 = skipDateTimeField5.getMinimumValue(0L);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology10);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.parse("");
        boolean boolean14 = monthDay11.isBefore((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay17 = monthDay11.withPeriodAdded(readablePeriod15, 0);
        int int18 = skipDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, (int) '#');
        try {
            long long23 = skipDateTimeField5.set((-62105242022000L), (-180));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -180 for dayOfMonth must be in the range [0,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("134440.771-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean6 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("134426.828-0700");
        boolean boolean9 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.Object obj11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj11);
        org.joda.time.Instant instant14 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("1");
        boolean boolean17 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) instant16);
        org.joda.time.DateTime dateTime20 = dateTime12.withMillis(0L);
        org.joda.time.DateTime dateTime22 = dateTime20.plusWeeks(3);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), dateTimeZone25);
        org.joda.time.Chronology chronology27 = dateTime26.getChronology();
        org.joda.time.DateTime.Property property28 = dateTime26.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime31 = dateTime26.withDurationAdded(readableDuration29, (int) (byte) 1);
        int int32 = property23.getDifference((org.joda.time.ReadableInstant) dateTime26);
        boolean boolean33 = jodaTimePermission1.equals((java.lang.Object) dateTime26);
        org.joda.time.DateTime dateTime35 = dateTime26.plusWeeks(57600000);
        org.joda.time.DateTime.Property property36 = dateTime26.secondOfMinute();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay.Property property2 = monthDay1.monthOfYear();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay4 = property2.getMonthDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("70", (java.lang.Number) (-1L), (java.lang.Number) 6, (java.lang.Number) 1439);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.monthOfYear();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        try {
            long long8 = durationField5.subtract((long) 12, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292277023 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1");
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.DateTime dateTime3 = instant1.toDateTimeISO();
        org.joda.time.DateTime dateTime5 = dateTime3.withEra((int) (short) 0);
        int int6 = dateTime3.getMillisOfDay();
        long long7 = dateTime3.getMillis();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62135596800000L) + "'", long7 == (-62135596800000L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.lang.String str7 = skipDateTimeField3.getAsShortText((long) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, dateTimeFieldType8);
        int int10 = skipDateTimeField3.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField3.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, 57600);
        java.lang.String str14 = offsetDateTimeField13.getName();
        long long17 = offsetDateTimeField13.add((long) (-11), 292278993L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25252904995199989L + "'", long17 == 25252904995199989L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.year();
        java.lang.String str7 = copticChronology5.toString();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = copticChronology5.add(readablePeriod8, (long) '4', 3);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology5.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology5.getZone();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CopticChronology[1969365T160000-0800]" + "'", str7.equals("CopticChronology[1969365T160000-0800]"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
        int int15 = property14.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay17 = property14.addToCopy(2);
        java.lang.String str18 = property14.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Property[monthOfYear]" + "'", str18.equals("Property[monthOfYear]"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.withPeriodAdded(readablePeriod12, (int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime16 = property15.roundCeilingCopy();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField9.getMaximumTextLength(locale10);
        org.joda.time.DurationField durationField12 = offsetDateTimeField9.getLeapDurationField();
        long long15 = offsetDateTimeField9.add((long) (-1), (long) 57600000);
        boolean boolean16 = offsetDateTimeField9.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4976639999999999L + "'", long15 == 4976639999999999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology8);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.parse("");
        boolean boolean12 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime13 = dateTime1.withFields((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTime dateTime15 = dateTime1.withMillisOfDay(30);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, (int) (short) -1);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 30L + "'", long19 == 30L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dividedDateTimeField13.getAsShortText((long) 1439, locale18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfSecond((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime11.minusDays((-2));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.withChronology(chronology15);
        try {
            org.joda.time.DateTime dateTime18 = dateTime16.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField7);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay10, locale11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 100);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField14.getMaximumTextLength(locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField14.getAsShortText((long) 31, locale18);
        org.joda.time.Instant instant21 = org.joda.time.Instant.parse("1");
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.Instant instant23 = instant21.minus(readableDuration22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology24, dateTimeField26);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField27.getAsText((org.joda.time.ReadablePartial) monthDay29, locale30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField27, (int) (short) 100);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField33.getAsShortText((int) (short) 1, locale35);
        boolean boolean38 = offsetDateTimeField33.isLeap(100L);
        java.lang.String str40 = offsetDateTimeField33.getAsText(365L);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField33.getType();
        boolean boolean42 = instant23.isSupported(dateTimeFieldType41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType41, (int) ' ', 0, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType41, 57600000, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder4.appendTimeZoneOffset("69", false, (int) 'a', 352);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "101" + "'", str19.equals("101"));
        org.junit.Assert.assertNotNull(instant21);
        org.junit.Assert.assertNotNull(instant23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "101" + "'", str40.equals("101"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = monthDay1.isSupported(dateTimeFieldType5);
        org.joda.time.Instant instant8 = org.joda.time.Instant.parse("1");
        long long9 = instant8.getMillis();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder12.addCutover((int) (byte) -1, 'a', 100, (int) (short) 100, 100, true, (int) '4');
        boolean boolean21 = iSOChronology10.equals((java.lang.Object) dateTimeZoneBuilder20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime23 = instant8.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime24 = monthDay1.toDateTime((org.joda.time.ReadableInstant) mutableDateTime23);
        java.lang.Class<?> wildcardClass25 = mutableDateTime23.getClass();
        java.lang.String str26 = mutableDateTime23.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135596800000L) + "'", long9 == (-62135596800000L));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0001-01-01T00:00:00.000Z" + "'", str26.equals("0001-01-01T00:00:00.000Z"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) 2019);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology10);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 28378000);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01T07:52:58Z" + "'", str2.equals("1970-01-01T07:52:58Z"));
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendLiteral("UTC");
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTimeZoneOffset("Property[dayOfMonth]", true, 1, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant5 = org.joda.time.Instant.parse("1");
        boolean boolean6 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis(0L);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(12);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withDurationAdded(readableDuration16, 3);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
        int int21 = dateTime20.getMonthOfYear();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipDateTimeField3.getAsText((org.joda.time.ReadablePartial) monthDay5, locale6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField3, (int) (short) 100);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsShortText((int) (short) 1, locale11);
        boolean boolean14 = offsetDateTimeField9.isLeap(100L);
        java.lang.String str16 = offsetDateTimeField9.getAsText(365L);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfMonth();
        java.lang.String str19 = iSOChronology17.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.Class<?> wildcardClass21 = dateTimeFormatter20.getClass();
        boolean boolean22 = iSOChronology17.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology23);
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.parse("");
        boolean boolean27 = monthDay24.isBefore((org.joda.time.ReadablePartial) monthDay26);
        org.joda.time.MonthDay monthDay29 = monthDay24.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay31 = monthDay29.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology32);
        org.joda.time.MonthDay monthDay35 = monthDay33.plusMonths((int) (short) 0);
        int int36 = monthDay29.compareTo((org.joda.time.ReadablePartial) monthDay35);
        org.joda.time.MonthDay.Property property37 = monthDay35.monthOfYear();
        java.lang.String str38 = dateTimeFormatter20.print((org.joda.time.ReadablePartial) monthDay35);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay35, locale39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField9.getAsShortText(0L, locale42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "101" + "'", str16.equals("101"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "�������T������" + "'", str38.equals("�������T������"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "19" + "'", str40.equals("19"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "101" + "'", str43.equals("101"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField2);
        int int5 = skipDateTimeField3.get((long) (byte) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = skipDateTimeField3.getAsShortText((int) (short) 0, locale7);
        long long10 = skipDateTimeField3.roundHalfFloor((long) 100);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField13);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.parse("");
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay16, locale17);
        org.joda.time.MonthDay monthDay20 = monthDay16.minusMonths((int) (byte) 10);
        int[] intArray28 = new int[] { 4, (short) -1, 12, (byte) -1, 4, (byte) 1 };
        try {
            int[] intArray30 = skipDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) monthDay16, 74, intArray28, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 74");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(intArray28);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale14 = null;
        int int15 = dividedDateTimeField13.getMaximumTextLength(locale14);
        int int16 = dividedDateTimeField13.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology18, dateTimeField20, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), dateTimeZone24);
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField20, dateTimeFieldType28, 100);
        int int32 = dividedDateTimeField30.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = dividedDateTimeField30.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField13, dateTimeFieldType33);
        long long36 = remainderDateTimeField34.roundCeiling(1000L);
        org.joda.time.DurationField durationField37 = remainderDateTimeField34.getRangeDurationField();
        long long39 = remainderDateTimeField34.roundFloor((-3421439999998031L));
        long long41 = remainderDateTimeField34.roundHalfFloor((long) 2019);
        java.lang.Object obj42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(obj42);
        org.joda.time.Instant instant45 = org.joda.time.Instant.parse("1");
        org.joda.time.Instant instant47 = org.joda.time.Instant.parse("1");
        boolean boolean48 = instant45.isBefore((org.joda.time.ReadableInstant) instant47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime43, (org.joda.time.ReadableInstant) instant47);
        org.joda.time.DateTime dateTime51 = dateTime43.withMillis(0L);
        org.joda.time.DateTime dateTime53 = dateTime51.plusWeeks(3);
        org.joda.time.DateTime.Property property54 = dateTime53.yearOfCentury();
        boolean boolean55 = property54.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property54.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = dividedDateTimeField57.getAsShortText(86918400000L, locale59);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 86400000L + "'", long36 == 86400000L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-3421440000000000L) + "'", long39 == (-3421440000000000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(instant45);
        org.junit.Assert.assertNotNull(instant47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.parse("");
        boolean boolean4 = monthDay1.isBefore((org.joda.time.ReadablePartial) monthDay3);
        org.joda.time.MonthDay monthDay6 = monthDay1.withDayOfMonth((int) (byte) 10);
        org.joda.time.MonthDay monthDay8 = monthDay6.minusMonths(131);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology9);
        org.joda.time.MonthDay monthDay12 = monthDay10.plusMonths((int) (short) 0);
        int int13 = monthDay6.compareTo((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property14 = monthDay12.monthOfYear();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.joda.time.JodaTimePermission jodaTimePermission17 = new org.joda.time.JodaTimePermission("134426.828-0700");
        org.joda.time.JodaTimePermission jodaTimePermission19 = new org.joda.time.JodaTimePermission("0001-01-01T07:52:58.000Z");
        boolean boolean20 = jodaTimePermission17.implies((java.security.Permission) jodaTimePermission19);
        boolean boolean21 = property14.equals((java.lang.Object) jodaTimePermission17);
        java.lang.String str22 = property14.getAsShortText();
        int int23 = property14.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Dec" + "'", str22.equals("Dec"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology1, dateTimeField3, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), dateTimeZone7);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime.Property property10 = dateTime8.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType11, 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField13.getAsShortText((long) 'a', locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfSecond((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear((int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology23, dateTimeField25, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), dateTimeZone29);
        org.joda.time.Chronology chronology31 = dateTime30.getChronology();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField35 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType33, 100);
        int int37 = dividedDateTimeField35.getLeapAmount((long) (-1));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = dividedDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType38);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology41, dateTimeField43, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), dateTimeZone47);
        org.joda.time.Chronology chronology49 = dateTime48.getChronology();
        org.joda.time.DateTime.Property property50 = dateTime48.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType51, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder19.appendText(dateTimeFieldType51);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField13, dateTimeFieldType51);
        int int57 = zeroIsMaxDateTimeField55.getLeapAmount(0L);
        org.joda.time.DurationField durationField58 = zeroIsMaxDateTimeField55.getLeapDurationField();
        int int59 = zeroIsMaxDateTimeField55.getMaximumValue();
        long long62 = zeroIsMaxDateTimeField55.add(292278993L, (long) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 8932278993L + "'", long62 == 8932278993L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology11 = gregorianChronology9.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[1969365T160000-0800]" + "'", str3.equals("JulianChronology[1969365T160000-0800]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        long long6 = fixedDateTimeZone4.previousTransition((long) 0);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.year();
        java.lang.String str7 = copticChronology5.toString();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = copticChronology5.add(readablePeriod8, (long) '4', 3);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology5.minuteOfDay();
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CopticChronology[1969365T160000-0800]" + "'", str7.equals("CopticChronology[1969365T160000-0800]"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), dateTimeZone1);
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        int int6 = dateTime2.getEra();
        org.joda.time.DateTime.Property property7 = dateTime2.centuryOfEra();
        java.lang.String str8 = property7.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "centuryOfEra" + "'", str8.equals("centuryOfEra"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DurationField durationField2 = julianChronology0.eras();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology0, dateTimeZone5);
        long long10 = dateTimeZone5.adjustOffset((long) 0, false);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.weekOfWeekyear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[1969365T160000-0800]" + "'", str3.equals("JulianChronology[1969365T160000-0800]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T160000-0800", "", 0, (int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        long long9 = fixedDateTimeZone4.convertLocalToUTC(1L, false);
        int int11 = fixedDateTimeZone4.getStandardOffset(10L);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }
}

