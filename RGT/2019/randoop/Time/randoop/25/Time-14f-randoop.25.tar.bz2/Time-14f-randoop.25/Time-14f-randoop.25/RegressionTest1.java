import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.String str1 = buddhistChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.yearOfCentury();
//        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = copticChronology9.withZone(dateTimeZone12);
//        org.joda.time.Chronology chronology15 = gregorianChronology6.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        boolean boolean18 = jodaTimePermission4.equals((java.lang.Object) dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone19.getUncachedZone();
//        boolean boolean21 = cachedDateTimeZone19.isFixed();
//        boolean boolean22 = cachedDateTimeZone19.isFixed();
//        java.lang.Object obj23 = null;
//        boolean boolean24 = cachedDateTimeZone19.equals(obj23);
//        org.joda.time.Chronology chronology25 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone19);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[America/Los_Angeles]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        long long40 = zeroIsMaxDateTimeField35.roundCeiling(2683350662400000L);
//        long long43 = zeroIsMaxDateTimeField35.addWrapField(0L, 19);
//        long long45 = zeroIsMaxDateTimeField35.remainder(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2686474857600000L + "'", long40 == 2686474857600000L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 59958230400000L + "'", long43 == 59958230400000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property10.getAsText(locale13);
        org.joda.time.DateTime dateTime16 = property10.setCopy((int) '#');
        org.joda.time.DurationField durationField17 = property10.getDurationField();
        int int18 = property10.getLeapAmount();
        int int19 = property10.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2922790, (int) 'a', (int) (byte) -1, (int) (byte) 1, 86399, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay4.getFieldType(0);
//        org.joda.time.MonthDay.Property property23 = monthDay4.dayOfMonth();
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) monthDay4);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTime dateTime36 = dateTime34.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime38 = dateTime36.withWeekyear((int) '4');
//        org.joda.time.DateTime.Property property39 = dateTime36.hourOfDay();
//        int int40 = dateTime36.getDayOfMonth();
//        org.joda.time.DateTime dateTime42 = dateTime36.plusHours(850);
//        org.joda.time.DateTime dateTime43 = monthDay24.toDateTime((org.joda.time.ReadableInstant) dateTime36);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime10.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gregorianChronology20.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23);
        int int25 = skipUndoDateTimeField24.getMaximumValue();
        long long28 = skipUndoDateTimeField24.addWrapField((long) 10, 850);
        java.lang.String str30 = skipUndoDateTimeField24.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property32 = dateTime15.property(dateTimeFieldType31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2922790 + "'", int25 == 2922790);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2682340963200010L + "'", long28 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "20" + "'", str30.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(12, (-1907));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-22884) + "'", int2 == (-22884));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = gregorianChronology1.getDateTimeMillis(960, 0, (int) (short) 100, 2922791);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
        boolean boolean17 = dateTime16.isAfterNow();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.yearOfEra();
        org.joda.time.DateTime dateTime26 = dateTime16.toDateTime((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology22.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime12.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("��:��:��.000", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        java.lang.Number number10 = illegalFieldValueException9.getIllegalNumberValue();
        java.lang.String str11 = illegalFieldValueException9.getIllegalStringValue();
        java.lang.String str12 = illegalFieldValueException9.getIllegalValueAsString();
        java.lang.Number number13 = illegalFieldValueException9.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("0", false);
        java.lang.String str15 = dateTimeZone14.toString();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField17 = copticChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = copticChronology16.getZone();
        java.lang.String str19 = dateTimeZone18.getID();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology13);
        org.joda.time.MonthDay.Property property15 = monthDay14.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay14.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        java.lang.Number number23 = illegalFieldValueException21.getUpperBound();
        java.lang.Throwable[] throwableArray24 = illegalFieldValueException21.getSuppressed();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) -1 + "'", number23.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(7, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2007 + "'", int2 == 2007);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str6 = iSOChronology5.toString();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
//        org.joda.time.Chronology chronology9 = iSOChronology5.withZone(dateTimeZone8);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 0, 2000, 3, (int) (short) 10, (int) (short) 100, chronology9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundHalfEven(28713602L);
//        int int39 = zeroIsMaxDateTimeField35.getLeapAmount((long) 850);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 978307200000L + "'", long37 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes((int) (short) 100);
//        int int14 = dateTime13.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology18);
//        org.joda.time.MonthDay.Property property20 = monthDay19.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology31);
//        int int34 = dateTime33.getMinuteOfDay();
//        org.joda.time.DateTime dateTime35 = monthDay19.toDateTime((org.joda.time.ReadableInstant) dateTime33);
//        int int37 = monthDay19.getValue(1);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology39.getZone();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology41);
//        org.joda.time.MonthDay.Property property43 = monthDay42.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = monthDay42.getFieldType((int) (short) 1);
//        int int46 = monthDay19.get(dateTimeFieldType45);
//        int int47 = dateTime13.get(dateTimeFieldType45);
//        java.util.Locale locale49 = null;
//        try {
//            java.lang.String str50 = dateTime13.toString("DateTimeField[centuryOfEra]", locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = zonedChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology20.getZone();
        try {
            long long28 = zonedChronology20.getDateTimeMillis(2000, 6, 0, (-144000000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -144000000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("hi!", 5);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder14.setStandardOffset((-1));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder16.addRecurringSavings("ISOChronology[America/Los_Angeles]", 2, (-22884), (int) '#', '#', 0, (int) '4', (-1), true, 2922790);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0052-10-09T00:00:00.100-07:52:58");
        boolean boolean3 = instant1.isAfter((long) 5);
        org.joda.time.Instant instant4 = instant1.toInstant();
        long long5 = instant1.getMillis();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60501830821900L) + "'", long5 == (-60501830821900L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DurationField durationField2 = buddhistChronology0.years();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 284);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusMinutes(0);
        org.joda.time.DateTime dateTime16 = dateTime11.minusSeconds(86399);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 284 + "'", int12 == 284);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("org.joda.time.IllegalFieldValueException: 0: Value \"0\" for dayOfMonth is not supported", (int) 'a', 100, 2000, 'a', 780, (int) '#', 2000, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay.Property property23 = monthDay22.dayOfMonth();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsShortText(locale24);
//        org.joda.time.MonthDay monthDay27 = property23.setCopy(10);
//        org.joda.time.DurationField durationField28 = property23.getRangeDurationField();
//        org.joda.time.MonthDay monthDay29 = property23.getMonthDay();
//        int int30 = monthDay29.getMonthOfYear();
//        long long32 = gregorianChronology11.set((org.joda.time.ReadablePartial) monthDay29, 2683319212800000L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DurationField durationField38 = gregorianChronology37.seconds();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40);
//        int int43 = skipUndoDateTimeField41.getLeapAmount(28800000L);
//        long long46 = skipUndoDateTimeField41.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MonthDay.Property property60 = monthDay59.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = monthDay59.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int67 = monthDay51.get(dateTimeFieldType62);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType62);
//        java.util.Locale locale69 = null;
//        int int70 = zeroIsMaxDateTimeField68.getMaximumShortTextLength(locale69);
//        boolean boolean71 = zeroIsMaxDateTimeField68.isSupported();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = zeroIsMaxDateTimeField68.getAsText((long) '#', locale73);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField68, (int) (short) 100);
//        int int78 = zeroIsMaxDateTimeField68.getMaximumValue(0L);
//        long long80 = zeroIsMaxDateTimeField68.roundHalfEven((long) (-22884));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2683319212800000L + "'", long32 == 2683319212800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-50491123199948L) + "'", long46 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 7 + "'", int70 == 7);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "20" + "'", str74.equals("20"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2922791 + "'", int78 == 2922791);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 978307200000L + "'", long80 == 978307200000L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0010-W40-7T00:00:00.100Z", (java.lang.Number) (-60501924479999L), (java.lang.Number) 86399999, (java.lang.Number) (short) 100);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        int int24 = skipUndoDateTimeField23.getMaximumValue();
        long long27 = skipUndoDateTimeField23.addWrapField((long) 10, 850);
        java.lang.String str29 = skipUndoDateTimeField23.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField23.getType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.DurationField durationField32 = property31.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2682340963200010L + "'", long27 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("����1231T������");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(960);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime15 = dateTime13.minusYears((int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime14 = property10.withMaximumValue();
        java.lang.String str15 = property10.getAsString();
        java.lang.String str16 = property10.getAsText();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.Chronology chronology7 = copticChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(9, 960, (org.joda.time.Chronology) gJChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfMonth must not be larger than 31");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        int int14 = skipUndoDateTimeField8.getMaximumValue((long) (byte) -1);
        boolean boolean16 = skipUndoDateTimeField8.isLeap((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922790 + "'", int14 == 2922790);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone14);
//        int int18 = dateTimeZone14.getOffsetFromLocal((long) 10);
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(copticChronology19);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay4.getFieldType(0);
//        org.joda.time.MonthDay.Property property23 = monthDay4.dayOfMonth();
//        org.joda.time.MonthDay monthDay25 = property23.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        java.lang.String str37 = property36.getAsText();
//        org.joda.time.DateTimeField dateTimeField38 = property36.getField();
//        boolean boolean39 = monthDay25.equals((java.lang.Object) dateTimeField38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendMinuteOfHour(0);
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder43.appendShortText(dateTimeFieldType51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
//        org.joda.time.DurationField durationField55 = gregorianChronology54.seconds();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
//        org.joda.time.DurationField durationField58 = gregorianChronology57.seconds();
//        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology57.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology57.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology54, dateTimeField60);
//        int int62 = skipUndoDateTimeField61.getMaximumValue();
//        long long65 = skipUndoDateTimeField61.addWrapField((long) 10, 850);
//        java.lang.String str67 = skipUndoDateTimeField61.getAsText((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = skipUndoDateTimeField61.getType();
//        java.lang.Number number70 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, (java.lang.Number) (-8643599040L), number70, (java.lang.Number) 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder52.appendText(dateTimeFieldType68);
//        int int74 = monthDay25.indexOf(dateTimeFieldType68);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, "����-07-22T��:��:��");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2922790 + "'", int62 == 2922790);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2682340963200010L + "'", long65 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "20" + "'", str67.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((-19), (int) (byte) 0, chronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        int int12 = property10.getMaximumValue();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property10.getAsText(locale13);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        long long16 = property10.getDifferenceAsLong(readableInstant15);
//        org.joda.time.DateTime dateTime18 = property10.setCopy(284);
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime18.toTimeOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61827235199L) + "'", long16 == (-61827235199L));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DurationField durationField12 = property11.getRangeDurationField();
//        int int13 = property11.getMaximumValue();
//        org.joda.time.DateTime dateTime14 = property11.roundHalfFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withYear((int) (byte) 1);
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime dateTime29 = dateTime14.withMillisOfSecond(850);
//        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded((-8643599040L), 31);
//        java.lang.String str33 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12:00:00 AM UTC" + "'", str33.equals("12:00:00 AM UTC"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gregorianChronology15.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField21);
        int int24 = skipUndoDateTimeField22.getLeapAmount(28800000L);
        int int25 = dateTime13.get((org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gregorianChronology30.seconds();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33);
        int int35 = skipUndoDateTimeField34.getMaximumValue();
        long long38 = skipUndoDateTimeField34.addWrapField((long) 10, 850);
        org.joda.time.DateTimeField dateTimeField39 = skipUndoDateTimeField34.getWrappedField();
        int int41 = skipUndoDateTimeField34.get((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology45);
        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = monthDay46.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField54 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType49);
        int int55 = dateTime13.get((org.joda.time.DateTimeField) skipUndoDateTimeField34);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2922790 + "'", int35 == 2922790);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2682340963200010L + "'", long38 == 2682340963200010L);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = zonedChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology20.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.monthOfYear();
        boolean boolean30 = zonedChronology20.equals((java.lang.Object) dateTimeField29);
        org.joda.time.Chronology chronology31 = zonedChronology20.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        org.joda.time.DurationField durationField10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = gregorianChronology12.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType7, durationField10, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
//        long long14 = gJChronology3.getDateTimeMillis((int) '4', 10, (int) (byte) 10, 5, (int) '4', 0, 1);
//        long long20 = gJChronology3.getDateTimeMillis((-60501896101999L), 10, 0, (int) (short) 0, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DurationField durationField26 = gregorianChronology25.seconds();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28);
//        int int30 = skipUndoDateTimeField29.getMaximumValue();
//        long long33 = skipUndoDateTimeField29.addWrapField((long) 10, 850);
//        org.joda.time.DateTimeField dateTimeField34 = skipUndoDateTimeField29.getWrappedField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField34, 100);
//        long long39 = skipDateTimeField36.set(10L, 5);
//        int int41 = skipDateTimeField36.getMinimumValue(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60501924479999L) + "'", long14 == (-60501924479999L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-60501909599900L) + "'", long20 == (-60501909599900L));
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2922790 + "'", int30 == 2922790);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2682340963200010L + "'", long33 == 2682340963200010L);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-44179689599990L) + "'", long39 == (-44179689599990L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.Chronology chronology12 = copticChronology7.withZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) (byte) -1, (-190), 2922791, 780, 780, (int) ' ', 1, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 780 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) (byte) 0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendCenturyOfEra(59, 0);
        boolean boolean10 = dateTimeFormatterBuilder9.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        boolean boolean41 = zeroIsMaxDateTimeField35.isLeap((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
//        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology45);
//        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = monthDay46.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology58);
//        int int61 = dateTime60.getMinuteOfDay();
//        org.joda.time.DateTime dateTime62 = monthDay46.toDateTime((org.joda.time.ReadableInstant) dateTime60);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = monthDay46.getFieldType(0);
//        org.joda.time.MonthDay.Property property65 = monthDay46.dayOfMonth();
//        org.joda.time.MonthDay monthDay67 = property65.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.MonthDay monthDay69 = property65.addToCopy(2000);
//        int int70 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay69);
//        java.util.Locale locale71 = null;
//        int int72 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale71);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2922791 + "'", int70 == 2922791);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 7 + "'", int72 == 7);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(10);
//        org.joda.time.DurationField durationField10 = property5.getRangeDurationField();
//        org.joda.time.DateTimeField dateTimeField11 = property5.getField();
//        int int12 = property5.getMaximumValueOverall();
//        java.lang.String str13 = property5.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        try {
//            int int15 = property5.compareTo(readablePartial14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[dayOfMonth]" + "'", str13.equals("Property[dayOfMonth]"));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone16.getUncachedZone();
//        boolean boolean18 = cachedDateTimeZone16.isFixed();
//        boolean boolean19 = cachedDateTimeZone16.isFixed();
//        long long21 = cachedDateTimeZone16.previousTransition((long) 15);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16, 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 30");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 15L + "'", long21 == 15L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime14 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime16 = property10.setCopy(0);
        org.joda.time.Chronology chronology17 = dateTime16.getChronology();
        org.joda.time.DateTime dateTime19 = dateTime16.plusWeeks(86399);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        int int7 = property5.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
        boolean boolean17 = dateTime16.isAfterNow();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.yearOfEra();
        org.joda.time.DateTime dateTime26 = dateTime16.toDateTime((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime28 = dateTime16.withDayOfMonth(20);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property10.getAsText(locale13);
        org.joda.time.DateTime dateTime16 = property10.setCopy((int) '#');
        org.joda.time.DurationField durationField17 = property10.getDurationField();
        long long18 = property10.remainder();
        java.util.Locale locale19 = null;
        int int20 = property10.getMaximumShortTextLength(locale19);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(10);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology13);
//        org.joda.time.MonthDay.Property property15 = monthDay14.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay14.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, "0");
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology23);
//        org.joda.time.MonthDay.Property property25 = monthDay24.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = monthDay24.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        illegalFieldValueException19.addSuppressed((java.lang.Throwable) illegalFieldValueException31);
//        boolean boolean33 = property5.equals((java.lang.Object) illegalFieldValueException19);
//        org.joda.time.DurationField durationField34 = property5.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(durationField34);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        java.lang.String str11 = property10.getAsText();
//        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
//        org.joda.time.DurationField durationField13 = property10.getRangeDurationField();
//        long long16 = durationField13.subtract(10L, (long) (byte) 1);
//        long long19 = durationField13.subtract(0L, (long) 86400);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-86399990L) + "'", long16 == (-86399990L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-7464960000000L) + "'", long19 == (-7464960000000L));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        boolean boolean16 = dateTime15.isAfterNow();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime15.toMutableDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsText(15, locale10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField8.getWrappedField();
        int int13 = skipUndoDateTimeField8.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsShortText(readablePartial14, (int) (short) 1, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-144000000");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = julianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gregorianChronology15.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField21);
        int int23 = skipUndoDateTimeField22.getMaximumValue();
        long long26 = skipUndoDateTimeField22.addWrapField((long) 10, 850);
        java.lang.String str28 = skipUndoDateTimeField22.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField22.getType();
        java.lang.Number number31 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-8643599040L), number31, (java.lang.Number) 6);
        boolean boolean34 = julianChronology0.equals((java.lang.Object) dateTimeFieldType29);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2922790 + "'", int23 == 2922790);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2682340963200010L + "'", long26 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20" + "'", str28.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        boolean boolean4 = dateTimeFormatter2.isPrinter();
        java.lang.Integer int5 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfYear(6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((-8643599040L));
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTimeISO();
        int int18 = mutableDateTime17.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology12.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 850);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20);
        int int22 = skipUndoDateTimeField21.getMaximumValue();
        long long25 = skipUndoDateTimeField21.addWrapField((long) 10, 850);
        java.lang.String str27 = skipUndoDateTimeField21.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField21.getType();
        java.lang.Number number30 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (-8643599040L), number30, (java.lang.Number) 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendEraText();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = gregorianChronology40.seconds();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
        org.joda.time.DurationField durationField44 = gregorianChronology43.seconds();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology40, dateTimeField46);
        int int48 = skipUndoDateTimeField47.getMaximumValue();
        long long51 = skipUndoDateTimeField47.addWrapField((long) 10, 850);
        java.lang.String str53 = skipUndoDateTimeField47.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = skipUndoDateTimeField47.getType();
        java.lang.Number number56 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) (-8643599040L), number56, (java.lang.Number) 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder37.appendDecimal(dateTimeFieldType54, 15, 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter62 = dateTimeFormatterBuilder37.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder12.append(dateTimePrinter62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder12.appendMinuteOfHour(86399999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2922790 + "'", int22 == 2922790);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2682340963200010L + "'", long25 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2922790 + "'", int48 == 2922790);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2682340963200010L + "'", long51 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "20" + "'", str53.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimePrinter62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        long long40 = zeroIsMaxDateTimeField35.roundHalfFloor((long) (-1907));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 978307200000L + "'", long40 == 978307200000L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = zeroIsMaxDateTimeField35.getAsText(30, locale39);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30" + "'", str40.equals("30"));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfMinute((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.hourOfDay();
        org.joda.time.Chronology chronology12 = gregorianChronology8.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.MonthDay.Property property17 = monthDay16.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay16.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int24 = monthDay8.get(dateTimeFieldType19);
//        int[] intArray30 = new int[] { 1, (byte) 10, 10, (short) 100, 'a' };
//        gJChronology3.validate((org.joda.time.ReadablePartial) monthDay8, intArray30);
//        org.joda.time.DurationField durationField32 = gJChronology3.months();
//        org.joda.time.DurationField durationField33 = gJChronology3.millis();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(durationField33);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
        int int15 = skipUndoDateTimeField8.get(31L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay.Property property23 = monthDay22.dayOfMonth();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsShortText(locale24);
//        org.joda.time.MonthDay monthDay27 = property23.setCopy(10);
//        org.joda.time.DurationField durationField28 = property23.getRangeDurationField();
//        org.joda.time.MonthDay monthDay29 = property23.getMonthDay();
//        int int30 = monthDay29.getMonthOfYear();
//        long long32 = gregorianChronology11.set((org.joda.time.ReadablePartial) monthDay29, 2683319212800000L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DurationField durationField38 = gregorianChronology37.seconds();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40);
//        int int43 = skipUndoDateTimeField41.getLeapAmount(28800000L);
//        long long46 = skipUndoDateTimeField41.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MonthDay.Property property60 = monthDay59.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = monthDay59.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int67 = monthDay51.get(dateTimeFieldType62);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType62);
//        java.util.Locale locale69 = null;
//        int int70 = zeroIsMaxDateTimeField68.getMaximumShortTextLength(locale69);
//        boolean boolean71 = zeroIsMaxDateTimeField68.isSupported();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = zeroIsMaxDateTimeField68.getAsText((long) '#', locale73);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField68, (int) (short) 100);
//        int int78 = skipDateTimeField76.get((long) 9);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2683319212800000L + "'", long32 == 2683319212800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-50491123199948L) + "'", long46 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 7 + "'", int70 == 7);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "20" + "'", str74.equals("20"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 19 + "'", int78 == 19);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        try {
            org.joda.time.Instant instant19 = new org.joda.time.Instant((java.lang.Object) cachedDateTimeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal(28800001L);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = buddhistChronology0.withZone(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName(3L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("0", locale16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) -1);
        int int21 = dateTime20.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTime dateTime33 = dateTime31.withYear((int) (byte) 1);
        org.joda.time.Instant instant34 = dateTime33.toInstant();
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) instant34);
        try {
            org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) instant34, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(chronology35);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
//        boolean boolean18 = dateTime17.isBeforeNow();
//        org.joda.time.DateTime dateTime20 = dateTime17.withWeekyear(850);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.minuteOfDay();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology29.getZone();
//        long long37 = dateTimeZone33.convertLocalToUTC(0L, true, (long) (short) 1);
//        org.joda.time.DateTime dateTime38 = dateTime17.withZoneRetainFields(dateTimeZone33);
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone33);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
        int int12 = skipUndoDateTimeField8.getLeapAmount(2683319184000000L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        org.joda.time.DurationField durationField36 = zeroIsMaxDateTimeField35.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNull(durationField36);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property10.getAsText(locale13);
        org.joda.time.DateTime dateTime16 = property10.setCopy((int) '#');
        org.joda.time.DurationField durationField17 = property10.getDurationField();
        long long18 = property10.remainder();
        org.joda.time.DateTime dateTime19 = property10.roundFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
        int int17 = dateTime16.getYearOfCentury();
        org.joda.time.DateTime.Property property18 = dateTime16.millisOfDay();
        org.joda.time.DateTime dateTime20 = dateTime16.plusSeconds(2922790);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        java.lang.String str11 = skipUndoDateTimeField8.getAsText(2682340963200010L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField8.getAsText(122528379120001L, locale13);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "870" + "'", str11.equals("870"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
//        int int14 = skipUndoDateTimeField13.getMaximumValue();
//        long long17 = skipUndoDateTimeField13.addWrapField((long) 10, 850);
//        java.lang.String str19 = skipUndoDateTimeField13.getAsText((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField13.getType();
//        java.lang.Number number22 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-8643599040L), number22, (java.lang.Number) 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType20, 15, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = gregorianChronology30.seconds();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = gregorianChronology33.seconds();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField36);
//        int int39 = skipUndoDateTimeField37.getLeapAmount(28800000L);
//        long long42 = skipUndoDateTimeField37.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45);
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology46);
//        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = monthDay47.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology52.getZone();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology54);
//        org.joda.time.MonthDay.Property property56 = monthDay55.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = monthDay55.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int63 = monthDay47.get(dateTimeFieldType58);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField37, dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder28.appendDecimal(dateTimeFieldType58, 0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder28.appendMonthOfYearText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922790 + "'", int14 == 2922790);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2682340963200010L + "'", long17 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-50491123199948L) + "'", long42 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        long long16 = skipUndoDateTimeField8.addWrapField((long) 20, (int) (byte) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 20L + "'", long16 == 20L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        boolean boolean18 = dateTime17.isBeforeNow();
        org.joda.time.DateTime dateTime20 = dateTime17.withWeekyear(850);
        org.joda.time.DateTime dateTime22 = dateTime17.plusWeeks((int) (short) 1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusHours((-19));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(12, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.minuteOfDay();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology19.getZone();
        org.joda.time.DateTime dateTime24 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime dateTime26 = dateTime9.minusSeconds(2922791);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        int int12 = property10.getMaximumValue();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property10.getAsText(locale13);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        long long16 = property10.getDifferenceAsLong(readableInstant15);
//        org.joda.time.DateTime dateTime18 = property10.setCopy(284);
//        int int19 = property10.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61827235199L) + "'", long16 == (-61827235199L));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusHours(4);
//        int int23 = dateTime22.getMillisOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 14400010 + "'", int23 == 14400010);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.Chronology chronology15 = copticChronology10.withZone(dateTimeZone13);
        org.joda.time.Chronology chronology16 = gregorianChronology7.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(20, 14400010, 86399, (int) (byte) -1, 15, (int) (byte) 10, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone1.convertUTCToLocal(28800001L);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = buddhistChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
//        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
//        int int18 = property16.getMaximumValue();
//        org.joda.time.DateTime dateTime19 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = property16.withMaximumValue();
//        int int21 = property16.getMinimumValueOverall();
//        boolean boolean22 = buddhistChronology0.equals((java.lang.Object) int21);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28800001L + "'", long3 == 28800001L);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes((int) (short) 100);
        org.joda.time.DateTime.Property property14 = dateTime9.era();
        org.joda.time.LocalTime localTime15 = dateTime9.toLocalTime();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localTime15);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        boolean boolean41 = zeroIsMaxDateTimeField35.isLeap((long) 12);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
//        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology45);
//        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = monthDay46.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology58);
//        int int61 = dateTime60.getMinuteOfDay();
//        org.joda.time.DateTime dateTime62 = monthDay46.toDateTime((org.joda.time.ReadableInstant) dateTime60);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = monthDay46.getFieldType(0);
//        org.joda.time.MonthDay.Property property65 = monthDay46.dayOfMonth();
//        org.joda.time.MonthDay monthDay67 = property65.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.MonthDay monthDay69 = property65.addToCopy(2000);
//        int int70 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay69);
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = zeroIsMaxDateTimeField35.getAsText((long) 86399, locale72);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2922791 + "'", int70 == 2922791);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "20" + "'", str73.equals("20"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        try {
            long long23 = gregorianChronology13.getDateTimeMillis(1, (int) (short) 100, 10, (int) (byte) 10, (int) (byte) 1, 12, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gregorianChronology15.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField21);
        int int24 = skipUndoDateTimeField22.getLeapAmount(28800000L);
        int int25 = dateTime13.get((org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology29);
        org.joda.time.DurationField durationField31 = gJChronology29.halfdays();
        boolean boolean32 = dateTime13.equals((java.lang.Object) durationField31);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
        long long16 = skipUndoDateTimeField8.add((-8643599040L), (int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100973602800960L + "'", long16 == 100973602800960L);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 86399);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
//        java.lang.Appendable appendable4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
//        int int14 = skipUndoDateTimeField13.getMaximumValue();
//        long long17 = skipUndoDateTimeField13.addWrapField((long) 10, 850);
//        java.lang.String str19 = skipUndoDateTimeField13.getAsText((long) 100);
//        int int21 = skipUndoDateTimeField13.getMaximumValue(122528379120001L);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = property27.getAsShortText(locale28);
//        org.joda.time.MonthDay monthDay31 = property27.setCopy(10);
//        org.joda.time.DurationField durationField32 = property27.getRangeDurationField();
//        org.joda.time.MonthDay monthDay33 = property27.getMonthDay();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) monthDay33, 15, locale35);
//        try {
//            dateTimeFormatter3.printTo(appendable4, (org.joda.time.ReadablePartial) monthDay33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922790 + "'", int14 == 2922790);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2682340963200010L + "'", long17 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2922790 + "'", int21 == 2922790);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "15" + "'", str36.equals("15"));
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
//        int int13 = dateTime9.getSecondOfMinute();
//        org.joda.time.DateTime.Property property14 = dateTime9.era();
//        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.DateTime dateTime27 = dateTime25.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime29 = dateTime27.withWeekyear((int) '4');
//        java.lang.String str30 = dateTime29.toString();
//        boolean boolean31 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0052-10-09T00:00:00.100Z" + "'", str30.equals("0052-10-09T00:00:00.100Z"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withWeekOfWeekyear((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        int int18 = dateTime17.getMinuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.minus(readablePeriod19);
        org.joda.time.DateTime dateTime25 = dateTime20.withTime((int) (byte) 0, 1, (int) (short) 0, 59);
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime25.toYearMonthDay();
        org.joda.time.DateTime dateTime28 = dateTime25.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField35, dateTimeFieldType51, 960);
//        long long55 = remainderDateTimeField53.roundCeiling(0L);
//        long long57 = remainderDateTimeField53.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 978307200000L + "'", long55 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 978307200000L + "'", long57 == 978307200000L);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        org.joda.time.MonthDay monthDay11 = monthDay8.plusDays(86400);
//        java.lang.String str12 = dateTimeFormatter3.print((org.joda.time.ReadablePartial) monthDay11);
//        java.io.Writer writer13 = null;
//        try {
//            dateTimeFormatter3.printTo(writer13, (-61827235199900L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����-07-23T��:��:��" + "'", str12.equals("����-07-23T��:��:��"));
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.LocalDate localDate13 = dateTime9.toLocalDate();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
        boolean boolean17 = dateTime16.isAfterNow();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime.Property property21 = dateTime16.dayOfYear();
        try {
            org.joda.time.DateTime dateTime23 = dateTime16.withHourOfDay(30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-60501830821900L));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
//        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.Chronology chronology22 = zonedChronology20.withZone(dateTimeZone21);
//        java.lang.String str23 = zonedChronology20.toString();
//        org.joda.time.Chronology chronology24 = zonedChronology20.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str23.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(chronology24);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal(28800001L);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        try {
//            long long8 = gJChronology3.getDateTimeMillis((-190), 100, 0, 2007);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800001L + "'", long2 == 28800001L);
//        org.junit.Assert.assertNotNull(gJChronology3);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
//        long long14 = gJChronology3.getDateTimeMillis((int) '4', 10, (int) (byte) 10, 5, (int) '4', 0, 1);
//        long long20 = gJChronology3.getDateTimeMillis((-60501896101999L), 10, 0, (int) (short) 0, (int) (byte) 100);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        long long24 = gJChronology3.add(readablePeriod21, (-28800000L), 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60501924479999L) + "'", long14 == (-60501924479999L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-60501909599900L) + "'", long20 == (-60501909599900L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28800000L) + "'", long24 == (-28800000L));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime9.minuteOfHour();
        int int13 = property12.getMaximumValue();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology18);
        org.joda.time.MonthDay.Property property20 = monthDay19.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.DateTime dateTime24 = monthDay19.toDateTime(readableInstant23);
        int int25 = property12.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20);
        int int22 = skipUndoDateTimeField21.getMaximumValue();
        long long25 = skipUndoDateTimeField21.addWrapField((long) 10, 850);
        java.lang.String str27 = skipUndoDateTimeField21.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipUndoDateTimeField21.getType();
        java.lang.Number number30 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (-8643599040L), number30, (java.lang.Number) 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder37.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendSecondOfMinute((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
        org.joda.time.DurationField durationField45 = gregorianChronology44.seconds();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology47.seconds();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology44, dateTimeField50);
        int int52 = skipUndoDateTimeField51.getMaximumValue();
        long long55 = skipUndoDateTimeField51.addWrapField((long) 10, 850);
        java.lang.String str57 = skipUndoDateTimeField51.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = skipUndoDateTimeField51.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType58, 2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2922790 + "'", int22 == 2922790);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2682340963200010L + "'", long25 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20" + "'", str27.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2922790 + "'", int52 == 2922790);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2682340963200010L + "'", long55 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "20" + "'", str57.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        int int4 = gJChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Instant instant5 = gJChronology3.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.era();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundFloor((long) 6);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2177452800000L) + "'", long37 == (-2177452800000L));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        int int22 = monthDay4.getValue(1);
//        java.lang.String str23 = monthDay4.toString();
//        org.joda.time.MonthDay monthDay25 = monthDay4.plusMonths(20);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 304 + "'", int19 == 304);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 26 + "'", int22 == 26);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "--03-26" + "'", str23.equals("--03-26"));
//        org.junit.Assert.assertNotNull(monthDay25);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTimeISO();
        int int15 = dateTime14.getMinuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusWeeks(52);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 304 + "'", int19 == 304);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
//        int int13 = offsetDateTimeField12.getMinimumValue();
//        boolean boolean14 = offsetDateTimeField12.isLenient();
//        int int16 = offsetDateTimeField12.get(36000032L);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 284 + "'", int13 == 284);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 294 + "'", int16 == 294);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay.Property property23 = monthDay22.dayOfMonth();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsShortText(locale24);
//        org.joda.time.MonthDay monthDay27 = property23.setCopy(10);
//        org.joda.time.DurationField durationField28 = property23.getRangeDurationField();
//        org.joda.time.MonthDay monthDay29 = property23.getMonthDay();
//        int int30 = monthDay29.getMonthOfYear();
//        long long32 = gregorianChronology11.set((org.joda.time.ReadablePartial) monthDay29, 2683319212800000L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DurationField durationField38 = gregorianChronology37.seconds();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40);
//        int int43 = skipUndoDateTimeField41.getLeapAmount(28800000L);
//        long long46 = skipUndoDateTimeField41.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MonthDay.Property property60 = monthDay59.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = monthDay59.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int67 = monthDay51.get(dateTimeFieldType62);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType62);
//        java.util.Locale locale69 = null;
//        int int70 = zeroIsMaxDateTimeField68.getMaximumShortTextLength(locale69);
//        boolean boolean71 = zeroIsMaxDateTimeField68.isSupported();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = zeroIsMaxDateTimeField68.getAsText((long) '#', locale73);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField68, (int) (short) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = zeroIsMaxDateTimeField68.getType();
//        int int78 = zeroIsMaxDateTimeField68.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "26" + "'", str25.equals("26"));
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2683326470400000L + "'", long32 == 2683326470400000L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-50491123199948L) + "'", long46 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 26 + "'", int67 == 26);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 7 + "'", int70 == 7);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "20" + "'", str74.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2922791 + "'", int78 == 2922791);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology3);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsText(15, locale10);
        int int12 = skipUndoDateTimeField8.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2922790 + "'", int12 == 2922790);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("hi!", 5);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder14.setStandardOffset((-1));
        java.io.OutputStream outputStream18 = null;
        try {
            dateTimeZoneBuilder14.writeTo("0", outputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay2 = monthDay0.plusMonths(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology10);
//        org.joda.time.MonthDay.Property property12 = monthDay11.dayOfMonth();
//        org.joda.time.MonthDay monthDay14 = monthDay11.plusDays(86400);
//        java.lang.String str15 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) monthDay14);
//        org.joda.time.Chronology chronology16 = monthDay14.getChronology();
//        boolean boolean17 = monthDay2.isAfter((org.joda.time.ReadablePartial) monthDay14);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "����-10-15T��:��:��" + "'", str15.equals("����-10-15T��:��:��"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withYearOfCentury((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(31);
        org.joda.time.DateTime dateTime13 = dateTime9.plusYears((int) (short) 0);
        org.joda.time.DateTime.Property property14 = dateTime9.secondOfDay();
        java.lang.String str15 = property14.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime14 = property10.roundHalfFloorCopy();
        int int15 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0052-10-09T00:00:00.100-07:52:58");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        boolean boolean4 = instant3.isAfterNow();
        org.joda.time.MutableDateTime mutableDateTime5 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTime.Property property12 = dateTime9.dayOfYear();
        try {
            org.joda.time.DateTime dateTime14 = dateTime9.withWeekOfWeekyear(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0052-10-09T00:00:00.100-07:52:58");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        boolean boolean4 = instant3.isAfterNow();
        org.joda.time.Instant instant7 = instant3.withDurationAdded((-8643599040L), 0);
        org.joda.time.Instant instant9 = instant7.minus(2686474857600000L);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9);
//        int int12 = skipUndoDateTimeField10.getLeapAmount(28800000L);
//        long long15 = skipUndoDateTimeField10.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.MonthDay.Property property21 = monthDay20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay20.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology27);
//        org.joda.time.MonthDay.Property property29 = monthDay28.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = monthDay28.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int36 = monthDay20.get(dateTimeFieldType31);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType31);
//        java.util.Locale locale38 = null;
//        int int39 = zeroIsMaxDateTimeField37.getMaximumShortTextLength(locale38);
//        boolean boolean40 = zeroIsMaxDateTimeField37.isSupported();
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = zeroIsMaxDateTimeField37.getAsText((long) '#', locale42);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField37, 52);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-50491123199948L) + "'", long15 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 26 + "'", int36 == 26);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 7 + "'", int39 == 7);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "20" + "'", str43.equals("20"));
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusMinutes(0);
        org.joda.time.DateTime dateTime16 = dateTime14.withHourOfDay(4);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 284 + "'", int12 == 284);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        java.lang.String str14 = property10.getAsShortText();
        org.joda.time.DateTime dateTime15 = property10.withMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        boolean boolean38 = zeroIsMaxDateTimeField35.isSupported();
//        int int40 = zeroIsMaxDateTimeField35.getLeapAmount((long) ' ');
//        long long42 = zeroIsMaxDateTimeField35.roundCeiling((long) 2000);
//        long long45 = zeroIsMaxDateTimeField35.add((-60501896101999L), (-19));
//        boolean boolean47 = zeroIsMaxDateTimeField35.isLeap((-57346235999900L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 978307200000L + "'", long42 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-120460126501999L) + "'", long45 == (-120460126501999L));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField35, dateTimeFieldType51, 960);
//        long long55 = remainderDateTimeField53.roundCeiling(0L);
//        long long57 = remainderDateTimeField53.roundHalfEven((long) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 978307200000L + "'", long55 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 978307200000L + "'", long57 == 978307200000L);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology20.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long19 = dateTimeZone9.adjustOffset((long) 960, true);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
        boolean boolean31 = dateTimeZone9.isLocalDateTimeGap(localDateTime30);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 960L + "'", long19 == 960L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime9.toMutableDateTime((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.DurationField durationField25 = gregorianChronology20.seconds();
        long long28 = durationField25.subtract((-61827235199900L), (int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61827235234900L) + "'", long28 == (-61827235234900L));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.DateTimeField dateTimeField2 = monthDay0.getField((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
//        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
//        java.util.Locale locale16 = null;
//        org.joda.time.DateTime dateTime17 = property13.setCopy("0", locale16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) -1);
//        boolean boolean21 = dateTime20.isBeforeNow();
//        org.joda.time.DateTime dateTime23 = dateTime20.withWeekyear(850);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.minuteOfDay();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology32.getZone();
//        long long40 = dateTimeZone36.convertLocalToUTC(0L, true, (long) (short) 1);
//        org.joda.time.DateTime dateTime41 = dateTime20.withZoneRetainFields(dateTimeZone36);
//        org.joda.time.DateTime dateTime43 = dateTime41.withYear(780);
//        org.joda.time.DateTime dateTime44 = monthDay0.toDateTime((org.joda.time.ReadableInstant) dateTime41);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((int) (short) 10);
        try {
            org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.parse("ISOChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Pacific Standard Time", (java.lang.Number) 100.0d, (java.lang.Number) (short) 0, (java.lang.Number) 10L);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
//        long long14 = gJChronology3.getDateTimeMillis((int) '4', 10, (int) (byte) 10, 5, (int) '4', 0, 1);
//        long long20 = gJChronology3.getDateTimeMillis((-60501896101999L), 10, 0, (int) (short) 0, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DurationField durationField26 = gregorianChronology25.seconds();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28);
//        int int30 = skipUndoDateTimeField29.getMaximumValue();
//        long long33 = skipUndoDateTimeField29.addWrapField((long) 10, 850);
//        org.joda.time.DateTimeField dateTimeField34 = skipUndoDateTimeField29.getWrappedField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField34, 100);
//        int int38 = skipDateTimeField36.get(34712668886400L);
//        int int40 = skipDateTimeField36.get(960L);
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        java.util.Locale locale42 = null;
//        try {
//            java.lang.String str43 = skipDateTimeField36.getAsShortText(readablePartial41, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60501924479999L) + "'", long14 == (-60501924479999L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-60501909599900L) + "'", long20 == (-60501909599900L));
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2922790 + "'", int30 == 2922790);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2682340963200010L + "'", long33 == 2682340963200010L);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 30 + "'", int38 == 30);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        int int4 = gJChronology3.getMinimumDaysInFirstWeek();
        int int5 = gJChronology3.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
//        java.lang.String str6 = copticChronology0.toString();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundHalfEven(28713602L);
//        java.lang.String str39 = zeroIsMaxDateTimeField35.getAsShortText(0L);
//        int int40 = zeroIsMaxDateTimeField35.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 978307200000L + "'", long37 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "20" + "'", str39.equals("20"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = property10.addWrapFieldToCopy(12);
        java.lang.Object obj16 = null;
        boolean boolean17 = property10.equals(obj16);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfYear();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
//        int int14 = skipUndoDateTimeField13.getMaximumValue();
//        long long17 = skipUndoDateTimeField13.addWrapField((long) 10, 850);
//        java.lang.String str19 = skipUndoDateTimeField13.getAsText((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField13.getType();
//        java.lang.Number number22 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-8643599040L), number22, (java.lang.Number) 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType20, 15, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = gregorianChronology30.seconds();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = gregorianChronology33.seconds();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField36);
//        int int39 = skipUndoDateTimeField37.getLeapAmount(28800000L);
//        long long42 = skipUndoDateTimeField37.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45);
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology46);
//        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = monthDay47.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology52.getZone();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology54);
//        org.joda.time.MonthDay.Property property56 = monthDay55.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = monthDay55.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int63 = monthDay47.get(dateTimeFieldType58);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField37, dateTimeFieldType58);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder28.appendDecimal(dateTimeFieldType58, 0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder28.appendDayOfYear(780);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2922790 + "'", int14 == 2922790);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2682340963200010L + "'", long17 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20" + "'", str19.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-50491123199948L) + "'", long42 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 26 + "'", int63 == 26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.LocalDate localDate6 = monthDay4.toLocalDate((int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.hourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime14.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        int int8 = property5.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "26" + "'", str7.equals("26"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        java.lang.String str12 = dateTime9.toString(dateTimeFormatter11);
//        org.joda.time.DateTime.Property property13 = dateTime9.dayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0010-W40-7T00:00:00.100Z" + "'", str12.equals("0010-W40-7T00:00:00.100Z"));
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        try {
//            long long38 = zeroIsMaxDateTimeField35.set(960L, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,2922791]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
//        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        int int21 = property19.getMaximumValue();
//        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTime dateTime34 = dateTime32.withYear((int) (byte) 1);
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gJChronology7, (java.lang.Object) dateTime34);
//        org.joda.time.DurationField durationField37 = gJChronology7.weekyears();
//        org.joda.time.Chronology chronology38 = gJChronology7.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = gregorianChronology40.seconds();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
//        org.joda.time.DurationField durationField44 = gregorianChronology43.seconds();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology43.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology40, dateTimeField46);
//        int int49 = skipUndoDateTimeField47.getLeapAmount(28800000L);
//        long long52 = skipUndoDateTimeField47.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone53);
//        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology54.getZone();
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55);
//        org.joda.time.MonthDay monthDay57 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology56);
//        org.joda.time.MonthDay.Property property58 = monthDay57.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = monthDay57.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61);
//        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology62.getZone();
//        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone63);
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology64);
//        org.joda.time.MonthDay.Property property66 = monthDay65.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = monthDay65.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int73 = monthDay57.get(dateTimeFieldType68);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField74 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField47, dateTimeFieldType68);
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone75);
//        org.joda.time.DateTimeZone dateTimeZone77 = gregorianChronology76.getZone();
//        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone77);
//        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology78);
//        int int80 = zeroIsMaxDateTimeField74.getMaximumValue((org.joda.time.ReadablePartial) monthDay79);
//        long long83 = zeroIsMaxDateTimeField74.getDifferenceAsLong((long) 2922790, (long) (byte) 0);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField85 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField74, 3);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86399 + "'", int21 == 86399);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-50491123199948L) + "'", long52 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(gJChronology64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 26 + "'", int73 == 26);
//        org.junit.Assert.assertNotNull(gregorianChronology76);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(gJChronology78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2922791 + "'", int80 == 2922791);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.joda.time.Chronology chronology4 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfHalfday(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = zonedChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology20.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.monthOfYear();
        boolean boolean30 = zonedChronology20.equals((java.lang.Object) dateTimeField29);
        long long34 = zonedChronology20.add((-60501924479999L), 6333480288000031L, 307);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1944317946491529518L + "'", long34 == 1944317946491529518L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.weekyear();
        try {
            long long12 = gJChronology3.getDateTimeMillis(86399, (int) (short) -1, (-22884), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
        long long16 = skipUndoDateTimeField8.set((long) 86400, 31);
        long long19 = skipUndoDateTimeField8.add((long) 3, 20);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34712668886400L + "'", long16 == 34712668886400L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 63113904000003L + "'", long19 == 63113904000003L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        boolean boolean14 = offsetDateTimeField12.isLeap((long) 5);
        long long16 = offsetDateTimeField12.roundHalfEven((long) (-28800000));
        long long18 = offsetDateTimeField12.roundFloor((-1L));
        boolean boolean20 = offsetDateTimeField12.isLeap(0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28800000L) + "'", long16 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfCeiling((long) 2000);
//        long long42 = zeroIsMaxDateTimeField35.addWrapField((long) (byte) 100, 0);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45);
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology46);
//        int[] intArray54 = new int[] { (byte) 100, 20, (short) -1, (-144000000), (-144000000), 59 };
//        int int55 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay47, intArray54);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2922791 + "'", int55 == 2922791);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-22884), (-46357113600000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-46357113622884L) + "'", long2 == (-46357113622884L));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        int int8 = property5.getMinimumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property5.getFieldType();
//        int int10 = property5.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "26" + "'", str7.equals("26"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundHalfEven(28713602L);
//        int int38 = zeroIsMaxDateTimeField35.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 978307200000L + "'", long37 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2922791 + "'", int38 == 2922791);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay4.getFieldType(0);
//        org.joda.time.MonthDay.Property property23 = monthDay4.dayOfMonth();
//        org.joda.time.MonthDay monthDay25 = property23.addWrapFieldToCopy((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.DateTime.Property property36 = dateTime35.secondOfDay();
//        org.joda.time.DurationField durationField37 = property36.getRangeDurationField();
//        java.util.Locale locale39 = null;
//        org.joda.time.DateTime dateTime40 = property36.setCopy("0", locale39);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime43 = dateTime40.withPeriodAdded(readablePeriod41, (int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology52);
//        org.joda.time.LocalDateTime localDateTime54 = dateTime53.toLocalDateTime();
//        org.joda.time.DateTime dateTime55 = dateTime40.withFields((org.joda.time.ReadablePartial) localDateTime54);
//        try {
//            boolean boolean56 = monthDay25.isBefore((org.joda.time.ReadablePartial) localDateTime54);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 305 + "'", int19 == 305);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(localDateTime54);
//        org.junit.Assert.assertNotNull(dateTime55);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime13.withMillisOfSecond(850);
        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((-8643599040L), 31);
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
        int int33 = dateTime31.getDayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 103 + "'", int33 == 103);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDateTime28);
        org.joda.time.DateTime dateTime31 = dateTime14.minusSeconds(5);
        org.joda.time.DateTime dateTime33 = dateTime14.minus((long) 20);
        java.util.Date date34 = dateTime14.toDate();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        int int21 = property19.getMaximumValue();
        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.DateTime dateTime34 = dateTime32.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime34);
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gJChronology7, (java.lang.Object) dateTime34);
        org.joda.time.DurationField durationField37 = gJChronology7.weekyears();
        org.joda.time.Chronology chronology38 = gJChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone39 = gJChronology7.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86399 + "'", int21 == 86399);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology39);
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay40);
//        long long44 = zeroIsMaxDateTimeField35.getDifferenceAsLong((long) 2922790, (long) (byte) 0);
//        java.lang.String str46 = zeroIsMaxDateTimeField35.getAsText((-44179689599990L));
//        long long48 = zeroIsMaxDateTimeField35.roundHalfFloor(960L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "6" + "'", str46.equals("6"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 978307200000L + "'", long48 == 978307200000L);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-365T15:59:55-08:00");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-365T15:59:55-08:00" + "'", str2.equals("1969-365T15:59:55-08:00"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsText(15, locale10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField8.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = monthDay7.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology19);
//        int int22 = dateTime21.getMinuteOfDay();
//        org.joda.time.DateTime dateTime23 = monthDay7.toDateTime((org.joda.time.ReadableInstant) dateTime21);
//        int int25 = monthDay7.getValue(1);
//        int int26 = monthDay7.getMonthOfYear();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) monthDay7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 305 + "'", int22 == 305);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 26 + "'", int25 == 26);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("31");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        java.lang.String str14 = skipUndoDateTimeField8.toString();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay16, 0, locale18);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = monthDay16.getFieldTypes();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str14.equals("DateTimeField[centuryOfEra]"));
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendHourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        long long46 = zeroIsMaxDateTimeField35.addWrapField((-50491123199948L), 284);
//        int int48 = zeroIsMaxDateTimeField35.get((-60501896101999L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 26 + "'", int34 == 26);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 845726313600052L + "'", long46 == 845726313600052L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        int int12 = property10.getMaximumValue();
//        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay.Property property23 = monthDay22.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = monthDay22.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
//        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology29);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = monthDay30.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int38 = monthDay22.get(dateTimeFieldType33);
//        int int39 = dateTime17.get(dateTimeFieldType33);
//        boolean boolean40 = dateTime15.isSupported(dateTimeFieldType33);
//        org.joda.time.DateTime.Property property41 = dateTime15.millisOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 26 + "'", int38 == 26);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 31 + "'", int39 == 31);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(property41);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology5);
//        org.joda.time.MonthDay.Property property7 = monthDay6.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = monthDay6.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology18);
//        int int21 = dateTime20.getMinuteOfDay();
//        org.joda.time.DateTime dateTime22 = monthDay6.toDateTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = monthDay6.getFieldType(0);
//        org.joda.time.MonthDay monthDay26 = monthDay6.minusDays((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.DateTime dateTime38 = dateTime36.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime40 = dateTime36.minusMinutes((int) (short) 100);
//        int int41 = dateTime40.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology43.getZone();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
//        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology45);
//        org.joda.time.DateTime dateTime47 = dateTime40.withFields((org.joda.time.ReadablePartial) monthDay46);
//        org.joda.time.DateTime dateTime48 = monthDay26.toDateTime((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.MonthDay monthDay50 = monthDay26.minusMonths((int) (short) -1);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 305 + "'", int21 == 305);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(monthDay50);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 14400010);
        try {
            long long4 = dateTimeFormatter2.parseMillis("20");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
        long long13 = skipUndoDateTimeField8.getDifferenceAsLong((-1L), 0L);
        int int15 = skipUndoDateTimeField8.getLeapAmount((-941L));
        int int17 = skipUndoDateTimeField8.getLeapAmount((-8643599040L));
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField8.getAsShortText((long) 14400010, locale19);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20" + "'", str20.equals("20"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.weekyearOfCentury();
        org.joda.time.DurationField durationField14 = gregorianChronology8.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDateTime28);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTime.Property property40 = dateTime39.secondOfDay();
        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
        int int42 = property40.getMaximumValue();
        org.joda.time.DateTime dateTime43 = property40.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone51 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime43, (org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime dateTime57 = dateTime14.withChronology(chronology56);
        org.joda.time.DateTimeField dateTimeField58 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField(chronology56, dateTimeField58, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 86399 + "'", int42 == 86399);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTime57);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendSecondOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("����1231T������");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendMonthOfYear(59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        long long14 = durationField11.subtract((-11L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-11L) + "'", long14 == (-11L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
        int int15 = skipUndoDateTimeField8.get((long) ' ');
        int int17 = skipUndoDateTimeField8.get((-1L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) -1);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.addToCopy((-44179689599990L));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        boolean boolean18 = dateTime17.isBeforeNow();
        org.joda.time.DateTime dateTime20 = dateTime17.plus((long) (short) 1);
        org.joda.time.DateTime.Property property21 = dateTime20.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        long long40 = zeroIsMaxDateTimeField35.roundCeiling(2683350662400000L);
//        long long43 = zeroIsMaxDateTimeField35.add(31L, 2007);
//        int int44 = zeroIsMaxDateTimeField35.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2686474857600000L + "'", long40 == 2686474857600000L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 6333480288000031L + "'", long43 == 6333480288000031L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes((int) (short) 100);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime.Property property15 = dateTime9.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfMinute((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        java.lang.String str14 = skipUndoDateTimeField8.toString();
//        int int16 = skipUndoDateTimeField8.get((-61827235199900L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str14.equals("DateTimeField[centuryOfEra]"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay10.getFieldType((int) (short) 1);
        int int14 = property5.compareTo((org.joda.time.ReadablePartial) monthDay10);
        int int15 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 30 + "'", int15 == 30);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        int int13 = offsetDateTimeField12.getMinimumValue();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeField dateTimeField16 = monthDay14.getField((int) (short) 0);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) monthDay14, (-1), locale18);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 284 + "'", int13 == 284);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1" + "'", str19.equals("-1"));
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
//        java.lang.String str15 = property14.getAsText();
//        int int16 = property14.get();
//        boolean boolean17 = copticChronology0.equals((java.lang.Object) property14);
//        long long22 = copticChronology0.getDateTimeMillis((int) '4', 1, 1, 0);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-51574752000000L) + "'", long22 == (-51574752000000L));
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DurationField durationField6 = property5.getDurationField();
//        java.lang.String str7 = property5.getAsString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = copticChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = gregorianChronology1.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
//        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay.Property property23 = monthDay22.dayOfMonth();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsShortText(locale24);
//        org.joda.time.MonthDay monthDay27 = property23.setCopy(10);
//        org.joda.time.DurationField durationField28 = property23.getRangeDurationField();
//        org.joda.time.MonthDay monthDay29 = property23.getMonthDay();
//        int int30 = monthDay29.getMonthOfYear();
//        long long32 = gregorianChronology11.set((org.joda.time.ReadablePartial) monthDay29, 2683319212800000L);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DurationField durationField38 = gregorianChronology37.seconds();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40);
//        int int43 = skipUndoDateTimeField41.getLeapAmount(28800000L);
//        long long46 = skipUndoDateTimeField41.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology58);
//        org.joda.time.MonthDay.Property property60 = monthDay59.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = monthDay59.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int67 = monthDay51.get(dateTimeFieldType62);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField41, dateTimeFieldType62);
//        java.util.Locale locale69 = null;
//        int int70 = zeroIsMaxDateTimeField68.getMaximumShortTextLength(locale69);
//        boolean boolean71 = zeroIsMaxDateTimeField68.isSupported();
//        java.util.Locale locale73 = null;
//        java.lang.String str74 = zeroIsMaxDateTimeField68.getAsText((long) '#', locale73);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField68, (int) (short) 100);
//        int int78 = zeroIsMaxDateTimeField68.getMaximumValue(0L);
//        long long80 = zeroIsMaxDateTimeField68.roundHalfCeiling((long) 304);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "15" + "'", str25.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2683333468800000L + "'", long32 == 2683333468800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-50491123199948L) + "'", long46 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 15 + "'", int67 == 15);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 7 + "'", int70 == 7);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "20" + "'", str74.equals("20"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2922791 + "'", int78 == 2922791);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 978307200000L + "'", long80 == 978307200000L);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
//        boolean boolean17 = dateTime16.isAfterNow();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.yearOfEra();
//        org.joda.time.DateTime dateTime26 = dateTime16.toDateTime((org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime dateTime28 = dateTime26.minusMillis(284);
//        int int29 = dateTime26.getDayOfWeek();
//        org.joda.time.DateTime.Property property30 = dateTime26.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
//        org.joda.time.DurationField durationField33 = gregorianChronology32.seconds();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
//        org.joda.time.Chronology chronology40 = copticChronology35.withZone(dateTimeZone38);
//        org.joda.time.Chronology chronology41 = gregorianChronology32.withZone(dateTimeZone38);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
//        long long46 = dateTimeZone38.convertLocalToUTC(1L, true, (long) '#');
//        java.lang.String str47 = dateTimeZone38.toString();
//        long long50 = dateTimeZone38.convertLocalToUTC((long) (byte) 100, true);
//        org.joda.time.DateTime dateTime51 = dateTime26.toDateTime(dateTimeZone38);
//        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay(dateTimeZone38);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1L + "'", long46 == 1L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UTC" + "'", str47.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
//        org.junit.Assert.assertNotNull(dateTime51);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendSecondOfDay(59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendPattern("--03-26");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(10);
//        org.joda.time.DurationField durationField10 = property5.getRangeDurationField();
//        org.joda.time.DateTimeField dateTimeField11 = property5.getField();
//        int int12 = property5.getMaximumValueOverall();
//        java.lang.String str13 = property5.toString();
//        org.joda.time.MonthDay monthDay15 = property5.addWrapFieldToCopy((int) ' ');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Property[dayOfMonth]" + "'", str13.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(monthDay15);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.DateTime dateTime15 = property10.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendSecondOfMinute((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay10.getFieldType((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder1.appendShortText(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int9 = skipUndoDateTimeField8.getMaximumValue();
//        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
//        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 100);
//        long long16 = skipUndoDateTimeField8.roundHalfFloor(2682340963200010L);
//        java.lang.String str17 = skipUndoDateTimeField8.getName();
//        long long19 = skipUndoDateTimeField8.roundHalfEven((-11L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2683319184000000L + "'", long16 == 2683319184000000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "centuryOfEra" + "'", str17.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 978307200000L + "'", long19 == 978307200000L);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22);
        int int24 = skipUndoDateTimeField23.getMaximumValue();
        long long27 = skipUndoDateTimeField23.addWrapField((long) 10, 850);
        java.lang.String str29 = skipUndoDateTimeField23.getAsText((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField23.getType();
        org.joda.time.DateTime.Property property31 = dateTime14.property(dateTimeFieldType30);
        org.joda.time.DateTime dateTime34 = dateTime14.withDurationAdded((long) 59, 31);
        org.joda.time.DateTime dateTime36 = dateTime34.plusHours(31);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2682340963200010L + "'", long27 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20" + "'", str29.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (long) 80400, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gJChronology16);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        try {
            org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) copticChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        long long18 = cachedDateTimeZone16.previousTransition((-60501881221900L));
//        int int20 = cachedDateTimeZone16.getStandardOffset((long) 86399);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60501881221900L) + "'", long18 == (-60501881221900L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone16.getUncachedZone();
//        boolean boolean18 = cachedDateTimeZone16.isFixed();
//        int int20 = cachedDateTimeZone16.getStandardOffset(68400001L);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0L, (java.lang.Number) 2683319212800000L, (java.lang.Number) 2683319212800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        long long40 = zeroIsMaxDateTimeField35.roundCeiling(2683350662400000L);
//        int int43 = zeroIsMaxDateTimeField35.getDifference((long) (short) 0, (long) (-190));
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = zeroIsMaxDateTimeField35.getAsText((long) 14400010, locale45);
//        int int48 = zeroIsMaxDateTimeField35.getMaximumValue((-1L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2686474857600000L + "'", long40 == 2686474857600000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20" + "'", str46.equals("20"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2922791 + "'", int48 == 2922791);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatterBuilder13.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime13.withMillisOfSecond(850);
        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((-8643599040L), 31);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.minus(readableDuration32);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        org.joda.time.DateTime dateTime29 = dateTime14.withFields((org.joda.time.ReadablePartial) localDateTime28);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.plus(readableDuration30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.withZoneRetainFields(dateTimeZone32);
        org.joda.time.DateTime.Property property34 = dateTime29.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        org.joda.time.DurationField durationField13 = offsetDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Instant instant17 = gJChronology16.getGregorianCutover();
        org.joda.time.Instant instant18 = gJChronology16.getGregorianCutover();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(instant17);
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DurationField durationField25 = property24.getRangeDurationField();
        int int26 = property24.getMaximumValue();
        org.joda.time.DateTime dateTime27 = property24.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime27, (org.joda.time.ReadableInstant) dateTime39);
        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gJChronology12, (java.lang.Object) dateTime39);
        org.joda.time.DurationField durationField42 = gJChronology12.weekyears();
        org.joda.time.Chronology chronology43 = gJChronology12.withUTC();
        try {
            org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(5, (-1907), (int) 'a', 59, 103, chronology43);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(chronology43);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 15, 15, 0, 284, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 284 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeFormatter5);
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(locale7);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundHalfEven(28713602L);
//        int int38 = zeroIsMaxDateTimeField35.getMinimumValue();
//        boolean boolean39 = zeroIsMaxDateTimeField35.isLenient();
//        int int41 = zeroIsMaxDateTimeField35.getLeapAmount(28800001L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 978307200000L + "'", long37 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime9.minusSeconds(86399);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
//        int int17 = dateTime16.getYearOfCentury();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("hi!");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendLiteral("0");
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.MonthDay.Property property32 = monthDay31.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = monthDay31.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology43);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology43);
//        int int46 = dateTime45.getMinuteOfDay();
//        org.joda.time.DateTime dateTime47 = monthDay31.toDateTime((org.joda.time.ReadableInstant) dateTime45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = monthDay31.getFieldType(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType49, (int) (byte) 100);
//        int int52 = dateTime16.get(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1272 + "'", int46 == 1272);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getName((long) (byte) 100, locale5);
//        boolean boolean8 = dateTimeZone2.isStandardOffset((long) (byte) 0);
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(monthDay9);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        boolean boolean38 = zeroIsMaxDateTimeField35.isSupported();
//        int int40 = zeroIsMaxDateTimeField35.getLeapAmount((long) ' ');
//        long long42 = zeroIsMaxDateTimeField35.roundCeiling((long) 2000);
//        long long45 = zeroIsMaxDateTimeField35.add((-60501896101999L), (-19));
//        long long47 = zeroIsMaxDateTimeField35.roundCeiling((-941L));
//        int int50 = zeroIsMaxDateTimeField35.getDifference((-60501830821900L), (long) 30);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 978307200000L + "'", long42 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-120460126501999L) + "'", long45 == (-120460126501999L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 978307200000L + "'", long47 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-19) + "'", int50 == (-19));
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusDays((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(100);
        boolean boolean17 = dateTime16.isAfterNow();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.withDurationAdded(readableDuration18, (int) (short) 100);
        org.joda.time.DateTime dateTime22 = dateTime20.plusYears(2);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        int int27 = dateTime25.getSecondOfDay();
        org.joda.time.DateTime dateTime29 = dateTime25.minusWeeks(780);
        int int30 = dateTime25.getYearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(307, (int) (short) 0, (int) (short) 1, 2007);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 307 + "'", int4 == 307);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset((-1));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int9 = skipUndoDateTimeField8.getMaximumValue();
//        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
//        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 100);
//        int int16 = skipUndoDateTimeField8.getMaximumValue(122528379120001L);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.MonthDay.Property property22 = monthDay21.dayOfMonth();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsShortText(locale23);
//        org.joda.time.MonthDay monthDay26 = property22.setCopy(10);
//        org.joda.time.DurationField durationField27 = property22.getRangeDurationField();
//        org.joda.time.MonthDay monthDay28 = property22.getMonthDay();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay28, 15, locale30);
//        int int32 = monthDay28.size();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2922790 + "'", int16 == 2922790);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "15" + "'", str24.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "15" + "'", str31.equals("15"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("0", locale13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (byte) -1);
        int int18 = dateTime17.getMinuteOfHour();
        org.joda.time.DateTime dateTime20 = dateTime17.withDayOfMonth(1);
        org.joda.time.DateTime dateTime22 = dateTime20.withMillis((-60501924479999L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = copticChronology0.add(readablePeriod2, (long) (short) 100, 307);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        org.joda.time.DurationField durationField39 = zeroIsMaxDateTimeField35.getDurationField();
//        long long41 = zeroIsMaxDateTimeField35.roundHalfCeiling((-51574752000000L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-52668576000000L) + "'", long41 == (-52668576000000L));
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        org.joda.time.MonthDay monthDay9 = property5.setCopy(10);
//        org.joda.time.MonthDay.Property property10 = monthDay9.monthOfYear();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "15" + "'", str7.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone8);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTimeZoneBuilder24.toDateTimeZone("0", false);
        org.joda.time.Chronology chronology28 = julianChronology0.withZone(dateTimeZone27);
        java.lang.String str29 = julianChronology0.toString();
        int int30 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone16.getUncachedZone();
//        boolean boolean18 = cachedDateTimeZone16.isFixed();
//        boolean boolean19 = cachedDateTimeZone16.isFixed();
//        int int21 = cachedDateTimeZone16.getStandardOffset((long) 'a');
//        org.joda.time.Instant instant23 = new org.joda.time.Instant((long) 15);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16, (org.joda.time.ReadableInstant) instant23);
//        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone16.getUncachedZone();
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime13.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField35, dateTimeFieldType51, 960);
//        int int54 = remainderDateTimeField53.getMinimumValue();
//        org.joda.time.DurationField durationField55 = remainderDateTimeField53.getRangeDurationField();
//        int int56 = remainderDateTimeField53.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText((long) 2000, locale14);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField8.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20" + "'", str15.equals("20"));
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        long long15 = offsetDateTimeField12.add((long) 1, 19);
        long long17 = offsetDateTimeField12.roundHalfEven((long) 86399999);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 68400001L + "'", long15 == 68400001L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400000L + "'", long17 == 86400000L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        long long15 = offsetDateTimeField12.add((long) 1, 19);
        java.lang.Object obj16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj16, chronology17);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = dateTimeZoneBuilder19.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeZoneBuilder30.toDateTimeZone("0", false);
        org.joda.time.DateTime dateTime34 = dateTime18.toDateTime(dateTimeZone33);
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
        java.util.Locale locale36 = null;
        try {
            java.lang.String str37 = offsetDateTimeField12.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 68400001L + "'", long15 == 68400001L);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(yearMonthDay35);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = monthDay10.getFieldType((int) (short) 1);
//        int int14 = property5.compareTo((org.joda.time.ReadablePartial) monthDay10);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property5.getAsText(locale15);
//        org.joda.time.MonthDay monthDay18 = property5.addToCopy(0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "15" + "'", str16.equals("15"));
//        org.junit.Assert.assertNotNull(monthDay18);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.Chronology chronology13 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gregorianChronology5.withZone(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        boolean boolean17 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Chronology chronology22 = zonedChronology20.withZone(dateTimeZone21);
        org.joda.time.Chronology chronology23 = zonedChronology20.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-144000000));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology13 = julianChronology1.withZone(dateTimeZone9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("0", false);
        org.joda.time.Chronology chronology29 = julianChronology1.withZone(dateTimeZone28);
        java.lang.String str30 = julianChronology1.toString();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((-8643599040L), (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "JulianChronology[UTC]" + "'", str30.equals("JulianChronology[UTC]"));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int9 = skipUndoDateTimeField8.getMaximumValue();
//        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
//        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 100);
//        long long16 = skipUndoDateTimeField8.roundHalfFloor(2682340963200010L);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime dateTime28 = dateTime26.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime30 = dateTime26.minusMinutes((int) (short) 100);
//        org.joda.time.LocalDateTime localDateTime31 = dateTime26.toLocalDateTime();
//        int[] intArray35 = new int[] { 6, '#', (-144000000) };
//        int int36 = skipUndoDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) localDateTime31, intArray35);
//        org.joda.time.DurationField durationField37 = skipUndoDateTimeField8.getRangeDurationField();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipUndoDateTimeField8.getAsText((int) (short) 10, locale39);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2683319184000000L + "'", long16 == 2683319184000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        long long37 = zeroIsMaxDateTimeField35.roundHalfEven(28713602L);
//        java.lang.String str39 = zeroIsMaxDateTimeField35.getAsShortText(0L);
//        int int40 = zeroIsMaxDateTimeField35.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
//        org.joda.time.DateTimeZone dateTimeZone43 = gregorianChronology42.getZone();
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43);
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology44);
//        org.joda.time.MonthDay.Property property46 = monthDay45.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology50);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType((int) (short) 1);
//        int int55 = property46.compareTo((org.joda.time.ReadablePartial) monthDay51);
//        boolean boolean57 = monthDay51.equals((java.lang.Object) 2922790);
//        int int58 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay51);
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone59);
//        org.joda.time.DurationField durationField61 = gregorianChronology60.seconds();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DurationField durationField64 = gregorianChronology63.seconds();
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology63.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology60, dateTimeField66);
//        int int68 = skipUndoDateTimeField67.getMaximumValue();
//        long long71 = skipUndoDateTimeField67.addWrapField((long) 10, 850);
//        java.lang.String str73 = skipUndoDateTimeField67.getAsText((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = skipUndoDateTimeField67.getType();
//        try {
//            org.joda.time.MonthDay monthDay76 = monthDay51.withField(dateTimeFieldType74, 30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 14 + "'", int34 == 14);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 978307200000L + "'", long37 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "20" + "'", str39.equals("20"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2922791 + "'", int40 == 2922791);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922791 + "'", int58 == 2922791);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2922790 + "'", int68 == 2922790);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 2682340963200010L + "'", long71 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "20" + "'", str73.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusYears(86400);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        org.joda.time.DurationField durationField36 = zeroIsMaxDateTimeField35.getLeapDurationField();
//        long long38 = zeroIsMaxDateTimeField35.roundHalfFloor((long) 0);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology40.getZone();
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology42);
//        org.joda.time.MonthDay.Property property44 = monthDay43.dayOfMonth();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = property44.getAsShortText(locale45);
//        org.joda.time.MonthDay monthDay48 = property44.setCopy(10);
//        org.joda.time.DurationField durationField49 = property44.getRangeDurationField();
//        org.joda.time.MonthDay monthDay50 = property44.getMonthDay();
//        int int51 = monthDay50.getMonthOfYear();
//        int int52 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) monthDay50);
//        java.lang.Object obj53 = null;
//        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) zeroIsMaxDateTimeField35, obj53);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 14 + "'", int34 == 14);
//        org.junit.Assert.assertNull(durationField36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 978307200000L + "'", long38 == 978307200000L);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "14" + "'", str46.equals("14"));
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2922791 + "'", int52 == 2922791);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property10.getAsText(locale13);
        org.joda.time.DateTime dateTime15 = property10.withMaximumValue();
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = skipUndoDateTimeField8.getAsText(15, locale10);
//        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField8.getWrappedField();
//        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
//        java.lang.String str14 = skipUndoDateTimeField8.getName();
//        long long16 = skipUndoDateTimeField8.roundHalfEven((long) 850);
//        try {
//            long long19 = skipUndoDateTimeField8.set((long) 2000, (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922790]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "centuryOfEra" + "'", str14.equals("centuryOfEra"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 978307200000L + "'", long16 == 978307200000L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.Interval interval12 = property11.toInterval();
        boolean boolean13 = property11.isLeap();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(interval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = julianChronology0.withUTC();
        org.joda.time.Chronology chronology14 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean6 = gregorianChronology1.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DurationField durationField18 = property17.getRangeDurationField();
        java.util.Locale locale20 = null;
        org.joda.time.DateTime dateTime21 = property17.setCopy("0", locale20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.withPeriodAdded(readablePeriod22, (int) (byte) -1);
        int int25 = dateTime24.getMinuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.minus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime41 = dateTime37.minusMinutes((int) (short) 100);
        org.joda.time.LocalDateTime localDateTime42 = dateTime37.toLocalDateTime();
        org.joda.time.DateTime dateTime43 = dateTime27.withFields((org.joda.time.ReadablePartial) localDateTime42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
        org.joda.time.DurationField durationField46 = gregorianChronology45.seconds();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
        org.joda.time.Chronology chronology53 = copticChronology48.withZone(dateTimeZone51);
        org.joda.time.Chronology chronology54 = gregorianChronology45.withZone(dateTimeZone51);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone51);
        org.joda.time.chrono.LimitChronology limitChronology56 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.ReadableDateTime) dateTime43, (org.joda.time.ReadableDateTime) dateTime55);
        org.joda.time.DateTime dateTime57 = limitChronology56.getUpperLimit();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(limitChronology56);
        org.junit.Assert.assertNotNull(dateTime57);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendMinuteOfHour(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendEraText();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DurationField durationField21 = gregorianChronology20.seconds();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DurationField durationField24 = gregorianChronology23.seconds();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26);
//        int int28 = skipUndoDateTimeField27.getMaximumValue();
//        long long31 = skipUndoDateTimeField27.addWrapField((long) 10, 850);
//        java.lang.String str33 = skipUndoDateTimeField27.getAsText((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipUndoDateTimeField27.getType();
//        java.lang.Number number36 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) (-8643599040L), number36, (java.lang.Number) 6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType34, 15, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.DurationField durationField45 = gregorianChronology44.seconds();
//        org.joda.time.DateTimeZone dateTimeZone46 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone46);
//        org.joda.time.DurationField durationField48 = gregorianChronology47.seconds();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology44, dateTimeField50);
//        int int53 = skipUndoDateTimeField51.getLeapAmount(28800000L);
//        long long56 = skipUndoDateTimeField51.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone57);
//        org.joda.time.DateTimeZone dateTimeZone59 = gregorianChronology58.getZone();
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone59);
//        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology60);
//        org.joda.time.MonthDay.Property property62 = monthDay61.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = monthDay61.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone65 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone65);
//        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology66.getZone();
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone67);
//        org.joda.time.MonthDay monthDay69 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology68);
//        org.joda.time.MonthDay.Property property70 = monthDay69.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = monthDay69.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType72, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int77 = monthDay61.get(dateTimeFieldType72);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField78 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, dateTimeFieldType72);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder42.appendDecimal(dateTimeFieldType72, 0, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType72, 294);
//        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.getDefault();
//        long long86 = dateTimeZone84.convertUTCToLocal(28800001L);
//        org.joda.time.chrono.GJChronology gJChronology87 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone84);
//        try {
//            org.joda.time.DateTime dateTime88 = new org.joda.time.DateTime((java.lang.Object) 294, dateTimeZone84);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2922790 + "'", int28 == 2922790);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2682340963200010L + "'", long31 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20" + "'", str33.equals("20"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-50491123199948L) + "'", long56 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 14 + "'", int77 == 14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertNotNull(dateTimeZone84);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 28800001L + "'", long86 == 28800001L);
//        org.junit.Assert.assertNotNull(gJChronology87);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        java.lang.String str11 = property10.getAsText();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField35, dateTimeFieldType51, 960);
//        int int54 = remainderDateTimeField53.getMinimumValue();
//        org.joda.time.DurationField durationField55 = remainderDateTimeField53.getRangeDurationField();
//        long long57 = remainderDateTimeField53.roundCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 14 + "'", int34 == 14);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 978307200000L + "'", long57 == 978307200000L);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsShortText(locale6);
//        int int8 = property5.getMinimumValue();
//        java.lang.String str9 = property5.getAsString();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property5.getAsShortText(locale10);
//        int int12 = property5.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "14" + "'", str7.equals("14"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14" + "'", str9.equals("14"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "14" + "'", str11.equals("14"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int9 = skipUndoDateTimeField8.getMaximumValue();
//        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
//        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 100);
//        long long17 = skipUndoDateTimeField8.getDifferenceAsLong((long) 30, (long) 850);
//        long long19 = skipUndoDateTimeField8.roundHalfFloor((long) 2);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 978307200000L + "'", long19 == 978307200000L);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime13.withMillisOfSecond(850);
        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded((-8643599040L), 31);
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime28.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"15\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTimeZoneOffset("1969-365T16:00:00.850-08:00", false, (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int9 = skipUndoDateTimeField8.getMaximumValue();
//        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
//        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField8.getWrappedField();
//        int int15 = skipUndoDateTimeField8.get((long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.MonthDay.Property property21 = monthDay20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay20.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType23);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = gregorianChronology30.seconds();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = gregorianChronology33.seconds();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField36);
//        int int39 = skipUndoDateTimeField37.getLeapAmount(28800000L);
//        long long42 = skipUndoDateTimeField37.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45);
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology46);
//        org.joda.time.MonthDay.Property property48 = monthDay47.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = monthDay47.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology52.getZone();
//        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology54);
//        org.joda.time.MonthDay.Property property56 = monthDay55.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = monthDay55.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int63 = monthDay47.get(dateTimeFieldType58);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField37, dateTimeFieldType58);
//        java.util.Locale locale65 = null;
//        int int66 = zeroIsMaxDateTimeField64.getMaximumShortTextLength(locale65);
//        org.joda.time.DurationField durationField67 = zeroIsMaxDateTimeField64.getDurationField();
//        org.joda.time.DurationField durationField68 = zeroIsMaxDateTimeField64.getDurationField();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder69 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder80 = dateTimeZoneBuilder69.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone83 = dateTimeZoneBuilder80.toDateTimeZone("0", false);
//        java.lang.String str84 = dateTimeZone83.toString();
//        org.joda.time.chrono.CopticChronology copticChronology85 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone83);
//        org.joda.time.DurationField durationField86 = copticChronology85.seconds();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField87 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField68, durationField86);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-50491123199948L) + "'", long42 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(gJChronology54);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 14 + "'", int63 == 14);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 7 + "'", int66 == 7);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder80);
//        org.junit.Assert.assertNotNull(dateTimeZone83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "0" + "'", str84.equals("0"));
//        org.junit.Assert.assertNotNull(copticChronology85);
//        org.junit.Assert.assertNotNull(durationField86);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(86400, 6, 3, (int) (short) 100, 307, (int) '#', 294, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.centuryOfEra();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfWeek(4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
//        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
//        int int12 = property10.getMaximumValue();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property10.getAsText(locale13);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        long long16 = property10.getDifferenceAsLong(readableInstant15);
//        int int17 = property10.get();
//        int int18 = property10.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-63387724335L) + "'", long16 == (-63387724335L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = julianChronology0.withUTC();
        java.lang.String str14 = julianChronology0.toString();
        org.joda.time.DurationField durationField15 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JulianChronology[UTC]" + "'", str14.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        long long39 = zeroIsMaxDateTimeField35.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = zeroIsMaxDateTimeField35.getMaximumValue(readablePartial40);
//        int int43 = zeroIsMaxDateTimeField35.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone44);
//        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology47);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = monthDay48.getFieldType((int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField35, dateTimeFieldType51, 960);
//        int int54 = remainderDateTimeField53.getMinimumValue();
//        org.joda.time.DurationField durationField55 = remainderDateTimeField53.getRangeDurationField();
//        int int56 = remainderDateTimeField53.getDivisor();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 14 + "'", int34 == 14);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 978307200000L + "'", long39 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922791 + "'", int41 == 2922791);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 960 + "'", int56 == 960);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readablePeriod11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded((long) 284, 0);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear((int) '4');
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumShortTextLength(locale15);
        org.joda.time.DurationField durationField17 = property14.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
//        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
//        long long18 = cachedDateTimeZone16.previousTransition((-60501881221900L));
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        long long21 = cachedDateTimeZone16.nextTransition((long) 4);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-60501881221900L) + "'", long18 == (-60501881221900L));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 4L + "'", long21 == 4L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        java.lang.String str10 = illegalFieldValueException9.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray11 = illegalFieldValueException9.getSuppressed();
        java.lang.Number number12 = illegalFieldValueException9.getUpperBound();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.Chronology chronology5 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = gJChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        int int21 = property19.getMaximumValue();
        org.joda.time.DateTime dateTime22 = property19.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.DateTime dateTime34 = dateTime32.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime34);
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gJChronology7, (java.lang.Object) dateTime34);
        org.joda.time.DurationField durationField37 = gJChronology7.weekyears();
        org.joda.time.DurationField durationField38 = gJChronology7.minutes();
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((java.lang.Object) durationField38, (org.joda.time.Chronology) buddhistChronology39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.field.PreciseDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86399 + "'", int21 == 86399);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(buddhistChronology39);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
        boolean boolean14 = offsetDateTimeField12.isLeap((long) 5);
        int int15 = offsetDateTimeField12.getMaximumValue();
        long long17 = offsetDateTimeField12.roundCeiling((-3600000L));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 307 + "'", int15 == 307);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3600000L) + "'", long17 == (-3600000L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.Chronology chronology10 = copticChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gregorianChronology2.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology13 = julianChronology0.withUTC();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("0052-10-09T00:00:00.100-07:52:58", 86399, 15, (int) (short) 0, 'a', 0, 850, (int) (short) -1, true, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("0", false);
        java.lang.String str29 = dateTimeZone28.toString();
        org.joda.time.Chronology chronology30 = julianChronology0.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        java.lang.Number number10 = illegalFieldValueException9.getIllegalNumberValue();
        java.lang.String str11 = illegalFieldValueException9.getIllegalStringValue();
        java.lang.String str12 = illegalFieldValueException9.getIllegalValueAsString();
        java.lang.Number number13 = illegalFieldValueException9.getUpperBound();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNull(number13);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology17);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int34 = monthDay18.get(dateTimeFieldType29);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType29);
//        java.util.Locale locale36 = null;
//        int int37 = zeroIsMaxDateTimeField35.getMaximumShortTextLength(locale36);
//        org.joda.time.DurationField durationField38 = zeroIsMaxDateTimeField35.getDurationField();
//        long long40 = zeroIsMaxDateTimeField35.roundCeiling(2683350662400000L);
//        int int43 = zeroIsMaxDateTimeField35.getDifference((long) (short) 0, (long) (-190));
//        long long45 = zeroIsMaxDateTimeField35.roundHalfFloor((long) 2007);
//        try {
//            long long48 = zeroIsMaxDateTimeField35.set((long) 'a', "12:00:00 AM UTC");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"12:00:00 AM UTC\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 14 + "'", int34 == 14);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2686474857600000L + "'", long40 == 2686474857600000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 978307200000L + "'", long45 == 978307200000L);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal(28800001L);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        java.lang.String str5 = dateTimeZone0.getName((-63387724335L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800001L + "'", long2 == 28800001L);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("31");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.Chronology chronology2 = copticChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
//        java.lang.String str4 = copticChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology0.getZone();
//        int int7 = copticChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15);
//        int int18 = skipUndoDateTimeField16.getLeapAmount(28800000L);
//        long long21 = skipUndoDateTimeField16.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology25);
//        org.joda.time.MonthDay.Property property27 = monthDay26.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = monthDay26.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology33);
//        org.joda.time.MonthDay.Property property35 = monthDay34.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = monthDay34.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int42 = monthDay26.get(dateTimeFieldType37);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType37);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField43, (int) (byte) 1);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50491123199948L) + "'", long21 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 14 + "'", int42 == 14);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "0010-10-10T00:00:00.100-07:52:58", "1969-365T16:00:00.850-08:00");
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "CopticChronology[America/Los_Angeles]", "0010-W40-7T00:00:00.100-07:52:58");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        java.lang.String str11 = skipUndoDateTimeField8.getAsText((long) 960);
        java.util.Locale locale14 = null;
        try {
            long long15 = skipUndoDateTimeField8.set((long) (byte) 100, "12:00:00 AM UTC", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"12:00:00 AM UTC\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int9 = skipUndoDateTimeField8.getMaximumValue();
        long long12 = skipUndoDateTimeField8.addWrapField((long) 10, 850);
        java.lang.String str14 = skipUndoDateTimeField8.getAsText((long) 100);
        boolean boolean15 = skipUndoDateTimeField8.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2922790 + "'", int9 == 2922790);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2682340963200010L + "'", long12 == 2682340963200010L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "20" + "'", str14.equals("20"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 284);
//        boolean boolean14 = offsetDateTimeField12.isLeap((long) 5);
//        long long17 = offsetDateTimeField12.addWrapField((long) ' ', 850);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = monthDay20.getFieldTypes();
//        int[] intArray22 = monthDay20.getValues();
//        try {
//            int[] intArray24 = offsetDateTimeField12.addWrapPartial(readablePartial18, 19, intArray22, 294);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 36000032L + "'", long17 == 36000032L);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
        long long13 = skipUndoDateTimeField8.getDifferenceAsLong((-1L), 0L);
        int int15 = skipUndoDateTimeField8.getLeapAmount((-941L));
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(durationField16);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology4.seconds();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getLeapAmount(28800000L);
//        long long13 = skipUndoDateTimeField8.set((long) '4', 4);
//        java.lang.String str14 = skipUndoDateTimeField8.toString();
//        java.lang.String str16 = skipUndoDateTimeField8.getAsShortText(0L);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.centuryOfEra();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25);
//        int int28 = skipUndoDateTimeField26.getLeapAmount(28800000L);
//        long long31 = skipUndoDateTimeField26.set((long) '4', 4);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34);
//        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology35);
//        org.joda.time.MonthDay.Property property37 = monthDay36.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay36.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology41.getZone();
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42);
//        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology43);
//        org.joda.time.MonthDay.Property property45 = monthDay44.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = monthDay44.getFieldType((int) (short) 1);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
//        int int52 = monthDay36.get(dateTimeFieldType47);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField26, dateTimeFieldType47);
//        java.util.Locale locale54 = null;
//        int int55 = zeroIsMaxDateTimeField53.getMaximumShortTextLength(locale54);
//        long long57 = zeroIsMaxDateTimeField53.roundHalfEven((long) 4);
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        int int59 = zeroIsMaxDateTimeField53.getMaximumValue(readablePartial58);
//        int int61 = zeroIsMaxDateTimeField53.getLeapAmount((long) (-28800000));
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone64 = gregorianChronology63.getZone();
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone64);
//        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology65);
//        org.joda.time.MonthDay.Property property67 = monthDay66.dayOfMonth();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = property67.getAsShortText(locale68);
//        org.joda.time.MonthDay monthDay71 = property67.setCopy(10);
//        org.joda.time.DurationField durationField72 = property67.getRangeDurationField();
//        org.joda.time.MonthDay monthDay73 = property67.getMonthDay();
//        org.joda.time.ReadableInstant readableInstant74 = null;
//        org.joda.time.DateTime dateTime75 = monthDay73.toDateTime(readableInstant74);
//        int[] intArray80 = new int[] { 86400, (byte) 10, 100, (short) -1 };
//        int int81 = zeroIsMaxDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay73, intArray80);
//        int int82 = skipUndoDateTimeField8.getMaximumValue(readablePartial17, intArray80);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-50491123199948L) + "'", long13 == (-50491123199948L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str14.equals("DateTimeField[centuryOfEra]"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "20" + "'", str16.equals("20"));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-50491123199948L) + "'", long31 == (-50491123199948L));
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 14 + "'", int52 == 14);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 7 + "'", int55 == 7);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 978307200000L + "'", long57 == 978307200000L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2922791 + "'", int59 == 2922791);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "14" + "'", str69.equals("14"));
//        org.junit.Assert.assertNotNull(monthDay71);
//        org.junit.Assert.assertNotNull(durationField72);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2922790 + "'", int82 == 2922790);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0052-10-09T00:00:00.100-07:52:58");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant5 = instant1.withMillis((long) 12);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology16);
//        int int19 = dateTime18.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.MonthDay.Property property21 = monthDay4.dayOfMonth();
//        org.joda.time.MonthDay monthDay23 = property21.addToCopy(0);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTime.Property property34 = dateTime33.secondOfDay();
//        org.joda.time.DurationField durationField35 = property34.getRangeDurationField();
//        java.util.Locale locale37 = null;
//        org.joda.time.DateTime dateTime38 = property34.setCopy("0", locale37);
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime41 = dateTime38.withPeriodAdded(readablePeriod39, (int) (byte) -1);
//        int int42 = dateTime41.getMinuteOfHour();
//        org.joda.time.DateTime dateTime44 = dateTime41.withDayOfMonth(1);
//        boolean boolean45 = property21.equals((java.lang.Object) dateTime41);
//        org.joda.time.MutableDateTime mutableDateTime46 = dateTime41.toMutableDateTimeISO();
//        boolean boolean48 = mutableDateTime46.isBefore((long) 7);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 312 + "'", int19 == 312);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime.Property property11 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime12 = property11.withMinimumValue();
        java.lang.String str13 = property11.getName();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "secondOfDay" + "'", str13.equals("secondOfDay"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes((int) (short) 100);
        int int14 = dateTime13.getDayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology18);
        org.joda.time.DateTime dateTime20 = dateTime13.withFields((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DurationField durationField32 = property31.getRangeDurationField();
        int int33 = property31.getMaximumValue();
        java.util.Locale locale34 = null;
        java.lang.String str35 = property31.getAsText(locale34);
        org.joda.time.DateTime dateTime37 = property31.setCopy((int) '#');
        org.joda.time.DurationField durationField38 = property31.getDurationField();
        int int39 = property31.getLeapAmount();
        java.lang.String str40 = property31.getAsString();
        org.joda.time.DateTimeField dateTimeField41 = property31.getField();
        int int42 = dateTime20.get(dateTimeField41);
        org.joda.time.DateTime.Property property43 = dateTime20.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 86399 + "'", int33 == 86399);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 80400 + "'", int42 == 80400);
        org.junit.Assert.assertNotNull(property43);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "0");
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology13);
        org.joda.time.MonthDay.Property property15 = monthDay14.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay14.getFieldType((int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 10, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1);
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        org.joda.time.DurationFieldType durationFieldType23 = illegalFieldValueException21.getDurationFieldType();
        java.lang.Number number24 = illegalFieldValueException21.getUpperBound();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) -1 + "'", number24.equals((byte) -1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, (int) (short) 10, 0, 0, (int) (byte) 0, (int) (byte) 100, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear((int) (byte) 1);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime25);
        int int27 = dateTime25.getSecondOfDay();
        org.joda.time.DateTime dateTime28 = dateTime25.toDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.Chronology chronology11 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
    }
}

