import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.Period period8 = new org.joda.time.Period((-210417480000L), 1L, periodType3, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DurationField durationField9 = iSOChronology6.hours();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        try {
            long long15 = offsetDateTimeField7.set(1560629460000L, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Period period17 = period15.withWeeks(5200);
        java.lang.String str18 = period17.toString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P5200WT5.201S" + "'", str18.equals("P5200WT5.201S"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology12);
        org.joda.time.Period period15 = period13.plusMillis(0);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = periodType16.indexOf(durationFieldType17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType16, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology25 = gregorianChronology23.withZone(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology23.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.Chronology chronology30 = gregorianChronology23.withZone(dateTimeZone28);
        boolean boolean31 = periodType16.equals((java.lang.Object) gregorianChronology23);
        org.joda.time.PeriodType periodType32 = periodType16.withYearsRemoved();
        try {
            org.joda.time.Period period33 = new org.joda.time.Period((int) (byte) 10, 30, (int) ' ', 0, 100, 0, (int) (short) -1, 0, periodType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        org.joda.time.DurationField durationField81 = dividedDateTimeField77.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertNotNull(durationField81);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        java.lang.String str9 = iSOChronology8.toString();
//        org.joda.time.DurationField durationField10 = iSOChronology8.days();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone12.getShortName(1L, locale15);
//        long long18 = dateTimeZone12.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology19 = iSOChronology2.withZone(dateTimeZone12);
//        java.lang.String str21 = dateTimeZone12.getName(5300L);
//        org.joda.time.PeriodType periodType23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(0L, periodType23);
//        org.joda.time.PeriodType periodType25 = null;
//        org.joda.time.Period period26 = period24.normalizedStandard(periodType25);
//        org.joda.time.DurationFieldType durationFieldType27 = null;
//        boolean boolean28 = period26.isSupported(durationFieldType27);
//        org.joda.time.DurationFieldType[] durationFieldTypeArray29 = period26.getFieldTypes();
//        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.forFields(durationFieldTypeArray29);
//        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str21, (java.lang.Object) durationFieldTypeArray29);
//        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.forFields(durationFieldTypeArray29);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(durationFieldTypeArray29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(periodType32);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period3.minusMonths(0);
        org.joda.time.Seconds seconds26 = period3.toStandardSeconds();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(seconds26);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = periodType6.indexOf(durationFieldType7);
        int int9 = periodType6.size();
        org.joda.time.PeriodType periodType10 = periodType6.withMonthsRemoved();
        org.joda.time.PeriodType periodType11 = periodType6.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = iSOChronology18.toString();
        boolean boolean21 = iSOChronology18.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField22 = iSOChronology18.millis();
        long long25 = durationField22.subtract((long) '#', (int) (short) 1);
        boolean boolean26 = gregorianChronology15.equals((java.lang.Object) durationField22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology32 = gregorianChronology15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone31);
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType6, (java.lang.Object) cachedDateTimeZone33);
        long long36 = cachedDateTimeZone33.convertUTCToLocal((long) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone37 = cachedDateTimeZone33.getUncachedZone();
        int int39 = cachedDateTimeZone33.getOffset((-34380000L));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 34L + "'", long25 == 34L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 31L + "'", long36 == 31L);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 32 + "'", int39 == 32);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DurationField durationField5 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Period period9 = period7.plusHours(10);
        org.joda.time.MutablePeriod mutablePeriod10 = period7.toMutablePeriod();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(mutablePeriod10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.days();
        long long37 = zonedChronology22.getDateTimeMillis(0L, 1, 32, 32, 7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 5551975L + "'", long37 == 5551975L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str6 = fixedDateTimeZone4.getName(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) 100);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) ' ');
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.032" + "'", str6.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.centuryOfEra();
        org.joda.time.Period period15 = new org.joda.time.Period(8, (int) '#', (int) (byte) 1, (int) ' ');
        int[] intArray17 = iSOChronology2.get((org.joda.time.ReadablePeriod) period15, (long) (byte) 100);
        org.joda.time.Period period19 = period15.withWeeks(10);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.Period period23 = period15.plusYears((-1));
        org.joda.time.Period period25 = period23.withMonths((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.getName();
        long long36 = preciseDurationField29.getMillis(36, (long) 36);
        int int39 = preciseDurationField29.getDifference((-48379510912250L), (long) ' ');
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "years" + "'", str33.equals("years"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-56182658391000L) + "'", long36 == (-56182658391000L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 30 + "'", int39 == 30);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.Period period4 = new org.joda.time.Period(10, 0, 1, (int) '4');
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', periodType13, chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = null;
        int int31 = periodType29.indexOf(durationFieldType30);
        int int32 = periodType29.size();
        org.joda.time.PeriodType periodType33 = periodType29.withMonthsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType29);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.years();
        org.joda.time.Period period37 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant35, periodType36);
        org.joda.time.format.PeriodFormatter periodFormatter38 = null;
        java.lang.String str39 = period37.toString(periodFormatter38);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "P0Y" + "'", str39.equals("P0Y"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 31L, (java.lang.Number) 1.0f, (java.lang.Number) (-210417480000000L));
        java.lang.Throwable[] throwableArray33 = illegalFieldValueException32.getSuppressed();
        illegalFieldValueException32.prependMessage("Seconds");
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        long long61 = decoratedDurationField58.add((-5199999L), 10);
        java.lang.String str62 = decoratedDurationField58.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-5189999L) + "'", long61 == (-5189999L));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "years" + "'", str62.equals("years"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "minuteOfHour");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        long long8 = fixedDateTimeZone4.nextTransition(5200L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        try {
            org.joda.time.DurationFieldType durationFieldType3 = period1.getFieldType(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology6);
        org.joda.time.Period period9 = period7.plusMillis(0);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        java.lang.String str14 = iSOChronology13.toString();
        org.joda.time.DurationField durationField15 = iSOChronology13.days();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.hourOfDay();
        org.joda.time.Chronology chronology17 = iSOChronology13.withUTC();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 100, 0L, periodType10, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType10);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(periodType20);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period8.withDays(1);
        org.joda.time.Period period13 = period8.negated();
        org.joda.time.Period period15 = period8.withHours(38);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.days();
        boolean boolean33 = zonedChronology22.equals((java.lang.Object) (-48379511392250L));
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology22.secondOfDay();
        try {
            long long42 = zonedChronology22.getDateTimeMillis(35, (int) (byte) 1, 159, 4, (int) (short) 10, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 159 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        boolean boolean7 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType27, 0L);
        long long34 = preciseDurationField31.getMillis((-60476390024L), (long) 'a');
        try {
            long long37 = preciseDurationField31.getDifferenceAsLong((long) 0, (-151381051775718L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler7 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file8 = null;
        java.io.File[] fileArray9 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = zoneInfoCompiler7.compile(file8, fileArray9);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = zoneInfoCompiler5.compile(file6, fileArray9);
        java.io.File file12 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler13 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file14 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler15 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file16 = null;
        java.io.File[] fileArray17 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = zoneInfoCompiler15.compile(file16, fileArray17);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = zoneInfoCompiler13.compile(file14, fileArray17);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap20 = zoneInfoCompiler5.compile(file12, fileArray17);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = zoneInfoCompiler0.compile(file4, fileArray17);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(fileArray17);
        org.junit.Assert.assertNotNull(strMap18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(strMap20);
        org.junit.Assert.assertNotNull(strMap21);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        long long44 = offsetDateTimeField7.roundHalfEven((long) 203);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        boolean boolean29 = unsupportedDurationField28.isPrecise();
        try {
            long long31 = unsupportedDurationField28.getMillis((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Hours hours16 = period15.toStandardHours();
        org.joda.time.Period period17 = period15.toPeriod();
        org.joda.time.Period period19 = period17.multipliedBy(0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology22);
        org.joda.time.Period period25 = period23.plusMillis(0);
        org.joda.time.PeriodType periodType26 = period25.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType27 = null;
        int int28 = periodType26.indexOf(durationFieldType27);
        int int29 = periodType26.size();
        org.joda.time.PeriodType periodType30 = periodType26.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType30.withMonthsRemoved();
        org.joda.time.Period period32 = period17.withPeriodType(periodType30);
        org.joda.time.PeriodType periodType33 = periodType30.withHoursRemoved();
        org.joda.time.PeriodType periodType34 = periodType33.withHoursRemoved();
        java.lang.String str35 = periodType33.getName();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(hours16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "StandardNoMonthsNoHours" + "'", str35.equals("StandardNoMonthsNoHours"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) dateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.RemainderDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add((long) (short) 0, 1560629399750L, (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.minuteOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1560629399750L) + "'", long4 == (-1560629399750L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        long long90 = remainderDateTimeField88.roundHalfFloor(5200000L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField88, (-34), 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -34 for minuteOfHour must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 5220000L + "'", long90 == 5220000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DurationField durationField9 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DurationField durationField16 = iSOChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) 100);
        int int21 = offsetDateTimeField19.get(0L);
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField19.getAsText(readablePartial22, 10, locale24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField19.getAsShortText(3, locale27);
        org.joda.time.DurationField durationField29 = offsetDateTimeField19.getLeapDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField19.getAsText(0, locale31);
        long long35 = offsetDateTimeField19.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 3505788410L, (java.lang.Number) 1L, (java.lang.Number) 1560629399782L);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType36, 201);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "3" + "'", str28.equals("3"));
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3505788410L + "'", long35 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.Period period14 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period16 = period14.minusWeeks(0);
        boolean boolean17 = period5.equals((java.lang.Object) period14);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology20);
        org.joda.time.Period period23 = period21.plusMillis(0);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.Period period25 = period5.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period27 = period23.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType29 = period23.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (-1560629399750L));
        org.joda.time.Period period33 = period1.withFieldAdded(durationFieldType29, 3);
        org.joda.time.Period period35 = period1.plusWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.PeriodType periodType14 = periodType12.withSecondsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        long long90 = remainderDateTimeField88.roundCeiling(3218570035200000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 3218570035200000L + "'", long90 == 3218570035200000L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str6 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission1.newPermissionCollection();
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) "7");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[UTC]", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.setFixedSavings("P-1W", (int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset(97);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.joda.time.Period period4 = period1.withWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.Period period1 = org.joda.time.Period.years(30);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DurationField durationField5 = iSOChronology3.days();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.hourOfDay();
        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
        org.joda.time.Chronology chronology8 = iSOChronology3.withUTC();
        org.joda.time.DurationField durationField9 = iSOChronology3.seconds();
        org.joda.time.Period period11 = new org.joda.time.Period((-61895577599900L));
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.get(durationFieldType12);
        org.joda.time.Period period14 = period11.normalizedStandard();
        long long17 = iSOChronology3.add((org.joda.time.ReadablePeriod) period14, 34L, (-52));
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology3.year();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology3.weekyearOfCentury();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((-1631169848614680000L), (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -2697040093");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3218570035194834L + "'", long17 == 3218570035194834L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int23 = fixedDateTimeZone19.getStandardOffset((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-3594800L), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35948000L) + "'", long2 == (-35948000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        int int34 = offsetDateTimeField7.get((-61895577599899L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (long) (short) 0, periodType8, chronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 10L, periodType5, chronology16);
        int int19 = period18.getWeeks();
        int int20 = period18.getDays();
        org.joda.time.Period period21 = period2.withFields((org.joda.time.ReadablePeriod) period18);
        try {
            org.joda.time.Period period23 = period18.withYears((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(1);
        org.joda.time.Period period3 = period1.minusMinutes(100);
        org.joda.time.Seconds seconds4 = period3.toStandardSeconds();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', periodType6, chronology7);
        org.joda.time.Period period17 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period19 = period17.minusWeeks(0);
        boolean boolean20 = period8.equals((java.lang.Object) period17);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology23);
        org.joda.time.Period period26 = period24.plusMillis(0);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.Period period28 = period8.plus((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period30 = period26.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType32 = period26.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField34 = new org.joda.time.field.PreciseDurationField(durationFieldType32, (-1560629399750L));
        org.joda.time.Period period36 = period3.withField(durationFieldType32, 201);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.Period period40 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology39);
        org.joda.time.Period period42 = period40.plusMillis(0);
        org.joda.time.PeriodType periodType43 = period42.getPeriodType();
        org.joda.time.PeriodType periodType45 = null;
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period((long) '#', periodType45, chronology46);
        org.joda.time.Period period56 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period58 = period56.minusWeeks(0);
        boolean boolean59 = period47.equals((java.lang.Object) period56);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology62);
        org.joda.time.Period period65 = period63.plusMillis(0);
        org.joda.time.PeriodType periodType66 = period65.getPeriodType();
        org.joda.time.Period period67 = period47.plus((org.joda.time.ReadablePeriod) period65);
        org.joda.time.Period period69 = period65.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType71 = period65.getFieldType((int) (short) 0);
        boolean boolean72 = periodType43.isSupported(durationFieldType71);
        org.joda.time.Period period74 = period36.withField(durationFieldType71, 32);
        org.joda.time.Period period76 = period36.minusMillis(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(seconds4);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(periodType66);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period76);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology17 = gregorianChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology15.withZone(dateTimeZone20);
        boolean boolean23 = periodType8.equals((java.lang.Object) gregorianChronology15);
        org.joda.time.PeriodType periodType24 = periodType8.withHoursRemoved();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        int int5 = period2.getWeeks();
        org.joda.time.Period period7 = period2.withWeeks(8);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationFrom(readableInstant8);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone13 = dateTimeZone6.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        boolean boolean16 = cachedDateTimeZone15.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone15.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int89 = remainderDateTimeField88.getMinimumValue();
        long long91 = remainderDateTimeField88.roundHalfEven(201L);
        int int92 = remainderDateTimeField88.getMinimumValue();
        int int93 = remainderDateTimeField88.getDivisor();
        long long95 = remainderDateTimeField88.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 30 + "'", int93 == 30);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 0L + "'", long95 == 0L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 197);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 197");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        boolean boolean59 = decoratedDurationField58.isPrecise();
        org.joda.time.DurationField durationField60 = decoratedDurationField58.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(durationField60);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str16 = iSOChronology15.toString();
        boolean boolean18 = iSOChronology15.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField19 = iSOChronology15.millis();
        long long22 = durationField19.subtract((long) '#', (int) (short) 1);
        boolean boolean23 = gregorianChronology12.equals((java.lang.Object) durationField19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str30 = fixedDateTimeZone28.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone28);
        java.lang.Object obj32 = null;
        boolean boolean33 = fixedDateTimeZone28.equals(obj32);
        org.joda.time.Chronology chronology34 = iSOChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[UTC]" + "'", str16.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 34L + "'", long22 == 34L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.032" + "'", str30.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long16 = offsetDateTimeField7.getDifferenceAsLong((long) 201, (long) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsText(3, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsText(1, locale21);
        long long25 = offsetDateTimeField7.add(0L, (int) '#');
        org.joda.time.DurationField durationField26 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2100000L + "'", long25 == 2100000L);
        org.junit.Assert.assertNull(durationField26);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 10, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField7.getAsShortText(3, locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField7.getLeapDurationField();
        int int18 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3" + "'", str16.equals("3"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType32, (int) (short) -1, (int) ' ', 13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [32,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Hours", 1, 203, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for Hours must be in the range [203,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int91 = dividedDateTimeField77.getDifference(0L, 32L);
        int int92 = dividedDateTimeField77.getDivisor();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 30 + "'", int92 == 30);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.Period period14 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period16 = period14.minusWeeks(0);
        boolean boolean17 = period5.equals((java.lang.Object) period14);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology20);
        org.joda.time.Period period23 = period21.plusMillis(0);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.Period period25 = period5.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period27 = period23.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType29 = period23.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (-1560629399750L));
        org.joda.time.Period period33 = period1.withFieldAdded(durationFieldType29, 3);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (long) 8);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType38 = periodType37.withMinutesRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period((long) '4', periodType37);
        boolean boolean40 = preciseDurationField35.equals((java.lang.Object) period39);
        int int42 = period39.getValue((int) (byte) 0);
        try {
            org.joda.time.Period period44 = period39.plusMonths((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period16 = period14.withWeeks((int) (short) -1);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology19);
        org.joda.time.Period period22 = period20.plusMillis(0);
        org.joda.time.Period period24 = period22.withYears((int) (short) 0);
        org.joda.time.Period period25 = period16.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) '#', periodType27, chronology28);
        org.joda.time.Period period38 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period40 = period38.minusWeeks(0);
        boolean boolean41 = period29.equals((java.lang.Object) period38);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.Period period45 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology44);
        org.joda.time.Period period47 = period45.plusMillis(0);
        org.joda.time.PeriodType periodType48 = period47.getPeriodType();
        org.joda.time.Period period49 = period29.plus((org.joda.time.ReadablePeriod) period47);
        org.joda.time.Period period51 = period47.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType53 = period47.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField54 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType53);
        org.joda.time.DurationFieldType durationFieldType55 = unsupportedDurationField54.getType();
        boolean boolean56 = period16.isSupported(durationFieldType55);
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(durationFieldType55, "100.0");
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(durationFieldType53);
        org.junit.Assert.assertNotNull(unsupportedDurationField54);
        org.junit.Assert.assertNotNull(durationFieldType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        int int31 = preciseDurationField29.getValue(5300L);
        long long34 = preciseDurationField29.add(0L, 10);
        long long35 = preciseDurationField29.getUnitMillis();
        org.joda.time.PeriodType periodType38 = null;
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.Period period40 = new org.joda.time.Period((long) '#', periodType38, chronology39);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Duration duration42 = period40.toDurationFrom(readableInstant41);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period45 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration42, readableInstant43, periodType44);
        org.joda.time.PeriodType periodType46 = periodType44.withMonthsRemoved();
        org.joda.time.Period period47 = new org.joda.time.Period(10L, periodType46);
        boolean boolean48 = preciseDurationField29.equals((java.lang.Object) period47);
        int[] intArray49 = period47.getValues();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-15606293997500L) + "'", long34 == (-15606293997500L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1560629399750L) + "'", long35 == (-1560629399750L));
        org.junit.Assert.assertNotNull(duration42);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology3.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DurationField durationField7 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.minuteOfHour();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 0, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period10 = new org.joda.time.Period(2440587L, (long) 8, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial13);
        long long17 = offsetDateTimeField7.getDifferenceAsLong(100L, (long) 13);
        boolean boolean18 = offsetDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfMonth();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology9);
        org.joda.time.Period period12 = period10.plusMillis(0);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = periodType13.indexOf(durationFieldType14);
        int int16 = periodType13.size();
        org.joda.time.PeriodType periodType17 = periodType13.withMonthsRemoved();
        org.joda.time.PeriodType periodType18 = periodType13.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        java.lang.String str26 = iSOChronology25.toString();
        boolean boolean28 = iSOChronology25.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField29 = iSOChronology25.millis();
        long long32 = durationField29.subtract((long) '#', (int) (short) 1);
        boolean boolean33 = gregorianChronology22.equals((java.lang.Object) durationField29);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology39 = gregorianChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        boolean boolean41 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType13, (java.lang.Object) cachedDateTimeZone40);
        long long43 = cachedDateTimeZone40.convertUTCToLocal((long) (byte) -1);
        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[UTC]" + "'", str26.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 34L + "'", long32 == 34L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 31L + "'", long43 == 31L);
        org.junit.Assert.assertNotNull(zonedChronology44);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        long long30 = unsupportedDurationField29.getUnitMillis();
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) '#', periodType32, chronology33);
        org.joda.time.Period period43 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period45 = period43.minusWeeks(0);
        boolean boolean46 = period34.equals((java.lang.Object) period43);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology49);
        org.joda.time.Period period52 = period50.plusMillis(0);
        org.joda.time.PeriodType periodType53 = period52.getPeriodType();
        org.joda.time.Period period54 = period34.plus((org.joda.time.ReadablePeriod) period52);
        org.joda.time.Period period56 = period52.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Duration duration58 = period56.toDurationFrom(readableInstant57);
        boolean boolean59 = unsupportedDurationField29.equals((java.lang.Object) duration58);
        org.joda.time.DurationFieldType durationFieldType60 = unsupportedDurationField29.getType();
        boolean boolean61 = unsupportedDurationField29.isPrecise();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(duration58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period(3L, (-35948000L), periodType9);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', periodType13, chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = null;
        int int31 = periodType29.indexOf(durationFieldType30);
        int int32 = periodType29.size();
        org.joda.time.PeriodType periodType33 = periodType29.withMonthsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType29);
        org.joda.time.Period period36 = period34.minusMonths((int) ' ');
        java.lang.String str37 = period36.toString();
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "P-32MT0.035S" + "'", str37.equals("P-32MT0.035S"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.centuryOfEra();
        org.joda.time.Period period15 = new org.joda.time.Period(8, (int) '#', (int) (byte) 1, (int) ' ');
        int[] intArray17 = iSOChronology2.get((org.joda.time.ReadablePeriod) period15, (long) (byte) 100);
        org.joda.time.Period period19 = period15.withWeeks(10);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period15.get(durationFieldType20);
        org.joda.time.Period period23 = period15.plusYears((-1));
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period15.toDurationTo(readableInstant24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology5);
        org.joda.time.Period period8 = period6.plusMillis(0);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = periodType9.indexOf(durationFieldType10);
        int int12 = periodType9.size();
        org.joda.time.PeriodType periodType13 = periodType9.withMonthsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((long) 'a', 5300L, periodType9);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology21);
        org.joda.time.Period period24 = period22.plusMillis(0);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = periodType25.indexOf(durationFieldType26);
        int int28 = periodType25.size();
        org.joda.time.PeriodType periodType29 = periodType25.withMonthsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', 5300L, periodType25);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration16, periodType25);
        org.joda.time.Period period33 = period31.withSeconds(0);
        org.joda.time.Period period35 = period33.withDays(3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.toString();
        long long36 = preciseDurationField29.add((long) ' ', (int) 'a');
        java.lang.String str37 = preciseDurationField29.toString();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-151381051775718L) + "'", long36 == (-151381051775718L));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[years]" + "'", str37.equals("DurationField[years]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.toString();
        long long36 = preciseDurationField29.getDifferenceAsLong((long) 3, 201L);
        long long38 = preciseDurationField29.getValueAsLong((-1L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(101928931200203L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3620320.5000023497d + "'", double1 == 3620320.5000023497d);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.lang.String str5 = iSOChronology4.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology4.days();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone8.getShortName(1L, locale11);
//        long long14 = dateTimeZone8.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone15 = dateTimeZone8.toTimeZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology1.withZone(dateTimeZone8);
//        try {
//            long long24 = gregorianChronology1.getDateTimeMillis(35, (int) ' ', 32, (-52), 197, 32, 203);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology5.withZone(dateTimeZone9);
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (short) 0, periodType2, chronology10);
        boolean boolean13 = periodType2.equals((java.lang.Object) 1L);
        org.joda.time.PeriodType periodType14 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType15 = periodType2.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.millisOfSecond();
        long long11 = iSOChronology2.add((-34380000L), (-56182658391000L), 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-34380000L) + "'", long11 == (-34380000L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField7.getAsText(1031592959L, locale11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "133" + "'", str12.equals("133"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int89 = remainderDateTimeField88.getMinimumValue();
        long long91 = remainderDateTimeField88.roundHalfEven(201L);
        int int92 = remainderDateTimeField88.getMinimumValue();
        long long94 = remainderDateTimeField88.roundHalfCeiling(57743287790L);
        try {
            long long97 = remainderDateTimeField88.set((-52000L), 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for minuteOfHour must be in the range [0,29]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 57743280000L + "'", long94 == 57743280000L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        java.lang.String str36 = iSOChronology35.toString();
        org.joda.time.DurationField durationField37 = iSOChronology35.days();
        org.joda.time.DurationField durationField38 = iSOChronology35.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.days();
        long long45 = durationField42.subtract((-5199999L), (long) (byte) 0);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField46 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType32, durationField38, durationField42);
        long long48 = preciseDateTimeField46.remainder(1560629400000L);
        org.joda.time.DurationField durationField49 = preciseDateTimeField46.getRangeDurationField();
        boolean boolean50 = preciseDateTimeField46.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[UTC]" + "'", str36.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-5199999L) + "'", long45 == (-5199999L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        int int79 = dividedDateTimeField77.get((long) 30);
        java.util.Locale locale81 = null;
        java.lang.String str82 = dividedDateTimeField77.getAsText(7, locale81);
        int int84 = dividedDateTimeField77.get(2259959L);
        int int86 = dividedDateTimeField77.get(3L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "7" + "'", str82.equals("7"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 3 + "'", int86 == 3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        long long90 = remainderDateTimeField88.roundCeiling((-5199999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType91 = remainderDateTimeField88.getType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-5160000L) + "'", long90 == (-5160000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType91);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology6);
        org.joda.time.Period period9 = period7.plusMillis(0);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = periodType10.indexOf(durationFieldType11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType10, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) 7, (-210347318460000L), (org.joda.time.Chronology) iSOChronology15);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.year();
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            int[] intArray13 = iSOChronology2.get(readablePartial11, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.toString();
        long long35 = preciseDurationField29.getMillis(2440588L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-3808853385477053000L) + "'", long35 == (-3808853385477053000L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        java.lang.String str36 = iSOChronology35.toString();
        org.joda.time.DurationField durationField37 = iSOChronology35.days();
        org.joda.time.DurationField durationField38 = iSOChronology35.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.days();
        long long45 = durationField42.subtract((-5199999L), (long) (byte) 0);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField46 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType32, durationField38, durationField42);
        long long48 = preciseDateTimeField46.remainder(1560629400000L);
        org.joda.time.DurationField durationField49 = preciseDateTimeField46.getRangeDurationField();
        org.joda.time.DurationField durationField50 = preciseDateTimeField46.getRangeDurationField();
        long long52 = preciseDateTimeField46.remainder(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[UTC]" + "'", str36.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-5199999L) + "'", long45 == (-5199999L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period8.withDays(1);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology15);
        org.joda.time.Period period18 = period16.plusMillis(0);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = periodType19.indexOf(durationFieldType20);
        int int22 = periodType19.size();
        org.joda.time.Period period23 = period12.normalizedStandard(periodType19);
        org.joda.time.MutablePeriod mutablePeriod24 = period23.toMutablePeriod();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(mutablePeriod24);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.add((long) (byte) -1, (long) 8);
        long long33 = preciseDurationField29.getUnitMillis();
        boolean boolean34 = preciseDurationField29.isPrecise();
        int int36 = preciseDurationField29.getValue((-210417480032000L));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-12485035198001L) + "'", long32 == (-12485035198001L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1560629399750L) + "'", long33 == (-1560629399750L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 134 + "'", int36 == 134);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11);
        org.joda.time.Period period14 = org.joda.time.Period.minutes((int) (short) 10);
        org.joda.time.Period period15 = period12.minus((org.joda.time.ReadablePeriod) period14);
        org.joda.time.Period period17 = period12.minusMinutes(8);
        org.joda.time.Period period19 = period12.plusYears(0);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period36 = period34.withWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period34.toDurationTo(readableInstant37);
        org.joda.time.MutablePeriod mutablePeriod39 = period34.toMutablePeriod();
        org.joda.time.Period period40 = period19.minus((org.joda.time.ReadablePeriod) period34);
        org.joda.time.Period period42 = period19.withMinutes(197);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertNotNull(mutablePeriod39);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        java.lang.String str16 = period3.toString();
        org.joda.time.Period period18 = period3.minusSeconds((int) (byte) 10);
        org.joda.time.format.PeriodFormatter periodFormatter19 = null;
        java.lang.String str20 = period3.toString(periodFormatter19);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT0.035S" + "'", str16.equals("PT0.035S"));
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PT0.035S" + "'", str20.equals("PT0.035S"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Seconds", "LenientChronology[ISOChronology[UTC]]", 0, (int) (short) -1);
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        org.joda.time.Period period3 = period1.toPeriod();
        org.joda.time.DurationFieldType[] durationFieldTypeArray4 = period3.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(durationFieldTypeArray4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long16 = offsetDateTimeField7.getDifferenceAsLong((long) 201, (long) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsText(3, locale18);
        java.lang.String str20 = offsetDateTimeField7.toString();
        java.lang.String str22 = offsetDateTimeField7.getAsShortText((-210865896000000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str20.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int89 = remainderDateTimeField88.getMinimumValue();
        long long91 = remainderDateTimeField88.roundHalfEven(201L);
        int int92 = remainderDateTimeField88.getMinimumValue();
        long long94 = remainderDateTimeField88.roundHalfCeiling(57743287790L);
        int int95 = remainderDateTimeField88.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 57743280000L + "'", long94 == 57743280000L);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 29 + "'", int95 == 29);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        int int31 = preciseDurationField29.getValue(5300L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology37);
        org.joda.time.Period period40 = period38.plusMillis(0);
        org.joda.time.PeriodType periodType41 = period40.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = periodType41.indexOf(durationFieldType42);
        int int44 = periodType41.size();
        org.joda.time.PeriodType periodType45 = periodType41.withMonthsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', 5300L, periodType41);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Duration duration48 = period46.toDurationFrom(readableInstant47);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology53);
        org.joda.time.Period period56 = period54.plusMillis(0);
        org.joda.time.PeriodType periodType57 = period56.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = periodType57.indexOf(durationFieldType58);
        int int60 = periodType57.size();
        org.joda.time.PeriodType periodType61 = periodType57.withMonthsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) 'a', 5300L, periodType57);
        org.joda.time.Period period63 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration48, periodType57);
        boolean boolean64 = preciseDurationField29.equals((java.lang.Object) duration48);
        long long67 = preciseDurationField29.getMillis(134, 3609976L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(duration48);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-209124339566500L) + "'", long67 == (-209124339566500L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        org.joda.time.DurationField durationField33 = offsetDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Period period24 = period19.minusDays((int) (short) 1);
        org.joda.time.Period period26 = period24.plusMinutes((int) (byte) -1);
        org.joda.time.Period period27 = period3.plus((org.joda.time.ReadablePeriod) period24);
        java.lang.String str28 = period3.toString();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PT0.001S" + "'", str28.equals("PT0.001S"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Period period8 = new org.joda.time.Period(8, 30, 36, (int) (short) -1, (int) ' ', 201, 3, 0);
        org.joda.time.Period period10 = period8.withHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long16 = offsetDateTimeField7.getDifferenceAsLong((long) 201, (long) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsText(3, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsText(1, locale21);
        long long25 = offsetDateTimeField7.add(0L, (int) '#');
        long long27 = offsetDateTimeField7.roundHalfCeiling((long) (short) -1);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField7.getAsText(3, locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField7.getType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2100000L + "'", long25 == 2100000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "3" + "'", str30.equals("3"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = iSOChronology7.toString();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField11 = iSOChronology7.millis();
        long long14 = durationField11.subtract((long) '#', (int) (short) 1);
        boolean boolean15 = gregorianChronology4.equals((java.lang.Object) durationField11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology21 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) '#', periodType25, chronology26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period32 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration29, readableInstant30, periodType31);
        org.joda.time.PeriodType periodType35 = null;
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) '#', periodType35, chronology36);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Duration duration39 = period37.toDurationFrom(readableInstant38);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period42 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration39, readableInstant40, periodType41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) (short) 0, periodType41);
        org.joda.time.Period period44 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration29, periodType41);
        boolean boolean45 = fixedDateTimeZone20.equals((java.lang.Object) period44);
        int int47 = fixedDateTimeZone20.getOffset(0L);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology48 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 34L + "'", long14 == 34L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(duration39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 32 + "'", int47 == 32);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', periodType2, chronology3);
        org.joda.time.Period period13 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period15 = period13.minusWeeks(0);
        boolean boolean16 = period4.equals((java.lang.Object) period13);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology19);
        org.joda.time.Period period22 = period20.plusMillis(0);
        org.joda.time.PeriodType periodType23 = period22.getPeriodType();
        org.joda.time.Period period24 = period4.plus((org.joda.time.ReadablePeriod) period22);
        org.joda.time.Period period26 = period22.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period26.toDurationFrom(readableInstant27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        java.lang.String str39 = iSOChronology38.toString();
        org.joda.time.DurationField durationField40 = iSOChronology38.days();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology38.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology43 = iSOChronology38.withZone(dateTimeZone42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, (long) (short) 0, periodType35, chronology43);
        org.joda.time.Period period45 = new org.joda.time.Period(0L, 10L, periodType32, chronology43);
        org.joda.time.PeriodType periodType46 = periodType32.withMinutesRemoved();
        org.joda.time.Period period47 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration28, readableInstant29, periodType46);
        org.joda.time.Period period48 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration28);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ISOChronology[UTC]" + "'", str39.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(periodType46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Period period11 = period8.withFieldAdded(durationFieldType9, (-34386431));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int89 = remainderDateTimeField88.getMinimumValue();
        long long91 = remainderDateTimeField88.roundHalfEven(201L);
        int int92 = remainderDateTimeField88.getMinimumValue();
        int int94 = remainderDateTimeField88.get((-3144959999964L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 10 + "'", int94 == 10);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField20 = iSOChronology16.millis();
        long long23 = durationField20.subtract((long) '#', (int) (short) 1);
        boolean boolean24 = gregorianChronology13.equals((java.lang.Object) durationField20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology30 = gregorianChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology34);
        org.joda.time.Period period37 = period35.plusMillis(0);
        org.joda.time.Period period39 = period37.multipliedBy(10);
        boolean boolean40 = cachedDateTimeZone31.equals((java.lang.Object) period37);
        java.lang.Object obj41 = null;
        boolean boolean42 = cachedDateTimeZone31.equals(obj41);
        org.joda.time.DateTimeZone dateTimeZone43 = cachedDateTimeZone31.getUncachedZone();
        long long45 = cachedDateTimeZone31.nextTransition(0L);
        java.lang.Class<?> wildcardClass46 = cachedDateTimeZone31.getClass();
        boolean boolean47 = cachedDateTimeZone31.isFixed();
        int int49 = cachedDateTimeZone31.getOffset((long) 36);
        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 34L + "'", long23 == 34L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 32 + "'", int49 == 32);
        org.junit.Assert.assertNotNull(zonedChronology50);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        long long17 = offsetDateTimeField7.roundCeiling((-8115272878700000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.lang.String str24 = iSOChronology23.toString();
        org.joda.time.DurationField durationField25 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.hourOfDay();
        org.joda.time.Chronology chronology27 = iSOChronology23.withUTC();
        org.joda.time.Chronology chronology28 = iSOChronology23.withUTC();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology28);
        int[] intArray30 = period29.getValues();
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial18, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField7.getType();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        java.lang.String str36 = iSOChronology35.toString();
        org.joda.time.DurationField durationField37 = iSOChronology35.days();
        org.joda.time.DurationField durationField38 = iSOChronology35.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.days();
        long long45 = durationField42.subtract((-5199999L), (long) (byte) 0);
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField46 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType32, durationField38, durationField42);
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 29, "hi!");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-8115272878680000L) + "'", long17 == (-8115272878680000L));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[UTC]" + "'", str24.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 159 + "'", int31 == 159);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[UTC]" + "'", str36.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-5199999L) + "'", long45 == (-5199999L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-52), (int) (short) 1, 197, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType24 = null;
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) '#', periodType24, chronology25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period26.toDurationFrom(readableInstant27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration28, readableInstant29, periodType30);
        org.joda.time.PeriodType periodType34 = null;
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) '#', periodType34, chronology35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period36.toDurationFrom(readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration38, readableInstant39, periodType40);
        org.joda.time.Period period42 = new org.joda.time.Period((long) (short) 0, periodType40);
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration28, periodType40);
        boolean boolean44 = fixedDateTimeZone19.equals((java.lang.Object) period43);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.Locale locale47 = null;
        java.lang.String str48 = fixedDateTimeZone19.getName(1000L, locale47);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+00:00:00.032" + "'", str48.equals("+00:00:00.032"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DurationField durationField51 = offsetDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField52 = offsetDateTimeField7.getLeapDurationField();
        int int54 = offsetDateTimeField7.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNull(durationField52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.getDifferenceAsLong((long) (-34386431), (long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-19L) + "'", long80 == (-19L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "Coordinated Universal Time");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"Coordinated Universal Time\" for  is not supported"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        long long61 = decoratedDurationField58.add((-5199999L), 10);
        long long64 = decoratedDurationField58.getDifferenceAsLong((long) 8, 315699999L);
        int int66 = decoratedDurationField58.getValue((-3594800L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-5189999L) + "'", long61 == (-5189999L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-315699L) + "'", long64 == (-315699L));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-3594) + "'", int66 == (-3594));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.weeks();
        try {
            long long10 = iSOChronology2.getDateTimeMillis(0, 5200, (int) (short) 10, (-34));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -34 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-3144959999964L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -3144959999964");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period8.withDays(1);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        org.joda.time.Period period15 = period13.withYears((int) ' ');
        org.joda.time.Period period17 = period15.withWeeks((int) (byte) 100);
        int int18 = period17.getYears();
        org.joda.time.Period period20 = period17.withYears(0);
        org.joda.time.Period period21 = period20.negated();
        org.joda.time.Period period23 = period20.plusDays((int) '#');
        org.joda.time.Period period24 = period8.withFields((org.joda.time.ReadablePeriod) period23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period23.toDurationFrom(readableInstant25);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        long long35 = preciseDurationField29.getDifferenceAsLong((long) 134, 28000L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology20);
        org.joda.time.Period period23 = period21.plusMillis(0);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType25 = null;
        int int26 = periodType24.indexOf(durationFieldType25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType24, (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Period period32 = period30.withWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Duration duration34 = period30.toDurationTo(readableInstant33);
        int[] intArray35 = period30.getValues();
        int int36 = offsetDateTimeField7.getMaximumValue(readablePartial15, intArray35);
        long long38 = offsetDateTimeField7.roundHalfFloor((long) 8);
        try {
            long long41 = offsetDateTimeField7.set((long) 38, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [100,159]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(duration34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 159 + "'", int36 == 159);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.days();
        boolean boolean33 = zonedChronology22.equals((java.lang.Object) (-48379511392250L));
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology22.secondOfDay();
        try {
            long long40 = zonedChronology22.getDateTimeMillis((long) (-1), (-1560628649), (int) ' ', 8, (-1560628649));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1560628649 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getName();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        boolean boolean8 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission7);
        jodaTimePermission7.checkGuard((java.lang.Object) "100.0");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.032" + "'", str5.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(6030L, "Seconds");
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1560629399751000L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560629399751000L) + "'", long2 == (-1560629399751000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 8, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str6 = fixedDateTimeZone4.getName(0L);
        long long8 = fixedDateTimeZone4.nextTransition((long) 100);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology11);
        org.joda.time.Period period14 = period12.plusMillis(0);
        boolean boolean15 = fixedDateTimeZone4.equals((java.lang.Object) period14);
        long long18 = fixedDateTimeZone4.adjustOffset((-210858120000000L), false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.032" + "'", str6.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210858120000000L) + "'", long18 == (-210858120000000L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(30);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period16 = period14.withWeeks((int) (short) -1);
        org.joda.time.PeriodType periodType17 = period16.getPeriodType();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.seconds();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        try {
            long long8 = iSOChronology0.getDateTimeMillis(5200, 97, (int) (short) 10, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        long long90 = remainderDateTimeField88.roundCeiling((-5199999L));
        java.util.Locale locale91 = null;
        int int92 = remainderDateTimeField88.getMaximumTextLength(locale91);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-5160000L) + "'", long90 == (-5160000L));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 10, locale12);
        int int14 = offsetDateTimeField7.getMinimumValue();
        long long16 = offsetDateTimeField7.roundHalfFloor((-8115272878700000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-8115272878680000L) + "'", long16 == (-8115272878680000L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        java.lang.String str6 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology6);
        org.joda.time.Period period9 = period7.plusMillis(0);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = periodType10.indexOf(durationFieldType11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType10, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period16);
        org.joda.time.Hours hours18 = period17.toStandardHours();
        org.joda.time.Period period19 = period17.toPeriod();
        org.joda.time.Period period21 = period19.multipliedBy(0);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        int int31 = periodType28.size();
        org.joda.time.PeriodType periodType32 = periodType28.withMonthsRemoved();
        org.joda.time.PeriodType periodType33 = periodType32.withMonthsRemoved();
        org.joda.time.Period period34 = period19.withPeriodType(periodType32);
        org.joda.time.PeriodType periodType35 = periodType32.withHoursRemoved();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology(chronology36);
        org.joda.time.Period period38 = new org.joda.time.Period((-62166182399948L), (-210347316660000L), periodType35, chronology37);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(hours18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.lang.String str23 = zonedChronology22.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ZonedChronology[GregorianChronology[UTC], ISOChronology[UTC]]" + "'", str23.equals("ZonedChronology[GregorianChronology[UTC], ISOChronology[UTC]]"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.weekOfWeekyear();
        org.joda.time.Chronology chronology18 = iSOChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology11.millisOfDay();
        org.joda.time.Chronology chronology20 = iSOChronology11.withUTC();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        long long61 = decoratedDurationField58.add((-5199999L), 10);
        long long63 = decoratedDurationField58.getValueAsLong(34L);
        long long66 = decoratedDurationField58.add(1560629399750L, 36);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-5189999L) + "'", long61 == (-5189999L));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560629435750L + "'", long66 == 1560629435750L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        int int89 = remainderDateTimeField88.getMinimumValue();
        long long91 = remainderDateTimeField88.roundHalfEven(201L);
        int int92 = remainderDateTimeField88.getMinimumValue();
        int int93 = remainderDateTimeField88.getDivisor();
        long long95 = remainderDateTimeField88.roundFloor((-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 30 + "'", int93 == 30);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-210347316660000L) + "'", long95 == (-210347316660000L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Period period15 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period17 = period15.minusWeeks(0);
        org.joda.time.Period period18 = period4.plus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = period18.isSupported(durationFieldType19);
        org.joda.time.Period period22 = period18.withYears(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        long long61 = decoratedDurationField58.getMillis(5200, (-49940140791000L));
        boolean boolean62 = decoratedDurationField58.isPrecise();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 5200000L + "'", long61 == 5200000L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfCentury();
        org.joda.time.DurationField durationField7 = iSOChronology2.years();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        boolean boolean31 = cachedDateTimeZone21.isFixed();
        int int33 = cachedDateTimeZone21.getStandardOffset(920246400017L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(4, 8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '#', periodType31, chronology32);
        org.joda.time.Period period42 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period44 = period42.minusWeeks(0);
        boolean boolean45 = period33.equals((java.lang.Object) period42);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology48);
        org.joda.time.Period period51 = period49.plusMillis(0);
        org.joda.time.PeriodType periodType52 = period51.getPeriodType();
        org.joda.time.Period period53 = period33.plus((org.joda.time.ReadablePeriod) period51);
        org.joda.time.Period period55 = period51.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType57 = period51.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField58 = new org.joda.time.field.DecoratedDurationField(durationField26, durationFieldType57);
        long long61 = decoratedDurationField58.add((-5199999L), 10);
        long long64 = decoratedDurationField58.getDifferenceAsLong((long) 8, 315699999L);
        long long66 = decoratedDurationField58.getValueAsLong(0L);
        long long68 = decoratedDurationField58.getMillis((-52));
        int int70 = decoratedDurationField58.getValue((long) 100);
        long long71 = decoratedDurationField58.getUnitMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-5189999L) + "'", long61 == (-5189999L));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-315699L) + "'", long64 == (-315699L));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-52000L) + "'", long68 == (-52000L));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1000L + "'", long71 == 1000L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedDateTimeZone19.equals(obj23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        int int26 = fixedDateTimeZone19.getOffset(readableInstant25);
        boolean boolean27 = fixedDateTimeZone19.isFixed();
        java.lang.Object obj28 = null;
        boolean boolean29 = fixedDateTimeZone19.equals(obj28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = fixedDateTimeZone19.getName((long) (byte) 10, locale31);
        long long34 = fixedDateTimeZone19.previousTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00:00.032" + "'", str32.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "", "107");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        long long87 = dividedDateTimeField77.remainder((long) (short) 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField88 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField77);
        long long90 = remainderDateTimeField88.roundHalfFloor(5200000L);
        long long92 = remainderDateTimeField88.roundHalfFloor(2100000L);
        int int95 = remainderDateTimeField88.getDifference(479990L, 1560629399782L);
        long long98 = remainderDateTimeField88.getDifferenceAsLong((long) 4, 97L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 5220000L + "'", long90 == 5220000L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 2100000L + "'", long92 == 2100000L);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-26010481) + "'", int95 == (-26010481));
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 0L + "'", long98 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        boolean boolean29 = unsupportedDurationField28.isPrecise();
        java.lang.String str30 = unsupportedDurationField28.toString();
        boolean boolean31 = unsupportedDurationField28.isSupported();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDurationField[years]" + "'", str30.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11);
        org.joda.time.Period period14 = org.joda.time.Period.minutes((int) (short) 10);
        org.joda.time.Period period15 = period12.minus((org.joda.time.ReadablePeriod) period14);
        int int16 = period15.getMonths();
        org.joda.time.Period period18 = period15.plusSeconds((-34386431));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long16 = offsetDateTimeField7.getDifferenceAsLong((long) 201, (long) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsText(3, locale18);
        java.lang.String str20 = offsetDateTimeField7.toString();
        long long22 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        long long25 = offsetDateTimeField7.add((long) 203, 32);
        org.joda.time.DurationField durationField26 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str20.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1920203L + "'", long25 == 1920203L);
        org.junit.Assert.assertNull(durationField26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.Period period12 = org.joda.time.Period.minutes(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period12.getFieldTypes();
        int[] intArray15 = iSOChronology2.get((org.joda.time.ReadablePeriod) period12, (long) (-26010481));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        java.lang.String str10 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1 + "'", number8.equals(1));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        java.lang.String str22 = iSOChronology21.toString();
        org.joda.time.DurationField durationField23 = iSOChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.hourOfDay();
        org.joda.time.Chronology chronology25 = iSOChronology21.withUTC();
        org.joda.time.Chronology chronology26 = iSOChronology21.withUTC();
        org.joda.time.Period period27 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology26);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField7.getMaximumValue(readablePartial16, intArray28);
        int int30 = offsetDateTimeField7.getOffset();
        int int32 = offsetDateTimeField7.get(1000L);
        long long34 = offsetDateTimeField7.roundCeiling((-1560629399751000L));
        int int36 = offsetDateTimeField7.getMinimumValue((-2L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[UTC]" + "'", str22.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 159 + "'", int29 == 159);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1560629399700000L) + "'", long34 == (-1560629399700000L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long16 = offsetDateTimeField7.getDifferenceAsLong((long) 201, (long) 100);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsText(3, locale18);
        java.lang.String str20 = offsetDateTimeField7.toString();
        long long22 = offsetDateTimeField7.roundHalfFloor((long) (short) 1);
        long long25 = offsetDateTimeField7.add((long) 203, 32);
        int int28 = offsetDateTimeField7.getDifference(90L, 2100000L);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField7.getAsShortText(readablePartial29, (int) (short) 1, locale31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str20.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1920203L + "'", long25 == 1920203L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-34) + "'", int28 == (-34));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = iSOChronology7.toString();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField11 = iSOChronology7.millis();
        long long14 = durationField11.subtract((long) '#', (int) (short) 1);
        boolean boolean15 = gregorianChronology4.equals((java.lang.Object) durationField11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology21 = gregorianChronology4.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.Period period30 = period28.multipliedBy(10);
        boolean boolean31 = cachedDateTimeZone22.equals((java.lang.Object) period28);
        int int33 = cachedDateTimeZone22.getStandardOffset((-1L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        boolean boolean35 = cachedDateTimeZone34.isFixed();
        long long37 = cachedDateTimeZone34.convertUTCToLocal(0L);
        long long39 = cachedDateTimeZone34.nextTransition((long) (short) 10);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 34L + "'", long14 == 34L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 32L + "'", long37 == 32L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        long long12 = offsetDateTimeField7.add((-210417480000000L), 1169389L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        java.lang.String str17 = iSOChronology16.toString();
        boolean boolean19 = iSOChronology16.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.PeriodType periodType28 = period27.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        int int30 = periodType28.indexOf(durationFieldType29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType28, (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Period period35 = new org.joda.time.Period((java.lang.Object) period34);
        int[] intArray37 = iSOChronology16.get((org.joda.time.ReadablePeriod) period35, (long) 8);
        int int38 = offsetDateTimeField7.getMaximumValue(readablePartial13, intArray37);
        int int39 = offsetDateTimeField7.getMaximumValue();
        long long42 = offsetDateTimeField7.add(0L, (long) (-52));
        int int44 = offsetDateTimeField7.getLeapAmount((long) ' ');
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray49 = period48.getValues();
        int int50 = offsetDateTimeField7.getMaximumValue(readablePartial45, intArray49);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        java.lang.String str54 = iSOChronology53.toString();
        org.joda.time.DurationField durationField55 = iSOChronology53.minutes();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology53.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (short) 100);
        int int60 = offsetDateTimeField58.get(0L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField58.getAsText(readablePartial61, 10, locale63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField58.getAsShortText(3, locale66);
        org.joda.time.DurationField durationField68 = offsetDateTimeField58.getLeapDurationField();
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField58.getAsText(0, locale70);
        long long74 = offsetDateTimeField58.getDifferenceAsLong((long) 159, (-210347304599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType75, 30);
        long long80 = dividedDateTimeField77.add(0L, 32);
        long long82 = dividedDateTimeField77.remainder((-5199999L));
        int int85 = dividedDateTimeField77.getDifference((long) '4', 5200L);
        org.joda.time.DurationField durationField86 = dividedDateTimeField77.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210347316660000L) + "'", long12 == (-210347316660000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 159 + "'", int38 == 159);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 159 + "'", int39 == 159);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3120000L) + "'", long42 == (-3120000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 159 + "'", int50 == 159);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ISOChronology[UTC]" + "'", str54.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "3" + "'", str67.equals("3"));
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3505788410L + "'", long74 == 3505788410L);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 57600000L + "'", long80 == 57600000L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-6999999L) + "'", long82 == (-6999999L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(durationField86);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        org.joda.time.DurationField durationField14 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "PT0S");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("LenientChronology[ISOChronology[UTC]]", "ISOChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException6.getIllegalStringValue();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Period period17 = period15.withWeeks(5200);
        int int18 = period17.getWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5200 + "'", int18 == 5200);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(34L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DurationField durationField10 = iSOChronology8.days();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period(0L, (long) (short) 0, periodType5, chronology13);
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 10L, periodType2, chronology13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.String str19 = iSOChronology18.toString();
        org.joda.time.DurationField durationField20 = iSOChronology18.days();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        long long24 = iSOChronology18.add(readablePeriod21, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology18.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology18.centuryOfEra();
        org.joda.time.Period period31 = new org.joda.time.Period(8, (int) '#', (int) (byte) 1, (int) ' ');
        int[] intArray33 = iSOChronology18.get((org.joda.time.ReadablePeriod) period31, (long) (byte) 100);
        org.joda.time.Period period35 = period31.withWeeks(10);
        org.joda.time.Period period37 = period35.plusDays((int) (short) -1);
        org.joda.time.Period period39 = period35.plusWeeks(3);
        boolean boolean40 = periodType2.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5200L + "'", long24 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.Period period14 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period16 = period14.minusWeeks(0);
        boolean boolean17 = period5.equals((java.lang.Object) period14);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology20);
        org.joda.time.Period period23 = period21.plusMillis(0);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.Period period25 = period5.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period27 = period23.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType29 = period23.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField31 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (-1560629399750L));
        org.joda.time.Period period33 = period1.withFieldAdded(durationFieldType29, 3);
        org.joda.time.field.PreciseDurationField preciseDurationField35 = new org.joda.time.field.PreciseDurationField(durationFieldType29, (long) 8);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType38 = periodType37.withMinutesRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period((long) '4', periodType37);
        boolean boolean40 = preciseDurationField35.equals((java.lang.Object) period39);
        long long41 = preciseDurationField35.getUnitMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 8L + "'", long41 == 8L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        boolean boolean10 = offsetDateTimeField7.isLenient();
        long long13 = offsetDateTimeField7.add((-48379511392250L), 8);
        long long15 = offsetDateTimeField7.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        java.lang.String str22 = iSOChronology21.toString();
        org.joda.time.DurationField durationField23 = iSOChronology21.days();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.hourOfDay();
        org.joda.time.Chronology chronology25 = iSOChronology21.withUTC();
        org.joda.time.Chronology chronology26 = iSOChronology21.withUTC();
        org.joda.time.Period period27 = new org.joda.time.Period((long) 10, (long) (byte) 10, chronology26);
        int[] intArray28 = period27.getValues();
        int int29 = offsetDateTimeField7.getMaximumValue(readablePartial16, intArray28);
        org.joda.time.DurationField durationField30 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray35 = period34.getValues();
        int int36 = offsetDateTimeField7.getMinimumValue(readablePartial31, intArray35);
        long long38 = offsetDateTimeField7.roundHalfCeiling((-8115272878700000L));
        int int40 = offsetDateTimeField7.getLeapAmount((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-48379510912250L) + "'", long13 == (-48379510912250L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[UTC]" + "'", str22.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 159 + "'", int29 == 159);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-8115272878680000L) + "'", long38 == (-8115272878680000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        org.joda.time.DurationFieldType durationFieldType30 = preciseDurationField29.getType();
        boolean boolean31 = preciseDurationField29.isPrecise();
        long long34 = preciseDurationField29.getMillis(10400L, (-5225370964833599488L));
        org.joda.time.DurationField durationField35 = null;
        try {
            int int36 = preciseDurationField29.compareTo(durationField35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-16230545757400000L) + "'", long34 == (-16230545757400000L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        long long27 = iSOChronology2.add(0L, (-48379510912250L), 8);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-387036087298000L) + "'", long27 == (-387036087298000L));
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        org.joda.time.DurationField durationField12 = iSOChronology10.days();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology15 = iSOChronology10.withZone(dateTimeZone14);
        org.joda.time.Period period16 = new org.joda.time.Period(0L, (long) (short) 0, periodType7, chronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, 10L, periodType4, chronology15);
        org.joda.time.PeriodType periodType18 = periodType4.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withWeeksRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        boolean boolean23 = period20.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }
}

