import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(10L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5200 + "'", int2 == 5200);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test006");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 1, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560629399750L + "'", long0 == 1560629399750L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, 0, (int) 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) (short) 10, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        java.lang.String str2 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            long long10 = iSOChronology2.getDateTimeMillis((int) (byte) 100, (int) '#', (int) ' ', (-1), 1, 8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = iSOChronology2.set(readablePartial3, 1560629399750L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 0, (int) (short) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1560629399750L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560629399750L + "'", long2 == 1560629399750L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Period period4 = period1.withFieldAdded(durationFieldType2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 5200, 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearDay();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) (byte) -1, periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        try {
            long long10 = iSOChronology2.getDateTimeMillis(0, (int) (byte) 1, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        try {
            long long24 = iSOChronology11.getDateTimeMillis(100, (int) (byte) 1, (int) '4', 0, 100, (int) '#', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.Period period7 = period5.withYears((int) (short) 0);
        org.joda.time.Period period9 = period5.plusWeeks((int) '4');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withField(durationFieldType4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000405d + "'", double1 == 2440587.500000405d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long8 = gregorianChronology3.getDateTimeMillis(0, (int) (short) 10, (int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        try {
            long long13 = iSOChronology2.getDateTimeMillis((int) (short) 100, 0, (int) (short) 0, 32, (int) (byte) 1, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.field.FieldUtils.verifyValueBounds("UTC", (int) (short) 10, 0, (int) (short) 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology2.weekyears();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 0, (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(100L, (long) 5200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5300L + "'", long2 == 5300L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        try {
            org.joda.time.DurationFieldType durationFieldType6 = period4.getFieldType(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        try {
            long long25 = gregorianChronology3.getDateTimeMillis((int) ' ', 8, 8, (int) (byte) 1, 0, (int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) 32, (java.lang.Number) (-10L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = periodType6.indexOf(durationFieldType7);
        org.joda.time.PeriodType periodType9 = periodType6.withYearsRemoved();
        java.lang.String str10 = periodType6.toString();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[Standard]" + "'", str10.equals("PeriodType[Standard]"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) -1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        boolean boolean12 = periodType8.equals((java.lang.Object) 0.0d);
        try {
            org.joda.time.Period period13 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.032/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 32, (int) (short) 1, (int) ' ');
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6, periodType7);
        org.joda.time.Seconds seconds9 = period8.toStandardSeconds();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(seconds9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology2.weekyears();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray10 = new int[] { 0, (short) 0 };
        try {
            iSOChronology2.validate(readablePartial7, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        java.lang.String str17 = periodType8.toString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PeriodType[Standard]" + "'", str17.equals("PeriodType[Standard]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        long long7 = durationField4.subtract((long) (byte) 100, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1, 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Hours hours16 = period15.toStandardHours();
        org.joda.time.Period period18 = period15.minusWeeks((int) (byte) -1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(hours16);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', 100, 0, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', periodType2, chronology3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 0, periodType8);
        org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(minutes11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(100L, (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray9 = new int[] { (short) 10, 32 };
        try {
            iSOChronology2.validate(readablePartial6, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField6 = iSOChronology2.millis();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        boolean boolean16 = iSOChronology2.equals((java.lang.Object) readableInstant13);
        try {
            long long21 = iSOChronology2.getDateTimeMillis(10, 100, (int) (byte) 0, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PeriodType[Standard]", (int) (byte) 1, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for PeriodType[Standard] must be in the range [97,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        try {
            long long27 = zonedChronology22.getDateTimeMillis((int) (byte) 0, 32, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (byte) 100, 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.lang.String str4 = iSOChronology3.toString();
//        org.joda.time.DurationField durationField5 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.lang.String str10 = iSOChronology9.toString();
//        org.joda.time.DurationField durationField11 = iSOChronology9.days();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology14 = iSOChronology9.withZone(dateTimeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone13.getShortName(1L, locale16);
//        long long19 = dateTimeZone13.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology20 = iSOChronology3.withZone(dateTimeZone13);
//        try {
//            org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) 2440587L, (org.joda.time.Chronology) iSOChronology3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(chronology20);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100.0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.centuryOfEra();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 0, 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) ' ', (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant13);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        java.lang.String str12 = iSOChronology11.toString();
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone15.getShortName(1L, locale18);
//        long long21 = dateTimeZone15.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology22 = iSOChronology2.withZone(dateTimeZone15);
//        java.lang.String str24 = dateTimeZone15.getShortName((long) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UTC" + "'", str24.equals("UTC"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Hours hours6 = period3.toStandardHours();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Period period9 = period3.withFieldAdded(durationFieldType7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology3);
        org.joda.time.Period period6 = period4.plusMillis(0);
        int int7 = period4.getSeconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.get(durationFieldType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period4.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Days days15 = period14.toStandardDays();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(days15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11);
        org.joda.time.Period period14 = period12.withMinutes(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology3);
        org.joda.time.Period period6 = period4.plusMillis(0);
        int int7 = period4.getSeconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.get(durationFieldType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period4.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period16 = period14.plusMonths((int) '#');
        int int17 = period16.getMillis();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(2440587L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5282475348d + "'", double1 == 2440587.5282475348d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 8, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 90L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) -1, (java.lang.Number) 100, (java.lang.Number) 2440587.5282475348d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfCentury();
        try {
            long long11 = iSOChronology2.getDateTimeMillis(0, 32, (int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("GregorianChronology[UTC]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period27.toString(periodFormatter31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT0.001S" + "'", str32.equals("PT0.001S"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = period4.isSupported(durationFieldType5);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period4.getFieldTypes();
        try {
            int int9 = period4.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            long long12 = iSOChronology2.set(readablePartial10, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.Period period26 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period28 = period26.minusWeeks(0);
        org.joda.time.Period period30 = period26.withDays(1);
        boolean boolean31 = gregorianChronology3.equals((java.lang.Object) period30);
        org.joda.time.Period period33 = period30.plusYears(0);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        java.lang.String str40 = iSOChronology39.toString();
        org.joda.time.DurationField durationField41 = iSOChronology39.days();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology44 = iSOChronology39.withZone(dateTimeZone43);
        org.joda.time.Period period45 = new org.joda.time.Period(0L, (long) (short) 0, periodType36, chronology44);
        try {
            org.joda.time.Period period46 = period30.normalizedStandard(periodType36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[UTC]" + "'", str40.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(chronology44);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) (byte) 100, 5200, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.ReadablePartial readablePartial30 = null;
        try {
            long long32 = zonedChronology22.set(readablePartial30, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) (short) 1, (java.lang.Number) 5200L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        java.lang.String str15 = gregorianChronology3.toString();
        try {
            long long20 = gregorianChronology3.getDateTimeMillis(0, (int) (short) 100, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[UTC]" + "'", str15.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((long) 1);
//        java.lang.String str4 = dateTimeZone0.getName(10L);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        int int7 = dateTimeZone0.getOffset(readableInstant6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology3);
        org.joda.time.Period period6 = period4.plusMillis(0);
        org.joda.time.PeriodType periodType7 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = periodType7.indexOf(durationFieldType8);
        int int10 = periodType7.size();
        org.joda.time.PeriodType periodType11 = periodType7.withMonthsRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withMonthsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 1, periodType11);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-61895577599900L), (java.lang.Number) 0, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) ' ');
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int[] intArray9 = iSOChronology2.get(readablePartial7, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(10);
        org.joda.time.Period period3 = period1.plusYears((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) -1, (int) (byte) 100, 0, (int) '4');
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        try {
            long long21 = gregorianChronology3.getDateTimeMillis(32, (int) (byte) -1, 32, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        long long23 = cachedDateTimeZone21.previousTransition((-1L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 100, 32, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int22 = fixedDateTimeZone19.getOffset((long) 10);
        java.util.TimeZone timeZone23 = fixedDateTimeZone19.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 32 + "'", int22 == 32);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', chronology1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, (int) ' ', 5200, (int) (byte) 1, (int) '#', (int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("ISOChronology[UTC]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", (java.lang.Number) (-1560629399750L), (java.lang.Number) 5300L, (java.lang.Number) (short) -1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-1), 32, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, 0, (int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PeriodType[Standard]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Object obj0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period(obj0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology2.weekyears();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) ' ');
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeField5, (java.lang.Object) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period3.withSeconds((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = iSOChronology28.toString();
        org.joda.time.DurationField durationField30 = iSOChronology28.days();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology33 = iSOChronology28.withZone(dateTimeZone32);
        int int35 = dateTimeZone32.getOffsetFromLocal(1560629399750L);
        long long37 = dateTimeZone32.convertUTCToLocal((long) (byte) -1);
        java.lang.String str38 = dateTimeZone32.getID();
        boolean boolean39 = period25.equals((java.lang.Object) dateTimeZone32);
        org.joda.time.Period period40 = org.joda.time.Period.ZERO;
        org.joda.time.Period period42 = period40.withYears((int) ' ');
        org.joda.time.Period period44 = period42.withWeeks((int) (byte) 100);
        int int45 = period42.getWeeks();
        org.joda.time.Period period46 = period25.withFields((org.joda.time.ReadablePeriod) period42);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ISOChronology[UTC]" + "'", str29.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(period46);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) 'a', (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str6 = fixedDateTimeZone4.getName(0L);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        boolean boolean10 = fixedDateTimeZone4.isStandardOffset((long) (byte) 100);
        long long12 = fixedDateTimeZone4.previousTransition((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.032" + "'", str6.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0d), (java.lang.Number) (byte) 10, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Period period17 = period3.plusMonths((int) (short) 10);
        try {
            org.joda.time.Seconds seconds18 = period17.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) '4', (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', periodType13, chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = null;
        int int31 = periodType29.indexOf(durationFieldType30);
        int int32 = periodType29.size();
        org.joda.time.PeriodType periodType33 = periodType29.withMonthsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType29);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant35);
        org.joda.time.Period period37 = period36.toPeriod();
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.PeriodType periodType11 = periodType8.withMinutesRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.Period period1 = org.joda.time.Period.months(0);
        org.joda.time.Period period3 = period1.minusHours((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        long long5 = dateTimeZone1.convertUTCToLocal(5200L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5200L + "'", long5 == 5200L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(5200, (int) '4', 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4999999884d + "'", double1 == 2440587.4999999884d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((long) 1);
//        java.lang.String str4 = dateTimeZone0.getName(10L);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField6 = iSOChronology5.months();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period8.withDays(1);
        try {
            org.joda.time.Days days13 = period12.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PT0.001S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period(0L, (long) 10, periodType5, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) -1, (long) 5200, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 8, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period25 = period23.multipliedBy(0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        org.joda.time.Period period5 = period2.toPeriod();
        org.joda.time.Period period7 = period5.plusMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 1);
        boolean boolean3 = dateTimeZone1.isStandardOffset(34L);
        long long7 = dateTimeZone1.convertLocalToUTC(5200L, false, (long) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3594800L) + "'", long7 == (-3594800L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology3);
        org.joda.time.Period period6 = period4.plusMillis(0);
        int int7 = period4.getSeconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.get(durationFieldType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period4.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        int int15 = period14.getMillis();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (byte) -1, (int) (byte) 10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2, chronology4);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, (int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 1, "PT0.001S");
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.plusSeconds(32);
        try {
            int int50 = period48.getValue(5200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5200");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Seconds");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str6 = iSOChronology5.toString();
        org.joda.time.DurationField durationField7 = iSOChronology5.days();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology5.withZone(dateTimeZone9);
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) (short) 0, periodType2, chronology10);
        boolean boolean13 = periodType2.equals((java.lang.Object) 1L);
        org.joda.time.PeriodType periodType14 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) '#', periodType16, chronology17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period18.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period23 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType22);
        int int24 = period23.getMinutes();
        boolean boolean25 = periodType14.equals((java.lang.Object) period23);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        try {
            org.joda.time.Period period28 = period23.withField(durationFieldType26, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.lang.String str37 = iSOChronology36.toString();
        boolean boolean39 = iSOChronology36.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField40 = iSOChronology36.millis();
        long long43 = durationField40.subtract((long) '#', (int) (short) 1);
        boolean boolean44 = gregorianChronology33.equals((java.lang.Object) durationField40);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology50 = gregorianChronology33.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology54);
        org.joda.time.Period period57 = period55.plusMillis(0);
        org.joda.time.Period period59 = period57.multipliedBy(10);
        boolean boolean60 = cachedDateTimeZone51.equals((java.lang.Object) period57);
        boolean boolean61 = zonedChronology22.equals((java.lang.Object) cachedDateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[UTC]" + "'", str37.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) -1, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        org.joda.time.Period period5 = period2.toPeriod();
        int int6 = period2.getMinutes();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DurationField durationField17 = gregorianChronology3.minutes();
        try {
            long long25 = gregorianChronology3.getDateTimeMillis((int) (short) 1, (int) (byte) 10, 8, 8, 10, 5200, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType24 = null;
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) '#', periodType24, chronology25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Duration duration28 = period26.toDurationFrom(readableInstant27);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period31 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration28, readableInstant29, periodType30);
        org.joda.time.PeriodType periodType34 = null;
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) '#', periodType34, chronology35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period36.toDurationFrom(readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration38, readableInstant39, periodType40);
        org.joda.time.Period period42 = new org.joda.time.Period((long) (short) 0, periodType40);
        org.joda.time.Period period43 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration28, periodType40);
        boolean boolean44 = fixedDateTimeZone19.equals((java.lang.Object) period43);
        org.joda.time.Seconds seconds45 = period43.toStandardSeconds();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(seconds45);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField6 = iSOChronology2.millis();
        org.joda.time.DurationField durationField7 = iSOChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 5200, (long) (byte) 100);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DurationField durationField8 = iSOChronology2.millis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) -1, (java.lang.Number) 5200L, (java.lang.Number) 1560629399750L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = periodType22.indexOf(durationFieldType23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType22, (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.Period period30 = period28.withWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period28.toDurationTo(readableInstant31);
        boolean boolean33 = period13.equals((java.lang.Object) duration32);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 0, (java.lang.Number) 10.0f, (java.lang.Number) 34L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) 0);
        int int8 = fixedDateTimeZone4.getOffset((long) 'a');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DurationField durationField17 = gregorianChronology3.minutes();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField20 = new org.joda.time.field.ScaledDurationField(durationField17, durationFieldType18, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.plusSeconds(32);
        int int49 = period48.getMonths();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(5200L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 100, "PT0.035S");
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = iSOChronology7.toString();
        org.joda.time.DurationField durationField9 = iSOChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.clockhourOfDay();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology15);
        org.joda.time.Period period18 = period16.plusMillis(0);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = periodType19.indexOf(durationFieldType20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType19, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) period25);
        int[] intArray29 = iSOChronology7.get((org.joda.time.ReadablePeriod) period26, 0L, 0L);
        try {
            gregorianChronology0.validate(readablePartial4, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        long long11 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 5200);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210417480000000L) + "'", long1 == (-210417480000000L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period3, (java.lang.Object) 1.0f);
        org.joda.time.Period period7 = period3.minusWeeks(8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        java.lang.String str15 = iSOChronology14.toString();
        org.joda.time.DurationField durationField16 = iSOChronology14.days();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.hourOfDay();
        org.joda.time.Chronology chronology18 = iSOChronology14.withUTC();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 100, 0L, periodType11, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType11);
        org.joda.time.PeriodType periodType21 = periodType11.withWeeksRemoved();
        org.joda.time.Period period22 = new org.joda.time.Period(5300L, periodType21);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType11, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 10, periodType2, (org.joda.time.Chronology) iSOChronology16);
        java.lang.String str19 = iSOChronology16.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PeriodType[Standard]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PeriodType[Standard]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        int int9 = period3.getYears();
        org.joda.time.Period period11 = period3.plusMonths(5200);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (long) (short) 0, periodType8, chronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, 10L, periodType5, chronology16);
        int int19 = period18.getWeeks();
        int int20 = period18.getDays();
        org.joda.time.Period period21 = period2.withFields((org.joda.time.ReadablePeriod) period18);
        int int22 = period18.getDays();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', periodType13, chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = null;
        int int31 = periodType29.indexOf(durationFieldType30);
        int int32 = periodType29.size();
        org.joda.time.PeriodType periodType33 = periodType29.withMonthsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType29);
        org.joda.time.Minutes minutes35 = period34.toStandardMinutes();
        org.joda.time.Period period37 = period34.minusSeconds(0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(minutes35);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-2L), (java.lang.Number) (byte) 10, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "P-1W" + "'", str3.equals("P-1W"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        long long29 = lenientChronology24.getDateTimeMillis(8, 8, (int) (byte) 10, 100);
        long long35 = lenientChronology24.getDateTimeMillis(90L, (int) (short) 1, 5200, (int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61895577599900L) + "'", long29 == (-61895577599900L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 315699999L + "'", long35 == 315699999L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        org.joda.time.Period period5 = period2.negated();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("GregorianChronology[UTC]");
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.weekOfWeekyear();
        java.lang.String str18 = iSOChronology11.toString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.Period period26 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period28 = period26.minusWeeks(0);
        org.joda.time.Period period30 = period26.withDays(1);
        boolean boolean31 = gregorianChronology3.equals((java.lang.Object) period30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField32, dateTimeFieldType33, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        int int14 = period11.getSeconds();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period11.get(durationFieldType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period11.toDurationFrom(readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant19, periodType20);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((int) (byte) 1, (int) (byte) 0, 10, (int) (byte) 1, 0, (int) (byte) 1, (int) (byte) 10, 3, periodType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(periodType20);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.weekyears();
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray36 = period35.getValues();
        try {
            zonedChronology22.validate(readablePartial32, intArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) 100.0d, (java.lang.Number) 5200L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', periodType2, chronology3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology11);
        org.joda.time.Period period14 = period12.plusMillis(0);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        int int17 = periodType15.indexOf(durationFieldType16);
        int int18 = periodType15.size();
        org.joda.time.PeriodType periodType19 = periodType15.withMonthsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType15);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = periodType15.indexOf(durationFieldType21);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period(0L, (long) 10, periodType5, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) -1, (long) 5200, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 8, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period24 = org.joda.time.Period.ZERO;
        org.joda.time.Period period26 = period24.withYears((int) ' ');
        org.joda.time.Period period28 = period26.withWeeks((int) (byte) 100);
        org.joda.time.Period period30 = period28.minusYears(0);
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 8, (java.lang.Object) period30);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.Period period26 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period28 = period26.minusWeeks(0);
        org.joda.time.Period period30 = period26.withDays(1);
        boolean boolean31 = gregorianChronology3.equals((java.lang.Object) period30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone33);
        boolean boolean35 = gregorianChronology3.equals((java.lang.Object) dateTimeZone33);
        try {
            long long43 = gregorianChronology3.getDateTimeMillis(5200, 3, 0, (int) (byte) 100, 8, (int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00:00.032");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField25 = lenientChronology24.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        int int9 = dateTimeZone6.getOffsetFromLocal(1560629399750L);
        int int11 = dateTimeZone6.getOffsetFromLocal(1560629399750L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        try {
            long long13 = iSOChronology2.getDateTimeMillis((int) 'a', 10, 0, 0, 10, (int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Seconds");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) (short) -1);
        org.joda.time.Period period4 = period2.withDays(0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = periodType6.indexOf(durationFieldType7);
        boolean boolean10 = periodType6.equals((java.lang.Object) 0.0d);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = periodType6.isSupported(durationFieldType11);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        java.lang.String str12 = iSOChronology11.toString();
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone15.getShortName(1L, locale18);
//        long long21 = dateTimeZone15.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology22 = iSOChronology2.withZone(dateTimeZone15);
//        java.lang.String str23 = dateTimeZone15.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
        org.joda.time.Period period3 = period1.withYears((int) 'a');
        org.joda.time.Period period5 = period1.plusMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.plusSeconds(32);
        try {
            org.joda.time.Period period50 = period48.withDays(32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone13 = dateTimeZone6.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        int int17 = dateTimeZone6.getOffset(readableInstant16);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("100.0", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.Period period18 = period16.plusMinutes(100);
        org.joda.time.Days days19 = period16.toStandardDays();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(days19);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long2 = dateTimeZone0.convertUTCToLocal((long) 1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "LenientChronology[ISOChronology[UTC]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(1);
        org.joda.time.Period period3 = period1.minusMinutes(100);
        org.joda.time.Seconds seconds4 = period3.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = period3.get(durationFieldType5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(seconds4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0.035S", (java.lang.Number) 1.0f, (java.lang.Number) 100L, (java.lang.Number) 10L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "100.0", "UTC");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField9 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        long long15 = dateTimeZone6.adjustOffset(0L, true);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone6.getShortName(34L, locale17);
//        java.lang.String str19 = dateTimeZone6.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.032" + "'", str10.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.032" + "'", str18.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[UTC]" + "'", str19.equals("ISOChronology[UTC]"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period5.getMonths();
        org.joda.time.Period period8 = period5.withHours(10);
        org.joda.time.Period period10 = period8.minusSeconds((int) (byte) -1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long9 = iSOChronology1.getDateTimeMillis(8, 0, 3, 0, 0, (int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.days();
        try {
            long long37 = zonedChronology22.getDateTimeMillis(10L, (int) (short) 10, (int) (short) -1, 32, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = iSOChronology7.toString();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField11 = iSOChronology7.millis();
        long long14 = durationField11.subtract((long) '#', (int) (short) 1);
        boolean boolean15 = gregorianChronology4.equals((java.lang.Object) durationField11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str22 = fixedDateTimeZone20.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology23.getZone();
        long long30 = zonedChronology23.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone31 = zonedChronology23.getZone();
        org.joda.time.DurationField durationField32 = zonedChronology23.weekyears();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 34L + "'", long14 == 34L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.032" + "'", str22.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3609976L + "'", long30 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType11, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 10, periodType2, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DurationField durationField19 = iSOChronology16.eras();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.Chronology chronology22 = iSOChronology16.withZone(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology16.dayOfYear();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology8);
        org.joda.time.Period period11 = period9.plusMillis(0);
        org.joda.time.PeriodType periodType12 = period11.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = periodType12.indexOf(durationFieldType13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType12, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 10, periodType3, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DurationField durationField20 = iSOChronology17.eras();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        java.lang.String str28 = iSOChronology27.toString();
        boolean boolean30 = iSOChronology27.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField31 = iSOChronology27.millis();
        long long34 = durationField31.subtract((long) '#', (int) (short) 1);
        boolean boolean35 = gregorianChronology24.equals((java.lang.Object) durationField31);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str42 = fixedDateTimeZone40.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, (org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone44 = zonedChronology43.getZone();
        long long50 = zonedChronology43.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone51 = zonedChronology43.getZone();
        org.joda.time.DurationField durationField52 = zonedChronology43.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField53 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField20, durationField52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[UTC]" + "'", str28.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 34L + "'", long34 == 34L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+00:00:00.032" + "'", str42.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3609976L + "'", long50 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(durationField52);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        int int2 = period1.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 32, 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        java.lang.String str15 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.year();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[UTC]" + "'", str15.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        org.joda.time.DurationField durationField26 = lenientChronology24.seconds();
        long long29 = durationField26.subtract((long) (short) 1, 5200);
        org.joda.time.DurationFieldType durationFieldType30 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType30, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-5199999L) + "'", long29 == (-5199999L));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone13 = dateTimeZone6.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone15.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.032" + "'", str10.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(4, 32, (int) '#', 5200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(3609976L, 2440587L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1169389L + "'", long2 == 1169389L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        int int15 = period14.getMillis();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 201 + "'", int15 == 201);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField14 = iSOChronology10.millis();
        long long17 = durationField14.subtract((long) '#', (int) (short) 1);
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) durationField14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str25 = fixedDateTimeZone23.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
        long long33 = zonedChronology26.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology26.getZone();
        boolean boolean35 = iSOChronology2.equals((java.lang.Object) zonedChronology26);
        try {
            long long43 = zonedChronology26.getDateTimeMillis(10, (int) (byte) 0, (int) ' ', 0, 0, 201, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 201 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.032" + "'", str25.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3609976L + "'", long33 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("P-1W");
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Period period1 = org.joda.time.Period.hours(5200);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) '#', periodType4, chronology5);
        org.joda.time.Period period15 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period17 = period15.minusWeeks(0);
        boolean boolean18 = period6.equals((java.lang.Object) period15);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology21);
        org.joda.time.Period period24 = period22.plusMillis(0);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.Period period26 = period6.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period2.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period29 = period27.minusMinutes((int) (byte) -1);
        org.joda.time.Weeks weeks30 = period27.toStandardWeeks();
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(weeks30);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(32, (int) ' ', 8, (int) (byte) -1, 100, 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField25 = lenientChronology24.eras();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) '#', periodType27, chronology28);
        org.joda.time.Period period38 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period40 = period38.minusWeeks(0);
        boolean boolean41 = period29.equals((java.lang.Object) period38);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.Period period45 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology44);
        org.joda.time.Period period47 = period45.plusMillis(0);
        org.joda.time.PeriodType periodType48 = period47.getPeriodType();
        org.joda.time.Period period49 = period29.plus((org.joda.time.ReadablePeriod) period47);
        org.joda.time.Period period51 = period47.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType53 = period47.getFieldType((int) (short) 0);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField54 = new org.joda.time.field.DecoratedDurationField(durationField25, durationFieldType53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(durationFieldType53);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-210417480000000L), (java.lang.Number) (-1.0f), (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.field.FieldUtils.verifyValueBounds("", 0, (-1), (int) (byte) 100);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Minutes minutes6 = period3.toStandardMinutes();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(minutes6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(0, (int) (short) 100, (int) (short) -1, 5200, 32, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period6 = period4.withMillis(4);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap25 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        boolean boolean26 = lenientChronology24.equals((java.lang.Object) strMap25);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap25);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(strMap25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology25 = lenientChronology24.withUTC();
        java.lang.String str26 = lenientChronology24.toString();
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.Period period30 = new org.joda.time.Period(10L, (long) ' ');
        int[] intArray31 = period30.getValues();
        try {
            lenientChronology24.validate(readablePartial27, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str26.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(intArray31);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560629429365L + "'", long1 == 1560629429365L);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.Period period26 = period25.negated();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.Period period14 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period16 = period14.minusWeeks(0);
        boolean boolean17 = period5.equals((java.lang.Object) period14);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology20);
        org.joda.time.Period period23 = period21.plusMillis(0);
        org.joda.time.PeriodType periodType24 = period23.getPeriodType();
        org.joda.time.Period period25 = period5.plus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period27 = period23.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationFrom(readableInstant28);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        java.lang.String str40 = iSOChronology39.toString();
        org.joda.time.DurationField durationField41 = iSOChronology39.days();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology39.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology44 = iSOChronology39.withZone(dateTimeZone43);
        org.joda.time.Period period45 = new org.joda.time.Period(0L, (long) (short) 0, periodType36, chronology44);
        org.joda.time.Period period46 = new org.joda.time.Period(0L, 10L, periodType33, chronology44);
        org.joda.time.PeriodType periodType47 = periodType33.withMinutesRemoved();
        org.joda.time.Period period48 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration29, readableInstant30, periodType47);
        try {
            org.joda.time.Period period49 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[UTC]" + "'", str40.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(periodType47);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.032", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.032/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.weeks();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology2.set(readablePartial6, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Period period17 = period12.minusDays((int) (short) 1);
        org.joda.time.Period period19 = period17.minusSeconds(3);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology5);
        org.joda.time.Period period8 = period6.plusMillis(0);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = periodType9.indexOf(durationFieldType10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType9, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.Period period17 = period15.withWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = period15.toDurationTo(readableInstant18);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration19);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000000116d + "'", double1 == 2440587.5000000116d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "UTC");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        int int24 = period23.getMillis();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 36 + "'", int24 == 36);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        int int5 = period4.getYears();
        org.joda.time.Period period7 = period4.withYears(0);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.Period period10 = period7.plusDays((int) '#');
        org.joda.time.Period period12 = period10.plusMonths(0);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P-1W");
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.Hours hours22 = period21.toStandardHours();
        org.joda.time.Period period23 = period21.toPeriod();
        int[] intArray25 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (-210865896000000L));
        try {
            long long33 = iSOChronology2.getDateTimeMillis((int) (byte) 10, (-52), 201, 36, 32, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(hours22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        int int5 = period4.getYears();
        org.joda.time.Period period7 = period4.withYears(0);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.Period period10 = period7.plusDays((int) '#');
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period7.toString(periodFormatter11);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "P100W" + "'", str12.equals("P100W"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.Period period8 = period6.withMinutes((int) (byte) 100);
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period8);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int22 = fixedDateTimeZone19.getOffset((long) 10);
        int int24 = fixedDateTimeZone19.getOffset(34L);
        long long26 = fixedDateTimeZone19.nextTransition((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 32 + "'", int22 == 32);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 32 + "'", int24 == 32);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long2 = dateTimeZone0.convertUTCToLocal((long) 1);
//        java.lang.String str4 = dateTimeZone0.getName(10L);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        java.lang.String str6 = dateTimeZone0.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.032" + "'", str4.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        java.lang.String str28 = iSOChronology27.toString();
        boolean boolean30 = iSOChronology27.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology35);
        org.joda.time.Period period38 = period36.plusMillis(0);
        org.joda.time.PeriodType periodType39 = period38.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType40 = null;
        int int41 = periodType39.indexOf(durationFieldType40);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        org.joda.time.Period period45 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType39, (org.joda.time.Chronology) iSOChronology44);
        org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) period45);
        int[] intArray48 = iSOChronology27.get((org.joda.time.ReadablePeriod) period46, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology49 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology27);
        long long54 = lenientChronology49.getDateTimeMillis(8, 8, (int) (byte) 10, 100);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone56);
        long long60 = dateTimeZone56.convertUTCToLocal((long) (byte) 10);
        org.joda.time.Chronology chronology61 = lenientChronology49.withZone(dateTimeZone56);
        org.joda.time.DurationField durationField62 = lenientChronology49.weekyears();
        try {
            org.joda.time.Period period63 = new org.joda.time.Period((java.lang.Object) iSOChronology2, (org.joda.time.Chronology) lenientChronology49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ISOChronology[UTC]" + "'", str28.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(lenientChronology49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61895577599900L) + "'", long54 == (-61895577599900L));
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(iSOChronology57);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 10L + "'", long60 == 10L);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(durationField62);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.Period period26 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period28 = period26.minusWeeks(0);
        org.joda.time.Period period30 = period26.withDays(1);
        boolean boolean31 = gregorianChronology3.equals((java.lang.Object) period30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology3.secondOfDay();
        org.joda.time.DurationField durationField33 = gregorianChronology3.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(0L, periodType3);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', periodType6, chronology7);
        org.joda.time.Period period17 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period19 = period17.minusWeeks(0);
        boolean boolean20 = period8.equals((java.lang.Object) period17);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology23);
        org.joda.time.Period period26 = period24.plusMillis(0);
        org.joda.time.PeriodType periodType27 = period26.getPeriodType();
        org.joda.time.Period period28 = period8.plus((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Period period29 = period4.plus((org.joda.time.ReadablePeriod) period26);
        boolean boolean30 = jodaTimePermission1.equals((java.lang.Object) period4);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.yearOfCentury();
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(lenientChronology8);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.clockhourOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, 32, 10, 32);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DurationField durationField17 = gregorianChronology3.minutes();
        try {
            long long22 = gregorianChronology3.getDateTimeMillis(32, (-52), 5200, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        long long29 = lenientChronology24.getDateTimeMillis(8, 8, (int) (byte) 10, 100);
        org.joda.time.DateTimeField dateTimeField30 = lenientChronology24.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField30, dateTimeFieldType31, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61895577599900L) + "'", long29 == (-61895577599900L));
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.plusDays((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology12);
        org.joda.time.Period period15 = period13.plusMillis(0);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = periodType16.indexOf(durationFieldType17);
        int int19 = periodType16.size();
        org.joda.time.PeriodType periodType20 = periodType16.withMonthsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType16);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        long long23 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Hours hours16 = period15.toStandardHours();
        org.joda.time.Period period17 = period15.toPeriod();
        org.joda.time.Period period19 = period17.multipliedBy(0);
        org.joda.time.Period period21 = period17.withDays((int) (byte) 100);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(hours16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-52), 8, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
//        org.joda.time.Period period13 = period11.plusMillis(0);
//        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        int int16 = periodType14.indexOf(durationFieldType15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
//        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        java.lang.String str27 = iSOChronology26.toString();
//        org.joda.time.DurationField durationField28 = iSOChronology26.minutes();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.lang.String str33 = iSOChronology32.toString();
//        org.joda.time.DurationField durationField34 = iSOChronology32.days();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology37 = iSOChronology32.withZone(dateTimeZone36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone36.getShortName(1L, locale39);
//        long long42 = dateTimeZone36.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology43 = iSOChronology26.withZone(dateTimeZone36);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone36);
//        boolean boolean46 = zonedChronology44.equals((java.lang.Object) (-10L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[UTC]" + "'", str33.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(5200);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.lang.String str5 = iSOChronology4.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology4.days();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone8.getShortName(1L, locale11);
//        long long14 = dateTimeZone8.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone15 = dateTimeZone8.toTimeZone();
//        long long17 = dateTimeZone1.getMillisKeepLocal(dateTimeZone8, (long) 5200);
//        long long20 = dateTimeZone8.adjustOffset(100L, false);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10400L + "'", long17 == 10400L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        int int5 = period4.getYears();
        org.joda.time.Period period7 = period4.withYears(0);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.Minutes minutes9 = period7.toStandardMinutes();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, 32L);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.lang.String str5 = iSOChronology4.toString();
//        org.joda.time.DurationField durationField6 = iSOChronology4.days();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone8.getShortName(1L, locale11);
//        long long14 = dateTimeZone8.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone15 = dateTimeZone8.toTimeZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology1.withZone(dateTimeZone8);
//        boolean boolean18 = dateTimeZone8.isStandardOffset((long) 8);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        int int11 = periodType8.size();
        org.joda.time.PeriodType periodType12 = periodType8.withMonthsRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withMonthsRemoved();
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) 1, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology30);
        org.joda.time.Period period33 = period31.plusMillis(0);
        org.joda.time.PeriodType periodType34 = period33.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType35 = null;
        int int36 = periodType34.indexOf(durationFieldType35);
        int int37 = periodType34.size();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone43);
        java.lang.String str45 = iSOChronology44.toString();
        boolean boolean47 = iSOChronology44.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField48 = iSOChronology44.millis();
        long long51 = durationField48.subtract((long) '#', (int) (short) 1);
        boolean boolean52 = gregorianChronology41.equals((java.lang.Object) durationField48);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str59 = fixedDateTimeZone57.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology60 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, (org.joda.time.DateTimeZone) fixedDateTimeZone57);
        org.joda.time.DateTimeZone dateTimeZone61 = zonedChronology60.getZone();
        try {
            org.joda.time.Period period62 = new org.joda.time.Period((java.lang.Object) durationFieldType27, periodType34, (org.joda.time.Chronology) zonedChronology60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DurationFieldType$StandardDurationFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ISOChronology[UTC]" + "'", str45.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 34L + "'", long51 == 34L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "+00:00:00.032" + "'", str59.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.joda.time.DurationField durationField5 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.clockhourOfDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField8 = iSOChronology3.weeks();
        long long11 = durationField8.subtract((-10L), 0);
        long long14 = durationField8.subtract(3609976L, 100);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-60476390024L) + "'", long14 == (-60476390024L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1 + "'", number7.equals(1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) '#', periodType4, chronology5);
        org.joda.time.Period period15 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period17 = period15.minusWeeks(0);
        boolean boolean18 = period6.equals((java.lang.Object) period15);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology21);
        org.joda.time.Period period24 = period22.plusMillis(0);
        org.joda.time.PeriodType periodType25 = period24.getPeriodType();
        org.joda.time.Period period26 = period6.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period2.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period29 = period27.minusMinutes((int) (byte) -1);
        int int30 = period27.getSeconds();
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "GregorianChronology[UTC]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "Standard", "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField25 = lenientChronology24.eras();
        org.joda.time.DateTimeField dateTimeField26 = lenientChronology24.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField26, dateTimeFieldType27, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
//        org.joda.time.Period period13 = period11.plusMillis(0);
//        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        int int16 = periodType14.indexOf(durationFieldType15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
//        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
//        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
//        long long29 = lenientChronology24.getDateTimeMillis(8, 8, (int) (byte) 10, 100);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.lang.String str33 = iSOChronology32.toString();
//        org.joda.time.DurationField durationField34 = iSOChronology32.days();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology37 = iSOChronology32.withZone(dateTimeZone36);
//        org.joda.time.DurationField durationField38 = iSOChronology32.hours();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
//        java.lang.String str42 = iSOChronology41.toString();
//        org.joda.time.DurationField durationField43 = iSOChronology41.days();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology41.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology46 = iSOChronology41.withZone(dateTimeZone45);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dateTimeZone45.getShortName(1L, locale48);
//        long long51 = dateTimeZone45.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology52 = iSOChronology32.withZone(dateTimeZone45);
//        long long55 = dateTimeZone45.adjustOffset((long) (short) 0, false);
//        org.joda.time.Chronology chronology56 = lenientChronology24.withZone(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(lenientChronology24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61895577599900L) + "'", long29 == (-61895577599900L));
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[UTC]" + "'", str33.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ISOChronology[UTC]" + "'", str42.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "UTC" + "'", str49.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertNotNull(chronology56);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        try {
            long long31 = unsupportedDurationField29.getMillis(36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField14 = iSOChronology10.millis();
        long long17 = durationField14.subtract((long) '#', (int) (short) 1);
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) durationField14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str25 = fixedDateTimeZone23.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
        long long33 = zonedChronology26.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology26.getZone();
        boolean boolean35 = iSOChronology2.equals((java.lang.Object) zonedChronology26);
        org.joda.time.ReadablePartial readablePartial36 = null;
        try {
            int[] intArray38 = iSOChronology2.get(readablePartial36, (long) (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.032" + "'", str25.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3609976L + "'", long33 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        try {
            int int32 = unsupportedDurationField29.getDifference(34L, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DurationField durationField9 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology0.months();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.hourOfDay();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology17);
        org.joda.time.Period period20 = period18.plusMillis(0);
        org.joda.time.PeriodType periodType21 = period20.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType22 = null;
        int int23 = periodType21.indexOf(durationFieldType22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType21, (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period27);
        org.joda.time.Hours hours29 = period28.toStandardHours();
        org.joda.time.Period period30 = period28.toPeriod();
        int[] intArray32 = iSOChronology9.get((org.joda.time.ReadablePeriod) period28, (-210865896000000L));
        try {
            gregorianChronology0.validate(readablePartial6, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(hours29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000010417d + "'", double1 == 2440587.5000010417d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology24 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap25 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        boolean boolean26 = lenientChronology24.equals((java.lang.Object) strMap25);
        org.joda.time.Period period28 = org.joda.time.Period.weeks(1);
        boolean boolean29 = lenientChronology24.equals((java.lang.Object) 1);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology32);
        org.joda.time.Period period35 = period33.plusMillis(0);
        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType37 = null;
        int int38 = periodType36.indexOf(durationFieldType37);
        org.joda.time.PeriodType periodType39 = periodType36.withYearsRemoved();
        org.joda.time.PeriodType periodType40 = periodType39.withSecondsRemoved();
        try {
            org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) lenientChronology24, periodType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.LenientChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(lenientChronology24);
        org.junit.Assert.assertNotNull(strMap25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        org.joda.time.DurationField durationField8 = iSOChronology2.hours();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        java.lang.String str12 = iSOChronology11.toString();
//        org.joda.time.DurationField durationField13 = iSOChronology11.days();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology16 = iSOChronology11.withZone(dateTimeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone15.getShortName(1L, locale18);
//        long long21 = dateTimeZone15.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology22 = iSOChronology2.withZone(dateTimeZone15);
//        long long25 = dateTimeZone15.adjustOffset((long) (short) 0, false);
//        org.joda.time.LocalDateTime localDateTime26 = null;
//        boolean boolean27 = dateTimeZone15.isLocalDateTimeGap(localDateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) (short) -1);
        org.joda.time.Period period4 = period2.plusMonths((int) (byte) 0);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '#', periodType2, chronology3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType8);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) '#', periodType12, chronology13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant17, periodType18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 0, periodType18);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType18);
        long long22 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration6);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        java.util.TimeZone timeZone13 = dateTimeZone6.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        boolean boolean16 = cachedDateTimeZone15.isFixed();
//        long long18 = cachedDateTimeZone15.previousTransition((-61895577599900L));
//        java.lang.String str19 = cachedDateTimeZone15.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61895577599900L) + "'", long18 == (-61895577599900L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission8);
        java.lang.String str11 = jodaTimePermission8.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.032" + "'", str11.equals("+00:00:00.032"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Period period1 = org.joda.time.Period.days(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        int int5 = period2.getWeeks();
        org.joda.time.Period period7 = period2.withWeeks(8);
        try {
            org.joda.time.Duration duration8 = period2.toStandardDuration();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Duration as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        int int31 = preciseDurationField29.getValue(5300L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology37);
        org.joda.time.Period period40 = period38.plusMillis(0);
        org.joda.time.PeriodType periodType41 = period40.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = periodType41.indexOf(durationFieldType42);
        int int44 = periodType41.size();
        org.joda.time.PeriodType periodType45 = periodType41.withMonthsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', 5300L, periodType41);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Duration duration48 = period46.toDurationFrom(readableInstant47);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology53);
        org.joda.time.Period period56 = period54.plusMillis(0);
        org.joda.time.PeriodType periodType57 = period56.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = periodType57.indexOf(durationFieldType58);
        int int60 = periodType57.size();
        org.joda.time.PeriodType periodType61 = periodType57.withMonthsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) 'a', 5300L, periodType57);
        org.joda.time.Period period63 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration48, periodType57);
        boolean boolean64 = preciseDurationField29.equals((java.lang.Object) duration48);
        java.lang.String str65 = preciseDurationField29.toString();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(duration48);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "DurationField[years]" + "'", str65.equals("DurationField[years]"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DurationField durationField9 = iSOChronology2.days();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.weekOfWeekyear();
        long long21 = iSOChronology11.add(315699999L, (long) 0, 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 315699999L + "'", long21 == 315699999L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField14 = iSOChronology10.millis();
        long long17 = durationField14.subtract((long) '#', (int) (short) 1);
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) durationField14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str25 = fixedDateTimeZone23.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
        long long33 = zonedChronology26.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology26.getZone();
        boolean boolean35 = iSOChronology2.equals((java.lang.Object) zonedChronology26);
        try {
            long long41 = zonedChronology26.getDateTimeMillis(2440588L, 3, (int) (short) 10, 201, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 201 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.032" + "'", str25.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3609976L + "'", long33 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Standard]");
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology2);
        try {
            long long14 = iSOChronology2.getDateTimeMillis((int) (short) 10, (int) (short) 10, 4, 0, 0, 201, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 201 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfMonth();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) '#', periodType9, chronology10);
        org.joda.time.Period period20 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period22 = period20.minusWeeks(0);
        boolean boolean23 = period11.equals((java.lang.Object) period20);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology26);
        org.joda.time.Period period29 = period27.plusMillis(0);
        org.joda.time.PeriodType periodType30 = period29.getPeriodType();
        org.joda.time.Period period31 = period11.plus((org.joda.time.ReadablePeriod) period29);
        org.joda.time.Period period33 = period11.withSeconds((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.lang.String str37 = iSOChronology36.toString();
        org.joda.time.DurationField durationField38 = iSOChronology36.days();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology41 = iSOChronology36.withZone(dateTimeZone40);
        int int43 = dateTimeZone40.getOffsetFromLocal(1560629399750L);
        long long45 = dateTimeZone40.convertUTCToLocal((long) (byte) -1);
        java.lang.String str46 = dateTimeZone40.getID();
        boolean boolean47 = period33.equals((java.lang.Object) dateTimeZone40);
        org.joda.time.Chronology chronology48 = iSOChronology2.withZone(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[UTC]" + "'", str37.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology48);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(1);
        org.joda.time.Period period3 = period1.minusMinutes(100);
        org.joda.time.Seconds seconds4 = period3.toStandardSeconds();
        org.joda.time.Period period6 = period3.withYears((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(seconds4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.Period period7 = period5.minusYears((int) (short) -1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Period period17 = period3.plusMonths((int) (short) 10);
        org.joda.time.Period period19 = period3.minusMinutes((int) (byte) 10);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        int int9 = period3.getMonths();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.Period period26 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period28 = period26.minusWeeks(0);
        org.joda.time.Period period30 = period26.withDays(1);
        boolean boolean31 = gregorianChronology3.equals((java.lang.Object) period30);
        try {
            long long36 = gregorianChronology3.getDateTimeMillis(5200, (-1), (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.centuryOfEra();
        org.joda.time.Period period15 = new org.joda.time.Period(8, (int) '#', (int) (byte) 1, (int) ' ');
        int[] intArray17 = iSOChronology2.get((org.joda.time.ReadablePeriod) period15, (long) (byte) 100);
        org.joda.time.Period period19 = period15.withWeeks(10);
        org.joda.time.Period period21 = period19.plusDays((int) (short) -1);
        org.joda.time.Period period23 = period19.plusWeeks(3);
        org.joda.time.Period period25 = period23.withYears(36);
        try {
            int int27 = period25.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePartial1, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.millisOfSecond();
        org.joda.time.DurationField durationField9 = iSOChronology2.hours();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType11, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.format.PeriodFormatter periodFormatter16 = null;
        java.lang.String str17 = period3.toString(periodFormatter16);
        org.joda.time.Period period19 = period3.withSeconds(36);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PT0.035S" + "'", str17.equals("PT0.035S"));
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period3.withSeconds((int) (byte) 10);
        org.joda.time.Period period27 = period3.plusWeeks((int) ' ');
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Duration duration29 = period27.toDurationTo(readableInstant28);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration29);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(315699999L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440591.1539351735d + "'", double1 == 2440591.1539351735d);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = dateTimeZone6.getShortName(1L, locale9);
//        long long12 = dateTimeZone6.convertUTCToLocal((long) (byte) 0);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = dateTimeZone6.getShortName(1169389L, locale14);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 100.0 for ISOChronology[UTC] must be in the range [0,1]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("UTC", "PT0S", 0, (int) (short) 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        java.lang.Object obj31 = null;
        boolean boolean32 = cachedDateTimeZone21.equals(obj31);
        java.lang.String str34 = cachedDateTimeZone21.getShortName((long) (short) 1);
        java.lang.String str36 = cachedDateTimeZone21.getNameKey(1169389L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.032" + "'", str34.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UTC" + "'", str36.equals("UTC"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology7 = iSOChronology2.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology2.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            long long39 = unsupportedDurationField36.add((-10L), (-1560629399750L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            long long39 = unsupportedDurationField36.getDifferenceAsLong((long) (short) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period16 = period14.withWeeks((int) (short) -1);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology19);
        org.joda.time.Period period22 = period20.plusMillis(0);
        org.joda.time.Period period24 = period22.withYears((int) (short) 0);
        org.joda.time.Period period25 = period16.plus((org.joda.time.ReadablePeriod) period22);
        java.lang.Object obj26 = null;
        boolean boolean27 = period25.equals(obj26);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        long long17 = durationField10.subtract((long) (short) 1, 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3609975L) + "'", long17 == (-3609975L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Days days4 = period3.toStandardDays();
        org.junit.Assert.assertNotNull(days4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        long long23 = cachedDateTimeZone21.nextTransition((long) 201);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 201L + "'", long23 == 201L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 31L, (java.lang.Number) 1.0f, (java.lang.Number) (-210417480000000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = illegalFieldValueException32.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNull(dateTimeFieldType33);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.lang.String str22 = fixedDateTimeZone19.getNameKey((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UTC" + "'", str22.equals("UTC"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Period period17 = period3.plusMonths((int) (short) 10);
        int int18 = period3.getYears();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str9 = iSOChronology8.toString();
        org.joda.time.DurationField durationField10 = iSOChronology8.days();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology13 = iSOChronology8.withZone(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period(0L, (long) (short) 0, periodType5, chronology13);
        org.joda.time.Period period15 = new org.joda.time.Period(0L, 10L, periodType2, chronology13);
        org.joda.time.PeriodType periodType16 = periodType2.withMinutesRemoved();
        int int17 = periodType16.size();
        java.lang.String str18 = periodType16.getName();
        org.joda.time.PeriodType periodType19 = periodType16.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Seconds" + "'", str18.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        long long30 = unsupportedDurationField29.getUnitMillis();
        try {
            long long33 = unsupportedDurationField29.add(0L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period0.withWeeks((int) '#');
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        int int26 = period25.getMillis();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            int int39 = unsupportedDurationField36.getValue(5200L, 34L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str3 = iSOChronology2.toString();
//        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
//        org.joda.time.Period period13 = period11.plusMillis(0);
//        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        int int16 = periodType14.indexOf(durationFieldType15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
//        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
//        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        java.lang.String str27 = iSOChronology26.toString();
//        org.joda.time.DurationField durationField28 = iSOChronology26.minutes();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology26.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.lang.String str33 = iSOChronology32.toString();
//        org.joda.time.DurationField durationField34 = iSOChronology32.days();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology37 = iSOChronology32.withZone(dateTimeZone36);
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dateTimeZone36.getShortName(1L, locale39);
//        long long42 = dateTimeZone36.convertUTCToLocal((long) (byte) 0);
//        org.joda.time.Chronology chronology43 = iSOChronology26.withZone(dateTimeZone36);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str46 = dateTimeZone45.toString();
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.Chronology chronology48 = iSOChronology2.withZone(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(periodType14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ISOChronology[UTC]" + "'", str27.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[UTC]" + "'", str33.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UTC" + "'", str40.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UTC" + "'", str46.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(chronology48);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Seconds", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 0.0f);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            long long38 = unsupportedDurationField36.getMillis((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        try {
            long long31 = unsupportedDurationField28.add((-2L), (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            long long39 = unsupportedDurationField36.getValueAsLong(0L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+00:00:00.032", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        boolean boolean7 = iSOChronology4.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology12);
        org.joda.time.Period period15 = period13.plusMillis(0);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = periodType16.indexOf(durationFieldType17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType16, (org.joda.time.Chronology) iSOChronology21);
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period22);
        int[] intArray25 = iSOChronology4.get((org.joda.time.ReadablePeriod) period23, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Chronology chronology27 = lenientChronology26.withUTC();
        java.lang.String str28 = lenientChronology26.toString();
        org.joda.time.Period period29 = new org.joda.time.Period((long) '4', periodType1, (org.joda.time.Chronology) lenientChronology26);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.lang.String str37 = iSOChronology36.toString();
        boolean boolean39 = iSOChronology36.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField40 = iSOChronology36.millis();
        long long43 = durationField40.subtract((long) '#', (int) (short) 1);
        boolean boolean44 = gregorianChronology33.equals((java.lang.Object) durationField40);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology50 = gregorianChronology33.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.PeriodType periodType54 = null;
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.Period period56 = new org.joda.time.Period((long) '#', periodType54, chronology55);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Duration duration58 = period56.toDurationFrom(readableInstant57);
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.PeriodType periodType60 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period61 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration58, readableInstant59, periodType60);
        org.joda.time.PeriodType periodType64 = null;
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period((long) '#', periodType64, chronology65);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.Duration duration68 = period66.toDurationFrom(readableInstant67);
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.PeriodType periodType70 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period71 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration68, readableInstant69, periodType70);
        org.joda.time.Period period72 = new org.joda.time.Period((long) (short) 0, periodType70);
        org.joda.time.Period period73 = new org.joda.time.Period(readableInstant52, (org.joda.time.ReadableDuration) duration58, periodType70);
        boolean boolean74 = fixedDateTimeZone49.equals((java.lang.Object) period73);
        org.joda.time.Chronology chronology75 = lenientChronology26.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        org.joda.time.DateTimeField dateTimeField76 = lenientChronology26.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str28.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[UTC]" + "'", str37.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertNotNull(duration58);
        org.junit.Assert.assertNotNull(periodType60);
        org.junit.Assert.assertNotNull(duration68);
        org.junit.Assert.assertNotNull(periodType70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology3);
        org.joda.time.Period period6 = period4.plusMillis(0);
        int int7 = period4.getSeconds();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.get(durationFieldType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period4.toDurationFrom(readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration11);
        int int15 = period14.getHours();
        int int16 = period14.getHours();
        org.joda.time.Period period17 = period14.normalizedStandard();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period2 = org.joda.time.Period.minutes(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.forFields(durationFieldTypeArray3);
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) '#', periodType6, chronology7);
        org.joda.time.Period period17 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period19 = period17.minusWeeks(0);
        boolean boolean20 = period8.equals((java.lang.Object) period17);
        org.joda.time.Period period22 = period17.minusDays((int) (short) 1);
        boolean boolean23 = periodType4.equals((java.lang.Object) period17);
        org.joda.time.Period period24 = new org.joda.time.Period(3218570035194834L, periodType4);
        java.lang.String str25 = periodType4.toString();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PeriodType[Standard]" + "'", str25.equals("PeriodType[Standard]"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology10);
        org.joda.time.Period period13 = period11.plusMillis(0);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = periodType14.indexOf(durationFieldType15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType14, (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) period20);
        int[] intArray23 = iSOChronology2.get((org.joda.time.ReadablePeriod) period21, (long) 8);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-35L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        try {
            long long15 = gregorianChronology0.getDateTimeMillis(4, (int) '#', (-52), (int) (short) 0, 0, (-52), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.Period period5 = org.joda.time.Period.ZERO;
        org.joda.time.Period period7 = period5.withYears((int) ' ');
        org.joda.time.Period period9 = period7.withWeeks((int) (byte) 100);
        int int10 = period9.getYears();
        long long13 = iSOChronology2.add((org.joda.time.ReadablePeriod) period9, 0L, (int) (byte) 0);
        try {
            org.joda.time.Hours hours14 = period9.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("Seconds", (java.lang.Number) (short) 0, (java.lang.Number) (short) 100, (java.lang.Number) 0.0f);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Number number14 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100.0f + "'", number14.equals(100.0f));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        int int31 = preciseDurationField29.getValue(5300L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology37);
        org.joda.time.Period period40 = period38.plusMillis(0);
        org.joda.time.PeriodType periodType41 = period40.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = periodType41.indexOf(durationFieldType42);
        int int44 = periodType41.size();
        org.joda.time.PeriodType periodType45 = periodType41.withMonthsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', 5300L, periodType41);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Duration duration48 = period46.toDurationFrom(readableInstant47);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology53);
        org.joda.time.Period period56 = period54.plusMillis(0);
        org.joda.time.PeriodType periodType57 = period56.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = periodType57.indexOf(durationFieldType58);
        int int60 = periodType57.size();
        org.joda.time.PeriodType periodType61 = periodType57.withMonthsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) 'a', 5300L, periodType57);
        org.joda.time.Period period63 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration48, periodType57);
        boolean boolean64 = preciseDurationField29.equals((java.lang.Object) duration48);
        long long67 = preciseDurationField29.add(35L, (long) (-1));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(duration48);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560629399785L + "'", long67 == 1560629399785L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long30 = preciseDurationField29.getUnitMillis();
        long long33 = preciseDurationField29.add(0L, 31L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1560629399750L) + "'", long30 == (-1560629399750L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-48379511392250L) + "'", long33 == (-48379511392250L));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, 0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for halfdayOfDay must be in the range [52,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(5200);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        long long30 = unsupportedDurationField29.getUnitMillis();
        org.joda.time.PeriodType periodType32 = null;
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((long) '#', periodType32, chronology33);
        org.joda.time.Period period43 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period45 = period43.minusWeeks(0);
        boolean boolean46 = period34.equals((java.lang.Object) period43);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology49);
        org.joda.time.Period period52 = period50.plusMillis(0);
        org.joda.time.PeriodType periodType53 = period52.getPeriodType();
        org.joda.time.Period period54 = period34.plus((org.joda.time.ReadablePeriod) period52);
        org.joda.time.Period period56 = period52.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Duration duration58 = period56.toDurationFrom(readableInstant57);
        boolean boolean59 = unsupportedDurationField29.equals((java.lang.Object) duration58);
        try {
            long long62 = unsupportedDurationField29.getMillis((int) (short) 1, (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(duration58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField5 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.plusSeconds(32);
        try {
            org.joda.time.Period period50 = period48.minusMonths((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType11, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 10, periodType2, (org.joda.time.Chronology) iSOChronology16);
        int int19 = periodType2.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) 5200, 0);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5200L + "'", long8 == 5200L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        int int31 = preciseDurationField29.getValue(5300L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology37);
        org.joda.time.Period period40 = period38.plusMillis(0);
        org.joda.time.PeriodType periodType41 = period40.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType42 = null;
        int int43 = periodType41.indexOf(durationFieldType42);
        int int44 = periodType41.size();
        org.joda.time.PeriodType periodType45 = periodType41.withMonthsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', 5300L, periodType41);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Duration duration48 = period46.toDurationFrom(readableInstant47);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.Period period54 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology53);
        org.joda.time.Period period56 = period54.plusMillis(0);
        org.joda.time.PeriodType periodType57 = period56.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType58 = null;
        int int59 = periodType57.indexOf(durationFieldType58);
        int int60 = periodType57.size();
        org.joda.time.PeriodType periodType61 = periodType57.withMonthsRemoved();
        org.joda.time.Period period62 = new org.joda.time.Period((long) 'a', 5300L, periodType57);
        org.joda.time.Period period63 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration48, periodType57);
        boolean boolean64 = preciseDurationField29.equals((java.lang.Object) duration48);
        try {
            long long67 = preciseDurationField29.add(201L, (-210417480000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210417480000000 * -1560629399750");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(duration48);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(100, (int) '4', 5200, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period14);
        org.joda.time.Hours hours16 = period15.toStandardHours();
        org.joda.time.Period period17 = period15.toPeriod();
        org.joda.time.Period period19 = period17.multipliedBy(0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology22);
        org.joda.time.Period period25 = period23.plusMillis(0);
        org.joda.time.PeriodType periodType26 = period25.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType27 = null;
        int int28 = periodType26.indexOf(durationFieldType27);
        int int29 = periodType26.size();
        org.joda.time.PeriodType periodType30 = periodType26.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType30.withMonthsRemoved();
        org.joda.time.Period period32 = period17.withPeriodType(periodType30);
        org.joda.time.Period period33 = period17.negated();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(hours16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period33);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField31 = zonedChronology22.dayOfWeek();
        try {
            long long39 = zonedChronology22.getDateTimeMillis((int) (byte) 0, (int) (byte) 0, (int) (byte) 10, (int) (byte) 0, 32, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField31 = zonedChronology22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField32 = zonedChronology22.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dateTimeField32, dateTimeFieldType33, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        int int32 = cachedDateTimeZone21.getStandardOffset((-1L));
        boolean boolean33 = cachedDateTimeZone21.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        java.lang.Object obj31 = null;
        boolean boolean32 = cachedDateTimeZone21.equals(obj31);
        org.joda.time.DateTimeZone dateTimeZone33 = cachedDateTimeZone21.getUncachedZone();
        int int35 = cachedDateTimeZone21.getStandardOffset((long) 5200);
        java.lang.String str36 = cachedDateTimeZone21.toString();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[UTC]" + "'", str36.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DurationField durationField4 = iSOChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyearOfCentury();
        try {
            long long10 = iSOChronology2.getDateTimeMillis((int) (byte) -1, (int) (byte) 1, (int) (byte) -1, 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.plusSeconds(32);
        int int49 = period46.getMillis();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.lang.String str10 = iSOChronology9.toString();
        org.joda.time.DurationField durationField11 = iSOChronology9.days();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology14 = iSOChronology9.withZone(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period(0L, (long) (short) 0, periodType6, chronology14);
        org.joda.time.Period period16 = new org.joda.time.Period(0L, 10L, periodType3, chronology14);
        int int17 = period16.getWeeks();
        int int18 = period16.getDays();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology0, (java.lang.Object) int18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str21 = dateTimeZone20.toString();
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ISOChronology[UTC]" + "'", str21.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.DurationField durationField31 = zonedChronology22.days();
        org.joda.time.Chronology chronology32 = zonedChronology22.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        java.lang.Object obj31 = null;
        boolean boolean32 = cachedDateTimeZone21.equals(obj31);
        org.joda.time.DateTimeZone dateTimeZone33 = cachedDateTimeZone21.getUncachedZone();
        long long35 = cachedDateTimeZone21.nextTransition(1560629429365L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560629429365L + "'", long35 == 1560629429365L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        try {
            long long31 = zonedChronology22.getDateTimeMillis(100, (int) '4', (int) (short) 100, (int) (short) 0, (int) (short) -1, (int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        int int9 = period3.getYears();
        org.joda.time.Period period11 = period3.withMonths((-52));
        org.joda.time.Period period13 = period3.plusYears(8);
        org.joda.time.Period period15 = period3.minusMonths(32);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "GregorianChronology[UTC]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        java.lang.String str8 = iSOChronology7.toString();
        boolean boolean10 = iSOChronology7.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField11 = iSOChronology7.millis();
        long long14 = durationField11.subtract((long) '#', (int) (short) 1);
        boolean boolean15 = gregorianChronology4.equals((java.lang.Object) durationField11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str22 = fixedDateTimeZone20.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = zonedChronology23.getZone();
        long long30 = zonedChronology23.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone31 = zonedChronology23.getZone();
        org.joda.time.Period period32 = new org.joda.time.Period((long) 'a', (org.joda.time.Chronology) zonedChronology23);
        org.joda.time.Chronology chronology33 = zonedChronology23.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 34L + "'", long14 == 34L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.032" + "'", str22.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3609976L + "'", long30 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        org.joda.time.Period period12 = period8.withDays(1);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology15);
        org.joda.time.Period period18 = period16.plusMillis(0);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = periodType19.indexOf(durationFieldType20);
        int int22 = periodType19.size();
        org.joda.time.Period period23 = period12.normalizedStandard(periodType19);
        java.lang.String str24 = periodType19.getName();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Standard" + "'", str24.equals("Standard"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.toString();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.lang.String str37 = iSOChronology36.toString();
        org.joda.time.DurationField durationField38 = iSOChronology36.days();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology41 = iSOChronology36.withZone(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology36.millisOfSecond();
        org.joda.time.DurationField durationField43 = iSOChronology36.hours();
        int int44 = preciseDurationField29.compareTo(durationField43);
        boolean boolean45 = preciseDurationField29.isSupported();
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[UTC]" + "'", str37.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.hourOfDay();
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.Chronology chronology7 = iSOChronology2.withUTC();
        org.joda.time.DurationField durationField8 = iSOChronology2.seconds();
        org.joda.time.Period period10 = new org.joda.time.Period((-61895577599900L));
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period10.get(durationFieldType11);
        org.joda.time.Period period13 = period10.normalizedStandard();
        long long16 = iSOChronology2.add((org.joda.time.ReadablePeriod) period13, 34L, (-52));
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3218570035194834L + "'", long16 == 3218570035194834L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant8);
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withYears((int) ' ');
        org.joda.time.Period period4 = period2.withWeeks((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Period period6 = period4.withFields(readablePeriod5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getHours();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            int int39 = unsupportedDurationField36.getValue((long) '4', (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        boolean boolean5 = iSOChronology2.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField6 = iSOChronology2.millis();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13, periodType14);
        boolean boolean16 = iSOChronology2.equals((java.lang.Object) readableInstant13);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology2.minuteOfDay();
        org.joda.time.Chronology chronology18 = iSOChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        java.lang.String str5 = iSOChronology4.toString();
        org.joda.time.DurationField durationField6 = iSOChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology9 = iSOChronology4.withZone(dateTimeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone8.getShortName(1L, locale11);
        long long14 = dateTimeZone8.convertUTCToLocal((long) (byte) 0);
        java.util.TimeZone timeZone15 = dateTimeZone8.toTimeZone();
        org.joda.time.Chronology chronology16 = gregorianChronology1.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField17 = gregorianChronology1.centuries();
        try {
            long long25 = gregorianChronology1.getDateTimeMillis(32, 100, (int) 'a', (int) (short) 100, 1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.032" + "'", str12.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.DurationField durationField6 = iSOChronology2.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.Period period6 = period4.withMonths((int) (short) 10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period4.getFieldTypes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str11 = iSOChronology10.toString();
        boolean boolean13 = iSOChronology10.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField14 = iSOChronology10.millis();
        long long17 = durationField14.subtract((long) '#', (int) (short) 1);
        boolean boolean18 = gregorianChronology7.equals((java.lang.Object) durationField14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str25 = fixedDateTimeZone23.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone27 = zonedChronology26.getZone();
        long long33 = zonedChronology26.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone34 = zonedChronology26.getZone();
        boolean boolean35 = iSOChronology2.equals((java.lang.Object) zonedChronology26);
        org.joda.time.DurationField durationField36 = zonedChronology26.years();
        try {
            long long44 = zonedChronology26.getDateTimeMillis((int) ' ', (-52), (int) (short) 1, 1, 36, (-52), 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.032" + "'", str25.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3609976L + "'", long33 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+00:00:00.032");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.Object obj4 = null;
        jodaTimePermission1.checkGuard(obj4);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.Period period3 = new org.joda.time.Period((-61895577599900L));
        org.joda.time.Period period5 = period3.plusMonths((int) ' ');
        boolean boolean6 = jodaTimePermission1.equals((java.lang.Object) period5);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology21 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("PT0.001S", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = periodType8.indexOf(durationFieldType9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType8, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.Period period16 = period14.withWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period14.toDurationTo(readableInstant17);
        org.joda.time.Period period20 = period14.withDays((int) ' ');
        org.joda.time.Period period21 = period14.normalizedStandard();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 100.0f, (java.lang.Number) 0, (java.lang.Number) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0" + "'", str8.equals("100.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        boolean boolean16 = gregorianChronology3.equals((java.lang.Object) (-1));
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.secondOfDay();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Period period2 = new org.joda.time.Period((-5189999L), (long) '4');
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology20 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology24);
        org.joda.time.Period period27 = period25.plusMillis(0);
        org.joda.time.Period period29 = period27.multipliedBy(10);
        boolean boolean30 = cachedDateTimeZone21.equals((java.lang.Object) period27);
        org.joda.time.Period period32 = period27.plusMinutes((-1));
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        try {
            org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) (-1), (org.joda.time.Chronology) iSOChronology35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', periodType3, chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationFrom(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', periodType13, chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period20 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18, periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period((long) (short) 0, periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType30 = null;
        int int31 = periodType29.indexOf(durationFieldType30);
        int int32 = periodType29.size();
        org.joda.time.PeriodType periodType33 = periodType29.withMonthsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType29);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.years();
        org.joda.time.Period period37 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant35, periodType36);
        org.joda.time.Period period39 = period37.plusYears(0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(period39);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType11, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 10, periodType2, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.PeriodType periodType19 = periodType2.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("P100W", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str6 = fixedDateTimeZone4.getName(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.032" + "'", str6.equals("+00:00:00.032"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.days();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray8 = new int[] { 10 };
        try {
            iSOChronology2.validate(readablePartial6, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        int int6 = period3.getSeconds();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period3.get(durationFieldType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period3.toDurationFrom(readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration10, readableInstant11, periodType12);
        try {
            org.joda.time.DurationFieldType durationFieldType15 = period13.getFieldType(4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Period period8 = new org.joda.time.Period((int) 'a', (int) '4', 10, (int) ' ', (int) (short) 0, (int) (short) -1, 8, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.Period period1 = org.joda.time.Period.millis(4);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology2);
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '#', periodType8, chronology9);
        org.joda.time.Period period19 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period21 = period19.minusWeeks(0);
        boolean boolean22 = period10.equals((java.lang.Object) period19);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology25);
        org.joda.time.Period period28 = period26.plusMillis(0);
        org.joda.time.PeriodType periodType29 = period28.getPeriodType();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period28);
        org.joda.time.Period period32 = period28.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType34 = period28.getFieldType((int) (short) 0);
        boolean boolean35 = periodType6.isSupported(durationFieldType34);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType34);
        try {
            long long39 = unsupportedDurationField36.getMillis(36, (-1560629399750L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField29 = new org.joda.time.field.PreciseDurationField(durationFieldType27, (-1560629399750L));
        long long32 = preciseDurationField29.getMillis((long) 5200, 34L);
        java.lang.String str33 = preciseDurationField29.toString();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        java.lang.String str37 = iSOChronology36.toString();
        org.joda.time.DurationField durationField38 = iSOChronology36.days();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology41 = iSOChronology36.withZone(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology36.millisOfSecond();
        org.joda.time.DurationField durationField43 = iSOChronology36.hours();
        int int44 = preciseDurationField29.compareTo(durationField43);
        long long46 = preciseDurationField29.getValueAsLong(0L);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8115272878700000L) + "'", long32 == (-8115272878700000L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[UTC]" + "'", str37.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField10 = iSOChronology6.millis();
        long long13 = durationField10.subtract((long) '#', (int) (short) 1);
        boolean boolean14 = gregorianChronology3.equals((java.lang.Object) durationField10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        java.lang.String str21 = fixedDateTimeZone19.getName(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = zonedChronology22.getZone();
        long long29 = zonedChronology22.getDateTimeMillis((long) 0, 1, (int) (byte) 0, (int) (short) 10, 8);
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology22.getZone();
        org.joda.time.Chronology chronology31 = zonedChronology22.withUTC();
        try {
            long long37 = zonedChronology22.getDateTimeMillis((long) 4, (int) (short) 1, (int) (byte) 100, 0, 5200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 34L + "'", long13 == 34L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.032" + "'", str21.equals("+00:00:00.032"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3609976L + "'", long29 == 3609976L);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffset((-210866673600000L));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        try {
            int int31 = unsupportedDurationField29.getValue((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        try {
            long long32 = unsupportedDurationField29.getMillis(1560629399785L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology7);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType11, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 10, periodType2, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.weekyearOfCentury();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        java.lang.String str25 = iSOChronology24.toString();
        boolean boolean27 = iSOChronology24.equals((java.lang.Object) 0L);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology32);
        org.joda.time.Period period35 = period33.plusMillis(0);
        org.joda.time.PeriodType periodType36 = period35.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType37 = null;
        int int38 = periodType36.indexOf(durationFieldType37);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.Period period42 = new org.joda.time.Period((long) (byte) -1, (long) 5200, periodType36, (org.joda.time.Chronology) iSOChronology41);
        org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) period42);
        int[] intArray45 = iSOChronology24.get((org.joda.time.ReadablePeriod) period43, (long) 8);
        org.joda.time.chrono.LenientChronology lenientChronology46 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Chronology chronology47 = lenientChronology46.withUTC();
        java.lang.String str48 = lenientChronology46.toString();
        org.joda.time.Period period49 = new org.joda.time.Period((long) '4', periodType21, (org.joda.time.Chronology) lenientChronology46);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
        java.lang.String str57 = iSOChronology56.toString();
        boolean boolean59 = iSOChronology56.equals((java.lang.Object) 0L);
        org.joda.time.DurationField durationField60 = iSOChronology56.millis();
        long long63 = durationField60.subtract((long) '#', (int) (short) 1);
        boolean boolean64 = gregorianChronology53.equals((java.lang.Object) durationField60);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone69 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "UTC", (int) ' ', (int) (short) 1);
        org.joda.time.Chronology chronology70 = gregorianChronology53.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone69);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone71 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone69);
        org.joda.time.ReadableInstant readableInstant72 = null;
        org.joda.time.PeriodType periodType74 = null;
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.Period period76 = new org.joda.time.Period((long) '#', periodType74, chronology75);
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Duration duration78 = period76.toDurationFrom(readableInstant77);
        org.joda.time.ReadableInstant readableInstant79 = null;
        org.joda.time.PeriodType periodType80 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period81 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration78, readableInstant79, periodType80);
        org.joda.time.PeriodType periodType84 = null;
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((long) '#', periodType84, chronology85);
        org.joda.time.ReadableInstant readableInstant87 = null;
        org.joda.time.Duration duration88 = period86.toDurationFrom(readableInstant87);
        org.joda.time.ReadableInstant readableInstant89 = null;
        org.joda.time.PeriodType periodType90 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period91 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration88, readableInstant89, periodType90);
        org.joda.time.Period period92 = new org.joda.time.Period((long) (short) 0, periodType90);
        org.joda.time.Period period93 = new org.joda.time.Period(readableInstant72, (org.joda.time.ReadableDuration) duration78, periodType90);
        boolean boolean94 = fixedDateTimeZone69.equals((java.lang.Object) period93);
        org.joda.time.Chronology chronology95 = lenientChronology46.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone69);
        org.joda.time.DateTimeZone dateTimeZone96 = lenientChronology46.getZone();
        org.joda.time.Chronology chronology97 = iSOChronology16.withZone(dateTimeZone96);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[UTC]" + "'", str25.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(lenientChronology46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str48.equals("LenientChronology[ISOChronology[UTC]]"));
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "ISOChronology[UTC]" + "'", str57.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 34L + "'", long63 == 34L);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(cachedDateTimeZone71);
        org.junit.Assert.assertNotNull(duration78);
        org.junit.Assert.assertNotNull(periodType80);
        org.junit.Assert.assertNotNull(duration88);
        org.junit.Assert.assertNotNull(periodType90);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(chronology95);
        org.junit.Assert.assertNotNull(dateTimeZone96);
        org.junit.Assert.assertNotNull(chronology97);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Weeks weeks1 = period0.toStandardWeeks();
        org.joda.time.Period period3 = period0.withMillis(3);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(weeks1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[UTC]", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder5.writeTo("LenientChronology[ISOChronology[UTC]]", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period21.getFieldType((int) (short) 0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField29 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType27);
        boolean boolean30 = unsupportedDurationField29.isPrecise();
        try {
            long long33 = unsupportedDurationField29.getMillis(8, 3218570035194834L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(unsupportedDurationField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, periodType1);
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = period2.normalizedStandard(periodType3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = period4.isSupported(durationFieldType5);
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period4.getFieldTypes();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.forFields(durationFieldTypeArray7);
        org.joda.time.PeriodType periodType9 = periodType8.withMonthsRemoved();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology4);
        org.joda.time.Period period7 = period5.plusMillis(0);
        org.joda.time.PeriodType periodType8 = period7.getPeriodType();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.lang.String str12 = iSOChronology11.toString();
        org.joda.time.DurationField durationField13 = iSOChronology11.days();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology15 = iSOChronology11.withUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, 0L, periodType8, (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology11.minuteOfDay();
        try {
            long long26 = iSOChronology11.getDateTimeMillis((int) '#', 36, (int) (byte) -1, (int) (byte) 0, 36, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[UTC]" + "'", str12.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Period period1 = new org.joda.time.Period(2440588L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1, chronology2);
        org.joda.time.Period period12 = new org.joda.time.Period((int) (short) 10, (int) (byte) -1, (int) 'a', (-1), (int) (short) 100, (int) 'a', (int) (byte) -1, (int) (short) 1);
        org.joda.time.Period period14 = period12.minusWeeks(0);
        boolean boolean15 = period3.equals((java.lang.Object) period12);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) 0, (long) (byte) 1, chronology18);
        org.joda.time.Period period21 = period19.plusMillis(0);
        org.joda.time.PeriodType periodType22 = period21.getPeriodType();
        org.joda.time.Period period23 = period3.plus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period25 = period21.multipliedBy((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Duration duration27 = period25.toDurationFrom(readableInstant26);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.PeriodType periodType31 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        java.lang.String str38 = iSOChronology37.toString();
        org.joda.time.DurationField durationField39 = iSOChronology37.days();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology42 = iSOChronology37.withZone(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period(0L, (long) (short) 0, periodType34, chronology42);
        org.joda.time.Period period44 = new org.joda.time.Period(0L, 10L, periodType31, chronology42);
        org.joda.time.PeriodType periodType45 = periodType31.withMinutesRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration27, readableInstant28, periodType45);
        org.joda.time.Period period48 = period46.minusYears(0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period48);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        int int10 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = iSOChronology2.toString();
        org.joda.time.DurationField durationField4 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 100);
        int int9 = offsetDateTimeField7.get(0L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(readablePartial10, 10, locale12);
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField7.set((long) 36, "Standard", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Standard\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10" + "'", str13.equals("10"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.Period period8 = new org.joda.time.Period(0, 0, (int) '4', (-1), (int) (short) 100, (int) '#', (int) (byte) 10, 3);
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = period8.getFieldTypes();
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
    }
}

