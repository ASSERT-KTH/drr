import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField14.getMaximumTextLength(locale18);
//        int int20 = offsetDateTimeField14.getOffset();
//        int int21 = offsetDateTimeField14.getOffset();
//        int int22 = offsetDateTimeField14.getOffset();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str4 = dateTimeZone2.getName((long) '4');
//        java.lang.String str5 = dateTimeZone2.getID();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology17);
//        java.util.Date date19 = dateTime18.toDate();
//        boolean boolean20 = dateTime18.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        int int29 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str30 = dateTimeZone12.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        java.util.Date date36 = dateTime35.toDate();
//        boolean boolean37 = dateTime35.isAfterNow();
//        boolean boolean39 = dateTime35.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfHalfday();
//        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(readableDuration49, 0);
//        boolean boolean52 = zonedChronology32.equals((java.lang.Object) readableDuration49);
//        org.joda.time.DateTimeField dateTimeField53 = zonedChronology32.dayOfWeek();
//        java.lang.String str54 = zonedChronology32.toString();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str59 = dateTimeZone57.getName((long) '4');
//        java.lang.String str60 = dateTimeZone57.getID();
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
//        org.joda.time.Chronology chronology62 = zonedChronology32.withZone(dateTimeZone61);
//        org.joda.time.DateTimeZone dateTimeZone63 = zonedChronology32.getZone();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+35:01" + "'", str30.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ZonedChronology[ISOChronology[UTC], +35:01]" + "'", str54.equals("ZonedChronology[ISOChronology[UTC], +35:01]"));
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "+35:01" + "'", str59.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+35:01" + "'", str60.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(chronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        long long24 = dividedDateTimeField19.add(100L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTime.Property property28 = dateTime27.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        java.util.Date date32 = dateTime31.toDate();
//        int int33 = property28.getDifference((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.yearOfCentury();
//        org.joda.time.DateTime dateTime35 = property34.roundFloorCopy();
//        org.joda.time.DateTime dateTime36 = property34.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19, dateTimeFieldType37);
//        java.util.Locale locale39 = null;
//        int int40 = dividedDateTimeField19.getMaximumTextLength(locale39);
//        long long43 = dividedDateTimeField19.add((long) 61200010, (-101));
//        java.lang.String str45 = dividedDateTimeField19.getAsText((long) 11);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1029599990L) + "'", long43 == (-1029599990L));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "8" + "'", str45.equals("8"));
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property15 = dateTime11.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((-18062));
//        boolean boolean17 = dateTime13.isBefore((long) 32);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (-3));
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str6 = dateTimeZone4.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withZone(dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        java.util.Date date11 = dateTime10.toDate();
//        boolean boolean12 = dateTime10.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsText(locale17);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property16.getFieldType();
//        int int20 = dateTime10.get(dateTimeFieldType19);
//        int int21 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.LocalDateTime localDateTime22 = dateTime10.toLocalDateTime();
//        boolean boolean23 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime22);
//        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 126060000 + "'", int21 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "110100" + "'", str24.equals("110100"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) 4, (java.lang.Number) (-89999990L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
        java.util.Date date7 = dateTime6.toDate();
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
        org.joda.time.DateTime dateTime13 = dateTime10.plusWeeks(12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours(52);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        int int4 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks(52);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        java.lang.String str15 = dateTimeZone12.getID();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        boolean boolean17 = gregorianChronology9.equals((java.lang.Object) dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology9.halfdayOfDay();
//        int int19 = dateTime8.get(dateTimeField18);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime21 = dateTime8.toDateTime();
//        try {
//            org.joda.time.DateTime dateTime23 = dateTime8.withMillisOfSecond((-363599900));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -363599900 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 126060000 + "'", int4 == 126060000);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        long long19 = offsetDateTimeField14.roundHalfFloor(1314000010L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1313940000L + "'", long19 == 1313940000L);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.getName();
//        try {
//            int int26 = unsupportedDateTimeField22.get((long) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfYear" + "'", str24.equals("dayOfYear"));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField14.getMaximumTextLength(locale18);
//        long long21 = offsetDateTimeField14.roundHalfCeiling((long) (short) -1);
//        long long23 = offsetDateTimeField14.roundCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-60000L) + "'", long21 == (-60000L));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3540000L + "'", long23 == 3540000L);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        long long12 = dateTime2.getMillis();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        int int4 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusWeeks(52);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        java.lang.String str15 = dateTimeZone12.getID();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        boolean boolean17 = gregorianChronology9.equals((java.lang.Object) dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology9.halfdayOfDay();
//        int int19 = dateTime8.get(dateTimeField18);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 126060000 + "'", int4 == 126060000);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusDays(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfYear();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property20.getAsText(locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
//        org.joda.time.DateTime.Property property24 = dateTime16.property(dateTimeFieldType23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gregorianChronology26);
//        boolean boolean28 = property24.equals((java.lang.Object) dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2" + "'", str22.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withTime(0, 1, (-1), 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        int int7 = property3.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        int int10 = property3.getMinimumValueOverall();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property14.getAsText(locale15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        java.lang.String str18 = property14.getAsText();
//        org.joda.time.DateTime dateTime20 = property14.addToCopy((int) (byte) -1);
//        int int21 = property3.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = property3.addToCopy((long) 126060000);
//        org.joda.time.DateTime dateTime24 = property3.withMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2" + "'", str16.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        long long24 = zeroIsMaxDateTimeField19.roundHalfCeiling((long) 0);
//        org.joda.time.DurationField durationField25 = zeroIsMaxDateTimeField19.getLeapDurationField();
//        java.util.Locale locale26 = null;
//        int int27 = zeroIsMaxDateTimeField19.getMaximumShortTextLength(locale26);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (long) '4', (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        java.util.Date date7 = dateTime6.toDate();
//        boolean boolean8 = dateTime6.isAfterNow();
//        boolean boolean10 = dateTime6.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.hourOfHalfday();
//        org.joda.time.DateTime dateTime15 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusDays((int) (short) 0);
//        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusDays(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        java.util.Date date24 = dateTime23.toDate();
//        boolean boolean25 = dateTime23.isAfterNow();
//        boolean boolean27 = dateTime23.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.hourOfHalfday();
//        org.joda.time.DateTime dateTime32 = dateTime23.withChronology((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTime dateTime34 = dateTime32.minusDays((int) (short) 0);
//        int int35 = dateTime34.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime37 = dateTime34.minusHours((-1));
//        boolean boolean38 = dateTime17.isBefore((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((java.lang.Object) dateTime17);
//        org.joda.time.DateTime dateTime41 = dateTime17.minusDays((int) '#');
//        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime2, (java.lang.Object) dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeFormatter3);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology10);
//        java.util.Date date12 = dateTime11.toDate();
//        boolean boolean13 = dateTime11.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property17.getAsText(locale18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
//        int int21 = dateTime11.get(dateTimeFieldType20);
//        int int22 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.LocalDateTime localDateTime23 = dateTime11.toLocalDateTime();
//        int[] intArray25 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime23, (long) 122400020);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.DateTime.Property property37 = dateTime36.dayOfYear();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = property37.getAsText(locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property37.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, dateTimeFieldType40, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField29, dateTimeFieldType40);
//        int int46 = zeroIsMaxDateTimeField45.getMaximumValue();
//        int int48 = zeroIsMaxDateTimeField45.getLeapAmount((long) ' ');
//        int int50 = zeroIsMaxDateTimeField45.getMinimumValue((long) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology52);
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology56);
//        org.joda.time.DateTime.Property property58 = dateTime57.dayOfYear();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = property58.getAsText(locale59);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property58.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, dateTimeFieldType61, 10, 126060000, (int) '#');
//        java.util.Locale locale67 = null;
//        java.lang.String str68 = offsetDateTimeField65.getAsShortText((long) ' ', locale67);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str74 = dateTimeZone72.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = dateTimeFormatter69.withZone(dateTimeZone72);
//        org.joda.time.chrono.GregorianChronology gregorianChronology77 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology77);
//        java.util.Date date79 = dateTime78.toDate();
//        boolean boolean80 = dateTime78.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology82);
//        org.joda.time.DateTime.Property property84 = dateTime83.dayOfYear();
//        java.util.Locale locale85 = null;
//        java.lang.String str86 = property84.getAsText(locale85);
//        org.joda.time.DateTimeFieldType dateTimeFieldType87 = property84.getFieldType();
//        int int88 = dateTime78.get(dateTimeFieldType87);
//        int int89 = dateTimeZone72.getOffset((org.joda.time.ReadableInstant) dateTime78);
//        org.joda.time.LocalDateTime localDateTime90 = dateTime78.toLocalDateTime();
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = offsetDateTimeField65.getAsShortText((org.joda.time.ReadablePartial) localDateTime90, 0, locale92);
//        int int94 = zeroIsMaxDateTimeField45.getMaximumValue((org.joda.time.ReadablePartial) localDateTime90);
//        boolean boolean95 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime90);
//        int[] intArray97 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime90, 1361448039660052L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2" + "'", str19.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 126060000 + "'", int22 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2" + "'", str39.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2" + "'", str60.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "21" + "'", str68.equals("21"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter69);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "+35:01" + "'", str74.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter75);
//        org.junit.Assert.assertNotNull(gregorianChronology77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology82);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "2" + "'", str86.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2 + "'", int88 == 2);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 126060000 + "'", int89 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime90);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "0" + "'", str93.equals("0"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 12 + "'", int94 == 12);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
//        org.junit.Assert.assertNotNull(intArray97);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTime dateTime7 = property3.addToCopy((-3));
//        java.lang.String str8 = property3.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfYear" + "'", str8.equals("dayOfYear"));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.setCopy((int) (short) 1);
//        int int10 = property3.getMaximumValue();
//        org.joda.time.DateTime dateTime11 = property3.withMinimumValue();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusYears(32);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for yearOfCentury must be in the range [1,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime10 = property3.getDateTime();
//        org.joda.time.DateTime dateTime12 = property3.addToCopy((long) 10);
//        long long13 = dateTime12.getMillis();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 864000010L + "'", long13 == 864000010L);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 1);
//        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean7 = jodaTimePermission5.equals((java.lang.Object) 1);
//        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean11 = jodaTimePermission9.equals((java.lang.Object) 1);
//        boolean boolean12 = jodaTimePermission5.implies((java.security.Permission) jodaTimePermission9);
//        java.lang.String str13 = jodaTimePermission9.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfYear();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property17.getAsText(locale18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
//        java.lang.String str21 = property17.getAsText();
//        org.joda.time.DateTime dateTime23 = property17.setCopy((int) (short) 1);
//        int int24 = property17.getMaximumValue();
//        org.joda.time.DateTime dateTime25 = property17.withMinimumValue();
//        java.util.Locale locale26 = null;
//        int int27 = property17.getMaximumTextLength(locale26);
//        jodaTimePermission9.checkGuard((java.lang.Object) property17);
//        boolean boolean29 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission9);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"365\")" + "'", str13.equals("(\"org.joda.time.JodaTimePermission\" \"365\")"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2" + "'", str19.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2" + "'", str21.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 365 + "'", int24 == 365);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        int int22 = dividedDateTimeField19.getMinimumValue((long) 1);
//        long long25 = dividedDateTimeField19.add(0L, 52L);
//        int int26 = dividedDateTimeField19.getDivisor();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 561600000L + "'", long25 == 561600000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        java.lang.String str16 = offsetDateTimeField14.getAsText(52L);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField14.getAsShortText((-363599900L), locale18);
//        boolean boolean20 = offsetDateTimeField14.isSupported();
//        long long22 = offsetDateTimeField14.remainder((long) 32);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21" + "'", str16.equals("21"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 60032L + "'", long22 == 60032L);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, (int) (short) 10);
//        int int13 = dateTime12.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths((-1));
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        int int22 = property21.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        long long24 = remainderDateTimeField22.roundHalfFloor(1313940000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1314000000L + "'", long24 == 1314000000L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-75618062L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusDays(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfYear();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property20.getAsText(locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
//        org.joda.time.DateTime.Property property24 = dateTime16.property(dateTimeFieldType23);
//        org.joda.time.DateTime dateTime25 = property24.roundFloorCopy();
//        org.joda.time.DurationField durationField26 = property24.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2" + "'", str22.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(durationField26);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
        org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra(70);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendDayOfYear(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfSecond(0, 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 39660);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
//        int int15 = mutableDateTime14.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str12 = dateTimeZone10.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter7.withZone(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology15);
//        java.util.Date date17 = dateTime16.toDate();
//        boolean boolean18 = dateTime16.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfYear();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = property22.getAsText(locale23);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property22.getFieldType();
//        int int26 = dateTime16.get(dateTimeFieldType25);
//        int int27 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        java.lang.String str28 = dateTimeZone10.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
//        int int31 = cachedDateTimeZone29.getStandardOffset((long) (byte) 10);
//        long long33 = cachedDateTimeZone29.nextTransition((long) (-18062));
//        java.lang.String str35 = cachedDateTimeZone29.getNameKey(0L);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone29);
//        try {
//            org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(13, (int) (short) -1, 39660010, 365, (-3), 365, 59, (org.joda.time.DateTimeZone) cachedDateTimeZone29);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+35:01" + "'", str12.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 126060000 + "'", int27 == 126060000);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+35:01" + "'", str28.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 126060000 + "'", int31 == 126060000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-18062L) + "'", long33 == (-18062L));
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology11);
//        java.util.Date date13 = dateTime12.toDate();
//        boolean boolean14 = dateTime12.isAfterNow();
//        boolean boolean16 = dateTime12.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.DateTime dateTime21 = dateTime12.withChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime25 = dateTime21.minusSeconds(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfYear();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        java.lang.String str33 = property29.getAsText();
//        org.joda.time.DateTime dateTime35 = property29.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime37 = dateTime35.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime40 = dateTime37.withTimeAtStartOfDay();
//        boolean boolean41 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime44 = dateTime9.withMillisOfSecond(0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2" + "'", str33.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str5 = dateTimeZone3.getName((long) '4');
        java.lang.String str6 = dateTimeZone3.getID();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField10 = gregorianChronology0.seconds();
        long long13 = durationField10.subtract(0L, (long) (-3));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3000L + "'", long13 == 3000L);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfYear();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType32, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField21, dateTimeFieldType32);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType32, 39660052, (int) '#', 12);
//        long long43 = offsetDateTimeField14.roundCeiling(3581938L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 7140000L + "'", long43 == 7140000L);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        java.lang.String str16 = offsetDateTimeField14.getAsText(52L);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField14.getAsShortText((-363599900L), locale18);
//        try {
//            long long22 = offsetDateTimeField14.set(0L, "");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21" + "'", str16.equals("21"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, 0, 0, 39660010, (-15), 365, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39660010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str21 = dateTimeZone19.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter16.withZone(dateTimeZone19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology24);
//        java.util.Date date26 = dateTime25.toDate();
//        boolean boolean27 = dateTime25.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfYear();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = property31.getAsText(locale32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        int int35 = dateTime25.get(dateTimeFieldType34);
//        int int36 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        java.lang.String str37 = dateTimeZone19.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone38 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
//        int int40 = cachedDateTimeZone38.getStandardOffset((long) (byte) 10);
//        long long42 = cachedDateTimeZone38.nextTransition((long) (-18062));
//        java.lang.String str44 = cachedDateTimeZone38.getNameKey(0L);
//        org.joda.time.MutableDateTime mutableDateTime45 = dateTime11.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone38);
//        int int46 = mutableDateTime45.getMonthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+35:01" + "'", str21.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2" + "'", str33.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 126060000 + "'", int36 == 126060000);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+35:01" + "'", str37.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 126060000 + "'", int40 == 126060000);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-18062L) + "'", long42 == (-18062L));
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property9.getAsText(locale11);
//        org.joda.time.DateTime dateTime13 = property9.withMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "70" + "'", str12.equals("70"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        long long24 = dividedDateTimeField19.add(100L, 0L);
//        long long27 = dividedDateTimeField19.addWrapField((long) (-18062), 200);
//        long long29 = dividedDateTimeField19.roundHalfEven((long) (-18062));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-75618062L) + "'", long27 == (-75618062L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str5 = dateTimeZone3.getName((long) '4');
        java.lang.String str6 = dateTimeZone3.getID();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField10 = gregorianChronology0.days();
        org.joda.time.DurationField durationField11 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTime dateTime6 = property3.roundHalfEvenCopy();
//        java.lang.String str7 = property3.getAsText();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getShortName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(16, true);
        boolean boolean6 = dateTimeFormatterBuilder2.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        boolean boolean22 = zeroIsMaxDateTimeField19.isLeap((long) 200);
//        int int24 = zeroIsMaxDateTimeField19.getMinimumValue((long) (-18062));
//        long long26 = zeroIsMaxDateTimeField19.roundHalfEven((long) 61200010);
//        int int28 = zeroIsMaxDateTimeField19.get(60011L);
//        int int30 = zeroIsMaxDateTimeField19.getMaximumValue((long) 39660010);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 61140000L + "'", long26 == 61140000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        long long24 = dividedDateTimeField19.add(100L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTime.Property property28 = dateTime27.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        java.util.Date date32 = dateTime31.toDate();
//        int int33 = property28.getDifference((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.yearOfCentury();
//        org.joda.time.DateTime dateTime35 = property34.roundFloorCopy();
//        org.joda.time.DateTime dateTime36 = property34.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19, dateTimeFieldType37);
//        long long41 = dividedDateTimeField19.add(0L, (-35999997L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-388799967600000L) + "'", long41 == (-388799967600000L));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str11 = dateTimeZone9.getName((long) '4');
        java.lang.String str12 = dateTimeZone9.getID();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        boolean boolean14 = gregorianChronology6.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DurationField durationField15 = gregorianChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology6.millisOfDay();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (byte) 0, 0, 21, 69, 59, 13, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+35:01" + "'", str11.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+35:01" + "'", str12.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getDurationField();
//        int int28 = unsupportedDateTimeField22.getDifference((long) 8, 60000L);
//        try {
//            long long31 = unsupportedDateTimeField22.set(57235L, "23");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        java.lang.String str16 = offsetDateTimeField14.getAsText(52L);
//        long long18 = offsetDateTimeField14.roundCeiling((long) 70);
//        int int20 = offsetDateTimeField14.getMinimumValue(6575L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21" + "'", str16.equals("21"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3540000L + "'", long18 == 3540000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 126060000 + "'", int20 == 126060000);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str4 = dateTimeZone2.getName((long) '4');
//        java.lang.String str5 = dateTimeZone2.getID();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology17);
//        java.util.Date date19 = dateTime18.toDate();
//        boolean boolean20 = dateTime18.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        int int29 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str30 = dateTimeZone12.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        java.util.Date date36 = dateTime35.toDate();
//        boolean boolean37 = dateTime35.isAfterNow();
//        boolean boolean39 = dateTime35.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfHalfday();
//        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(readableDuration49, 0);
//        boolean boolean52 = zonedChronology32.equals((java.lang.Object) readableDuration49);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str58 = dateTimeZone56.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter53.withZone(dateTimeZone56);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology61);
//        java.util.Date date63 = dateTime62.toDate();
//        boolean boolean64 = dateTime62.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.DateTime.Property property68 = dateTime67.dayOfYear();
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = property68.getAsText(locale69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = property68.getFieldType();
//        int int72 = dateTime62.get(dateTimeFieldType71);
//        int int73 = dateTimeZone56.getOffset((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.LocalDateTime localDateTime74 = dateTime62.toLocalDateTime();
//        int[] intArray76 = zonedChronology32.get((org.joda.time.ReadablePartial) localDateTime74, (long) (short) 1);
//        try {
//            long long82 = zonedChronology32.getDateTimeMillis((-1L), 200, (int) (byte) 10, (-101), (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+35:01" + "'", str30.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+35:01" + "'", str58.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2" + "'", str70.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 126060000 + "'", int73 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime74);
//        org.junit.Assert.assertNotNull(intArray76);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        java.lang.String str15 = dateTimeZone12.getID();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str24 = dateTimeZone22.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter19.withZone(dateTimeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        java.util.Date date29 = dateTime28.toDate();
//        boolean boolean30 = dateTime28.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfYear();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = property34.getAsText(locale35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
//        int int38 = dateTime28.get(dateTimeFieldType37);
//        int int39 = dateTimeZone22.getOffset((org.joda.time.ReadableInstant) dateTime28);
//        java.lang.String str40 = dateTimeZone22.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, dateTimeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology44);
//        java.util.Date date46 = dateTime45.toDate();
//        boolean boolean47 = dateTime45.isAfterNow();
//        boolean boolean49 = dateTime45.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology51);
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.hourOfHalfday();
//        org.joda.time.DateTime dateTime54 = dateTime45.withChronology((org.joda.time.Chronology) gregorianChronology51);
//        org.joda.time.DateTime dateTime56 = dateTime54.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime58 = dateTime54.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration59 = null;
//        org.joda.time.DateTime dateTime61 = dateTime58.withDurationAdded(readableDuration59, 0);
//        boolean boolean62 = zonedChronology42.equals((java.lang.Object) readableDuration59);
//        org.joda.time.DateTime dateTime63 = dateTime9.withChronology((org.joda.time.Chronology) zonedChronology42);
//        org.joda.time.DurationFieldType durationFieldType64 = null;
//        try {
//            org.joda.time.DateTime dateTime66 = dateTime63.withFieldAdded(durationFieldType64, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+35:01" + "'", str24.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2" + "'", str36.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 126060000 + "'", int39 == 126060000);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+35:01" + "'", str40.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(dateTime63);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendDayOfYear(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitWeekyear(1969, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        org.joda.time.DurationField durationField23 = remainderDateTimeField22.getRangeDurationField();
//        org.joda.time.DurationField durationField24 = remainderDateTimeField22.getRangeDurationField();
//        int int25 = remainderDateTimeField22.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        long long24 = dividedDateTimeField19.add(100L, 0L);
//        long long27 = dividedDateTimeField19.addWrapField((long) (-18062), 200);
//        org.joda.time.DurationField durationField28 = dividedDateTimeField19.getDurationField();
//        long long31 = dividedDateTimeField19.add(0L, 1);
//        long long34 = dividedDateTimeField19.getDifferenceAsLong((long) 34, 57720059L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-75618062L) + "'", long27 == (-75618062L));
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10800000L + "'", long31 == 10800000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-5L) + "'", long34 == (-5L));
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology3);
//        java.util.Date date5 = dateTime4.toDate();
//        boolean boolean6 = dateTime4.isAfterNow();
//        boolean boolean8 = dateTime4.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfHalfday();
//        org.joda.time.DateTime dateTime13 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusDays((int) (short) 0);
//        int int16 = dateTime15.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusHours((-1));
//        org.joda.time.DateTime dateTime20 = dateTime15.withEra((int) (byte) 1);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        java.lang.String str21 = dividedDateTimeField19.getAsText((long) (-363599900));
//        int int22 = dividedDateTimeField19.getDivisor();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "6" + "'", str21.equals("6"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getRangeDurationField();
//        try {
//            long long26 = unsupportedDateTimeField22.roundHalfFloor((long) 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(durationField24);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsText(locale9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        int int12 = dateTime2.get(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime13 = dateTime2.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime2.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology16);
//        java.util.Date date18 = dateTime17.toDate();
//        boolean boolean19 = dateTime17.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfYear();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsText(locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
//        int int27 = dateTime17.get(dateTimeFieldType26);
//        int int28 = dateTime17.getYear();
//        int int29 = property14.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2" + "'", str25.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1970 + "'", int28 == 1970);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(10);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (-363599900));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -363599900");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str5 = dateTimeZone3.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        java.util.Date date10 = dateTime9.toDate();
//        boolean boolean11 = dateTime9.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property15.getAsText(locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
//        int int19 = dateTime9.get(dateTimeFieldType18);
//        int int20 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str21 = dateTimeZone3.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        int int24 = cachedDateTimeZone22.getStandardOffset((long) (byte) 10);
//        long long26 = cachedDateTimeZone22.nextTransition((long) (-18062));
//        java.lang.String str28 = cachedDateTimeZone22.getNameKey(0L);
//        long long30 = cachedDateTimeZone22.previousTransition((long) 12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 126060000 + "'", int20 == 126060000);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+35:01" + "'", str21.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 126060000 + "'", int24 == 126060000);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-18062L) + "'", long26 == (-18062L));
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 12L + "'", long30 == 12L);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        java.util.Locale locale26 = null;
//        try {
//            java.lang.String str27 = unsupportedDateTimeField22.getAsText(21, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTime.Property property41 = dateTime40.dayOfYear();
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = property41.getAsText(locale42);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property41.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType44, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField33, dateTimeFieldType44, 3);
//        long long52 = dividedDateTimeField50.remainder(1L);
//        long long55 = dividedDateTimeField50.add(100L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology57);
//        org.joda.time.DateTime.Property property59 = dateTime58.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology61);
//        java.util.Date date63 = dateTime62.toDate();
//        int int64 = property59.getDifference((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime.Property property65 = dateTime62.yearOfCentury();
//        org.joda.time.DateTime dateTime66 = property65.roundFloorCopy();
//        org.joda.time.DateTime dateTime67 = property65.roundHalfEvenCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property65.getFieldType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField50, dateTimeFieldType68);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder30.appendShortText(dateTimeFieldType68);
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology72);
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology72.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology76 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology76);
//        org.joda.time.DateTime.Property property78 = dateTime77.dayOfYear();
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = property78.getAsText(locale79);
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = property78.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, dateTimeFieldType81, 10, 126060000, (int) '#');
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder87 = dateTimeFormatterBuilder70.appendFixedDecimal(dateTimeFieldType81, (-18062));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -18062");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2" + "'", str43.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(gregorianChronology76);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2" + "'", str80.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str5 = dateTimeZone3.getName((long) '4');
        java.lang.String str6 = dateTimeZone3.getID();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField10 = gregorianChronology0.seconds();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter11.withZoneUTC();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("57600010", "", 2, 200);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str5 = dateTimeZone3.getName((long) '4');
        java.lang.String str6 = dateTimeZone3.getID();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsText(locale6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        int int9 = property5.getLeapAmount();
//        org.joda.time.DateTime dateTime10 = property5.withMinimumValue();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology12);
//        java.util.Date date14 = dateTime13.toDate();
//        boolean boolean15 = dateTime13.isAfterNow();
//        boolean boolean17 = dateTime13.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfHalfday();
//        org.joda.time.DateTime dateTime22 = dateTime13.withChronology((org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTime dateTime24 = dateTime22.minusDays((int) (short) 0);
//        int int25 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusHours((-1));
//        org.joda.time.DateTime dateTime29 = dateTime24.withWeekyear(200);
//        org.joda.time.TimeOfDay timeOfDay30 = dateTime24.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime24.getZone();
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime10.toMutableDateTime(dateTimeZone31);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(timeOfDay30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str4 = dateTimeZone2.getName((long) '4');
//        java.lang.String str5 = dateTimeZone2.getID();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology17);
//        java.util.Date date19 = dateTime18.toDate();
//        boolean boolean20 = dateTime18.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        int int29 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str30 = dateTimeZone12.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        java.util.Date date36 = dateTime35.toDate();
//        boolean boolean37 = dateTime35.isAfterNow();
//        boolean boolean39 = dateTime35.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfHalfday();
//        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(readableDuration49, 0);
//        boolean boolean52 = zonedChronology32.equals((java.lang.Object) readableDuration49);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str58 = dateTimeZone56.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter53.withZone(dateTimeZone56);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology61);
//        java.util.Date date63 = dateTime62.toDate();
//        boolean boolean64 = dateTime62.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.DateTime.Property property68 = dateTime67.dayOfYear();
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = property68.getAsText(locale69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = property68.getFieldType();
//        int int72 = dateTime62.get(dateTimeFieldType71);
//        int int73 = dateTimeZone56.getOffset((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.LocalDateTime localDateTime74 = dateTime62.toLocalDateTime();
//        int[] intArray76 = zonedChronology32.get((org.joda.time.ReadablePartial) localDateTime74, (long) (short) 1);
//        org.joda.time.DateTimeField dateTimeField77 = zonedChronology32.monthOfYear();
//        try {
//            long long83 = zonedChronology32.getDateTimeMillis((-205L), 100, 70, 365, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+35:01" + "'", str30.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+35:01" + "'", str58.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "2" + "'", str70.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 126060000 + "'", int73 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder25.appendDayOfWeekText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime.Property property43 = dateTime42.dayOfYear();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = property43.getAsText(locale44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType46, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField35, dateTimeFieldType46);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType46, (int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder25.appendYear(365, (-3));
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2" + "'", str45.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatterBuilder0.toFormatter();
        try {
            org.joda.time.LocalDateTime localDateTime28 = dateTimeFormatter26.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        org.joda.time.DurationField durationField23 = remainderDateTimeField22.getRangeDurationField();
//        org.joda.time.DurationField durationField24 = remainderDateTimeField22.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology26);
//        java.util.Date date28 = dateTime27.toDate();
//        boolean boolean29 = dateTime27.isAfterNow();
//        int int30 = dateTime27.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology32);
//        java.util.Date date34 = dateTime33.toDate();
//        boolean boolean35 = dateTime33.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = property39.getAsText(locale40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property39.getFieldType();
//        int int43 = dateTime33.get(dateTimeFieldType42);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "14");
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology47);
//        java.util.Date date49 = dateTime48.toDate();
//        boolean boolean50 = dateTime48.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology52);
//        org.joda.time.DateTime.Property property54 = dateTime53.dayOfYear();
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = property54.getAsText(locale55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property54.getFieldType();
//        int int58 = dateTime48.get(dateTimeFieldType57);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, "14");
//        illegalFieldValueException45.addSuppressed((java.lang.Throwable) illegalFieldValueException60);
//        java.lang.Number number62 = illegalFieldValueException45.getLowerBound();
//        illegalFieldValueException45.prependMessage("1");
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = illegalFieldValueException45.getDateTimeFieldType();
//        boolean boolean66 = dateTime27.isSupported(dateTimeFieldType65);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2" + "'", str41.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2" + "'", str56.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
//        org.junit.Assert.assertNull(number62);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
//        int int2 = dateTime1.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTime dateTime6 = property3.roundHalfCeilingCopy();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        boolean boolean22 = zeroIsMaxDateTimeField19.isLeap((long) (short) 10);
//        long long25 = zeroIsMaxDateTimeField19.getDifferenceAsLong((long) (-18062), (long) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = zeroIsMaxDateTimeField19.getType();
//        int int28 = zeroIsMaxDateTimeField19.getMinimumValue((-18062L));
//        long long30 = zeroIsMaxDateTimeField19.roundHalfFloor((long) 365);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = zeroIsMaxDateTimeField19.getAsShortText(readablePartial31, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60000L) + "'", long30 == (-60000L));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        org.joda.time.DurationField durationField18 = offsetDateTimeField14.getLeapDurationField();
//        long long21 = offsetDateTimeField14.getDifferenceAsLong(864000010L, (long) 11);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 239L + "'", long21 == 239L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str5 = dateTimeZone3.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        java.util.Date date10 = dateTime9.toDate();
//        boolean boolean11 = dateTime9.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property15.getAsText(locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
//        int int19 = dateTime9.get(dateTimeFieldType18);
//        int int20 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str21 = dateTimeZone3.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        boolean boolean24 = cachedDateTimeZone22.isStandardOffset((long) 57600);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 126060000 + "'", int20 == 126060000);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+35:01" + "'", str21.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime10 = property3.getDateTime();
//        org.joda.time.DurationField durationField11 = property3.getRangeDurationField();
//        long long14 = durationField11.subtract(6209L, (long) (byte) 100);
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField11, durationFieldType15, 57600010);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-3155673593791L) + "'", long14 == (-3155673593791L));
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getRangeDurationField();
//        long long27 = unsupportedDateTimeField22.add(52L, 0);
//        try {
//            long long29 = unsupportedDateTimeField22.remainder(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusHours((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime16.toMutableDateTime((org.joda.time.Chronology) gregorianChronology18);
//        int int22 = dateTime16.getMillisOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime16.withEra(0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 43260010 + "'", int22 == 43260010);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusHours((-1));
//        org.joda.time.DateTime dateTime18 = dateTime13.withEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "69", (int) 'a', (int) 'a');
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths((-1));
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology23);
//        java.util.Date date25 = dateTime24.toDate();
//        boolean boolean26 = dateTime24.isAfterNow();
//        boolean boolean28 = dateTime24.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.hourOfHalfday();
//        org.joda.time.DateTime dateTime33 = dateTime24.withChronology((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTime dateTime35 = dateTime33.minusDays((int) (short) 0);
//        org.joda.time.MutableDateTime mutableDateTime36 = dateTime35.toMutableDateTime();
//        long long37 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime36);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTime.Property property41 = dateTime40.dayOfYear();
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = property41.getAsText(locale42);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property41.getFieldType();
//        java.lang.String str45 = property41.getAsText();
//        org.joda.time.DateTime dateTime47 = property41.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime49 = dateTime47.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime51 = dateTime49.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime52 = dateTime49.withTimeAtStartOfDay();
//        boolean boolean53 = mutableDateTime36.isBefore((org.joda.time.ReadableInstant) dateTime52);
//        try {
//            org.joda.time.DateTime dateTime55 = dateTime52.withHourOfDay(200);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-217L) + "'", long37 == (-217L));
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2" + "'", str43.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2" + "'", str45.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        boolean boolean29 = dateTimeFormatterBuilder28.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        try {
//            long long26 = unsupportedDateTimeField22.roundHalfEven(31507200010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, (-14420390941194800L), 57600010);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14420390941194800L) + "'", long7 == (-14420390941194800L));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField21 = zeroIsMaxDateTimeField19.getWrappedField();
//        boolean boolean23 = zeroIsMaxDateTimeField19.isLeap(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(16, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfYear();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsText(locale17);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property16.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType19, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType19, 3);
//        long long27 = dividedDateTimeField25.remainder(1L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology29);
//        java.util.Date date31 = dateTime30.toDate();
//        boolean boolean32 = dateTime30.isAfterNow();
//        boolean boolean34 = dateTime30.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.hourOfHalfday();
//        org.joda.time.DateTime dateTime39 = dateTime30.withChronology((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusDays((int) (short) 0);
//        org.joda.time.DateTime.Property property42 = dateTime41.minuteOfDay();
//        org.joda.time.DateTime dateTime44 = dateTime41.minusDays(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology46);
//        org.joda.time.DateTime.Property property48 = dateTime47.dayOfYear();
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = property48.getAsText(locale49);
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property48.getFieldType();
//        org.joda.time.DateTime.Property property52 = dateTime44.property(dateTimeFieldType51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField53 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField25, dateTimeFieldType51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2" + "'", str50.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        org.joda.time.DateTime dateTime5 = dateTime2.toDateTimeISO();
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        long long24 = zeroIsMaxDateTimeField19.roundHalfCeiling((long) 0);
//        int int26 = zeroIsMaxDateTimeField19.get((long) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfYear();
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = property34.getAsText(locale35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType37, 10, 126060000, (int) '#');
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField41.getAsShortText((long) ' ', locale43);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str50 = dateTimeZone48.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter45.withZone(dateTimeZone48);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology53);
//        java.util.Date date55 = dateTime54.toDate();
//        boolean boolean56 = dateTime54.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.dayOfYear();
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = property60.getAsText(locale61);
//        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property60.getFieldType();
//        int int64 = dateTime54.get(dateTimeFieldType63);
//        int int65 = dateTimeZone48.getOffset((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.LocalDateTime localDateTime66 = dateTime54.toLocalDateTime();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = offsetDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, 0, locale68);
//        int int70 = zeroIsMaxDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) localDateTime66);
//        int int71 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int73 = zeroIsMaxDateTimeField19.getMinimumValue((long) 960);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2" + "'", str36.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "21" + "'", str44.equals("21"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "+35:01" + "'", str50.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter51);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2" + "'", str62.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 126060000 + "'", int65 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 12 + "'", int71 == 12);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        long long19 = offsetDateTimeField14.roundHalfEven((long) (-18062));
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfYear();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = property27.getAsText(locale28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property27.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType30, 10, 126060000, (int) '#');
//        boolean boolean36 = offsetDateTimeField34.isLeap((long) 126060000);
//        int int37 = offsetDateTimeField34.getOffset();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology43);
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.DateTime.Property property49 = dateTime48.dayOfYear();
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = property49.getAsText(locale50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, dateTimeFieldType52, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField57 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType52);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType52, 39660052, (int) '#', 12);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-60000L) + "'", long19 == (-60000L));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2" + "'", str29.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2" + "'", str51.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.getName();
//        java.lang.String str25 = unsupportedDateTimeField22.getName();
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField22.getRangeDurationField();
//        try {
//            java.lang.String str28 = unsupportedDateTimeField22.getAsText((long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfYear" + "'", str24.equals("dayOfYear"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "dayOfYear" + "'", str25.equals("dayOfYear"));
//        org.junit.Assert.assertNull(durationField26);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getRangeDurationField();
//        long long27 = unsupportedDateTimeField22.add(52L, 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology29);
//        java.util.Date date31 = dateTime30.toDate();
//        boolean boolean32 = dateTime30.isAfterNow();
//        boolean boolean34 = dateTime30.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.hourOfHalfday();
//        org.joda.time.DateTime dateTime39 = dateTime30.withChronology((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime43 = dateTime39.minusSeconds(10);
//        org.joda.time.DateTime dateTime45 = dateTime39.withMillisOfDay((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime45.minus(readablePeriod46);
//        org.joda.time.LocalDate localDate48 = dateTime45.toLocalDate();
//        java.util.Locale locale50 = null;
//        try {
//            java.lang.String str51 = unsupportedDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDate48, 43260010, locale50);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDate48);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        int int7 = property3.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        boolean boolean10 = property3.isLeap();
//        org.joda.time.Interval interval11 = property3.toInterval();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(interval11);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 1);
//        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean7 = jodaTimePermission5.equals((java.lang.Object) 1);
//        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
//        java.lang.String str9 = jodaTimePermission5.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfYear();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property13.getAsText(locale14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
//        java.lang.String str17 = property13.getAsText();
//        org.joda.time.DateTime dateTime19 = property13.setCopy((int) (short) 1);
//        int int20 = property13.getMaximumValue();
//        org.joda.time.DateTime dateTime21 = property13.withMinimumValue();
//        java.util.Locale locale22 = null;
//        int int23 = property13.getMaximumTextLength(locale22);
//        jodaTimePermission5.checkGuard((java.lang.Object) property13);
//        java.lang.String str25 = jodaTimePermission5.getActions();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"365\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"365\")"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2" + "'", str15.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime14 = dateTime11.withTimeAtStartOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology15.add(readablePeriod16, (long) '4', (int) (byte) 10);
//        int int20 = gregorianChronology15.getMinimumDaysInFirstWeek();
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime14, (java.lang.Object) int20);
//        org.joda.time.DateTime.Property property22 = dateTime14.centuryOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(property22);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder25.appendDayOfWeekText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime.Property property43 = dateTime42.dayOfYear();
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = property43.getAsText(locale44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property43.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType46, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField35, dateTimeFieldType46);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType46, (int) (byte) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder53.appendDayOfWeekShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2" + "'", str45.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.DateTime dateTime17 = dateTime11.withWeekyear(6);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str38 = dateTimeZone36.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter33.withZone(dateTimeZone36);
        org.joda.time.format.DateTimeParser dateTimeParser40 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str46 = dateTimeZone44.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter41.withZone(dateTimeZone44);
        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean50 = dateTimeFormatter49.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter49.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean53 = dateTimeFormatter52.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter52.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray55 = new org.joda.time.format.DateTimeParser[] { dateTimeParser40, dateTimeParser48, dateTimeParser51, dateTimeParser54 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder31.append(dateTimePrinter32, dateTimeParserArray55);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser58 = dateTimeFormatter57.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder56.append(dateTimeParser58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder30.appendOptional(dateTimeParser58);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder30.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder61.appendDayOfYear(3);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+35:01" + "'", str38.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeParser40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+35:01" + "'", str46.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNotNull(dateTimeParser48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeParser51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dateTimeParser54);
        org.junit.Assert.assertNotNull(dateTimeParserArray55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTimeParser58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (long) '4', (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        boolean boolean31 = dateTimeFormatterBuilder30.canBuildParser();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology33);
//        java.util.Date date35 = dateTime34.toDate();
//        boolean boolean36 = dateTime34.isAfterNow();
//        int int37 = dateTime34.getEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology39);
//        java.util.Date date41 = dateTime40.toDate();
//        boolean boolean42 = dateTime40.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology44);
//        org.joda.time.DateTime.Property property46 = dateTime45.dayOfYear();
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = property46.getAsText(locale47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property46.getFieldType();
//        int int50 = dateTime40.get(dateTimeFieldType49);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, "14");
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology54);
//        java.util.Date date56 = dateTime55.toDate();
//        boolean boolean57 = dateTime55.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology59);
//        org.joda.time.DateTime.Property property61 = dateTime60.dayOfYear();
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = property61.getAsText(locale62);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property61.getFieldType();
//        int int65 = dateTime55.get(dateTimeFieldType64);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "14");
//        illegalFieldValueException52.addSuppressed((java.lang.Throwable) illegalFieldValueException67);
//        java.lang.Number number69 = illegalFieldValueException52.getLowerBound();
//        illegalFieldValueException52.prependMessage("1");
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = illegalFieldValueException52.getDateTimeFieldType();
//        boolean boolean73 = dateTime34.isSupported(dateTimeFieldType72);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder30.appendFixedDecimal(dateTimeFieldType72, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2" + "'", str48.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2" + "'", str63.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.getName();
//        int int27 = unsupportedDateTimeField22.getDifference((-35999997L), 1314000010L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfYear" + "'", str24.equals("dayOfYear"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("365");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 1);
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("365");
        boolean boolean7 = jodaTimePermission5.equals((java.lang.Object) 1);
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        java.lang.String str9 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DateTimeField[dayOfYear]", "14");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "UTC", "1970-01-02T11:01:00.010+35:01");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "70", "10");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfYear();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType32, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField21, dateTimeFieldType32);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType32, 39660052, (int) '#', 12);
//        java.lang.Number number42 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, number42, "dayOfYear");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        long long24 = zeroIsMaxDateTimeField19.roundHalfCeiling((long) 0);
//        long long27 = zeroIsMaxDateTimeField19.getDifferenceAsLong((long) 1, (long) (-3));
//        org.joda.time.DurationField durationField28 = zeroIsMaxDateTimeField19.getLeapDurationField();
//        try {
//            long long31 = zeroIsMaxDateTimeField19.set((long) (-3), 57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for dayOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNull(durationField28);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(16, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.append(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
        java.util.Date date11 = dateTime10.toDate();
        int int12 = property7.getDifference((org.joda.time.ReadableInstant) dateTime10);
        int int13 = property7.getLeapAmount();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property7.getFieldType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DurationField durationField12 = gregorianChronology8.years();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 1);
//        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean7 = jodaTimePermission5.equals((java.lang.Object) 1);
//        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
//        java.lang.String str9 = jodaTimePermission1.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTime.Property property21 = dateTime20.dayOfYear();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property21.getAsText(locale22);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType24, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType24);
//        int int30 = zeroIsMaxDateTimeField29.getMaximumValue();
//        int int32 = zeroIsMaxDateTimeField29.getLeapAmount((long) ' ');
//        long long34 = zeroIsMaxDateTimeField29.roundHalfCeiling((long) 0);
//        int int36 = zeroIsMaxDateTimeField29.get((long) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology38);
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology42);
//        org.joda.time.DateTime.Property property44 = dateTime43.dayOfYear();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = property44.getAsText(locale45);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, dateTimeFieldType47, 10, 126060000, (int) '#');
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField51.getAsShortText((long) ' ', locale53);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str60 = dateTimeZone58.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = dateTimeFormatter55.withZone(dateTimeZone58);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology63);
//        java.util.Date date65 = dateTime64.toDate();
//        boolean boolean66 = dateTime64.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.DateTime.Property property70 = dateTime69.dayOfYear();
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = property70.getAsText(locale71);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property70.getFieldType();
//        int int74 = dateTime64.get(dateTimeFieldType73);
//        int int75 = dateTimeZone58.getOffset((org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.LocalDateTime localDateTime76 = dateTime64.toLocalDateTime();
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = offsetDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) localDateTime76, 0, locale78);
//        int int80 = zeroIsMaxDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) localDateTime76);
//        jodaTimePermission1.checkGuard((java.lang.Object) int80);
//        java.security.PermissionCollection permissionCollection82 = jodaTimePermission1.newPermissionCollection();
//        java.security.PermissionCollection permissionCollection83 = jodaTimePermission1.newPermissionCollection();
//        org.joda.time.JodaTimePermission jodaTimePermission85 = new org.joda.time.JodaTimePermission("365");
//        boolean boolean87 = jodaTimePermission85.equals((java.lang.Object) 1);
//        boolean boolean88 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission85);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"365\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"365\")"));
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2" + "'", str23.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-60000L) + "'", long34 == (-60000L));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2" + "'", str46.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "21" + "'", str54.equals("21"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+35:01" + "'", str60.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2" + "'", str72.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 126060000 + "'", int75 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime76);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "0" + "'", str79.equals("0"));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(permissionCollection82);
//        org.junit.Assert.assertNotNull(permissionCollection83);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.appendCenturyOfEra((int) (byte) 10, 39660052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder25.appendTimeZoneId();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology40);
//        org.joda.time.DateTime.Property property42 = dateTime41.dayOfYear();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = property42.getAsText(locale43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType45, 10, 126060000, (int) '#');
//        boolean boolean51 = offsetDateTimeField49.isLeap((long) 126060000);
//        int int52 = offsetDateTimeField49.getOffset();
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology62);
//        org.joda.time.DateTime.Property property64 = dateTime63.dayOfYear();
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = property64.getAsText(locale65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property64.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, dateTimeFieldType67, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField72 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField56, dateTimeFieldType67);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField49, dateTimeFieldType67, 39660052, (int) '#', 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder34.appendSignedDecimal(dateTimeFieldType67, 59, 0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter80 = dateTimeFormatterBuilder34.toPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2" + "'", str44.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2" + "'", str66.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertNotNull(dateTimePrinter80);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        int int24 = zeroIsMaxDateTimeField19.getMinimumValue((long) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTime.Property property32 = dateTime31.dayOfYear();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = property32.getAsText(locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType35, 10, 126060000, (int) '#');
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField39.getAsShortText((long) ' ', locale41);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str48 = dateTimeZone46.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter43.withZone(dateTimeZone46);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology51);
//        java.util.Date date53 = dateTime52.toDate();
//        boolean boolean54 = dateTime52.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology56);
//        org.joda.time.DateTime.Property property58 = dateTime57.dayOfYear();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = property58.getAsText(locale59);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property58.getFieldType();
//        int int62 = dateTime52.get(dateTimeFieldType61);
//        int int63 = dateTimeZone46.getOffset((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.LocalDateTime localDateTime64 = dateTime52.toLocalDateTime();
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) localDateTime64, 0, locale66);
//        int int68 = zeroIsMaxDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDateTime64);
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = zeroIsMaxDateTimeField19.getAsText((long) 4, locale70);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2" + "'", str34.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "21" + "'", str42.equals("21"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+35:01" + "'", str48.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2" + "'", str60.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 126060000 + "'", int63 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 12 + "'", int68 == 12);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "11" + "'", str71.equals("11"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        long long24 = zeroIsMaxDateTimeField19.roundHalfCeiling((long) 0);
//        long long27 = zeroIsMaxDateTimeField19.getDifferenceAsLong((long) 1969, (long) 11);
//        long long29 = zeroIsMaxDateTimeField19.roundHalfFloor(62135568422002L);
//        int int31 = zeroIsMaxDateTimeField19.getMinimumValue((-660960108000000L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 62135567940000L + "'", long29 == 62135567940000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendDayOfYear(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMillisOfSecond((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendTwoDigitYear(57600, true);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitYear((-15));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
//        java.lang.String str4 = dateTimeFormatter0.print((long) 34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str10 = dateTimeZone8.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology13);
//        java.util.Date date15 = dateTime14.toDate();
//        boolean boolean16 = dateTime14.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfYear();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property20.getAsText(locale21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
//        int int24 = dateTime14.get(dateTimeFieldType23);
//        int int25 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        java.lang.String str26 = dateTimeZone8.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        int int29 = cachedDateTimeZone27.getStandardOffset((long) (byte) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "T110100+3501" + "'", str4.equals("T110100+3501"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+35:01" + "'", str10.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2" + "'", str22.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 126060000 + "'", int25 == 126060000);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+35:01" + "'", str26.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.minusSeconds(10);
//        org.joda.time.DateTime dateTime17 = dateTime11.withMillisOfDay((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(readablePeriod18);
//        org.joda.time.DateTime.Property property20 = dateTime17.secondOfMinute();
//        int int21 = property20.getLeapAmount();
//        org.joda.time.DateTime dateTime22 = property20.roundHalfFloorCopy();
//        boolean boolean23 = property20.isLeap();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        int int24 = zeroIsMaxDateTimeField19.getMinimumValue((long) (byte) 0);
//        int int25 = zeroIsMaxDateTimeField19.getMaximumValue();
//        boolean boolean27 = zeroIsMaxDateTimeField19.isLeap(1314000010L);
//        int int29 = zeroIsMaxDateTimeField19.getMinimumValue((long) (byte) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsText(locale9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        int int12 = dateTime2.get(dateTimeFieldType11);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "14");
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology16);
//        java.util.Date date18 = dateTime17.toDate();
//        boolean boolean19 = dateTime17.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfYear();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsText(locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
//        int int27 = dateTime17.get(dateTimeFieldType26);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "14");
//        illegalFieldValueException14.addSuppressed((java.lang.Throwable) illegalFieldValueException29);
//        illegalFieldValueException14.prependMessage("DateTimeField[dayOfYear]");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2" + "'", str25.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
//        int int13 = dateTime9.getDayOfWeek();
//        org.joda.time.DurationFieldType durationFieldType14 = null;
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime9.withFieldAdded(durationFieldType14, 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (long) '4', (int) (byte) 10);
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        java.lang.Class<?> wildcardClass7 = gregorianChronology0.getClass();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTime dateTime7 = property3.addToCopy((-3));
//        boolean boolean8 = property3.isLeap();
//        org.joda.time.DateTime dateTime10 = property3.addWrapFieldToCopy((int) (byte) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) -1);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTime dateTime4 = property2.roundFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMinuteOfHour(1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        int int3 = dateTime2.getYear();
//        try {
//            org.joda.time.DateTime dateTime5 = dateTime2.withEra(8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendSecondOfDay(12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendSecondOfMinute(61200010);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsText(locale9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        int int12 = dateTime2.get(dateTimeFieldType11);
//        int int13 = dateTime2.getYear();
//        org.joda.time.DateTime.Property property14 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = property14.setCopy(0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        int int22 = zeroIsMaxDateTimeField19.getLeapAmount((long) ' ');
//        long long24 = zeroIsMaxDateTimeField19.roundHalfCeiling((long) 0);
//        long long27 = zeroIsMaxDateTimeField19.getDifferenceAsLong((long) 1, (long) (-3));
//        org.joda.time.DurationField durationField28 = zeroIsMaxDateTimeField19.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTime.Property property32 = dateTime31.dayOfYear();
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = property32.getAsText(locale33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
//        java.lang.String str36 = property32.getAsText();
//        org.joda.time.DateTime dateTime38 = property32.setCopy((int) (short) 1);
//        int int39 = property32.getMaximumValue();
//        org.joda.time.DateTime dateTime40 = property32.roundFloorCopy();
//        org.joda.time.TimeOfDay timeOfDay41 = dateTime40.toTimeOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology44);
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology48);
//        org.joda.time.DateTime.Property property50 = dateTime49.dayOfYear();
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = property50.getAsText(locale51);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType53, 10, 126060000, (int) '#');
//        boolean boolean59 = offsetDateTimeField57.isLeap((long) 126060000);
//        int int60 = offsetDateTimeField57.getOffset();
//        org.joda.time.ReadablePartial readablePartial61 = null;
//        int[] intArray68 = new int[] { 52, (-1), 1, (short) -1, 57600, 200 };
//        int int69 = offsetDateTimeField57.getMinimumValue(readablePartial61, intArray68);
//        try {
//            int[] intArray71 = zeroIsMaxDateTimeField19.add((org.joda.time.ReadablePartial) timeOfDay41, 2, intArray68, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2" + "'", str34.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2" + "'", str36.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 365 + "'", int39 == 365);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(timeOfDay41);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2" + "'", str52.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 126060000 + "'", int69 == 126060000);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusHours((-1));
//        org.joda.time.DateTime dateTime18 = dateTime13.withWeekyear(200);
//        org.joda.time.DateTime dateTime19 = dateTime13.toDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
//        java.util.Date date23 = dateTime22.toDate();
//        boolean boolean24 = dateTime22.isAfterNow();
//        boolean boolean26 = dateTime22.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfHalfday();
//        org.joda.time.DateTime dateTime31 = dateTime22.withChronology((org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.DateTime dateTime33 = dateTime31.minusDays((int) (short) 0);
//        int int34 = dateTime33.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime36 = dateTime33.minusHours((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology38);
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime36.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
//        int int42 = dateTime13.compareTo((org.joda.time.ReadableInstant) mutableDateTime41);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField20, dateTimeFieldType27);
//        java.lang.String str30 = remainderDateTimeField20.getAsText(100L);
//        long long32 = remainderDateTimeField20.remainder((-18062L));
//        long long35 = remainderDateTimeField20.getDifferenceAsLong((long) 21, (long) (byte) 1);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = remainderDateTimeField20.getAsShortText((-75618062L), locale37);
//        long long40 = remainderDateTimeField20.roundHalfFloor(3600000L);
//        org.joda.time.DurationField durationField41 = remainderDateTimeField20.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology43);
//        java.util.Date date45 = dateTime44.toDate();
//        boolean boolean46 = dateTime44.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology48);
//        org.joda.time.DateTime.Property property50 = dateTime49.dayOfYear();
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = property50.getAsText(locale51);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
//        int int54 = dateTime44.get(dateTimeFieldType53);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, "14");
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology58);
//        java.util.Date date60 = dateTime59.toDate();
//        boolean boolean61 = dateTime59.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology63);
//        org.joda.time.DateTime.Property property65 = dateTime64.dayOfYear();
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = property65.getAsText(locale66);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property65.getFieldType();
//        int int69 = dateTime59.get(dateTimeFieldType68);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, "14");
//        illegalFieldValueException56.addSuppressed((java.lang.Throwable) illegalFieldValueException71);
//        java.lang.Number number73 = illegalFieldValueException56.getLowerBound();
//        illegalFieldValueException56.prependMessage("1");
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = illegalFieldValueException56.getDateTimeFieldType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = illegalFieldValueException56.getDateTimeFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField20, dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3581938L + "'", long32 == 3581938L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2" + "'", str38.equals("2"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 3600000L + "'", long40 == 3600000L);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2" + "'", str52.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2" + "'", str67.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
//        org.junit.Assert.assertNull(number73);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getDurationField();
//        try {
//            int int27 = unsupportedDateTimeField22.get((long) 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField25);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod3, 10800000L, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.Chronology chronology7 = iSOChronology1.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        int int4 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int6 = dateTime5.getMinuteOfHour();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((-18062));
//        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 126060000 + "'", int4 == 126060000);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        boolean boolean22 = zeroIsMaxDateTimeField19.isLeap((long) 200);
//        int int24 = zeroIsMaxDateTimeField19.getMinimumValue((long) (-18062));
//        int int27 = zeroIsMaxDateTimeField19.getDifference(100L, (long) 2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter29 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str35 = dateTimeZone33.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter30.withZone(dateTimeZone33);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter30.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str43 = dateTimeZone41.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter38.withZone(dateTimeZone41);
//        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter38.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean47 = dateTimeFormatter46.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter46.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean50 = dateTimeFormatter49.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter49.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray52 = new org.joda.time.format.DateTimeParser[] { dateTimeParser37, dateTimeParser45, dateTimeParser48, dateTimeParser51 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder28.append(dateTimePrinter29, dateTimeParserArray52);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatter54.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder53.append(dateTimeParser55);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder53.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder53.appendDayOfWeekText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology61);
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology65);
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology65.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology69);
//        org.joda.time.DateTime.Property property71 = dateTime70.dayOfYear();
//        java.util.Locale locale72 = null;
//        java.lang.String str73 = property71.getAsText(locale72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = property71.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, dateTimeFieldType74, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField63, dateTimeFieldType74);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder53.appendFixedSignedDecimal(dateTimeFieldType74, (int) (byte) 100);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField19, dateTimeFieldType74, (int) '#', (-15), (int) (byte) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+35:01" + "'", str35.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+35:01" + "'", str43.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeParser45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser51);
//        org.junit.Assert.assertNotNull(dateTimeParserArray52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeParser55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2" + "'", str73.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(32, (int) (short) -1, 0, 0, (int) (short) 10, 12, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTime dateTime7 = property3.addToCopy((-3));
//        boolean boolean8 = property3.isLeap();
//        java.lang.String str9 = property3.getAsString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str4 = dateTimeZone2.getName((long) '4');
//        java.lang.String str5 = dateTimeZone2.getID();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology17);
//        java.util.Date date19 = dateTime18.toDate();
//        boolean boolean20 = dateTime18.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        int int29 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str30 = dateTimeZone12.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        java.util.Date date36 = dateTime35.toDate();
//        boolean boolean37 = dateTime35.isAfterNow();
//        boolean boolean39 = dateTime35.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfHalfday();
//        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(readableDuration49, 0);
//        boolean boolean52 = zonedChronology32.equals((java.lang.Object) readableDuration49);
//        org.joda.time.DateTimeField dateTimeField53 = zonedChronology32.dayOfWeek();
//        java.lang.String str54 = zonedChronology32.toString();
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str59 = dateTimeZone57.getName((long) '4');
//        java.lang.String str60 = dateTimeZone57.getID();
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone57);
//        org.joda.time.Chronology chronology62 = zonedChronology32.withZone(dateTimeZone61);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+35:01" + "'", str30.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ZonedChronology[ISOChronology[UTC], +35:01]" + "'", str54.equals("ZonedChronology[ISOChronology[UTC], +35:01]"));
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "+35:01" + "'", str59.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+35:01" + "'", str60.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(chronology62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        int int4 = dateTimeZone2.getOffsetFromLocal(0L);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
//        int int6 = dateTime5.getMinuteOfHour();
//        int int7 = dateTime5.getMillisOfDay();
//        int int8 = dateTime5.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 126060000 + "'", int4 == 126060000);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 39660001 + "'", int7 == 39660001);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 661 + "'", int8 == 661);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getDurationField();
//        int int28 = unsupportedDateTimeField22.getDifference((long) 8, 60000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfYear();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = property36.getAsText(locale37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, dateTimeFieldType39, 10, 126060000, (int) '#');
//        boolean boolean45 = offsetDateTimeField43.isLeap((long) 126060000);
//        int int46 = offsetDateTimeField43.getOffset();
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        int[] intArray54 = new int[] { 52, (-1), 1, (short) -1, 57600, 200 };
//        int int55 = offsetDateTimeField43.getMinimumValue(readablePartial47, intArray54);
//        long long57 = offsetDateTimeField43.remainder(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology59);
//        java.util.Date date61 = dateTime60.toDate();
//        boolean boolean62 = dateTime60.isAfterNow();
//        boolean boolean64 = dateTime60.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology66.hourOfHalfday();
//        org.joda.time.DateTime dateTime69 = dateTime60.withChronology((org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.DateTime dateTime71 = dateTime69.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime73 = dateTime69.minusSeconds(10);
//        org.joda.time.DateTime dateTime75 = dateTime69.withMillisOfDay((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod76 = null;
//        org.joda.time.DateTime dateTime77 = dateTime75.minus(readablePeriod76);
//        org.joda.time.LocalDate localDate78 = dateTime75.toLocalDate();
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = offsetDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) localDate78, locale79);
//        java.util.Locale locale82 = null;
//        try {
//            java.lang.String str83 = unsupportedDateTimeField22.getAsText((org.joda.time.ReadablePartial) localDate78, (-3), locale82);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2" + "'", str38.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 126060000 + "'", int55 == 126060000);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 60000L + "'", long57 == 60000L);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2" + "'", str80.equals("2"));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
        java.util.Date date7 = dateTime6.toDate();
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.plus(readablePeriod9);
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.joda.time.DateTime.Property property12 = dateTime10.weekyear();
        boolean boolean14 = dateTime10.isBefore((-1L));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        boolean boolean3 = dateTime2.isBeforeNow();
//        org.joda.time.DateTime dateTime5 = dateTime2.withHourOfDay((int) (byte) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getRangeDurationField();
//        long long27 = unsupportedDateTimeField22.add(52L, 0);
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField22.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.append(dateTimeFormatter26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendWeekOfWeekyear(6);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        long long21 = dividedDateTimeField19.remainder(1L);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        org.joda.time.DurationField durationField23 = remainderDateTimeField22.getRangeDurationField();
//        org.joda.time.DurationField durationField24 = remainderDateTimeField22.getRangeDurationField();
//        long long26 = remainderDateTimeField22.remainder((long) 34);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 34L + "'", long26 == 34L);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DateTimeField[dayOfYear]", "14");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "UTC", "1970-01-02T11:01:00.010+35:01");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths((-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        org.joda.time.DateTime dateTime30 = dateTime18.withWeekyear(0);
//        org.joda.time.DateMidnight dateMidnight31 = dateTime30.toDateMidnight();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateMidnight31);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 365, 979200059L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 979200424L + "'", long2 == 979200424L);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        int int7 = property3.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        boolean boolean10 = property3.isLeap();
//        org.joda.time.DateTime dateTime11 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        java.lang.String str16 = offsetDateTimeField14.getAsText(52L);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField14.getAsShortText((-363599900L), locale18);
//        long long21 = offsetDateTimeField14.roundHalfEven((long) 32);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21" + "'", str16.equals("21"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-60000L) + "'", long21 == (-60000L));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy(2);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear(0);
//        int int12 = dateTime11.getYear();
//        int int13 = dateTime11.getHourOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField14.getAsShortText((long) ' ', locale16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str23 = dateTimeZone21.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter18.withZone(dateTimeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology26);
//        java.util.Date date28 = dateTime27.toDate();
//        boolean boolean29 = dateTime27.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTime.Property property33 = dateTime32.dayOfYear();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = property33.getAsText(locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property33.getFieldType();
//        int int37 = dateTime27.get(dateTimeFieldType36);
//        int int38 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime27.toLocalDateTime();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDateTime39, 0, locale41);
//        boolean boolean43 = offsetDateTimeField14.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "21" + "'", str17.equals("21"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+35:01" + "'", str23.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2" + "'", str35.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 126060000 + "'", int38 == 126060000);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str5 = dateTimeZone3.getName((long) '4');
//        java.lang.String str6 = dateTimeZone3.getID();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        boolean boolean8 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
//        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str16 = dateTimeZone14.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter11.withZone(dateTimeZone14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        java.util.Date date21 = dateTime20.toDate();
//        boolean boolean22 = dateTime20.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfYear();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = property26.getAsText(locale27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        int int30 = dateTime20.get(dateTimeFieldType29);
//        int int31 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.String str32 = dateTimeZone14.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        int int35 = cachedDateTimeZone33.getStandardOffset((long) (byte) 10);
//        long long37 = cachedDateTimeZone33.nextTransition((long) (-18062));
//        java.lang.String str39 = cachedDateTimeZone33.getNameKey(0L);
//        java.lang.String str41 = cachedDateTimeZone33.getShortName((long) 'a');
//        org.joda.time.Chronology chronology42 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone33);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+35:01" + "'", str6.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+35:01" + "'", str16.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2" + "'", str28.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 126060000 + "'", int31 == 126060000);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+35:01" + "'", str32.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 126060000 + "'", int35 == 126060000);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-18062L) + "'", long37 == (-18062L));
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+35:01" + "'", str41.equals("+35:01"));
//        org.junit.Assert.assertNotNull(chronology42);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (long) '4', (int) (byte) 10);
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendSecondOfDay(12);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendPattern("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: O");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField19);
//        int int22 = remainderDateTimeField20.get((long) (-3));
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = remainderDateTimeField20.getAsText(0, locale24);
//        long long27 = remainderDateTimeField20.roundHalfCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
//        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
//        org.joda.time.DateTime dateTime11 = property9.roundHalfEvenCopy();
//        boolean boolean13 = property9.equals((java.lang.Object) 10);
//        org.joda.time.DateTime dateTime14 = property9.withMaximumValue();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfYear();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = property25.getAsText(locale26);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType28, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, 3);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology37);
//        org.joda.time.DateTime.Property property39 = dateTime38.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = property39.getAsText(locale40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property39.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField35, dateTimeFieldType42);
//        org.joda.time.DateTime.Property property44 = dateTime14.property(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2" + "'", str27.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2" + "'", str41.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(property44);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property9.getAsText(locale11);
//        int int13 = property9.get();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "70" + "'", str12.equals("70"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 70 + "'", int13 == 70);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType14, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType14);
//        int int20 = zeroIsMaxDateTimeField19.getMaximumValue();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = zeroIsMaxDateTimeField19.getAsText(32, locale22);
//        int int26 = zeroIsMaxDateTimeField19.getDifference((long) 960, (-101L));
//        boolean boolean28 = zeroIsMaxDateTimeField19.isLeap((-363599900L));
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2" + "'", str13.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "32" + "'", str23.equals("32"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(4, 0, 1969, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
        java.util.Date date7 = dateTime6.toDate();
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = property9.roundHalfEvenCopy();
        boolean boolean13 = property9.equals((java.lang.Object) 10);
        java.util.Locale locale14 = null;
        int int15 = property9.getMaximumTextLength(locale14);
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) locale14, (java.lang.Object) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        int int7 = property3.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        int int10 = property3.getMinimumValueOverall();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfYear();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property14.getAsText(locale15);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        java.lang.String str18 = property14.getAsText();
//        org.joda.time.DateTime dateTime20 = property14.addToCopy((int) (byte) -1);
//        int int21 = property3.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = property3.addToCopy((long) 126060000);
//        boolean boolean24 = property3.isLeap();
//        java.util.Locale locale26 = null;
//        org.joda.time.DateTime dateTime27 = property3.setCopy("70", locale26);
//        java.lang.String str28 = property3.getAsString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2" + "'", str16.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2" + "'", str28.equals("2"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatterBuilder26.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendDayOfMonth(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology11);
//        java.util.Date date13 = dateTime12.toDate();
//        boolean boolean14 = dateTime12.isAfterNow();
//        boolean boolean16 = dateTime12.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.DateTime dateTime21 = dateTime12.withChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime25 = dateTime21.minusSeconds(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfYear();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        java.lang.String str33 = property29.getAsText();
//        org.joda.time.DateTime dateTime35 = property29.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime37 = dateTime35.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime40 = dateTime37.withTimeAtStartOfDay();
//        boolean boolean41 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.ReadableDuration readableDuration43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime9.minus(readableDuration43);
//        boolean boolean45 = dateTime9.isAfterNow();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2" + "'", str33.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType10, 10, 126060000, (int) '#');
//        boolean boolean16 = offsetDateTimeField14.isLeap((long) 126060000);
//        int int17 = offsetDateTimeField14.getOffset();
//        org.joda.time.DurationField durationField18 = offsetDateTimeField14.getLeapDurationField();
//        long long20 = offsetDateTimeField14.roundCeiling(34L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3540000L + "'", long20 == 3540000L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (long) '4', (int) (byte) 10);
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        java.lang.Class<?> wildcardClass7 = gregorianChronology0.getClass();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField9 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("57600010");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDateTime2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatterBuilder30.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimePrinter31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 19, 661, (-101));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for hourOfHalfday must be in the range [661,-101]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addWrapFieldToCopy(2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology11);
//        java.util.Date date13 = dateTime12.toDate();
//        boolean boolean14 = dateTime12.isAfterNow();
//        boolean boolean16 = dateTime12.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.DateTime dateTime21 = dateTime12.withChronology((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime25 = dateTime21.minusSeconds(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfYear();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property29.getAsText(locale30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        java.lang.String str33 = property29.getAsText();
//        org.joda.time.DateTime dateTime35 = property29.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime37 = dateTime35.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) (byte) 100);
//        org.joda.time.DateTime dateTime40 = dateTime37.withTimeAtStartOfDay();
//        boolean boolean41 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.LocalTime localTime43 = dateTime9.toLocalTime();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2" + "'", str31.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2" + "'", str33.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(localTime43);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str4 = dateTimeZone2.getName((long) '4');
        java.lang.String str5 = dateTimeZone2.getID();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        long long9 = dateTimeZone6.adjustOffset((long) 39660052, true);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 39660052L + "'", long9 == 39660052L);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusHours((-1));
//        int int17 = dateTime13.getHourOfDay();
//        org.joda.time.DateTime dateTime19 = dateTime13.plusDays(0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 11 + "'", int17 == 11);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
//        org.joda.time.DateTime dateTime15 = property14.getDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str7 = dateTimeZone5.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str15 = dateTimeZone13.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.appendCenturyOfEra((int) (byte) 10, 39660052);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder25.appendTimeZoneId();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology40);
//        org.joda.time.DateTime.Property property42 = dateTime41.dayOfYear();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = property42.getAsText(locale43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType45, 10, 126060000, (int) '#');
//        boolean boolean51 = offsetDateTimeField49.isLeap((long) 126060000);
//        int int52 = offsetDateTimeField49.getOffset();
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology62);
//        org.joda.time.DateTime.Property property64 = dateTime63.dayOfYear();
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = property64.getAsText(locale65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property64.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, dateTimeFieldType67, 10, 126060000, (int) '#');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField72 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField56, dateTimeFieldType67);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField49, dateTimeFieldType67, 39660052, (int) '#', 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder34.appendSignedDecimal(dateTimeFieldType67, 59, 0);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap80 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder79.appendTimeZoneName(strMap80);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeParser23);
//        org.junit.Assert.assertNotNull(dateTimeParserArray24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeParser27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2" + "'", str44.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2" + "'", str66.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str4 = dateTimeZone2.getName((long) '4');
        java.lang.String str5 = dateTimeZone2.getID();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long10 = dateTimeZone2.adjustOffset(31507200010L, false);
        java.lang.String str11 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31507200010L + "'", long10 == 31507200010L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+35:01" + "'", str11.equals("+35:01"));
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str4 = dateTimeZone2.getName((long) '4');
//        java.lang.String str5 = dateTimeZone2.getID();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.yearOfEra();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str14 = dateTimeZone12.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter9.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology17);
//        java.util.Date date19 = dateTime18.toDate();
//        boolean boolean20 = dateTime18.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        int int28 = dateTime18.get(dateTimeFieldType27);
//        int int29 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str30 = dateTimeZone12.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology34);
//        java.util.Date date36 = dateTime35.toDate();
//        boolean boolean37 = dateTime35.isAfterNow();
//        boolean boolean39 = dateTime35.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.hourOfHalfday();
//        org.joda.time.DateTime dateTime44 = dateTime35.withChronology((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration49 = null;
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(readableDuration49, 0);
//        boolean boolean52 = zonedChronology32.equals((java.lang.Object) readableDuration49);
//        org.joda.time.DateTimeField dateTimeField53 = zonedChronology32.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField54 = zonedChronology32.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField55 = zonedChronology32.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+35:01" + "'", str4.equals("+35:01"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+35:01" + "'", str14.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2" + "'", str26.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 126060000 + "'", int29 == 126060000);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+35:01" + "'", str30.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        int int5 = dateTime2.getEra();
//        int int6 = dateTime2.getMonthOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths(57600010);
//        org.joda.time.DateTime dateTime9 = dateTime8.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime9.plus((long) 61200010);
//        org.joda.time.LocalDateTime localDateTime12 = dateTime9.toLocalDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
        boolean boolean31 = dateTimeFormatterBuilder25.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.appendLiteral("(\"org.joda.time.JodaTimePermission\" \"365\")");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendHourOfHalfday((int) (short) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendCenturyOfEra((-101), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(16, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond(0, 21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths((-1));
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        java.lang.String str22 = property21.getAsText();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "December" + "'", str22.equals("December"));
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfYear();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType13, 10, 126060000, (int) '#');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType13, 3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        boolean boolean23 = unsupportedDateTimeField22.isSupported();
//        java.lang.String str24 = unsupportedDateTimeField22.toString();
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getDurationField();
//        int int28 = unsupportedDateTimeField22.getDifference((long) 8, 60000L);
//        java.util.Locale locale29 = null;
//        try {
//            int int30 = unsupportedDateTimeField22.getMaximumTextLength(locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDateTimeField" + "'", str24.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfYear();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsText(locale9);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        int int12 = dateTime2.get(dateTimeFieldType11);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "14");
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology16);
//        java.util.Date date18 = dateTime17.toDate();
//        boolean boolean19 = dateTime17.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfYear();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = property23.getAsText(locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
//        int int27 = dateTime17.get(dateTimeFieldType26);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "14");
//        illegalFieldValueException14.addSuppressed((java.lang.Throwable) illegalFieldValueException29);
//        java.lang.Number number31 = illegalFieldValueException14.getLowerBound();
//        java.lang.Number number32 = illegalFieldValueException14.getIllegalNumberValue();
//        java.lang.Number number33 = illegalFieldValueException14.getIllegalNumberValue();
//        java.lang.Number number34 = illegalFieldValueException14.getIllegalNumberValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2" + "'", str25.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertNull(number34);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
//        int int13 = dateTime9.getDayOfWeek();
//        org.joda.time.DateTime dateTime14 = dateTime9.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        int int7 = property3.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property3.getAsText(locale8);
//        int int10 = property3.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime12 = property3.setCopy(10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2" + "'", str9.equals("2"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology5);
//        java.util.Date date7 = dateTime6.toDate();
//        int int8 = property3.getDifference((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.withFields(readablePartial9);
//        boolean boolean12 = dateTime6.isBefore((long) 16);
//        int int13 = dateTime6.getYear();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.append(dateTimeParser27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatterBuilder30.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        boolean boolean26 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendDayOfYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendDayOfYear(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder0.appendMinuteOfDay(39660010);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendFractionOfSecond(39660, 1969);
        boolean boolean36 = dateTimeFormatterBuilder35.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str7 = dateTimeZone5.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
        java.lang.String str15 = dateTimeZone13.getName((long) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter10.withZone(dateTimeZone13);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean19 = dateTimeFormatter18.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean22 = dateTimeFormatter21.isOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray24 = new org.joda.time.format.DateTimeParser[] { dateTimeParser9, dateTimeParser17, dateTimeParser20, dateTimeParser23 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter1, dateTimeParserArray24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) '#', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendClockhourOfDay(13);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+35:01" + "'", str7.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+35:01" + "'", str15.equals("+35:01"));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeParserArray24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        java.util.Date date3 = dateTime2.toDate();
//        boolean boolean4 = dateTime2.isAfterNow();
//        boolean boolean6 = dateTime2.equals((java.lang.Object) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.hourOfHalfday();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 0);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime13.minusHours((-1));
//        org.joda.time.DateTime dateTime18 = dateTime13.withEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime18.withTimeAtStartOfDay();
//        java.lang.String str20 = dateTime19.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-02T00:00:00.000+35:01" + "'", str20.equals("1970-01-02T00:00:00.000+35:01"));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime10 = property3.getDateTime();
//        org.joda.time.DurationField durationField11 = property3.getRangeDurationField();
//        org.joda.time.DateTime dateTime12 = property3.getDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
//        java.lang.String str7 = property3.getAsText();
//        org.joda.time.DateTime dateTime9 = property3.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (byte) 100);
//        int int14 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1970", "(\"org.joda.time.JodaTimePermission\" \"365\")", (int) (byte) 10, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getStandardOffset((long) 59);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(57720059L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (byte) 1);
//        java.lang.String str5 = dateTimeZone3.getName((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology8);
//        java.util.Date date10 = dateTime9.toDate();
//        boolean boolean11 = dateTime9.isAfterNow();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property15.getAsText(locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
//        int int19 = dateTime9.get(dateTimeFieldType18);
//        int int20 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str21 = dateTimeZone3.getID();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        int int24 = cachedDateTimeZone22.getStandardOffset((long) (byte) 10);
//        long long26 = cachedDateTimeZone22.nextTransition((long) (-18062));
//        java.lang.String str28 = cachedDateTimeZone22.getNameKey(0L);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTime.Property property33 = dateTime32.dayOfYear();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = property33.getAsText(locale34);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property33.getFieldType();
//        java.lang.String str37 = property33.getAsText();
//        org.joda.time.DateTime dateTime39 = property33.addToCopy((int) (byte) -1);
//        org.joda.time.DateTime dateTime41 = dateTime39.minusDays((int) 'a');
//        org.joda.time.DateTime dateTime43 = dateTime41.withMillis((long) (byte) 100);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime46 = dateTime43.withPeriodAdded(readablePeriod44, 3);
//        java.lang.Class<?> wildcardClass47 = dateTime43.getClass();
//        int int48 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) dateTime43);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTime.Property property50 = dateTime49.weekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+35:01" + "'", str5.equals("+35:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2" + "'", str17.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 126060000 + "'", int20 == 126060000);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+35:01" + "'", str21.equals("+35:01"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 126060000 + "'", int24 == 126060000);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-18062L) + "'", long26 == (-18062L));
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2" + "'", str35.equals("2"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2" + "'", str37.equals("2"));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 126060000 + "'", int48 == 126060000);
//        org.junit.Assert.assertNotNull(property50);
//    }
//}

