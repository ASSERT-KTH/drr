import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        int int76 = remainderDateTimeField74.get((long) 83555325);
//        java.util.Locale locale77 = null;
//        int int78 = remainderDateTimeField74.getMaximumTextLength(locale77);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.Chronology chronology5 = dateTime0.getChronology();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        int int76 = remainderDateTimeField74.get((long) 83555325);
//        long long78 = remainderDateTimeField74.roundHalfEven(54755180L);
//        long long80 = remainderDateTimeField74.roundHalfFloor((-61157376000000L));
//        long long82 = remainderDateTimeField74.roundHalfEven(34L);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 54755000L + "'", long78 == 54755000L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-61157376000000L) + "'", long80 == (-61157376000000L));
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        int int68 = unsupportedDateTimeField65.getDifference((-54755324L), 35L);
//        try {
//            int int70 = unsupportedDateTimeField65.getMinimumValue(2998127984648127L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615200 + "'", int48 == 83615200);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis(54755324);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withDefaultYear(54755955);
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        try {
//            java.lang.String str13 = dateTime7.toString("JulianChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "07:25:46.651-07:00" + "'", str11.equals("07:25:46.651-07:00"));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 54755359);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(355, 32);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.append(dateTimeParser10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType13, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTimeZoneOffset("", true, 13, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField8.getAsText((long) 59, locale17);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField8.getRangeDurationField();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField8.getAsText(36, locale21);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate26 = localDate24.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate28 = localDate24.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property29 = localDate28.year();
//        org.joda.time.LocalDate.Property property30 = localDate28.monthOfYear();
//        org.joda.time.LocalDate localDate31 = property30.withMinimumValue();
//        org.joda.time.LocalDate localDate33 = localDate31.withDayOfYear(15);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.LocalDate localDate35 = localDate33.minus(readablePeriod34);
//        int[] intArray40 = new int[] { 54755840, 12, 83555506 };
//        java.util.Locale locale42 = null;
//        try {
//            int[] intArray43 = offsetDateTimeField8.set((org.joda.time.ReadablePartial) localDate35, 6, intArray40, "JulianChronology[UTC]", locale42);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[UTC]\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615642 + "'", int6 == 83615642);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "91" + "'", str18.equals("91"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "36" + "'", str22.equals("36"));
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(intArray40);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withMinuteOfHour(15);
//        org.joda.time.DurationFieldType durationFieldType8 = null;
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime0.withFieldAdded(durationFieldType8, 54755939);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        int int8 = cachedDateTimeZone5.getOffset((long) 12);
//        long long10 = cachedDateTimeZone5.nextTransition((long) '4');
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfMonth();
//        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        long long19 = dateTimeZone16.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        int int24 = cachedDateTimeZone21.getOffset((long) 12);
//        long long26 = cachedDateTimeZone21.nextTransition((long) '4');
//        org.joda.time.Chronology chronology27 = gJChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        int int29 = cachedDateTimeZone21.getOffset(83555474L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9972000000L + "'", long10 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 34L + "'", long19 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9972000000L + "'", long26 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long11 = offsetDateTimeField8.set(1239139619L, 100);
//        long long14 = offsetDateTimeField8.add((long) 39, (long) 54755726);
//        int int16 = offsetDateTimeField8.getLeapAmount((long) 54755098);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615776 + "'", int6 == 83615776);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1209600068L + "'", long11 == 1209600068L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54755765L + "'", long14 == 54755765L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfEvenCopy();
        int int8 = localDate7.getDayOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate localDate13 = localDate11.plusDays(16);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfYear();
        boolean boolean15 = property14.isLeap();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.toString();
        java.lang.String str6 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")", "0010");
        illegalFieldValueException2.prependMessage("0001-167T16:12:50.915-07:52:58");
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, (int) ' ');
//        org.joda.time.DateTime.Property property7 = dateTime3.year();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale7 = dateTimeFormatter6.getLocale();
        boolean boolean8 = cachedDateTimeZone5.equals((java.lang.Object) locale7);
        java.lang.String str10 = cachedDateTimeZone5.getNameKey((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.LocalDate localDate6 = localDate2.minus(readablePeriod5);
        int int7 = localDate2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        int int5 = dateTimeFormatter4.getDefaultYear();
        int int6 = dateTimeFormatter4.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = localDate11.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
        org.joda.time.DurationFieldType durationFieldType18 = illegalFieldValueException17.getDurationFieldType();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNull(durationFieldType18);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        int int68 = unsupportedDateTimeField65.getDifference((-54755324L), 35L);
//        try {
//            long long71 = unsupportedDateTimeField65.set((-9L), "100");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615315 + "'", int48 == 83615315);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate4 = localDate1.minus(readablePeriod3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        java.lang.String str7 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology13 = gregorianChronology5.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.DateMidnight dateMidnight15 = localDate4.toDateMidnight(dateTimeZone8);
        int int16 = localDate4.getYearOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfMonth();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) instant0, dateTimeZone1);
        org.junit.Assert.assertNotNull(instant0);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.centuries();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology3.weekyear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendWeekyear(83615943, 870);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology4.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, 54755726);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 54755726");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        boolean boolean2 = gJChronology0.equals((java.lang.Object) 'a');
        org.joda.time.DurationField durationField3 = gJChronology0.months();
        org.joda.time.DurationField durationField4 = gJChronology0.hours();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        int int76 = remainderDateTimeField74.get((long) 83555325);
//        long long78 = remainderDateTimeField74.roundHalfEven(54755180L);
//        long long80 = remainderDateTimeField74.roundFloor((long) 83615719);
//        long long82 = remainderDateTimeField74.roundHalfCeiling((long) 'a');
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 54755000L + "'", long78 == 54755000L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 83615000L + "'", long80 == 83615000L);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendWeekyear(166, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime6.plusWeeks((int) '4');
        boolean boolean12 = dateTime6.isBefore((long) (short) 10);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        int int7 = property6.getMaximumValueOverall();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        int int4 = property2.getMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime6 = property2.setCopy("");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86399999 + "'", int4 == 86399999);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        int int4 = property2.getMaximumValueOverall();
//        org.joda.time.DurationField durationField5 = property2.getLeapDurationField();
//        java.lang.String str6 = property2.getAsString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58408241" + "'", str3.equals("58408241"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86399999 + "'", int4 == 86399999);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "58408241" + "'", str6.equals("58408241"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) 54755939);
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant6 = instant3.withDurationAdded(readableDuration4, 83555060);
        org.joda.time.Instant instant7 = instant3.toInstant();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) 54755939);
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.Instant instant5 = instant2.minus((long) 1239081290);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology69.centuryOfEra();
//        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology69);
//        org.joda.time.LocalDate localDate72 = dateTime71.toLocalDate();
//        org.joda.time.LocalDate.Property property73 = localDate72.dayOfMonth();
//        java.util.Locale locale74 = null;
//        try {
//            java.lang.String str75 = unsupportedDateTimeField65.getAsShortText((org.joda.time.ReadablePartial) localDate72, locale74);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615343 + "'", int48 == 83615343);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertNotNull(property73);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("58372709", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int12 = offsetDateTimeField8.getLeapAmount((long) 912);
//        long long14 = offsetDateTimeField8.roundHalfCeiling((long) ' ');
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.String str16 = partial15.toString();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = partial15.toDateTime((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.String str22 = partial15.toStringList();
//        int[] intArray24 = new int[] { 54755955 };
//        int int25 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) partial15, intArray24);
//        int[] intArray26 = partial15.getValues();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615379 + "'", int6 == 83615379);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[]" + "'", str16.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[]" + "'", str22.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
//        org.junit.Assert.assertNotNull(intArray26);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property10 = dateTime0.monthOfYear();
//        int int11 = dateTime0.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime0.withDate((int) (short) 10, 58354, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58354 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28 + "'", int11 == 28);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        java.util.Locale locale14 = null;
//        int int15 = skipUndoDateTimeField12.getMaximumTextLength(locale14);
//        java.lang.String str17 = skipUndoDateTimeField12.getAsText(20032L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20" + "'", str17.equals("20"));
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime30 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime27.minus(readablePeriod31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfMinute();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        int int37 = dateTime36.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap40 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) strMap40);
//        org.joda.time.DurationField durationField43 = iSOChronology39.weeks();
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate47 = localDate45.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate49 = localDate45.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property50 = localDate45.era();
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate54 = localDate52.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate55 = localDate45.withFields((org.joda.time.ReadablePartial) localDate54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = localDate55.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, durationField43, dateTimeFieldType57, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime64 = dateTime27.withField(dateTimeFieldType57, (-292275054));
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, dateTimeFieldType57);
//        long long68 = dividedDateTimeField26.add((long) 32, 35);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 15 + "'", int37 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(strMap40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 30450032L + "'", long68 == 30450032L);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        java.lang.String str3 = gregorianChronology1.toString();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        int int8 = dateTime7.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime7.millisOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.minusHours(0);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        int int13 = dateTime12.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime7.toMutableDateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime18 = dateTime7.minusDays(1);
//        boolean boolean20 = dateTime18.isBefore(32L);
//        boolean boolean22 = dateTime18.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate23 = dateTime18.toLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime18.plus(readablePeriod24);
//        long long26 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        int int7 = localDate1.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone3.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        try {
            org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, 83615182);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 83615182");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(54755338);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfMinute(452, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.Partial partial3 = new org.joda.time.Partial();
//        java.lang.String str4 = partial3.toString();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfEra((int) (byte) 1);
//        boolean boolean9 = partial3.equals((java.lang.Object) dateTime8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        int int11 = dateTime10.getDayOfMonth();
//        org.joda.time.DateTime.Property property12 = dateTime10.millisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime10.minusHours(0);
//        int int15 = dateTime10.getMinuteOfHour();
//        org.joda.time.DateTime dateTime17 = dateTime10.withMinuteOfHour(15);
//        boolean boolean18 = partial3.isMatch((org.joda.time.ReadableInstant) dateTime10);
//        java.lang.String str19 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 2019);
        org.joda.time.Instant instant5 = instant0.withMillis((long) 58385757);
        org.joda.time.Instant instant8 = instant0.withDurationAdded((long) 83615248, 0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(83555325);
        org.joda.time.DateTime.Property property12 = dateTime9.dayOfWeek();
        int int13 = property6.getDifference((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond(83555642);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime9 = property8.withMinimumValue();
//        org.joda.time.DateTime dateTime10 = property8.roundCeilingCopy();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
//        int int29 = dateTime10.get(dateTimeFieldType24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder3.appendFraction(dateTimeFieldType24, 83555419, 0);
//        boolean boolean33 = dateTimeFormatterBuilder3.canBuildParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
//        org.joda.time.DateTime dateTime8 = dateTime6.minus(83555411L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
//        int int5 = property2.getLeapAmount();
//        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate12 = localDate8.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property13 = localDate12.year();
        org.joda.time.LocalDate localDate15 = localDate12.withWeekyear(10);
        org.joda.time.LocalDate localDate16 = localDate1.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property17 = localDate12.monthOfYear();
        org.joda.time.DurationField durationField18 = property17.getLeapDurationField();
        long long21 = durationField18.subtract((long) 29538231, 32015L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2766066461769L) + "'", long21 == (-2766066461769L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '4', (long) 86399999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86400051L + "'", long2 == 86400051L);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str6 = copticChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.millisOfDay();
//        int int8 = dateTime4.get(dateTimeField7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
//        int int12 = offsetDateTimeField10.getMinimumValue(0L);
//        int int14 = offsetDateTimeField10.getLeapAmount((long) 912);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField10, 0);
//        int int18 = skipDateTimeField16.get((long) 54755359);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate22 = localDate20.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate24 = localDate20.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
//        org.joda.time.LocalDate.Property property29 = localDate28.dayOfMonth();
//        boolean boolean30 = localDate24.isEqual((org.joda.time.ReadablePartial) localDate28);
//        java.lang.Object obj31 = null;
//        boolean boolean32 = localDate24.equals(obj31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfMinute();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        int int37 = dateTime36.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap40 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) strMap40);
//        org.joda.time.DurationField durationField43 = iSOChronology39.weeks();
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate47 = localDate45.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate49 = localDate45.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property50 = localDate45.era();
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate54 = localDate52.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate55 = localDate45.withFields((org.joda.time.ReadablePartial) localDate54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = localDate55.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, durationField43, dateTimeFieldType57, 870);
//        boolean boolean60 = localDate24.isSupported(dateTimeFieldType57);
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime63 = dateTime61.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str65 = copticChronology64.toString();
//        org.joda.time.DateTimeField dateTimeField66 = copticChronology64.millisOfDay();
//        int int67 = dateTime63.get(dateTimeField66);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, (int) ' ');
//        int int71 = offsetDateTimeField69.getMinimumValue(0L);
//        int int74 = offsetDateTimeField69.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale75 = null;
//        int int76 = offsetDateTimeField69.getMaximumShortTextLength(locale75);
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = offsetDateTimeField69.getAsText((long) 59, locale78);
//        org.joda.time.DurationField durationField80 = offsetDateTimeField69.getRangeDurationField();
//        long long83 = durationField80.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField84 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType57, durationField80);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField88 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType57, 0, 29537, (-100));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83615582 + "'", int8 == 83615582);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 54755391 + "'", int18 == 54755391);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 15 + "'", int37 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(strMap40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(copticChronology64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "CopticChronology[UTC]" + "'", str65.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 83615625 + "'", int67 == 83615625);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 32 + "'", int71 == 32);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-58328) + "'", int74 == (-58328));
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 8 + "'", int76 == 8);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "91" + "'", str79.equals("91"));
//        org.junit.Assert.assertNotNull(durationField80);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-2552633244806L) + "'", long83 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField84);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate8 = localDate6.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate10 = localDate6.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property11 = localDate10.year();
        org.joda.time.LocalDate localDate13 = localDate10.withWeekyear(10);
        jodaTimePermission1.checkGuard((java.lang.Object) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        java.lang.String str18 = skipUndoDateTimeField12.getAsShortText((long) '#');
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
//        int int21 = localDate20.getWeekOfWeekyear();
//        int int22 = localDate20.getYearOfEra();
//        org.joda.time.DateTime dateTime23 = localDate20.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeField dateTimeField25 = localDate20.getField((int) (short) 1);
//        org.joda.time.LocalDate localDate27 = localDate20.withYearOfEra(54755939);
//        org.joda.time.LocalDate localDate29 = localDate27.withWeekyear(54755172);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime33 = dateTime31.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str35 = copticChronology34.toString();
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.millisOfDay();
//        int int37 = dateTime33.get(dateTimeField36);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) ' ');
//        int int41 = offsetDateTimeField39.getMinimumValue(0L);
//        int int43 = offsetDateTimeField39.getLeapAmount((long) 912);
//        long long45 = offsetDateTimeField39.roundHalfCeiling((long) ' ');
//        org.joda.time.Partial partial46 = new org.joda.time.Partial();
//        java.lang.String str47 = partial46.toString();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime50 = dateTime48.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime51 = dateTime48.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime52 = partial46.toDateTime((org.joda.time.ReadableInstant) dateTime51);
//        java.lang.String str53 = partial46.toStringList();
//        int[] intArray55 = new int[] { 54755955 };
//        int int56 = offsetDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) partial46, intArray55);
//        try {
//            int[] intArray58 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) localDate29, 83615943, intArray55, 83555190);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555190 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(copticChronology34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "CopticChronology[UTC]" + "'", str35.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 83615757 + "'", int37 == 83615757);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 32 + "'", int41 == 32);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 32L + "'", long45 == 32L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "[]" + "'", str47.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "[]" + "'", str53.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 32 + "'", int56 == 32);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        boolean boolean8 = cachedDateTimeZone5.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate localDate8 = localDate1.withYearOfEra(54755939);
        org.joda.time.LocalDate localDate10 = localDate8.withWeekyear(54755172);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str12 = localDate10.toString(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "54755172-12-31T��:��:��" + "'", str12.equals("54755172-12-31T��:��:��"));
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getDayOfMonth();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra((int) (byte) 1);
//        boolean boolean6 = partial0.equals((java.lang.Object) dateTime5);
//        int int7 = dateTime5.getYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime();
//        boolean boolean9 = dateTime8.isEqualNow();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(54755955);
        java.lang.Appendable appendable3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.Appendable appendable2 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate6 = localDate4.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate8 = localDate4.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property9 = localDate8.weekyear();
        org.joda.time.LocalDate localDate10 = property9.roundHalfFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
//        int int7 = property6.getMaximumValueOverall();
//        java.lang.String str8 = property6.getAsText();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Saturday" + "'", str8.equals("Saturday"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
        int int5 = localDate2.getDayOfYear();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = localDate2.toString("2019-06-15T16:13:12.918-07:00", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        java.lang.String str9 = gregorianChronology7.toString();
        org.joda.time.DateTime dateTime10 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        try {
            long long18 = gregorianChronology7.getDateTimeMillis(83555092, 54755098, 355, 54755027, 83615776, (int) (byte) 0, 54755194);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755027 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        try {
//            int int66 = unsupportedDateTimeField65.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615911 + "'", int48 == 83615911);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        int int3 = property2.get();
//        org.joda.time.DurationField durationField4 = property2.getDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField12.getAsShortText((long) 54755359, locale18);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "35" + "'", str19.equals("35"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = localDate11.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 29, "58372709");
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology3.centuryOfEra();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        int int10 = dateTime9.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap13);
//        boolean boolean15 = iSOChronology12.equals((java.lang.Object) strMap13);
//        org.joda.time.Chronology chronology16 = iSOChronology12.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField19, 1);
//        org.joda.time.DurationField durationField22 = skipUndoDateTimeField21.getRangeDurationField();
//        org.joda.time.Partial partial23 = new org.joda.time.Partial();
//        java.lang.String str24 = partial23.toString();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime27 = dateTime25.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime28 = dateTime25.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime29 = partial23.toDateTime((org.joda.time.ReadableInstant) dateTime28);
//        java.lang.String str30 = partial23.toStringList();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) partial23, (int) ' ', locale32);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = skipUndoDateTimeField21.getAsText((long) 36, locale35);
//        java.lang.String str37 = skipUndoDateTimeField21.toString();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = skipUndoDateTimeField21.getAsText((long) (byte) 1, locale39);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField21, 20);
//        int int44 = skipDateTimeField42.get(0L);
//        try {
//            long long47 = skipDateTimeField42.set((long) 152, 83615719);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83615719 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(strMap13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "[]" + "'", str24.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[]" + "'", str30.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "32" + "'", str33.equals("32"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str37.equals("DateTimeField[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(54755338);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendFractionOfMinute(452, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendWeekOfWeekyear(29545);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        long long2 = dateTimeFormatter0.parseMillis("32");
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTime.Property property5 = dateTime3.millisOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime3.minusHours(0);
//        int int8 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        int int10 = dateTime9.getDayOfMonth();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime9.minusHours(0);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        int int15 = dateTime14.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime9.toMutableDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime3.toDateTime(dateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime19.toMutableDateTime();
//        int int23 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime20, "2019W246T161316-0700", 83555133);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61157376000000L) + "'", long2 == (-61157376000000L));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-83555134) + "'", int23 == (-83555134));
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = iSOChronology3.add(readablePeriod4, (long) 54755506, 83555506);
        java.lang.String str8 = iSOChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 54755506L + "'", long7 == 54755506L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str8.equals("ISOChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.adjustOffset(34L, true);
//        java.lang.String str6 = dateTimeZone1.getShortName((long) 12);
//        org.joda.time.Chronology chronology7 = julianChronology0.withZone(dateTimeZone1);
//        org.joda.time.DurationField durationField8 = julianChronology0.halfdays();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 34L + "'", long4 == 34L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        boolean boolean16 = offsetDateTimeField8.isSupported();
//        long long18 = offsetDateTimeField8.roundFloor((long) 54755180);
//        long long20 = offsetDateTimeField8.roundHalfCeiling((long) '#');
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfMinute();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        int int25 = dateTime24.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime24.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap28 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap28);
//        boolean boolean30 = iSOChronology27.equals((java.lang.Object) strMap28);
//        org.joda.time.DurationField durationField31 = iSOChronology27.weeks();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate37 = localDate33.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property38 = localDate33.era();
//        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate42 = localDate40.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate43 = localDate33.withFields((org.joda.time.ReadablePartial) localDate42);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = localDate43.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField23, durationField31, dateTimeFieldType45, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 6, "29551638");
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615434 + "'", int6 == 83615434);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 54755180L + "'", long18 == 54755180L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(strMap28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(83615248, 86399999, 1, 54755939);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5747430 + "'", int4 == 5747430);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology8.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 83615361, dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 34L + "'", long4 == 34L);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendWeekOfWeekyear(54755498);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str4 = copticChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        int int7 = dateTime2.get(dateTimeField6);
        org.joda.time.DateTime dateTime8 = dateTime2.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withDate(365, 7, 54755194);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755194 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        long long52 = skipUndoDateTimeField12.set((long) 32, 20);
//        long long55 = skipUndoDateTimeField12.set((long) 83555787, "10");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83615572 + "'", int35 == 83615572);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20032L + "'", long52 == 20032L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 83530787L + "'", long55 == 83530787L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        java.util.Locale locale69 = null;
//        try {
//            int int70 = unsupportedDateTimeField65.getMaximumTextLength(locale69);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615948 + "'", int48 == 83615948);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        int int75 = dividedDateTimeField26.getMinimumValue();
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = dividedDateTimeField26.getAsShortText(0L, locale77);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "0" + "'", str78.equals("0"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone3.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        long long16 = dateTimeZone13.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology18 = gregorianChronology10.withZone(dateTimeZone13);
        try {
            org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((java.lang.Object) dateTimeZone3, (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[UTC]" + "'", str12.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(chronology18);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        int int16 = skipUndoDateTimeField12.getMaximumValue((long) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField12.getAsText((long) (short) 0, locale18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField12.getAsShortText((-2766066461769L), locale21);
//        long long24 = skipUndoDateTimeField12.roundCeiling(0L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate8 = localDate6.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate10 = localDate6.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property11 = localDate6.era();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate15 = localDate13.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate16 = localDate6.withFields((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = localDate16.getFieldType(0);
        int int19 = localDate16.size();
        org.joda.time.DateTime dateTime20 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTime dateTime21 = localDate16.toDateTimeAtCurrentTime();
        int int22 = localDate16.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 51 + "'", int22 == 51);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        long long18 = skipUndoDateTimeField12.roundCeiling(2998127984648127L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfMinute();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        int int23 = dateTime22.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime22.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap26 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap26);
//        boolean boolean28 = iSOChronology25.equals((java.lang.Object) strMap26);
//        org.joda.time.DurationField durationField29 = iSOChronology25.weeks();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate33 = localDate31.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate35 = localDate31.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property36 = localDate31.era();
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate40 = localDate38.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate41 = localDate31.withFields((org.joda.time.ReadablePartial) localDate40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = localDate41.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, durationField29, dateTimeFieldType43, 870);
//        int int46 = dividedDateTimeField45.getDivisor();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime();
//        int int48 = dateTime47.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone49 = dateTime47.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap51 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap51);
//        boolean boolean53 = iSOChronology50.equals((java.lang.Object) strMap51);
//        org.joda.time.Chronology chronology54 = iSOChronology50.withUTC();
//        long long58 = iSOChronology50.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
//        long long62 = dateTimeZone59.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone59);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone59);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale66 = dateTimeFormatter65.getLocale();
//        boolean boolean67 = cachedDateTimeZone64.equals((java.lang.Object) locale66);
//        org.joda.time.Chronology chronology68 = iSOChronology50.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone64);
//        org.joda.time.DurationField durationField69 = iSOChronology50.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone74 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int76 = fixedDateTimeZone74.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone74);
//        org.joda.time.LocalDate localDate79 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate81 = localDate79.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate83 = localDate79.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property84 = localDate79.era();
//        org.joda.time.LocalDate localDate86 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate88 = localDate86.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate89 = localDate79.withFields((org.joda.time.ReadablePartial) localDate88);
//        org.joda.time.DateTimeFieldType dateTimeFieldType91 = localDate89.getFieldType(0);
//        int int92 = dateTime77.get(dateTimeFieldType91);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField93 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField45, durationField69, dateTimeFieldType91);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField95 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType91, 355);
//        try {
//            long long98 = skipUndoDateTimeField12.set(86400000L, "DateTimeField[secondOfMinute]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[secondOfMinute]\" for secondOfMinute is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2998127984649000L + "'", long18 == 2998127984649000L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(strMap26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 870 + "'", int46 == 870);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 15 + "'", int48 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(iSOChronology50);
//        org.junit.Assert.assertNotNull(strMap51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 361L + "'", long58 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 34L + "'", long62 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTimeFormatter65);
//        org.junit.Assert.assertNull(locale66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 54755180 + "'", int76 == 54755180);
//        org.junit.Assert.assertNotNull(localDate81);
//        org.junit.Assert.assertNotNull(localDate83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(localDate88);
//        org.junit.Assert.assertNotNull(localDate89);
//        org.junit.Assert.assertNotNull(dateTimeFieldType91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2019 + "'", int92 == 2019);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        java.lang.String str28 = skipUndoDateTimeField12.toString();
//        int int30 = skipUndoDateTimeField12.get((long) 355);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str28.equals("DateTimeField[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(54755338);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(83555642);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.monthOfYear();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.halfdayOfDay();
        org.joda.time.DurationField durationField15 = copticChronology12.halfdays();
        boolean boolean16 = localDate11.equals((java.lang.Object) durationField15);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendWeekyear(54755774, 83555436);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int[] intArray1 = partial0.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = partial0.getFormatter();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNull(dateTimeFormatter2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendFractionOfDay(54755793, 35);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        int int5 = localDate4.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property6 = localDate4.dayOfYear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = localDate7.toDateTimeAtStartOfDay();
        int[] intArray10 = gJChronology2.get((org.joda.time.ReadablePartial) localDate7, (long) 54755172);
        try {
            long long15 = gJChronology2.getDateTimeMillis(869, 54755055, 54755769, 165);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755055 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(intArray10);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property6 = localDate1.era();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime10 = dateTime7.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.minus(readablePeriod11);
//        int int13 = dateTime7.getDayOfYear();
//        try {
//            long long14 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 166 + "'", int13 == 166);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour(83555016, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        int int6 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        int int8 = property6.getMinimumValue();
        org.joda.time.LocalDate localDate10 = property6.setCopy(7);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        java.lang.String str69 = unsupportedDateTimeField65.toString();
//        try {
//            int int71 = unsupportedDateTimeField65.get((long) 1239081290);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615207 + "'", int48 == 83615207);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "UnsupportedDateTimeField" + "'", str69.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property6 = localDate5.year();
//        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
//        org.joda.time.LocalDate localDate8 = property7.withMinimumValue();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        int int10 = dateTime9.getDayOfMonth();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfDay();
//        boolean boolean12 = localDate8.equals((java.lang.Object) property11);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(32, 8);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays(83555325);
        int int5 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2268 + "'", int5 == 2268);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        int int7 = property4.getDifference((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1061364907) + "'", int7 == (-1061364907));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.centuries();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology3.era();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        int int16 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTime.Property property17 = dateTime15.millisOfDay();
//        org.joda.time.DateTime dateTime19 = dateTime15.minusHours(0);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        int int21 = dateTime20.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.MutableDateTime mutableDateTime24 = dateTime15.toMutableDateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime26 = dateTime15.minusDays(1);
//        boolean boolean28 = dateTime26.isBefore(32L);
//        boolean boolean30 = dateTime26.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate31 = dateTime26.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) 0, dateTimeZone33);
//        boolean boolean35 = localDate31.isEqual((org.joda.time.ReadablePartial) localDate34);
//        long long37 = iSOChronology3.set((org.joda.time.ReadablePartial) localDate31, (long) 58354);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology3.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology3.dayOfMonth();
//        java.lang.String str40 = iSOChronology3.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560553258354L + "'", long37 == 1560553258354L);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str40.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology0.getZone();
        org.joda.time.DurationField durationField7 = copticChronology0.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        try {
//            long long70 = unsupportedDateTimeField65.roundHalfFloor(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615813 + "'", int48 == 83615813);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DurationField durationField8 = limitChronology7.weekyears();
//        java.lang.String str9 = limitChronology7.toString();
//        org.joda.time.DateTime dateTime10 = limitChronology7.getLowerLimit();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LimitChronology[CopticChronology[UTC], 2019-06-15T16:13:35.836-07:00, 2019-06-15T16:13:35.837-07:00]" + "'", str9.equals("LimitChronology[CopticChronology[UTC], 2019-06-15T16:13:35.836-07:00, 2019-06-15T16:13:35.837-07:00]"));
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        int int8 = cachedDateTimeZone5.getOffset((long) 12);
//        long long10 = cachedDateTimeZone5.nextTransition((long) '4');
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfMonth();
//        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        long long19 = dateTimeZone16.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        int int24 = cachedDateTimeZone21.getOffset((long) 54755503);
//        org.joda.time.DateTime dateTime25 = dateTime14.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        java.util.Date date26 = dateTime14.toDate();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9972000000L + "'", long10 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 34L + "'", long19 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(date26);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime5 = localDate4.toDateTimeAtStartOfDay();
        int[] intArray6 = localDate4.getValues();
        org.joda.time.LocalDate.Property property7 = localDate4.yearOfCentury();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.LocalDate localDate10 = property7.setCopy("58330981", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58330981 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0001-167T16:12:50.915-07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0001-167T16:12:50.915-07:52:58\" is malformed at \"01-167T16:12:50.915-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = copticChronology0.minutes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        int int2 = localDate1.getWeekOfWeekyear();
//        int int3 = localDate1.getYearOfEra();
//        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
//        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
//        java.util.Locale locale12 = null;
//        java.util.Calendar calendar13 = dateTime9.toCalendar(locale12);
//        boolean boolean14 = dateTime4.equals((java.lang.Object) dateTime9);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(calendar13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "");
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str6 = copticChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.millisOfDay();
//        int int8 = dateTime4.get(dateTimeField7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
//        int int12 = offsetDateTimeField10.getMinimumValue(0L);
//        int int14 = offsetDateTimeField10.getLeapAmount((long) 912);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField10, 0);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipDateTimeField16.getAsText((long) 54755939, locale18);
//        int int20 = skipDateTimeField16.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83615108 + "'", int8 == 83615108);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "54755971" + "'", str19.equals("54755971"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.getDateTime();
//        org.joda.time.DateTime dateTime5 = property2.roundHalfFloorCopy();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58416148" + "'", str3.equals("58416148"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(355, 32);
//        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.append(dateTimeParser10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendLiteral("58372709");
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime17.minus(readablePeriod21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        int int27 = dateTime26.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap30 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap30);
//        boolean boolean32 = iSOChronology29.equals((java.lang.Object) strMap30);
//        org.joda.time.DurationField durationField33 = iSOChronology29.weeks();
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate37 = localDate35.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate39 = localDate35.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property40 = localDate35.era();
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate44 = localDate42.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate45 = localDate35.withFields((org.joda.time.ReadablePartial) localDate44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = localDate45.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, durationField33, dateTimeFieldType47, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime54 = dateTime17.withField(dateTimeFieldType47, (-292275054));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder12.appendDecimal(dateTimeFieldType47, 7, 83555060);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder12.appendMinuteOfHour((-292275054));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeParser10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(strMap30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        java.lang.String str16 = offsetDateTimeField8.getName();
//        long long19 = offsetDateTimeField8.addWrapField((long) '#', 2);
//        long long21 = offsetDateTimeField8.roundHalfEven((long) 54755098);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615237 + "'", int6 == 83615237);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 37L + "'", long19 == 37L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 54755098L + "'", long21 == 54755098L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone3.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long11 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone8, (long) 83555965);
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 83555965L + "'", long11 == 83555965L);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(54755721, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean15 = dateTimeFormatter0.isPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        try {
            org.joda.time.DateTime dateTime11 = dateTime0.withTime(54755731, 83555419, (int) (short) 0, 83615971);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755731 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        int int15 = dateTime14.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        boolean boolean18 = mutableDateTime10.equals((java.lang.Object) dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime4 = property2.withMinimumValue();
//        int int5 = dateTime4.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 58416533 + "'", int5 == 58416533);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        long long29 = durationField10.subtract((long) 355, (long) 10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-6051599645L) + "'", long29 == (-6051599645L));
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        int int6 = localDate1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str12 = copticChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.millisOfDay();
//        int int14 = dateTime10.get(dateTimeField13);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
//        int int18 = offsetDateTimeField16.getMinimumValue(0L);
//        int int20 = offsetDateTimeField16.getLeapAmount((long) 912);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate24 = localDate22.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate26 = localDate22.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property27 = localDate26.year();
//        org.joda.time.LocalDate localDate29 = localDate26.withWeekyear(10);
//        org.joda.time.LocalDate localDate31 = localDate29.plusMonths((int) (short) -1);
//        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale34);
//        boolean boolean36 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.LocalDate localDate38 = localDate31.plusYears(83555015);
//        org.joda.time.LocalDate.Property property39 = localDate38.dayOfMonth();
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CopticChronology[UTC]" + "'", str12.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 83615334 + "'", int14 == 83615334);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(452, 83555016, 54755180, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555016 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        java.lang.String str28 = skipUndoDateTimeField12.toString();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField12.getAsText((long) (byte) 1, locale30);
//        long long34 = skipUndoDateTimeField12.set((long) 15, (int) ' ');
//        try {
//            long long37 = skipUndoDateTimeField12.set(0L, 83555907);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555907 for secondOfMinute must be in the range [1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str28.equals("DateTimeField[secondOfMinute]"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 32015L + "'", long34 == 32015L);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        java.lang.String str4 = partial3.toStringList();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial3.plus(readablePeriod5);
        try {
            java.lang.String str8 = partial3.toString("LimitChronology[CopticChronology[UTC], 2019-06-15T16:12:53.341-07:00, 2019-06-15T16:12:53.342-07:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: L");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        boolean boolean5 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField8.getAsText((long) 59, locale17);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField8.getRangeDurationField();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField8.getAsText(36, locale21);
//        java.util.Locale locale25 = null;
//        try {
//            long long26 = offsetDateTimeField8.set((long) 83615776, "0", locale25);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [32,86400031]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615758 + "'", int6 == 83615758);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "91" + "'", str18.equals("91"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "36" + "'", str22.equals("36"));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        org.joda.time.DurationField durationField75 = dividedDateTimeField26.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertNotNull(durationField75);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        long long11 = iSOChronology3.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long15 = dateTimeZone12.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale19 = dateTimeFormatter18.getLocale();
//        boolean boolean20 = cachedDateTimeZone17.equals((java.lang.Object) locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateMidnight dateMidnight23 = dateTime22.toDateMidnight();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 361L + "'", long11 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 34L + "'", long15 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(locale19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        boolean boolean2 = gJChronology0.equals((java.lang.Object) 'a');
        org.joda.time.DurationField durationField3 = gJChronology0.months();
        int int4 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        long long76 = dividedDateTimeField26.roundFloor(29537L);
//        int int78 = dividedDateTimeField26.get(11L);
//        long long81 = dividedDateTimeField26.getDifferenceAsLong((long) (-1061364907), (long) 83615572);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-1316L) + "'", long81 == (-1316L));
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        boolean boolean2 = gJChronology0.equals((java.lang.Object) 'a');
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long6 = dateTimeZone3.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone8);
//        int int11 = cachedDateTimeZone8.getOffset((long) 12);
//        long long13 = cachedDateTimeZone8.nextTransition((long) '4');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        int int15 = dateTime14.getDayOfMonth();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfMonth();
//        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone8, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        long long22 = dateTimeZone19.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        int int27 = cachedDateTimeZone24.getOffset((long) 54755503);
//        org.joda.time.DateTime dateTime28 = dateTime17.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        org.joda.time.Chronology chronology29 = gJChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 34L + "'", long22 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(chronology29);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.minusDays(83555325);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
//        org.joda.time.DateTime dateTime8 = property7.withMinimumValue();
//        org.joda.time.DurationField durationField9 = property7.getLeapDurationField();
//        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
//        int int11 = dateTime10.getDayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = dateTime10.withChronology((org.joda.time.Chronology) gregorianChronology12);
//        boolean boolean15 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(166);
        int int12 = dateTime11.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime30 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime27.minus(readablePeriod31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfMinute();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        int int37 = dateTime36.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap40 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) strMap40);
//        org.joda.time.DurationField durationField43 = iSOChronology39.weeks();
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate47 = localDate45.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate49 = localDate45.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property50 = localDate45.era();
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate54 = localDate52.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate55 = localDate45.withFields((org.joda.time.ReadablePartial) localDate54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = localDate55.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, durationField43, dateTimeFieldType57, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime64 = dateTime27.withField(dateTimeFieldType57, (-292275054));
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, dateTimeFieldType57);
//        long long67 = dividedDateTimeField26.remainder((long) 29);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 15 + "'", int37 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(strMap40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 29L + "'", long67 == 29L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 83615182);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long12 = julianChronology4.getDateTimeMillis(83555574, 83555027, 15, 83615749, 1, 0, 83615943);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83615749 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(julianChronology4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays(83555325);
        org.joda.time.DateTime dateTime6 = dateTime2.minus((long) 83555795);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        boolean boolean13 = dateTime11.isBefore(32L);
//        boolean boolean15 = dateTime11.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate16 = dateTime11.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) 0, dateTimeZone18);
//        boolean boolean20 = localDate16.isEqual((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.LocalDate.Property property21 = localDate16.year();
//        int int22 = property21.getMinimumValueOverall();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292275054) + "'", int22 == (-292275054));
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis(54755324);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withDefaultYear(54755955);
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        int int12 = dateTime7.getDayOfYear();
//        org.joda.time.TimeOfDay timeOfDay13 = dateTime7.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "07:26:04.309-07:00" + "'", str11.equals("07:26:04.309-07:00"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 167 + "'", int12 == 167);
//        org.junit.Assert.assertNotNull(timeOfDay13);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray17 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray19 = offsetDateTimeField8.add(readablePartial11, 0, intArray17, 0);
//        long long21 = offsetDateTimeField8.roundHalfFloor((long) 83555787);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615060 + "'", int6 == 83615060);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 83555787L + "'", long21 == 83555787L);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str6 = copticChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.millisOfDay();
//        int int8 = dateTime4.get(dateTimeField7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
//        int int12 = offsetDateTimeField10.getMinimumValue(0L);
//        int int14 = offsetDateTimeField10.getLeapAmount((long) 912);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField10, 0);
//        int int18 = skipDateTimeField16.get((long) 54755359);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        int int20 = dateTime19.getDayOfMonth();
//        org.joda.time.DateTime dateTime22 = dateTime19.withYearOfEra((int) (byte) 1);
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
//        java.util.Locale locale24 = null;
//        try {
//            java.lang.String str25 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) timeOfDay23, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83615092 + "'", int8 == 83615092);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 54755391 + "'", int18 == 54755391);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.LocalDate.Property property4 = localDate3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.LocalDate localDate6 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        java.lang.String str18 = skipUndoDateTimeField12.getAsShortText((long) '#');
//        boolean boolean20 = skipUndoDateTimeField12.isLeap((long) 83615498);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        int int16 = skipUndoDateTimeField12.getMaximumValue((long) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField12.getAsText((long) (short) 0, locale18);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField12.getAsShortText((-2766066461769L), locale21);
//        int int24 = skipUndoDateTimeField12.getLeapAmount((long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "20" + "'", str22.equals("20"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
        java.lang.Object obj12 = null;
        boolean boolean13 = localDate5.equals(obj12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        boolean boolean15 = localDate5.isSupported(durationFieldType14);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
        java.lang.String str5 = localDate2.toString();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31" + "'", str5.equals("1969-12-31"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        long long77 = remainderDateTimeField74.addWrapField((long) 83555506, 0);
//        boolean boolean78 = remainderDateTimeField74.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 83555506L + "'", long77 == 83555506L);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        int int5 = localDate4.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property6 = localDate4.dayOfYear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = localDate7.toDateTimeAtStartOfDay();
        int[] intArray10 = gJChronology2.get((org.joda.time.ReadablePartial) localDate7, (long) 54755172);
        org.joda.time.LocalDate localDate12 = localDate7.plusMonths(0);
        org.joda.time.LocalDate localDate14 = localDate12.minusWeeks(83615349);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(29538231);
//        org.joda.time.DateMidnight dateMidnight9 = dateTime5.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 166 + "'", int6 == 166);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 12);
        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay(83555325);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour(54755617, 54755769);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendDayOfMonth(54755503);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 2019);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.Class<?> wildcardClass13 = fixedDateTimeZone9.getClass();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long19 = zonedChronology14.getDateTimeMillis(83555436, 4, 20, 54755359);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54755180 + "'", int11 == 54755180);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2636692725456000179L + "'", long19 == 2636692725456000179L);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        boolean boolean13 = dateTime11.isBefore(32L);
//        boolean boolean15 = dateTime11.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate16 = dateTime11.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) 0, dateTimeZone18);
//        boolean boolean20 = localDate16.isEqual((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.LocalDate.Property property21 = localDate16.year();
//        org.joda.time.LocalDate localDate22 = property21.withMaximumValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate22);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        long long11 = iSOChronology3.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long15 = dateTimeZone12.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale19 = dateTimeFormatter18.getLocale();
//        boolean boolean20 = cachedDateTimeZone17.equals((java.lang.Object) locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate25 = localDate23.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate27 = localDate23.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property28 = localDate27.weekyear();
//        org.joda.time.LocalDate localDate29 = property28.roundHalfFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        int int31 = localDate29.indexOf(dateTimeFieldType30);
//        boolean boolean32 = cachedDateTimeZone17.equals((java.lang.Object) int31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = cachedDateTimeZone17.getShortName(2998127984648127L, locale34);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 361L + "'", long11 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 34L + "'", long15 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(locale19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PST" + "'", str35.equals("PST"));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 2019);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.Class<?> wildcardClass13 = fixedDateTimeZone9.getClass();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str15 = zonedChronology14.toString();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54755180 + "'", int11 == 54755180);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str15.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        int int8 = localDate7.getWeekyear();
        java.util.Date date9 = localDate7.toDate();
        org.joda.time.LocalDate localDate11 = localDate7.withCenturyOfEra(4);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(83615060);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 54755428);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks(83615253);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        long long13 = offsetDateTimeField8.set((long) 54755219, 83555506);
//        long long15 = offsetDateTimeField8.roundFloor((long) '#');
//        int int16 = offsetDateTimeField8.getOffset();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615234 + "'", int6 == 83615234);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 83555474L + "'", long13 == 83555474L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str6 = copticChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.millisOfDay();
//        int int8 = dateTime4.get(dateTimeField7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
//        int int12 = offsetDateTimeField10.getMinimumValue(0L);
//        int int15 = offsetDateTimeField10.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale16 = null;
//        int int17 = offsetDateTimeField10.getMaximumShortTextLength(locale16);
//        java.lang.String str18 = offsetDateTimeField10.getName();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDate19, 2, locale21);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83615268 + "'", int8 == 83615268);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-58328) + "'", int15 == (-58328));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "millisOfDay" + "'", str18.equals("millisOfDay"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2" + "'", str22.equals("2"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        java.lang.Integer int5 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology14 = gJChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        boolean boolean16 = cachedDateTimeZone13.isStandardOffset((long) 35);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour(83555016, 16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimeFormatter9);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 0, dateTimeZone12);
//        org.joda.time.LocalDate localDate15 = localDate13.withYear(0);
//        int int16 = localDate13.getDayOfYear();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime17.minus(readablePeriod21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
//        int int27 = dateTime26.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap30 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap30);
//        boolean boolean32 = iSOChronology29.equals((java.lang.Object) strMap30);
//        org.joda.time.DurationField durationField33 = iSOChronology29.weeks();
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate37 = localDate35.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate39 = localDate35.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property40 = localDate35.era();
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate44 = localDate42.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate45 = localDate35.withFields((org.joda.time.ReadablePartial) localDate44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = localDate45.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, durationField33, dateTimeFieldType47, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime54 = dateTime17.withField(dateTimeFieldType47, (-292275054));
//        org.joda.time.LocalDate localDate56 = localDate13.withField(dateTimeFieldType47, 83555133);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType47, 54755731, 83555133);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeParser2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(strMap30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        java.lang.String str18 = skipUndoDateTimeField12.getAsShortText((long) '#');
//        long long21 = skipUndoDateTimeField12.add((long) 51, 54755840);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 54755840051L + "'", long21 == 54755840051L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime4 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime6 = property2.setCopy("2019");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 83615237);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.getDateTime();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTime();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58424200" + "'", str3.equals("58424200"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str7 = partial0.toStringList();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = partial0.getFieldTypes();
        int[] intArray9 = null;
        try {
            org.joda.time.Partial partial10 = new org.joda.time.Partial(dateTimeFieldTypeArray8, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        int int51 = skipUndoDateTimeField12.getMinimumValue((long) 870);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83615397 + "'", int35 == 83615397);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("100");
        org.joda.time.DateTime dateTime2 = instant1.toDateTime();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        int int27 = localDate26.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property28 = localDate26.dayOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        java.lang.Number number30 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, number30, (java.lang.Number) (short) 100, (java.lang.Number) 51);
//        try {
//            org.joda.time.Partial partial35 = partial14.withField(dateTimeFieldType29, 83615060);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str4 = copticChronology3.toString();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        int int7 = dateTime2.get(dateTimeField6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 36 + "'", int7 == 36);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate localDate8 = localDate1.withYearOfEra(54755939);
        org.joda.time.LocalDate localDate10 = localDate1.minusMonths(4);
        org.joda.time.LocalDate.Property property11 = localDate10.weekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        boolean boolean16 = offsetDateTimeField8.isSupported();
//        long long18 = offsetDateTimeField8.roundFloor(0L);
//        int int19 = offsetDateTimeField8.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615735 + "'", int6 == 83615735);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86400031 + "'", int19 == 86400031);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        java.lang.String str28 = offsetDateTimeField26.getAsText((long) 9);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615791 + "'", int6 == 83615791);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2060" + "'", str28.equals("2060"));
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        try {
            long long8 = gregorianChronology1.getDateTimeMillis(870, 54755820, 83615234, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755820 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 2019);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant3.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = instant6.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        java.lang.String str10 = gregorianChronology8.toString();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.year();
        int int12 = gregorianChronology8.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) property7, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) dateTime1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
//        try {
//            long long13 = gregorianChronology0.getDateTimeMillis(83615018, 167, 54813384, 6, 54813384, 83555015, 152);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54813384 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        java.lang.String str69 = unsupportedDateTimeField65.toString();
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime();
//        int int71 = dateTime70.getDayOfMonth();
//        org.joda.time.DateTime.Property property72 = dateTime70.millisOfDay();
//        org.joda.time.DateTime dateTime74 = dateTime70.minusHours(0);
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime();
//        int int76 = dateTime75.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone77 = dateTime75.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone77);
//        org.joda.time.MutableDateTime mutableDateTime79 = dateTime70.toMutableDateTime(dateTimeZone77);
//        org.joda.time.DateTime dateTime81 = dateTime70.minusDays(1);
//        boolean boolean83 = dateTime81.isBefore(32L);
//        boolean boolean85 = dateTime81.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate86 = dateTime81.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone88 = null;
//        org.joda.time.LocalDate localDate89 = new org.joda.time.LocalDate((long) 0, dateTimeZone88);
//        boolean boolean90 = localDate86.isEqual((org.joda.time.ReadablePartial) localDate89);
//        java.util.Locale locale92 = null;
//        try {
//            java.lang.String str93 = unsupportedDateTimeField65.getAsShortText((org.joda.time.ReadablePartial) localDate89, 83615306, locale92);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615053 + "'", int48 == 83615053);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "UnsupportedDateTimeField" + "'", str69.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 15 + "'", int71 == 15);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 15 + "'", int76 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(iSOChronology78);
//        org.junit.Assert.assertNotNull(mutableDateTime79);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(localDate86);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        int[] intArray3 = null;
        try {
            org.joda.time.Partial partial4 = new org.joda.time.Partial(dateTimeFieldTypeArray2, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(83555795, 54755172);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 138310967 + "'", int2 == 138310967);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withMinuteOfHour(15);
//        org.joda.time.DateTime dateTime8 = dateTime0.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 54755474, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = partial0.getFieldTypes();
        int[] intArray8 = partial0.getValues();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.Partial partial3 = new org.joda.time.Partial();
        java.lang.String str4 = partial3.toString();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime8 = dateTime5.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = partial3.toDateTime((org.joda.time.ReadableInstant) dateTime8);
        java.lang.String str10 = partial3.toStringList();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray11 = partial3.getFieldTypes();
        long long13 = gregorianChronology0.set((org.joda.time.ReadablePartial) partial3, (long) 83615253);
        boolean boolean15 = gregorianChronology0.equals((java.lang.Object) 6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 83615253L + "'", long13 == 83615253L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("20", (java.lang.Number) 54755498, (java.lang.Number) 54755180L, (java.lang.Number) 83615099);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime5);
//        org.joda.time.Partial partial9 = new org.joda.time.Partial();
//        java.lang.String str10 = partial9.toString();
//        long long12 = copticChronology1.set((org.joda.time.ReadablePartial) partial9, (long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        long long16 = dateTimeZone13.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology17 = copticChronology1.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-54755324L), dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone13);
//        int int20 = dateTime19.getEra();
//        org.joda.time.DateTime dateTime22 = dateTime19.withMillis((long) 167);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(limitChronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears(0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        boolean boolean16 = offsetDateTimeField8.isSupported();
//        long long18 = offsetDateTimeField8.roundFloor(0L);
//        long long20 = offsetDateTimeField8.roundHalfFloor(32L);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615446 + "'", int6 == 83615446);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(15);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology4, dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        java.lang.String str3 = gregorianChronology1.toString();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        int int5 = dateTime4.getMillisOfSecond();
//        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
//        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 543 + "'", int5 == 543);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNull(durationField7);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Class<?> wildcardClass8 = fixedDateTimeZone4.getClass();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        long long11 = fixedDateTimeZone4.previousTransition((long) 15);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755180 + "'", int6 == 54755180);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 15L + "'", long11 == 15L);
        org.junit.Assert.assertNotNull(timeZone12);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (short) 10);
//        int int7 = dateTime6.getDayOfWeek();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime6.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime6.getZone();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfHour(355, 32);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.append(dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendLiteral("58372709");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap18 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.appendTimeZoneShortName(strMap18);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(strMap18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 83555739);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getDayOfMonth();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra((int) (byte) 1);
//        boolean boolean6 = partial0.equals((java.lang.Object) dateTime5);
//        int int7 = partial0.size();
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType9 = partial0.getFieldType(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        long long76 = remainderDateTimeField74.roundHalfEven((long) 83615971);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 83616000L + "'", long76 == 83616000L);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime6 = dateTime4.minus((long) 54755180);
//        try {
//            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        java.lang.String str69 = unsupportedDateTimeField65.toString();
//        java.util.Locale locale70 = null;
//        try {
//            int int71 = unsupportedDateTimeField65.getMaximumShortTextLength(locale70);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615012 + "'", int48 == 83615012);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "UnsupportedDateTimeField" + "'", str69.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        java.lang.String str69 = unsupportedDateTimeField65.toString();
//        java.lang.String str70 = unsupportedDateTimeField65.getName();
//        try {
//            long long72 = unsupportedDateTimeField65.remainder((long) 54755301);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615042 + "'", int48 == 83615042);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "UnsupportedDateTimeField" + "'", str69.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "year" + "'", str70.equals("year"));
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        int int68 = unsupportedDateTimeField65.getDifference((long) 83615361, (long) (short) 10);
//        long long71 = unsupportedDateTimeField65.add(1560553258354L, 0);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615096 + "'", int48 == 83615096);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560553258354L + "'", long71 == 1560553258354L);
//    }
//}

