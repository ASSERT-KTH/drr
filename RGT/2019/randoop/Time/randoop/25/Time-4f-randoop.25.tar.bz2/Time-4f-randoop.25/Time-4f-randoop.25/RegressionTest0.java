import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField1, dateTimeFieldType2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', (int) 'a', (int) (short) 0, (int) (byte) 1, 0, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.DateTime.Property property2 = dateTime0.property(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            java.lang.String str4 = dateTimeFormatter2.print(readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '#', 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            long long8 = copticChronology0.getDateTimeMillis((int) (byte) 100, 10, 15, (int) (byte) 100, (int) (short) 0, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        try {
            java.lang.String str5 = dateTime3.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime1.withField(dateTimeFieldType8, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 58329);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.util.Locale locale4 = null;
//        try {
//            org.joda.time.DateTime dateTime5 = property2.setCopy("CopticChronology[UTC]", locale4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[UTC]\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((-1), (int) '4', 12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 58329, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        try {
//            int[] intArray10 = limitChronology7.get(readablePeriod8, (long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withSecondOfMinute(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Date date0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.Partial partial3 = new org.joda.time.Partial(dateTimeFieldType0, 58329, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.centuries();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[UTC]" + "'", str2.equals("CopticChronology[UTC]"));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.LocalDateTime localDateTime5 = dateTime0.toLocalDateTime();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localDateTime5);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        int int4 = dateTime0.getYearOfEra();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(10L, 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("58330981");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58330981\" is malformed at \"330981\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        try {
            org.joda.time.LocalDate localDate5 = localDate3.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime0.isSupported(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        int int4 = dateTime3.getSecondOfMinute();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        try {
            java.lang.String str8 = partial2.toString(dateTimeFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
//        java.lang.Appendable appendable5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        int int11 = dateTime6.getMinuteOfHour();
//        org.joda.time.DateTime dateTime13 = dateTime6.withMinuteOfHour(15);
//        try {
//            dateTimeFormatter2.printTo(appendable5, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str4 = copticChronology3.toString();
        org.joda.time.Partial partial5 = new org.joda.time.Partial();
        long long7 = copticChronology3.set((org.joda.time.ReadablePartial) partial5, (long) (byte) 10);
        org.joda.time.DurationField durationField8 = copticChronology3.minutes();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField11 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField8, dateTimeFieldType9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        long long7 = dateTimeZone4.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology9 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '#', chronology9);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 34L + "'", long7 == 34L);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.weekyearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, 1969, 2000, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int int8 = localDate5.compareTo(readablePartial7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone3.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int11 = cachedDateTimeZone9.getOffset((long) 1969);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        java.lang.String str2 = gregorianChronology0.toString();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(2000, 166, 0, (int) '#', (int) (short) 10, 10, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        java.lang.String str7 = dateTime6.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15T16:12:15.404-07:00" + "'", str7.equals("2019-06-15T16:12:15.404-07:00"));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
        org.joda.time.TimeOfDay timeOfDay6 = dateTime3.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 0);
        int int8 = localDate7.getWeekOfWeekyear();
        int int9 = localDate7.getYearOfEra();
        int[] intArray14 = new int[] { 2019, (byte) 100, 2000, 16 };
        try {
            copticChronology0.validate((org.joda.time.ReadablePartial) localDate7, intArray14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = localDate1.toString("GregorianChronology[UTC]", locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-28800000));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        int int3 = property2.get();
//        int int4 = property2.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property10 = dateTime0.monthOfYear();
//        try {
//            org.joda.time.DateTime dateTime12 = property10.setCopy("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalTime localTime7 = null;
        try {
            org.joda.time.LocalDateTime localDateTime8 = localDate1.toLocalDateTime(localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(1, (int) '4', (int) (short) 1, 0, (int) ' ', (int) (short) 100, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")", 100, 83555506, 86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for (\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\") must be in the range [83555506,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str8 = copticChronology7.toString();
//        org.joda.time.Partial partial9 = new org.joda.time.Partial();
//        long long11 = copticChronology7.set((org.joda.time.ReadablePartial) partial9, (long) (byte) 10);
//        org.joda.time.DurationField durationField12 = copticChronology7.minutes();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, durationField12, dateTimeFieldType13, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755027 + "'", int6 == 54755027);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CopticChronology[UTC]" + "'", str8.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        try {
            org.joda.time.LocalDate localDate7 = localDate1.withYearOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        long long6 = dateTimeZone3.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1000, (int) (short) 10, 0, (org.joda.time.Chronology) copticChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
        org.junit.Assert.assertNotNull(copticChronology7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.LocalDate localDate5 = localDate2.withFieldAdded(durationFieldType3, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        int int2 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        int int5 = dateTime4.getDayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
//        int int7 = property3.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        int int9 = dateTime8.getDayOfMonth();
//        boolean boolean10 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime12 = dateTime4.withYear(36);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("PST", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(6, (int) ' ', 2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime2.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime2.withWeekyear(1);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((java.lang.Object) dateTime8);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (-28800000), 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long10 = dateTimeZone7.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        int int14 = dateTimeZone7.getOffsetFromLocal((long) 10);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '4', 36, (int) (short) 0, 15, 83555506, (int) (byte) 10, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555506 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
//        int int5 = dateTime4.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29538231 + "'", int5 == 29538231);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.Partial partial7 = partial2.with(dateTimeFieldType5, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.getDateTime();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "29538637" + "'", str3.equals("29538637"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58333668");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58333668\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, (java.lang.Number) (-1.0f), (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property6 = localDate1.era();
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        int int13 = dateTime12.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
//        long long17 = dateTimeZone14.convertLocalToUTC((long) (byte) 0, true);
//        org.joda.time.DateTime dateTime18 = localDate10.toDateTimeAtCurrentTime(dateTimeZone14);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 166, (-28800000), (-100), 2019, 1, 12, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeParser5);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DateTime dateTime8 = limitChronology7.getUpperLimit();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray12 = limitChronology7.get(readablePeriod9, (long) 'a', (long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        try {
            org.joda.time.LocalDate localDate8 = property6.addToCopy(2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "58334063");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime9 = dateTime5.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        try {
            int int13 = localDate4.compareTo((org.joda.time.ReadablePartial) localDateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.LocalTime localTime6 = dateTimeFormatter4.parseLocalTime("58330981");
        try {
            org.joda.time.DateTime dateTime7 = localDate3.toDateTime(localTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(localTime6);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime4 = property2.setCopy(365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 6, "58333668");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        int int8 = localDate7.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 166, 166, 0, 29537, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29537 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        boolean boolean6 = dateTime0.isEqual(0L);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str4 = copticChronology3.toString();
        try {
            org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(54755027, 0, (int) '4', (org.joda.time.Chronology) copticChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis(29538231, 365, (int) (short) -1, 0, (int) (byte) 100, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        long long9 = dateTimeZone6.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology11 = gregorianChronology3.withZone(dateTimeZone6);
        try {
            org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((int) '#', 2000, 10, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 34L + "'", long9 == 34L);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.LocalDate localDate11 = localDate8.withFieldAdded(durationFieldType9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.Partial partial8 = new org.joda.time.Partial();
//        java.lang.String str9 = partial8.toString();
//        long long11 = copticChronology0.set((org.joda.time.ReadablePartial) partial8, (long) ' ');
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.secondOfDay();
//        org.joda.time.Instant instant13 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.Instant instant16 = instant13.withDurationAdded(readableDuration14, 12);
//        org.joda.time.MutableDateTime mutableDateTime17 = instant16.toMutableDateTime();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str22 = copticChronology21.toString();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.millisOfDay();
//        int int24 = dateTime20.get(dateTimeField23);
//        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) mutableDateTime17, (org.joda.time.ReadableDateTime) dateTime20);
//        try {
//            org.joda.time.Instant instant26 = new org.joda.time.Instant((java.lang.Object) copticChronology0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(copticChronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CopticChronology[UTC]" + "'", str22.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 54755767 + "'", int24 == 54755767);
//        org.junit.Assert.assertNotNull(limitChronology25);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
//        java.lang.String str9 = gregorianChronology7.toString();
//        org.joda.time.DateTime dateTime10 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        int int11 = dateTime10.getMinuteOfDay();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 912 + "'", int11 == 912);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        boolean boolean7 = dateTime2.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755098 + "'", int6 == 54755098);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        try {
            int int13 = localDate5.compareTo((org.joda.time.ReadablePartial) partial12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) 54755324, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-54755324L) + "'", long2 == (-54755324L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType5 = partial3.getFieldType((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str20 = copticChronology19.toString();
//        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.millisOfDay();
//        int int22 = dateTime18.get(dateTimeField21);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) ' ');
//        long long26 = offsetDateTimeField24.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        int[] intArray33 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray35 = offsetDateTimeField24.add(readablePartial27, 0, intArray33, 0);
//        try {
//            int[] intArray37 = offsetDateTimeField8.addWrapField(readablePartial14, 8, intArray33, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755471 + "'", int6 == 54755471);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(copticChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "CopticChronology[UTC]" + "'", str20.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 54755479 + "'", int22 == 54755479);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        int int6 = localDate1.getDayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate1.withPeriodAdded(readablePeriod7, 0);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray17 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray19 = offsetDateTimeField8.add(readablePartial11, 0, intArray17, 0);
//        try {
//            long long22 = offsetDateTimeField8.set((long) 12, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [32,86400031]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755002 + "'", int6 == 54755002);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        long long11 = iSOChronology3.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.dayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 361L + "'", long11 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        try {
//            org.joda.time.LocalDate localDate16 = dateTimeFormatter14.parseLocalDate("America/Los_Angeles");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) -1);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        int int12 = property11.getLeapAmount();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        java.util.Date date7 = dateTime5.toDate();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) -1);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        try {
            org.joda.time.LocalDate localDate13 = localDate10.withCenturyOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        int int4 = property2.getMaximumValueOverall();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfMinute();
        java.lang.String str8 = gregorianChronology6.toString();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(1000, (-58328), 1, 0, (int) (byte) 1, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -58328 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str8.equals("GregorianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone8.getID();
//        try {
//            org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((java.lang.Object) durationField7, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        java.lang.String str4 = partial3.toStringList();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial3.plus(readablePeriod5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.Partial partial8 = partial6.without(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(partial8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1239139619L, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 12391396190");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long10 = dateTimeZone7.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(54755939, 0, 19, 58329, 54755180, 1969, 29537, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58329 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
        org.junit.Assert.assertNotNull(copticChronology11);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate16.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property21 = localDate20.year();
//        org.joda.time.LocalDate localDate23 = localDate20.withWeekyear(10);
//        org.joda.time.LocalDate localDate25 = localDate23.plusMonths((int) (short) -1);
//        org.joda.time.LocalDate.Property property26 = localDate25.centuryOfEra();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime30 = dateTime28.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str32 = copticChronology31.toString();
//        org.joda.time.DateTimeField dateTimeField33 = copticChronology31.millisOfDay();
//        int int34 = dateTime30.get(dateTimeField33);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) ' ');
//        long long38 = offsetDateTimeField36.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        int[] intArray45 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray47 = offsetDateTimeField36.add(readablePartial39, 0, intArray45, 0);
//        try {
//            int[] intArray49 = skipUndoDateTimeField12.add((org.joda.time.ReadablePartial) localDate25, 1969, intArray47, (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(copticChronology31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CopticChronology[UTC]" + "'", str32.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 54755403 + "'", int34 == 54755403);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("32", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(1000);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale27 = null;
//        try {
//            long long28 = skipUndoDateTimeField12.set(0L, "", locale27);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis(54755769, 31, (int) (short) 100, 0, (int) (short) 0, 870, 54755731);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 870 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale16 = null;
//        try {
//            long long17 = offsetDateTimeField8.set((long) (byte) 0, "Pacific Standard Time", locale16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755371 + "'", int6 == 54755371);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = localDate11.getFieldType(0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType13, (int) ' ', (int) '4', (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for year must be in the range [52,-292275054]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        int int4 = property2.getMaximumValue();
//        java.lang.String str5 = property2.getAsText();
//        org.joda.time.DurationField durationField6 = property2.getRangeDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86399999 + "'", int4 == 86399999);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "29546702" + "'", str5.equals("29546702"));
//        org.junit.Assert.assertNotNull(durationField6);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) copticChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate5 = localDate3.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property8 = localDate7.year();
        org.joda.time.LocalDate localDate10 = localDate7.withWeekyear(10);
        org.joda.time.LocalDate localDate12 = localDate10.plusMonths((int) (short) -1);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths(83555506);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        long long14 = skipUndoDateTimeField12.roundHalfFloor((long) 86399999);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(166);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) 54755180);
//        int int6 = dateTime3.getDayOfYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 166 + "'", int6 == 166);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 54755428, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 12);
        org.joda.time.Instant instant5 = instant3.withMillis((long) 54755873);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        java.lang.String str7 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology13 = gregorianChronology5.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(0, 54755793, (int) (short) 100, (int) (byte) 100, (int) (byte) -1, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = localDate9.toDateTimeAtCurrentTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.Chronology chronology14 = dateTimeFormatter0.getChronology();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNull(chronology14);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("PST", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap5);
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) strMap5);
//        org.joda.time.DurationField durationField8 = iSOChronology4.weekyears();
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField8, dateTimeFieldType22, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(strMap5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.DurationField durationField14 = skipUndoDateTimeField12.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNull(durationField14);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(54755726, 1000, (-28800000), 54755793, 365, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755793 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        java.io.Writer writer15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        int int17 = dateTime16.getDayOfMonth();
//        org.joda.time.DateTime.Property property18 = dateTime16.millisOfDay();
//        org.joda.time.DateTime dateTime19 = property18.withMinimumValue();
//        org.joda.time.DateTime dateTime20 = property18.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime21 = property18.roundHalfFloorCopy();
//        try {
//            dateTimeFormatter0.printTo(writer15, (org.joda.time.ReadableInstant) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property10 = dateTime0.monthOfYear();
//        int int11 = dateTime0.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime0.minus((long) '4');
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 29 + "'", int11 == 29);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        int int4 = property2.getMaximumValue();
//        java.lang.String str5 = property2.getAsText();
//        org.joda.time.DateTime dateTime7 = property2.addToCopy(100);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86399999 + "'", int4 == 86399999);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "29549601" + "'", str5.equals("29549601"));
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DurationField durationField4 = property2.getLeapDurationField();
//        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
//        org.joda.time.DateTime dateTime7 = property2.addToCopy(29537);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        long long11 = cachedDateTimeZone9.nextTransition((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9972000000L + "'", long11 == 9972000000L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) 54755939);
        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        long long6 = dateTimeFormatter4.parseMillis("32");
        try {
            java.lang.String str7 = instant0.toString(dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157376000000L) + "'", long6 == (-61157376000000L));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        boolean boolean6 = dateTime0.isBefore(100L);
//        org.joda.time.DateTime.Property property7 = dateTime0.era();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        boolean boolean13 = dateTime11.isBefore(32L);
//        boolean boolean15 = dateTime11.isBefore((long) 86399999);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusYears(20);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) (short) 0);
//        int int29 = localDate28.getWeekOfWeekyear();
//        int int30 = localDate28.getYearOfEra();
//        org.joda.time.DateTime dateTime31 = localDate28.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeField dateTimeField33 = localDate28.getField((int) (short) 1);
//        org.joda.time.LocalDate localDate35 = localDate28.withYearOfEra(54755939);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        int int38 = dateTime37.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone39 = dateTime37.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap41 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap41);
//        boolean boolean43 = iSOChronology40.equals((java.lang.Object) strMap41);
//        org.joda.time.Chronology chronology44 = iSOChronology40.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology40, dateTimeField47, 1);
//        org.joda.time.DurationField durationField50 = skipUndoDateTimeField49.getRangeDurationField();
//        org.joda.time.Partial partial51 = new org.joda.time.Partial();
//        java.lang.String str52 = partial51.toString();
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime55 = dateTime53.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime56 = dateTime53.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime57 = partial51.toDateTime((org.joda.time.ReadableInstant) dateTime56);
//        java.lang.String str58 = partial51.toStringList();
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = skipUndoDateTimeField49.getAsShortText((org.joda.time.ReadablePartial) partial51, (int) ' ', locale60);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = skipUndoDateTimeField49.getAsText((long) 36, locale63);
//        org.joda.time.ReadablePartial readablePartial65 = null;
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime68 = dateTime66.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str70 = copticChronology69.toString();
//        org.joda.time.DateTimeField dateTimeField71 = copticChronology69.millisOfDay();
//        int int72 = dateTime68.get(dateTimeField71);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField71, (int) ' ');
//        long long76 = offsetDateTimeField74.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial77 = null;
//        int[] intArray83 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray85 = offsetDateTimeField74.add(readablePartial77, 0, intArray83, 0);
//        int int86 = skipUndoDateTimeField49.getMaximumValue(readablePartial65, intArray85);
//        try {
//            int[] intArray88 = offsetDateTimeField8.add((org.joda.time.ReadablePartial) localDate35, 36, intArray85, 54755194);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755052 + "'", int6 == 54755052);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(strMap41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "[]" + "'", str52.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "[]" + "'", str58.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "32" + "'", str61.equals("32"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(copticChronology69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "CopticChronology[UTC]" + "'", str70.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 54755073 + "'", int72 == 54755073);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 59 + "'", int86 == 59);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.centuries();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        long long28 = dateTimeZone25.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology29 = iSOChronology20.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime30 = dateTime0.withZone(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 34L + "'", long28 == 34L);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime4 = property2.getDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "29551400" + "'", str3.equals("29551400"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        boolean boolean11 = offsetDateTimeField8.isSupported();
//        long long14 = offsetDateTimeField8.getDifferenceAsLong(0L, 1239139619L);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755474 + "'", int6 == 54755474);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1239139619L) + "'", long14 == (-1239139619L));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DurationField durationField4 = property2.getLeapDurationField();
//        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
//        int int6 = dateTime5.getDayOfWeek();
//        try {
//            org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) int6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        boolean boolean16 = offsetDateTimeField8.isSupported();
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField8.getMaximumTextLength(locale17);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755574 + "'", int6 == 54755574);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime0.plusHours(1239081290);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate17 = localDate15.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate19 = localDate15.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.centuryOfEra();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
//        org.joda.time.LocalDate.Property property24 = localDate23.dayOfMonth();
//        boolean boolean25 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate23);
//        int[] intArray31 = new int[] { ' ', 54755820, 6, 54755873 };
//        try {
//            int[] intArray33 = skipUndoDateTimeField12.add((org.joda.time.ReadablePartial) localDate23, 16, intArray31, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(intArray31);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getDayOfMonth();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra((int) (byte) 1);
//        boolean boolean6 = partial0.equals((java.lang.Object) dateTime5);
//        int int7 = dateTime5.getYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        try {
//            java.lang.String str9 = dateTime5.toString(dateTimeFormatter8);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial();
//        java.lang.String str5 = partial4.toString();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime10 = partial4.toDateTime((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (short) 1);
//        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        int int14 = dateTime12.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 164L + "'", long13 == 164L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 29551916 + "'", int14 == 29551916);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime0.plus(readableDuration10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        try {
//            org.joda.time.DateTime dateTime5 = property2.setCopy("millisOfDay");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            long long7 = gJChronology2.getDateTimeMillis(54755955, 54755793, 29537, 54755180);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755793 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial();
//        java.lang.String str5 = partial4.toString();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime10 = partial4.toDateTime((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (short) 1);
//        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property14 = dateTime12.monthOfYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 164L + "'", long13 == 164L);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
//        int int7 = dateTime3.getMillisOfSecond();
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime3.withSecondOfMinute(54755955);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755955 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 450 + "'", int7 == 450);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial();
//        java.lang.String str5 = partial4.toString();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime10 = partial4.toDateTime((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (short) 1);
//        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTimeField dateTimeField14 = property2.getField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 164L + "'", long13 == 164L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long12 = dateTimeZone9.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        int int17 = cachedDateTimeZone14.getOffset((long) 12);
        long long19 = cachedDateTimeZone14.nextTransition((long) '4');
        org.joda.time.Interval interval20 = localDate8.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval20);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 34L + "'", long12 == 34L);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9972000000L + "'", long19 == 9972000000L);
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(chronology21);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        try {
//            long long29 = dividedDateTimeField26.set((long) 54755726, (-10));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for year must be in the range [0,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str10 = copticChronology9.toString();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        long long13 = copticChronology9.set((org.joda.time.ReadablePartial) partial11, (long) (byte) 10);
        try {
            int int14 = localDate8.compareTo((org.joda.time.ReadablePartial) partial11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CopticChronology[UTC]" + "'", str10.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        long long16 = skipUndoDateTimeField12.add((long) 29537, (long) 54755721);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 0);
//        int int19 = localDate18.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.LocalDate localDate21 = localDate18.minus(readablePeriod20);
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate21, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54755750537L + "'", long16 == 54755750537L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(localDate21);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate53 = localDate51.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate55 = localDate51.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.centuryOfEra();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology56);
//        org.joda.time.LocalDate localDate59 = dateTime58.toLocalDate();
//        org.joda.time.LocalDate.Property property60 = localDate59.dayOfMonth();
//        boolean boolean61 = localDate55.isEqual((org.joda.time.ReadablePartial) localDate59);
//        java.util.Locale locale62 = null;
//        try {
//            java.lang.String str63 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate55, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83555690 + "'", int35 == 83555690);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
//        org.joda.time.Partial partial4 = new org.joda.time.Partial();
//        java.lang.String str5 = partial4.toString();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime10 = partial4.toDateTime((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (short) 1);
//        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
//        java.util.Locale locale15 = null;
//        try {
//            org.joda.time.DateTime dateTime16 = property2.setCopy("GregorianChronology[America/Los_Angeles]", locale15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 164L + "'", long13 == 164L);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
//        int int7 = dateTime3.getMillisOfSecond();
//        org.joda.time.DateTime dateTime9 = dateTime3.withDayOfMonth(6);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime3.withEra(54755506);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755506 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 772 + "'", int7 == 772);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.minus((long) 54755180);
//        int int6 = dateTime3.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58354 + "'", int6 == 58354);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        boolean boolean6 = dateTime0.isBefore(100L);
//        boolean boolean7 = dateTime0.isEqualNow();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        boolean boolean14 = skipUndoDateTimeField12.isSupported();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property10 = dateTime0.monthOfYear();
//        long long11 = property10.remainder();
//        boolean boolean12 = property10.isLeap();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1267954762L + "'", long11 == 1267954762L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.minuteOfDay();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        int int2 = dateTime0.getSecondOfMinute();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.clockhourOfHalfday();
        try {
            long long8 = copticChronology0.getDateTimeMillis(83555060, (-10), 166, 54755338);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        try {
//            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) -1, 54755574, 54755574, 20, 54755955, 0, (org.joda.time.Chronology) iSOChronology9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755955 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime(dateTimeZone13);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone13.getShortName((long) (short) -1, locale18);
//        java.lang.String str21 = dateTimeZone13.getShortName(0L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PST" + "'", str19.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        long long28 = offsetDateTimeField26.roundHalfCeiling((long) 54755939);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555325 + "'", int6 == 83555325);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 54755939L + "'", long28 == 54755939L);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        int int7 = dateTime4.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("32", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) 6, locale2);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PST" + "'", str3.equals("PST"));
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 29545, 54755950);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfDay();
        try {
            long long13 = copticChronology4.getDateTimeMillis(912, 870, 54755503, (-58328), 3, (-1), (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -58328 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 8);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(0L);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime11 = dateTime7.plusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear((int) (short) 10);
//        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
//        long long15 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime13);
//        try {
//            org.joda.time.DateTime dateTime17 = property4.setCopy("2019-06-15T16:12:15.404-07:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T16:12:15.404-07:00\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1061223847L) + "'", long15 == (-1061223847L));
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
//        boolean boolean5 = dateTime0.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long11 = offsetDateTimeField8.set(1239139619L, 100);
//        java.util.Locale locale14 = null;
//        try {
//            long long15 = offsetDateTimeField8.set(20032L, "0", locale14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [32,86400031]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555982 + "'", int6 == 83555982);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1209600068L + "'", long11 == 1209600068L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        java.util.Locale locale15 = null;
//        int int16 = skipUndoDateTimeField12.getMaximumShortTextLength(locale15);
//        long long18 = skipUndoDateTimeField12.roundFloor(10L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime5 = property2.roundCeilingCopy();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology1.eras();
        java.lang.String str4 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str4.equals("GregorianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        int int3 = dateTime2.getDayOfMonth();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra((int) (byte) 1);
//        boolean boolean6 = partial0.equals((java.lang.Object) dateTime5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        int int8 = dateTime7.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime7.millisOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime7.minusHours(0);
//        int int12 = dateTime7.getMinuteOfHour();
//        org.joda.time.DateTime dateTime14 = dateTime7.withMinuteOfHour(15);
//        boolean boolean15 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        try {
//            int int17 = partial0.compareTo(readablePartial16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        java.lang.String str4 = dateTimeFormatter2.print((long) 152);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970W013T160000-0800" + "'", str4.equals("1970W013T160000-0800"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withDate(365, 8, 54755219);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755219 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap5);
//        boolean boolean7 = iSOChronology4.equals((java.lang.Object) strMap5);
//        org.joda.time.DurationField durationField8 = iSOChronology4.weekyears();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str13 = copticChronology12.toString();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.millisOfDay();
//        int int15 = dateTime11.get(dateTimeField14);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) ' ');
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate23 = localDate19.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property24 = localDate19.era();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate29 = localDate19.withFields((org.joda.time.ReadablePartial) localDate28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = localDate29.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType31, 2019, 16, 0);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField8, dateTimeFieldType31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(strMap5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CopticChronology[UTC]" + "'", str13.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 83555509 + "'", int15 == 83555509);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.minuteOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        long long28 = offsetDateTimeField26.roundHalfEven((long) 10);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555133 + "'", int6 == 83555133);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        int int7 = dateTime5.getMinuteOfHour();
//        int int8 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime9 = dateTime5.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property10 = dateTime0.monthOfYear();
//        int int11 = dateTime0.getSecondOfMinute();
//        org.joda.time.DateTime dateTime14 = dateTime0.withDurationAdded((long) 54755172, 86399999);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 39 + "'", int11 == 39);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate8 = localDate6.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate10 = localDate6.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property11 = localDate6.era();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate15 = localDate13.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate16 = localDate6.withFields((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = localDate16.getFieldType(0);
        int int19 = localDate16.size();
        org.joda.time.DateTime dateTime20 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTime dateTime21 = localDate16.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime24 = dateTime21.withDurationAdded((long) 100, 54755055);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            java.lang.String str26 = dateTime24.toString(dateTimeFormatter25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        int int7 = localDate5.getYearOfEra();
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = localDate5.getFields();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        org.joda.time.ReadablePartial readablePartial50 = null;
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = skipUndoDateTimeField12.getAsShortText(readablePartial50, (int) ' ', locale52);
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((long) (short) 0);
//        int int56 = localDate55.getWeekOfWeekyear();
//        java.util.Locale locale57 = null;
//        try {
//            java.lang.String str58 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localDate55, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83555869 + "'", int35 == 83555869);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "32" + "'", str53.equals("32"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        boolean boolean13 = dateTime11.isBefore(32L);
//        boolean boolean15 = dateTime11.isBefore((long) 86399999);
//        org.joda.time.LocalDate localDate16 = dateTime11.toLocalDate();
//        int int17 = localDate16.getDayOfYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 165 + "'", int17 == 165);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(83555060);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        long long52 = skipUndoDateTimeField12.set((long) 32, 20);
//        long long54 = skipUndoDateTimeField12.remainder((long) 54755950);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83555084 + "'", int35 == 83555084);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20032L + "'", long52 == 20032L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 950L + "'", long54 == 950L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        java.lang.String str6 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("58334063", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58334063\" is malformed at \"334063\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) -1);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.LocalDate localDate14 = property11.setCopy("", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now(dateTimeZone8);
        org.joda.time.Chronology chronology11 = gJChronology7.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        org.joda.time.Partial partial27 = new org.joda.time.Partial();
//        java.lang.String str28 = partial27.toString();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime32 = dateTime29.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime33 = partial27.toDateTime((org.joda.time.ReadableInstant) dateTime32);
//        java.lang.String str34 = partial27.toStringList();
//        java.util.Locale locale35 = null;
//        try {
//            java.lang.String str36 = offsetDateTimeField26.getAsText((org.joda.time.ReadablePartial) partial27, locale35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555799 + "'", int6 == 83555799);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[]" + "'", str28.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "[]" + "'", str34.equals("[]"));
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58333668");
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.DateTime dateTime8 = dateTime2.plusMinutes(166);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555219 + "'", int6 == 83555219);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int10 = fixedDateTimeZone8.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate15 = localDate13.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate17 = localDate13.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property18 = localDate13.era();
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate22 = localDate20.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate23 = localDate13.withFields((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = localDate23.getFieldType(0);
        int int26 = dateTime11.get(dateTimeFieldType25);
        try {
            org.joda.time.Partial.Property property27 = partial3.property(dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 54755180 + "'", int10 == 54755180);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.Partial partial8 = new org.joda.time.Partial();
//        java.lang.String str9 = partial8.toString();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime12 = dateTime10.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime13 = dateTime10.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime14 = partial8.toDateTime((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime13.getMinuteOfHour();
//        org.joda.time.DateTime dateTime17 = dateTime13.minus((long) 2000);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime22 = dateTime18.plusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime24 = dateTime22.withWeekOfWeekyear((int) (short) 10);
//        int int25 = dateTime24.getDayOfWeek();
//        int int26 = dateTime24.getMillisOfSecond();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 480 + "'", int26 == 480);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.centuries();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone8);
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withZone(dateTimeZone16);
//        java.lang.String str19 = dateTimeZone16.getName((long) 1000);
//        java.lang.String str21 = dateTimeZone16.getShortName((long) 7);
//        org.joda.time.Chronology chronology22 = iSOChronology3.withZone(dateTimeZone16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField24 = gregorianChronology23.centuries();
//        boolean boolean25 = iSOChronology3.equals((java.lang.Object) durationField24);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Pacific Standard Time" + "'", str19.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = dateTimeFormatter2.parseMutableDateTime("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.Partial partial8 = new org.joda.time.Partial();
//        java.lang.String str9 = partial8.toString();
//        long long11 = copticChronology0.set((org.joda.time.ReadablePartial) partial8, (long) ' ');
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology0.weekOfWeekyear();
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate16 = localDate14.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate18 = localDate14.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property19 = localDate14.era();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate23 = localDate21.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate24 = localDate14.withFields((org.joda.time.ReadablePartial) localDate23);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = localDate24.getFieldType(0);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[]" + "'", str9.equals("[]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 83555002);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate11 = localDate9.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate13 = localDate9.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property14 = localDate9.era();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate19 = localDate9.withFields((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = localDate19.getFieldType(0);
//        int int22 = dateTime7.get(dateTimeFieldType21);
//        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime26 = dateTime24.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology23, (org.joda.time.ReadableDateTime) dateTime24, (org.joda.time.ReadableDateTime) dateTime27);
//        org.joda.time.DurationField durationField31 = limitChronology30.weeks();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.secondOfMinute();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        int int36 = dateTime35.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime35.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap39);
//        boolean boolean41 = iSOChronology38.equals((java.lang.Object) strMap39);
//        org.joda.time.DurationField durationField42 = iSOChronology38.weeks();
//        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate46 = localDate44.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate48 = localDate44.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property49 = localDate44.era();
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate53 = localDate51.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate54 = localDate44.withFields((org.joda.time.ReadablePartial) localDate53);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = localDate54.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField34, durationField42, dateTimeFieldType56, 870);
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField59 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType21, durationField31, durationField42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 54755180 + "'", int6 == 54755180);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(copticChronology23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(strMap39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        long long8 = dateTimeZone5.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(20, 54755338, 10, 83555092, 54755939, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555092 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 34L + "'", long8 == 34L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        int int2 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        int int5 = dateTime4.getDayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
//        int int7 = property3.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        boolean boolean8 = dateTime4.isAfterNow();
//        org.joda.time.DateTime.Property property9 = dateTime4.minuteOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        long long52 = skipUndoDateTimeField12.set((long) 32, 20);
//        int int54 = skipUndoDateTimeField12.getMinimumValue((long) 6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83555574 + "'", int35 == 83555574);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20032L + "'", long52 == 20032L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        org.joda.time.Instant instant8 = new org.joda.time.Instant((java.lang.Object) dateTime6);
        int int9 = dateTime6.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        java.lang.String str3 = gregorianChronology1.toString();
        try {
            long long8 = gregorianChronology1.getDateTimeMillis((int) ' ', 83555002, 29, 452);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555002 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 0L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime4.getDayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime4.withMonthOfYear((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology3.getZone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
//        org.joda.time.LocalDate.Property property4 = localDate3.dayOfMonth();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsText(locale5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(8, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60 + "'", int2 == 60);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray17 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray19 = offsetDateTimeField8.add(readablePartial11, 0, intArray17, 0);
//        long long22 = offsetDateTimeField8.add((long) 870, 365);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField8.getRangeDurationField();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555965 + "'", int6 == 83555965);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1235L + "'", long22 == 1235L);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Chronology chronology3 = null;
        try {
            org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((int) (byte) 1, 54755774, (int) '#', chronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755774 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str6 = copticChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.millisOfDay();
//        int int8 = dateTime4.get(dateTimeField7);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
//        int int12 = offsetDateTimeField10.getMinimumValue(0L);
//        int int14 = offsetDateTimeField10.getLeapAmount((long) 912);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeField) offsetDateTimeField10, 0);
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField10.getMaximumShortTextLength(locale17);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CopticChronology[UTC]" + "'", str6.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 83555016 + "'", int8 == 83555016);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        int int8 = localDate7.getWeekyear();
        int int9 = localDate7.getDayOfMonth();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        int int7 = localDate1.getDayOfYear();
        org.joda.time.LocalTime localTime8 = null;
        try {
            org.joda.time.LocalDateTime localDateTime9 = localDate1.toLocalDateTime(localTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        java.lang.String str1 = partial0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
//        int int7 = dateTime5.getMinuteOfHour();
//        org.joda.time.DateTime dateTime9 = dateTime5.minus((long) 2000);
//        java.util.GregorianCalendar gregorianCalendar10 = dateTime5.toGregorianCalendar();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianCalendar10);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate8 = localDate6.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate10 = localDate6.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property11 = localDate6.era();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate15 = localDate13.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate16 = localDate6.withFields((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = localDate16.getFieldType(0);
        int int19 = localDate16.size();
        org.joda.time.DateTime dateTime20 = dateTime4.withFields((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTime dateTime21 = localDate16.toDateTimeAtCurrentTime();
        try {
            org.joda.time.DateTime dateTime23 = dateTime21.withEra(83555325);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555325 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        java.lang.String str27 = offsetDateTimeField26.toString();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = offsetDateTimeField26.getAsText(20, locale29);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555015 + "'", int6 == 83555015);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DateTimeField[year]" + "'", str27.equals("DateTimeField[year]"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "20" + "'", str30.equals("20"));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(54755055, 58329, 58329, 83555411);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 54813384 + "'", int4 == 54813384);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) ' ', "BuddhistChronology[America/Los_Angeles]");
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int9 = fixedDateTimeZone7.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.Class<?> wildcardClass11 = fixedDateTimeZone7.getClass();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 54755180 + "'", int9 == 54755180);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        int int4 = localDate3.getWeekOfWeekyear();
        int int5 = localDate3.getYearOfEra();
        org.joda.time.DateTime dateTime6 = localDate3.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField8 = localDate3.getField((int) (short) 1);
        org.joda.time.LocalDate localDate10 = localDate3.withYearOfEra(54755939);
        org.joda.time.LocalDate localDate12 = localDate10.withWeekyear(54755172);
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localDate12.getFields();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        int int8 = localDate7.getWeekyear();
        java.util.Date date9 = localDate7.toDate();
        org.joda.time.LocalDate localDate11 = localDate7.withWeekyear(36);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 1000);
        long long13 = fixedDateTimeZone9.previousTransition((long) 29537);
        java.lang.String str15 = fixedDateTimeZone9.getNameKey(0L);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(54755359, 83555118, (int) (byte) 100, 912, (int) (short) 10, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 912 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54755180 + "'", int11 == 54755180);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 29537L + "'", long13 == 29537L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        int int2 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        int int5 = dateTime4.getDayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
//        int int7 = property3.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.LocalDate localDate8 = property3.roundHalfEvenCopy();
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        int int13 = offsetDateTimeField8.getDifference(1239139619L, (long) 58329);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) 0, dateTimeZone15);
//        org.joda.time.LocalDate localDate18 = localDate16.withYear(0);
//        int int19 = localDate16.getDayOfYear();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime22 = dateTime20.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime23 = dateTime20.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.minus(readablePeriod24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.secondOfMinute();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        int int30 = dateTime29.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime29.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap33 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap33);
//        boolean boolean35 = iSOChronology32.equals((java.lang.Object) strMap33);
//        org.joda.time.DurationField durationField36 = iSOChronology32.weeks();
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate40 = localDate38.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate42 = localDate38.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property43 = localDate38.era();
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate47 = localDate45.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate48 = localDate38.withFields((org.joda.time.ReadablePartial) localDate47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = localDate48.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(dateTimeField28, durationField36, dateTimeFieldType50, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime57 = dateTime20.withField(dateTimeFieldType50, (-292275054));
//        org.joda.time.LocalDate localDate59 = localDate16.withField(dateTimeFieldType50, 83555133);
//        java.util.Locale locale60 = null;
//        try {
//            java.lang.String str61 = offsetDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDate16, locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555548 + "'", int6 == 83555548);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1239081290 + "'", int13 == 1239081290);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(strMap33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(localDate48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate59);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        long long9 = cachedDateTimeZone5.previousTransition((long) 83555118);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-5756400001L) + "'", long9 == (-5756400001L));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 54755301, (long) 54755027);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2998127984648127L + "'", long2 == 2998127984648127L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.Appendable appendable2 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate6 = localDate4.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate8 = localDate4.withWeekyear((int) (byte) 10);
        int int9 = localDate4.getDayOfMonth();
        org.joda.time.DateTime dateTime10 = localDate4.toDateTimeAtCurrentTime();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DurationField durationField8 = limitChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField9 = limitChronology7.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) 0, dateTimeZone11);
//        org.joda.time.LocalDate localDate14 = localDate12.withYear(0);
//        try {
//            long long16 = limitChronology7.set((org.joda.time.ReadablePartial) localDate12, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 1735-10-08T23:12:49.225Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = partial0.getFormatter();
        org.junit.Assert.assertNull(dateTimeFormatter1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) 54755939);
        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTime();
        org.joda.time.Chronology chronology5 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.centuries();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology12 = iSOChronology3.withZone(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology3.era();
//        org.joda.time.DurationField durationField15 = iSOChronology3.centuries();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = localDate11.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
        java.lang.String str18 = illegalFieldValueException17.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "20032" + "'", str18.equals("20032"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant0.withDurationAdded(1267954762L, (-292275054));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        java.lang.String str2 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        java.lang.String str9 = gregorianChronology7.toString();
        org.joda.time.DateTime dateTime10 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime12 = dateTime6.withMinuteOfHour(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[UTC]" + "'", str9.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = localDate16.getFields();
        boolean boolean18 = localDate11.isAfter((org.joda.time.ReadablePartial) localDate16);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate4 = property3.roundHalfFloorCopy();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.LocalDate localDate6 = localDate4.withFields(readablePartial5);
        int int7 = localDate4.getEra();
        try {
            org.joda.time.LocalDate localDate9 = localDate4.withDayOfWeek(83555133);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555133 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DurationField durationField8 = limitChronology7.weekyears();
//        org.joda.time.DateTimeField dateTimeField9 = limitChronology7.hourOfHalfday();
//        org.joda.time.Chronology chronology10 = limitChronology7.withUTC();
//        org.joda.time.DateTime dateTime11 = limitChronology7.getUpperLimit();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate4 = localDate2.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate6 = localDate2.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property7 = localDate6.weekyear();
        org.joda.time.LocalDate localDate8 = property7.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate9 = property7.getLocalDate();
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0010" + "'", str10.equals("0010"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField26, dateTimeFieldType75, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(86400000L, (long) 83555411);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7219187510400000L + "'", long2 == 7219187510400000L);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        java.lang.String str3 = property2.getAsText();
//        org.joda.time.DateTime dateTime5 = property2.addWrapFieldToCopy((-28800000));
//        int int6 = property2.getMaximumValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "58372709" + "'", str3.equals("58372709"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) 'a', 29538231, 54755506);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29538231 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusSeconds(29538231);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime5.withMillisOfSecond(83555436);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555436 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 166 + "'", int6 == 166);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) dateTime1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap10);
//        boolean boolean12 = iSOChronology9.equals((java.lang.Object) strMap10);
//        org.joda.time.DurationField durationField13 = iSOChronology9.centuries();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        long long17 = dateTimeZone14.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology18 = iSOChronology9.withZone(dateTimeZone14);
//        org.joda.time.Chronology chronology19 = iSOChronology9.withUTC();
//        try {
//            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) gregorianChronology0, chronology19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(strMap10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 34L + "'", long17 == 34L);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        java.lang.String str16 = offsetDateTimeField8.getName();
//        long long19 = offsetDateTimeField8.addWrapField((long) '#', 2);
//        long long22 = offsetDateTimeField8.add(0L, 83555411);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555140 + "'", int6 == 83555140);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "millisOfDay" + "'", str16.equals("millisOfDay"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 37L + "'", long19 == 37L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 83555411L + "'", long22 == 83555411L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology14 = gJChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.Chronology chronology15 = gJChronology6.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        long long13 = offsetDateTimeField8.set((long) 54755219, 83555506);
//        long long15 = offsetDateTimeField8.roundFloor((long) '#');
//        try {
//            long long18 = offsetDateTimeField8.add((long) (short) 100, (-61157376000000L));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555385 + "'", int6 == 83555385);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 83555474L + "'", long13 == 83555474L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime16.withDayOfWeek(39);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 39 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(54755774);
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        java.lang.String str2 = partial1.toString();
        int[] intArray3 = partial1.getValues();
        try {
            java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) partial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType1, 16, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) strMap15);
//        org.joda.time.DurationField durationField18 = iSOChronology14.weeks();
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate22 = localDate20.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate24 = localDate20.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property25 = localDate20.era();
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate29 = localDate27.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate20.withFields((org.joda.time.ReadablePartial) localDate29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = localDate30.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, durationField18, dateTimeFieldType32, 870);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, (org.joda.time.DateTimeField) dividedDateTimeField34, 10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(strMap15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology8 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology1, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime5);
//        org.joda.time.Partial partial9 = new org.joda.time.Partial();
//        java.lang.String str10 = partial9.toString();
//        long long12 = copticChronology1.set((org.joda.time.ReadablePartial) partial9, (long) ' ');
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        long long16 = dateTimeZone13.adjustOffset(34L, true);
//        org.joda.time.Chronology chronology17 = copticChronology1.withZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-54755324L), dateTimeZone13);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone13);
//        java.lang.String str21 = dateTimeZone13.getName((long) 29538231);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(limitChronology8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[]" + "'", str10.equals("[]"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 34L + "'", long16 == 34L);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000046d + "'", double1 == 2440587.500000046d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        int int6 = localDate5.getYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfWeek();
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfMonth();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy((long) 15);
//        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        long long15 = offsetDateTimeField8.roundHalfEven((-54755324L));
//        long long18 = offsetDateTimeField8.add(0L, 1239139619L);
//        long long20 = offsetDateTimeField8.remainder((long) 29);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555642 + "'", int6 == 83555642);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-54755324L) + "'", long15 == (-54755324L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1239139619L + "'", long18 == 1239139619L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        boolean boolean7 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        boolean boolean9 = jodaTimePermission6.equals((java.lang.Object) 83555015);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int12 = offsetDateTimeField8.getLeapAmount((long) 912);
//        long long14 = offsetDateTimeField8.roundHalfCeiling((long) ' ');
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.String str16 = partial15.toString();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = partial15.toDateTime((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.String str22 = partial15.toStringList();
//        int[] intArray24 = new int[] { 54755955 };
//        int int25 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) partial15, intArray24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        try {
//            org.joda.time.Partial.Property property27 = partial15.property(dateTimeFieldType26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555693 + "'", int6 == 83555693);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[]" + "'", str16.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[]" + "'", str22.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("CopticChronology[UTC]");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str5 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertNotNull(permissionCollection4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"CopticChronology[UTC]\")"));
        org.junit.Assert.assertNotNull(permissionCollection6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.Instant instant4 = instant2.minus((long) 54755939);
        org.joda.time.MutableDateTime mutableDateTime5 = instant2.toMutableDateTimeISO();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "", 83555015);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-83555016) + "'", int8 == (-83555016));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes((int) '#');
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond(83555219);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83555219 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology3.secondOfDay();
//        org.joda.time.DurationField durationField14 = iSOChronology3.halfdays();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime0.plusYears((-100));
        int int6 = dateTime0.getEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Partial partial2 = new org.joda.time.Partial();
        long long4 = copticChronology0.set((org.joda.time.ReadablePartial) partial2, (long) (byte) 10);
        org.joda.time.DurationField durationField5 = copticChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        int int12 = localDate10.getDayOfYear();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 355 + "'", int12 == 355);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
//        int int5 = localDate2.getDayOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime6.minus(readablePeriod10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfMinute();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        int int16 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap19);
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) strMap19);
//        org.joda.time.DurationField durationField22 = iSOChronology18.weeks();
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate26 = localDate24.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate28 = localDate24.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property29 = localDate24.era();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate33 = localDate31.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate34 = localDate24.withFields((org.joda.time.ReadablePartial) localDate33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = localDate34.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, durationField22, dateTimeFieldType36, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime43 = dateTime6.withField(dateTimeFieldType36, (-292275054));
//        org.joda.time.LocalDate localDate45 = localDate2.withField(dateTimeFieldType36, 83555133);
//        org.joda.time.LocalDate localDate47 = localDate2.withEra((int) (byte) 0);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(strMap19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(localDate47);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray17 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray19 = offsetDateTimeField8.add(readablePartial11, 0, intArray17, 0);
//        long long22 = offsetDateTimeField8.add((long) 870, 365);
//        java.util.Locale locale23 = null;
//        int int24 = offsetDateTimeField8.getMaximumShortTextLength(locale23);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83555419 + "'", int6 == 83555419);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1235L + "'", long22 == 1235L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.joda.time.DurationField durationField9 = property6.getRangeDurationField();
        org.joda.time.LocalDate localDate11 = property6.addToCopy(54755820);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        try {
//            org.joda.time.LocalDate localDate16 = dateTimeFormatter14.parseLocalDate("JulianChronology[UTC]");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DurationField durationField4 = property2.getDurationField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(durationField4);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        long long77 = remainderDateTimeField74.addWrapField((long) 83555506, 0);
//        org.joda.time.DurationField durationField78 = remainderDateTimeField74.getDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 83555506L + "'", long77 == 83555506L);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        long long15 = offsetDateTimeField8.roundHalfEven((-54755324L));
//        long long18 = offsetDateTimeField8.add(0L, 1239139619L);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField8.getDurationField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        int int23 = delegatedDateTimeField20.getDifference((-1239139619L), 30L);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615038 + "'", int6 == 83615038);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-54755324L) + "'", long15 == (-54755324L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1239139619L + "'", long18 == 1239139619L);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1239139649) + "'", int23 == (-1239139649));
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) dateTime1);
//        org.joda.time.DateTime dateTime6 = dateTime1.minusHours(83555015);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
        boolean boolean6 = localDate4.equals((java.lang.Object) (-210866846400000L));
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long10 = dateTimeZone7.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology13.withUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        long long18 = dateTimeZone15.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.Chronology chronology21 = gJChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology13.minuteOfDay();
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(54755172, 83555092, 10, 1969, 54755359, 152, 0, (org.joda.time.Chronology) gJChronology13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 34L + "'", long10 == 34L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 34L + "'", long18 == 34L);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("CopticChronology[UTC]", 0, 86399999, 54755474);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for CopticChronology[UTC] must be in the range [86399999,54755474]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        int int8 = cachedDateTimeZone5.getOffset((long) 12);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        long long11 = cachedDateTimeZone5.convertUTCToLocal((long) 2019);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28797981L) + "'", long11 == (-28797981L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) -1);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property11.withMinimumValue();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        org.joda.time.ReadablePartial readablePartial50 = null;
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = skipUndoDateTimeField12.getAsShortText(readablePartial50, (int) ' ', locale52);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = skipUndoDateTimeField12.getAsText((long) 54755098, locale55);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83615943 + "'", int35 == 83615943);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "32" + "'", str53.equals("32"));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "35" + "'", str56.equals("35"));
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate localDate8 = localDate5.withWeekyear(10);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) -1);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.joda.time.LocalDate localDate12 = property11.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.halfdayOfDay();
        try {
            long long10 = copticChronology0.getDateTimeMillis(12, 54755338, (-292275054), 54755055, 15, 54755840, 54755721);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755055 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate7 = localDate5.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate9 = localDate5.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property10 = localDate5.era();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate15 = localDate5.withFields((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = localDate15.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType17);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter24 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter24, dateTimeParser26);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.append(dateTimePrinter23, dateTimeParser26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 54755774, (java.lang.Number) 83555795, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
//        int int8 = cachedDateTimeZone5.getOffset((long) 12);
//        long long10 = cachedDateTimeZone5.nextTransition((long) '4');
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfMonth();
//        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        long long19 = dateTimeZone16.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        int int24 = cachedDateTimeZone21.getOffset((long) 12);
//        long long26 = cachedDateTimeZone21.nextTransition((long) '4');
//        org.joda.time.Chronology chronology27 = gJChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        boolean boolean28 = cachedDateTimeZone21.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9972000000L + "'", long10 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 34L + "'", long19 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9972000000L + "'", long26 == 9972000000L);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.Instant instant5 = org.joda.time.Instant.now();
//        boolean boolean6 = dateTime1.isEqual((org.joda.time.ReadableInstant) instant5);
//        try {
//            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant5);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long11 = offsetDateTimeField8.set(1239139619L, 100);
//        int int12 = offsetDateTimeField8.getMinimumValue();
//        int int13 = offsetDateTimeField8.getOffset();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615248 + "'", int6 == 83615248);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1209600068L + "'", long11 == 1209600068L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        int int3 = gJChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(361L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial0.getFormatter();
        try {
            int int5 = partial0.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNull(dateTimeFormatter3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        int int3 = gJChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gJChronology2.minutes();
        int int5 = gJChronology2.getMinimumDaysInFirstWeek();
        try {
            long long13 = gJChronology2.getDateTimeMillis(100, 0, 54755338, 54755731, 355, 83555140, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755731 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant1 = instant0.toInstant();
        org.joda.time.MutableDateTime mutableDateTime2 = instant0.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime(dateTimeZone13);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime16.withMinuteOfHour((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        long long10 = offsetDateTimeField8.remainder((long) 2019);
//        int int12 = offsetDateTimeField8.getMinimumValue(32L);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615306 + "'", int6 == 83615306);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.joda.time.LocalDate localDate9 = property6.getLocalDate();
        java.lang.String str10 = property6.toString();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property6.getAsShortText(locale11);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[weekyear]" + "'", str10.equals("Property[weekyear]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology3.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.LocalDate.Property property4 = localDate3.dayOfMonth();
        org.joda.time.LocalDate localDate5 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        int int16 = skipUndoDateTimeField12.getMaximumValue((long) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField12.getAsText((long) (short) 0, locale18);
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate23 = localDate21.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate25 = localDate21.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property26 = localDate21.era();
//        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate30 = localDate28.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate31 = localDate21.withFields((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = localDate31.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField12, dateTimeFieldType33, 83615038);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = partial0.getFieldTypes();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial0.getFormatter();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial0.withFieldAddWrapped(durationFieldType4, 83555092);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNull(dateTimeFormatter3);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate12 = localDate10.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate14 = localDate10.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property15 = localDate10.era();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate19 = localDate17.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate10.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = localDate20.getFieldType(0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 2019, 16, 0);
//        long long29 = offsetDateTimeField26.getDifferenceAsLong((long) 31, (long) 54755793);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615939 + "'", int6 == 83615939);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-54755762L) + "'", long29 == (-54755762L));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateMidnight dateMidnight12 = localDate11.toDateMidnight();
        org.joda.time.LocalDate.Property property13 = localDate11.dayOfYear();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        boolean boolean11 = offsetDateTimeField8.isSupported();
//        long long14 = offsetDateTimeField8.getDifferenceAsLong((long) 54755873, (long) 54755172);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615177 + "'", int6 == 83615177);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 701L + "'", long14 == 701L);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        int int16 = skipUndoDateTimeField12.getMaximumValue((long) (short) 1);
//        int int17 = skipUndoDateTimeField12.getMinimumValue();
//        org.joda.time.DateTimeField dateTimeField18 = skipUndoDateTimeField12.getWrappedField();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str7 = partial0.toStringList();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.Partial partial10 = partial0.withPeriodAdded(readablePeriod8, 59);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(partial10);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusHours(54755617);
//        int int4 = dateTime3.getMinuteOfHour();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime4.getDayOfWeek();
//        boolean boolean6 = dateTime4.isAfterNow();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        boolean boolean4 = property2.isLeap();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.monthOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate5 = localDate3.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate7 = localDate3.withWeekyear((int) (byte) 10);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.millisOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = skipDateTimeField14.getRangeDurationField();
//        long long18 = skipDateTimeField14.addWrapField(35L, (-100));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-65L) + "'", long18 == (-65L));
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 6, "29551638");
//        java.lang.Number number30 = illegalFieldValueException29.getIllegalNumberValue();
//        java.lang.String str31 = illegalFieldValueException29.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 6 + "'", number30.equals(6));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 6 for year is not supported: 29551638" + "'", str31.equals("org.joda.time.IllegalFieldValueException: Value 6 for year is not supported: 29551638"));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate12 = localDate8.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property13 = localDate12.year();
        org.joda.time.LocalDate localDate15 = localDate12.withWeekyear(10);
        org.joda.time.LocalDate localDate16 = localDate1.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property17 = localDate12.monthOfYear();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = localDate12.toString("Pacific Standard Time", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        boolean boolean5 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone1.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 83555506, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 34L + "'", long4 == 34L);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-28800000) + "'", int8 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("36");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"36/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 54755027, (long) 54755731);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2998151529309737");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long6 = dateTimeZone3.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTime0, (org.joda.time.Chronology) copticChronology7);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusDays(1000);
//        org.joda.time.DateTime dateTime12 = dateTime8.plusWeeks(83555795);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(0);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTime();
//        int int18 = mutableDateTime17.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, 0);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        int int16 = dateTime14.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 58385757 + "'", int16 == 58385757);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        int int16 = skipUndoDateTimeField12.getMaximumValue((long) (short) 1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = skipUndoDateTimeField12.getAsText((long) (short) 0, locale18);
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (short) 0);
//        int int22 = localDate21.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property23 = localDate21.dayOfYear();
//        org.joda.time.LocalDate localDate24 = property23.roundHalfFloorCopy();
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        org.joda.time.LocalDate localDate26 = localDate24.withFields(readablePartial25);
//        int[] intArray28 = null;
//        try {
//            int[] intArray30 = skipUndoDateTimeField12.addWrapField(readablePartial25, 58329, intArray28, 54755474);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate26);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        int int6 = dateTime0.getYearOfCentury();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay(83555325);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate11 = localDate9.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate13 = localDate9.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property14 = localDate9.era();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate19 = localDate9.withFields((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = localDate19.getFieldType(0);
//        try {
//            org.joda.time.Partial.Property property22 = partial7.property(dateTimeFieldType21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withLocale(locale15);
//        org.joda.time.Chronology chronology17 = dateTimeFormatter0.getChronology();
//        int int18 = dateTimeFormatter0.getDefaultYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNull(chronology17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2000 + "'", int18 == 2000);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("29551638", "America/Los_Angeles");
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        java.util.Date date8 = localDate5.toDate();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime11 = dateTime0.minusDays(1);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, 0);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        long long18 = dateTimeZone15.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone20);
//        int int23 = cachedDateTimeZone20.getOffset((long) 12);
//        org.joda.time.DateTime dateTime24 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone20);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 34L + "'", long18 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology19);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-28800000) + "'", int23 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        int int14 = skipUndoDateTimeField12.getMaximumValue();
//        long long16 = skipUndoDateTimeField12.roundHalfFloor((long) 54755721);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime21 = dateTime19.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str23 = copticChronology22.toString();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.millisOfDay();
//        int int25 = dateTime21.get(dateTimeField24);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) ' ');
//        long long29 = offsetDateTimeField27.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        int[] intArray36 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray38 = offsetDateTimeField27.add(readablePartial30, 0, intArray36, 0);
//        try {
//            int[] intArray40 = skipUndoDateTimeField12.set(readablePartial17, 83555642, intArray38, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 83555642");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 54756000L + "'", long16 == 54756000L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CopticChronology[UTC]" + "'", str23.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 83615313 + "'", int25 == 83615313);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
//        int int7 = dateTime0.getYear();
//        boolean boolean8 = dateTime0.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate11 = localDate1.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = localDate11.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 20032L, (java.lang.Number) 54755338, (java.lang.Number) 54755474);
        java.lang.Number number18 = illegalFieldValueException17.getIllegalNumberValue();
        illegalFieldValueException17.prependMessage("91");
        java.lang.Number number21 = illegalFieldValueException17.getUpperBound();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 20032L + "'", number18.equals(20032L));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 54755474 + "'", number21.equals(54755474));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.withMinimumValue();
        org.joda.time.LocalDate localDate10 = localDate8.withDayOfYear(15);
        try {
            org.joda.time.DateTimeField dateTimeField12 = localDate8.getField(83555795);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 83555795");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        int int6 = localDate1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtCurrentTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        int int12 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap15);
//        boolean boolean17 = iSOChronology14.equals((java.lang.Object) strMap15);
//        org.joda.time.DurationField durationField18 = iSOChronology14.weeks();
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate22 = localDate20.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate24 = localDate20.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property25 = localDate20.era();
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate29 = localDate27.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate20.withFields((org.joda.time.ReadablePartial) localDate29);
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = localDate30.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, durationField18, dateTimeFieldType32, 870);
//        boolean boolean35 = localDate1.isSupported(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(strMap15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime3 = property2.withMinimumValue();
//        org.joda.time.DurationField durationField4 = property2.getLeapDurationField();
//        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
//        int int6 = dateTime5.getDayOfWeek();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime5.toDateMidnight();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        long long15 = offsetDateTimeField8.roundHalfEven((-54755324L));
//        long long18 = offsetDateTimeField8.add(0L, 1239139619L);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField8.getDurationField();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.Partial partial22 = new org.joda.time.Partial();
//        java.lang.String str23 = partial22.toString();
//        int[] intArray24 = partial22.getValues();
//        int int25 = offsetDateTimeField8.getMaximumValue(readablePartial21, intArray24);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615296 + "'", int6 == 83615296);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-54755324L) + "'", long15 == (-54755324L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1239139619L + "'", long18 == 1239139619L);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[]" + "'", str23.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 86400031 + "'", int25 == 86400031);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            long long7 = gJChronology2.getDateTimeMillis(0, 2019, 83555506, 54813384);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int12 = offsetDateTimeField8.getLeapAmount((long) 912);
//        long long14 = offsetDateTimeField8.roundHalfCeiling((long) ' ');
//        org.joda.time.Partial partial15 = new org.joda.time.Partial();
//        java.lang.String str16 = partial15.toString();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime17.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = partial15.toDateTime((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.String str22 = partial15.toStringList();
//        int[] intArray24 = new int[] { 54755955 };
//        int int25 = offsetDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) partial15, intArray24);
//        try {
//            java.lang.String str27 = partial15.toString("hi!");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615375 + "'", int6 == 83615375);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[]" + "'", str16.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[]" + "'", str22.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.DurationField durationField7 = iSOChronology3.millis();
//        org.joda.time.DurationFieldType durationFieldType8 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, 83555411);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime0.withWeekyear(1);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime6.plusWeeks((int) '4');
        org.joda.time.DateTime dateTime12 = dateTime6.minusMinutes(54755219);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime3 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(12);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis(54755324);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withDefaultYear(54755955);
//        java.lang.String str11 = dateTime7.toString(dateTimeFormatter10);
//        boolean boolean13 = dateTime7.isBefore((long) 54755324);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "07:25:32.806-07:00" + "'", str11.equals("07:25:32.806-07:00"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.withMinimumValue();
        org.joda.time.LocalDate localDate10 = localDate8.minusWeeks((-1239139649));
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        org.joda.time.ReadablePartial readablePartial50 = null;
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = skipUndoDateTimeField12.getAsShortText(readablePartial50, (int) ' ', locale52);
//        org.joda.time.Partial partial54 = new org.joda.time.Partial();
//        java.lang.String str55 = partial54.toString();
//        int[] intArray56 = partial54.getValues();
//        org.joda.time.Chronology chronology57 = partial54.getChronology();
//        org.joda.time.Partial partial59 = new org.joda.time.Partial();
//        java.lang.String str60 = partial59.toString();
//        int[] intArray61 = partial59.getValues();
//        try {
//            int[] intArray63 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) partial54, 6, intArray61, 83615943);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83615943 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83615028 + "'", int35 == 83615028);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "32" + "'", str53.equals("32"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "[]" + "'", str55.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "[]" + "'", str60.equals("[]"));
//        org.junit.Assert.assertNotNull(intArray61);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) 86400031);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate1.era();
        org.joda.time.LocalDate localDate7 = property6.withMinimumValue();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str1 = partial0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime5 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime6 = partial0.toDateTime((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((-100));
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[]" + "'", str1.equals("[]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology14 = gJChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.LocalDate.Property property16 = localDate15.dayOfYear();
        org.joda.time.LocalDate localDate18 = localDate15.plusDays((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate18);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        int int7 = dateTime2.getYear();
//        org.joda.time.DateTime.Property property8 = dateTime2.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615361 + "'", int6 == 83615361);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 24, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTime dateTime8 = dateTime5.withYearOfEra((int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 83615943, (java.lang.Number) 100.0d, (java.lang.Number) 83555133);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615253 + "'", int48 == 83615253);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate10 = localDate8.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate12 = localDate8.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property13 = localDate12.year();
        org.joda.time.LocalDate localDate15 = localDate12.withWeekyear(10);
        org.joda.time.LocalDate localDate16 = localDate1.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property17 = localDate12.monthOfYear();
        java.lang.String str18 = property17.getAsString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1560553258354L, "58360890");
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
        org.joda.time.DateTime dateTime4 = dateTime0.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMinutes(29537);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour(83555016, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        int int6 = dateTime5.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime5.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime0.toMutableDateTime(dateTimeZone7);
//        java.util.TimeZone timeZone10 = dateTimeZone7.toTimeZone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(timeZone10);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 29);
        org.joda.time.Instant instant3 = instant1.withMillis((-28797981L));
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
//        java.lang.String str6 = dateTimeZone3.getName((long) 1000);
//        java.lang.String str8 = dateTimeZone3.getShortName((long) 7);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) 54755172, (int) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pacific Standard Time" + "'", str6.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology11);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str1.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        long long11 = iSOChronology3.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        long long15 = dateTimeZone12.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone12);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale19 = dateTimeFormatter18.getLocale();
//        boolean boolean20 = cachedDateTimeZone17.equals((java.lang.Object) locale19);
//        org.joda.time.Chronology chronology21 = iSOChronology3.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DurationField durationField22 = iSOChronology3.centuries();
//        try {
//            long long25 = durationField22.subtract(10L, (long) 54755617);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -5475561700");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 361L + "'", long11 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 34L + "'", long15 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(locale19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str3 = copticChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.millisOfDay();
        org.joda.time.Partial partial5 = new org.joda.time.Partial((org.joda.time.Chronology) copticChronology2);
        java.lang.String str6 = partial5.toStringList();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.Partial partial8 = partial5.plus(readablePeriod7);
        boolean boolean9 = julianChronology0.equals((java.lang.Object) partial8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[UTC]" + "'", str3.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        int int28 = dividedDateTimeField26.getMaximumValue();
//        boolean boolean30 = dividedDateTimeField26.isLeap((long) 100);
//        long long33 = dividedDateTimeField26.add((long) 58329, (long) 2019);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1756588329L + "'", long33 == 1756588329L);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        java.lang.String str4 = dateTime0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15T16:13:12.918-07:00" + "'", str4.equals("2019-06-15T16:13:12.918-07:00"));
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        int int2 = localDate1.getWeekOfWeekyear();
        int int3 = localDate1.getYearOfEra();
        org.joda.time.DateTime dateTime4 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.DateTimeField dateTimeField6 = localDate1.getField((int) (short) 1);
        org.joda.time.LocalDate.Property property7 = localDate1.dayOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1969 + "'", int3 == 1969);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615959 + "'", int6 == 83615959);
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.millisOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField13);
//        org.joda.time.DurationField durationField15 = copticChronology0.weekyears();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.Chronology chronology7 = gJChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone8.adjustOffset(34L, true);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.Chronology chronology14 = gJChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 34L + "'", long11 == 34L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate71 = localDate67.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology72);
//        org.joda.time.LocalDate localDate75 = dateTime74.toLocalDate();
//        org.joda.time.LocalDate.Property property76 = localDate75.dayOfMonth();
//        boolean boolean77 = localDate71.isEqual((org.joda.time.ReadablePartial) localDate75);
//        java.lang.Object obj78 = null;
//        boolean boolean79 = localDate71.equals(obj78);
//        java.util.Locale locale81 = null;
//        try {
//            java.lang.String str82 = unsupportedDateTimeField65.getAsShortText((org.joda.time.ReadablePartial) localDate71, 1, locale81);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615238 + "'", int48 == 83615238);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.LimitChronology limitChronology7 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) copticChronology0, (org.joda.time.ReadableDateTime) dateTime1, (org.joda.time.ReadableDateTime) dateTime4);
//        org.joda.time.DurationField durationField8 = limitChronology7.millis();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(limitChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        int int6 = localDate1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = localDate1.toDateTimeAtCurrentTime();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str12 = copticChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.millisOfDay();
//        int int14 = dateTime10.get(dateTimeField13);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
//        int int18 = offsetDateTimeField16.getMinimumValue(0L);
//        int int20 = offsetDateTimeField16.getLeapAmount((long) 912);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate24 = localDate22.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate26 = localDate22.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property27 = localDate26.year();
//        org.joda.time.LocalDate localDate29 = localDate26.withWeekyear(10);
//        org.joda.time.LocalDate localDate31 = localDate29.plusMonths((int) (short) -1);
//        org.joda.time.LocalDate.Property property32 = localDate31.centuryOfEra();
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate31, 0, locale34);
//        boolean boolean36 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate31);
//        org.joda.time.LocalDate localDate38 = localDate31.plusYears(83555015);
//        try {
//            org.joda.time.DateTimeField dateTimeField40 = localDate31.getField(54755359);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 54755359");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CopticChronology[UTC]" + "'", str12.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 83615793 + "'", int14 == 83615793);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0" + "'", str35.equals("0"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.weekyear();
        org.joda.time.LocalDate localDate7 = property6.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate8 = property6.getLocalDate();
        org.joda.time.LocalDate localDate9 = property6.getLocalDate();
        java.lang.String str10 = property6.toString();
        java.util.Locale locale11 = null;
        int int12 = property6.getMaximumShortTextLength(locale11);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[weekyear]" + "'", str10.equals("Property[weekyear]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap4);
//        boolean boolean6 = iSOChronology3.equals((java.lang.Object) strMap4);
//        org.joda.time.Chronology chronology7 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField10, 1);
//        org.joda.time.DurationField durationField13 = skipUndoDateTimeField12.getRangeDurationField();
//        org.joda.time.Partial partial14 = new org.joda.time.Partial();
//        java.lang.String str15 = partial14.toString();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime20 = partial14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
//        java.lang.String str21 = partial14.toStringList();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial14, (int) ' ', locale23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipUndoDateTimeField12.getAsText((long) 36, locale26);
//        org.joda.time.ReadablePartial readablePartial28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str33 = copticChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.millisOfDay();
//        int int35 = dateTime31.get(dateTimeField34);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        long long39 = offsetDateTimeField37.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray46 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray48 = offsetDateTimeField37.add(readablePartial40, 0, intArray46, 0);
//        int int49 = skipUndoDateTimeField12.getMaximumValue(readablePartial28, intArray48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = skipUndoDateTimeField12.getAsShortText((long) 8, locale51);
//        try {
//            long long55 = skipUndoDateTimeField12.set(0L, 165);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 165 for secondOfMinute must be in the range [1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(strMap4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "32" + "'", str24.equals("32"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "CopticChronology[UTC]" + "'", str33.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 83615856 + "'", int35 == 83615856);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 59 + "'", int49 == 59);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMinutes((int) '#');
        boolean boolean6 = dateTime2.isBefore(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readablePeriod3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("07:25:27.537-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"07:25:27.537-07:00\" is malformed at \":25:27.537-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 2019);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) 1000);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.Class<?> wildcardClass13 = fixedDateTimeZone9.getClass();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        boolean boolean16 = fixedDateTimeZone9.equals((java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54755180 + "'", int11 == 54755180);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime.Property property2 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime0.minusHours(0);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withMinuteOfHour(15);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) 83615177, (long) 83555002);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019W246T161316-0700" + "'", str6.equals("2019W246T161316-0700"));
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfEra((int) (byte) 1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withTimeAtStartOfDay();
//        int int5 = dateTime0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        int int68 = unsupportedDateTimeField65.getDifference((-54755324L), 35L);
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate((long) 0, dateTimeZone70);
//        org.joda.time.LocalDate localDate73 = localDate71.withYear(0);
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime77 = dateTime75.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology78 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str79 = copticChronology78.toString();
//        org.joda.time.DateTimeField dateTimeField80 = copticChronology78.millisOfDay();
//        int int81 = dateTime77.get(dateTimeField80);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField83 = new org.joda.time.field.OffsetDateTimeField(dateTimeField80, (int) ' ');
//        long long85 = offsetDateTimeField83.remainder((long) 2019);
//        org.joda.time.ReadablePartial readablePartial86 = null;
//        int[] intArray92 = new int[] { 54755955, 365, 0, 2000 };
//        int[] intArray94 = offsetDateTimeField83.add(readablePartial86, 0, intArray92, 0);
//        try {
//            int[] intArray96 = unsupportedDateTimeField65.set((org.joda.time.ReadablePartial) localDate71, 54755180, intArray92, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615742 + "'", int48 == 83615742);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(copticChronology78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "CopticChronology[UTC]" + "'", str79.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 83615747 + "'", int81 == 83615747);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
//        org.junit.Assert.assertNotNull(intArray92);
//        org.junit.Assert.assertNotNull(intArray94);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeParser2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendYear((-292275054), 83615248);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset(34L, true);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        int int5 = julianChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfDay();
//        org.joda.time.DurationField durationField6 = copticChronology4.seconds();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime12 = dateTime8.plusMonths((int) (short) 0);
//        org.joda.time.DateTime dateTime14 = dateTime8.withWeekyear(1);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond((int) (short) 10);
//        java.util.Date date17 = dateTime14.toDate();
//        java.lang.String str18 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) dateTime14);
//        boolean boolean19 = copticChronology4.equals((java.lang.Object) dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0001-167T16:13:17.871-07:52:58" + "'", str18.equals("0001-167T16:13:17.871-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str4 = copticChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.millisOfDay();
//        int int6 = dateTime2.get(dateTimeField5);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        int int10 = offsetDateTimeField8.getMinimumValue(0L);
//        int int13 = offsetDateTimeField8.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale14 = null;
//        int int15 = offsetDateTimeField8.getMaximumShortTextLength(locale14);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField8.getAsText((long) 59, locale17);
//        org.joda.time.DurationField durationField19 = offsetDateTimeField8.getRangeDurationField();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField8.getAsText(36, locale21);
//        long long25 = offsetDateTimeField8.getDifferenceAsLong(10L, (long) 19);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CopticChronology[UTC]" + "'", str4.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 83615971 + "'", int6 == 83615971);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-58328) + "'", int13 == (-58328));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "91" + "'", str18.equals("91"));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "36" + "'", str22.equals("36"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9L) + "'", long25 == (-9L));
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
        org.joda.time.LocalDate.Property property6 = localDate5.year();
        org.joda.time.LocalDate.Property property7 = localDate5.monthOfYear();
        org.joda.time.LocalDate localDate8 = property7.withMinimumValue();
        org.joda.time.LocalDate localDate10 = localDate8.withDayOfYear(15);
        org.joda.time.LocalDate.Property property11 = localDate8.yearOfEra();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long6 = dateTimeZone3.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTime0, (org.joda.time.Chronology) copticChronology7);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusDays(1000);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond(36);
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime12.withEra(54755428);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54755428 for era must be in the range [1,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 34L + "'", long6 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 83555642, (long) 365);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 83556007L + "'", long2 == 83556007L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property3 = dateTime1.millisOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(0);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone8);
//        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "Pacific Standard Time", (int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean15 = dateTimeFormatter0.isParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        int int2 = localDate1.getWeekOfWeekyear();
//        org.joda.time.LocalDate.Property property3 = localDate1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        int int5 = dateTime4.getDayOfMonth();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
//        int int7 = property3.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.LocalDate localDate8 = property3.roundHalfEvenCopy();
//        java.lang.String str9 = property3.toString();
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 0);
//        int int12 = localDate11.getWeekOfWeekyear();
//        int int13 = localDate11.getYearOfEra();
//        org.joda.time.DateTime dateTime14 = localDate11.toDateTimeAtCurrentTime();
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate18 = localDate16.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate20 = localDate16.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property21 = localDate16.era();
//        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate25 = localDate23.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate26 = localDate16.withFields((org.joda.time.ReadablePartial) localDate25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = localDate26.getFieldType(0);
//        int int29 = localDate26.size();
//        org.joda.time.DateTime dateTime30 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate26);
//        org.joda.time.DateTime dateTime31 = localDate26.toDateTimeAtCurrentTime();
//        long long32 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDate localDate34 = property3.addToCopy(54755950);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[dayOfYear]" + "'", str9.equals("Property[dayOfYear]"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 8L + "'", long32 == 8L);
//        org.junit.Assert.assertNotNull(localDate34);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime30 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime27.minus(readablePeriod31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfMinute();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        int int37 = dateTime36.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime36.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap40 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap40);
//        boolean boolean42 = iSOChronology39.equals((java.lang.Object) strMap40);
//        org.joda.time.DurationField durationField43 = iSOChronology39.weeks();
//        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate47 = localDate45.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate49 = localDate45.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property50 = localDate45.era();
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate54 = localDate52.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate55 = localDate45.withFields((org.joda.time.ReadablePartial) localDate54);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = localDate55.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, durationField43, dateTimeFieldType57, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime64 = dateTime27.withField(dateTimeFieldType57, (-292275054));
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, dateTimeFieldType57);
//        long long68 = dividedDateTimeField26.add((long) 13, 83615253);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 15 + "'", int37 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(strMap40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-269173921987L) + "'", long68 == (-269173921987L));
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        int int2 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime1.getZone();
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) dateTime1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) 0, dateTimeZone1);
//        org.joda.time.LocalDate localDate4 = localDate2.withYear(0);
//        int int5 = localDate2.getDayOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.withSecondOfMinute((int) '#');
//        org.joda.time.DateTime dateTime9 = dateTime6.withLaterOffsetAtOverlap();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime6.minus(readablePeriod10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfMinute();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        int int16 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap19);
//        boolean boolean21 = iSOChronology18.equals((java.lang.Object) strMap19);
//        org.joda.time.DurationField durationField22 = iSOChronology18.weeks();
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate26 = localDate24.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate28 = localDate24.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property29 = localDate24.era();
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate33 = localDate31.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate34 = localDate24.withFields((org.joda.time.ReadablePartial) localDate33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = localDate34.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, durationField22, dateTimeFieldType36, 870);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 6, "29551638");
//        org.joda.time.DateTime dateTime43 = dateTime6.withField(dateTimeFieldType36, (-292275054));
//        org.joda.time.LocalDate localDate45 = localDate2.withField(dateTimeFieldType36, 83555133);
//        org.joda.time.Partial partial46 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate45);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(strMap19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(localDate45);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate3 = localDate1.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate5 = localDate1.withWeekyear((int) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
//        org.joda.time.LocalDate.Property property10 = localDate9.dayOfMonth();
//        boolean boolean11 = localDate5.isEqual((org.joda.time.ReadablePartial) localDate9);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = localDate5.equals(obj12);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.secondOfMinute();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        int int18 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap21);
//        boolean boolean23 = iSOChronology20.equals((java.lang.Object) strMap21);
//        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate28 = localDate26.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = localDate26.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property31 = localDate26.era();
//        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate35 = localDate33.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate36 = localDate26.withFields((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = localDate36.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, durationField24, dateTimeFieldType38, 870);
//        boolean boolean41 = localDate5.isSupported(dateTimeFieldType38);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime44 = dateTime42.withSecondOfMinute((int) '#');
//        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        java.lang.String str46 = copticChronology45.toString();
//        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.millisOfDay();
//        int int48 = dateTime44.get(dateTimeField47);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) ' ');
//        int int52 = offsetDateTimeField50.getMinimumValue(0L);
//        int int55 = offsetDateTimeField50.getDifference((long) (byte) 1, (long) 58329);
//        java.util.Locale locale56 = null;
//        int int57 = offsetDateTimeField50.getMaximumShortTextLength(locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField50.getAsText((long) 59, locale59);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField50.getRangeDurationField();
//        long long64 = durationField61.subtract((long) 54755194, (long) 29545);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField61);
//        long long68 = unsupportedDateTimeField65.add(11L, (long) 7);
//        try {
//            boolean boolean70 = unsupportedDateTimeField65.isLeap((long) 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(strMap21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(copticChronology45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "CopticChronology[UTC]" + "'", str46.equals("CopticChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 83615645 + "'", int48 == 83615645);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-58328) + "'", int55 == (-58328));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "91" + "'", str60.equals("91"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2552633244806L) + "'", long64 == (-2552633244806L));
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604800011L + "'", long68 == 604800011L);
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        int int4 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
//        boolean boolean9 = iSOChronology6.equals((java.lang.Object) strMap7);
//        org.joda.time.DurationField durationField10 = iSOChronology6.weeks();
//        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate14 = localDate12.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = localDate12.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property17 = localDate12.era();
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate21 = localDate19.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate22 = localDate12.withFields((org.joda.time.ReadablePartial) localDate21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = localDate22.getFieldType(0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, durationField10, dateTimeFieldType24, 870);
//        int int27 = dividedDateTimeField26.getDivisor();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        int int29 = dateTime28.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime28.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap32);
//        boolean boolean34 = iSOChronology31.equals((java.lang.Object) strMap32);
//        org.joda.time.Chronology chronology35 = iSOChronology31.withUTC();
//        long long39 = iSOChronology31.add((long) 1, (long) (byte) 10, 36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        long long43 = dateTimeZone40.adjustOffset(34L, true);
//        org.joda.time.chrono.CopticChronology copticChronology44 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone45 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.util.Locale locale47 = dateTimeFormatter46.getLocale();
//        boolean boolean48 = cachedDateTimeZone45.equals((java.lang.Object) locale47);
//        org.joda.time.Chronology chronology49 = iSOChronology31.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone45);
//        org.joda.time.DurationField durationField50 = iSOChronology31.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", 54755180, 166);
//        int int57 = fixedDateTimeZone55.getOffsetFromLocal((long) 1000);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate62 = localDate60.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate64 = localDate60.withWeekyear((int) (byte) 10);
//        org.joda.time.LocalDate.Property property65 = localDate60.era();
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 0);
//        org.joda.time.LocalDate localDate69 = localDate67.minusDays((int) (short) 10);
//        org.joda.time.LocalDate localDate70 = localDate60.withFields((org.joda.time.ReadablePartial) localDate69);
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = localDate70.getFieldType(0);
//        int int73 = dateTime58.get(dateTimeFieldType72);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, durationField50, dateTimeFieldType72);
//        int int76 = remainderDateTimeField74.get((long) 83555325);
//        int int78 = remainderDateTimeField74.getMinimumValue((long) 19);
//        int int79 = remainderDateTimeField74.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(strMap7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 870 + "'", int27 == 870);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(strMap32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 361L + "'", long39 == 361L);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 34L + "'", long43 == 34L);
//        org.junit.Assert.assertNotNull(copticChronology44);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNull(locale47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 54755180 + "'", int57 == 54755180);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(localDate69);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 869 + "'", int79 == 869);
//    }
//}

