import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) ' ', (int) (short) 100, (int) (short) 1, (int) (short) -1, (int) (byte) 10, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 10, (java.lang.Object) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test006");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560634131160L + "'", long1 == 1560634131160L);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (int) (short) -1, (int) (byte) 0, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 0.0d, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = dateTime5.toString("hi!", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) 'a', (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray3 = new int[] {};
        try {
            iSOChronology1.validate(readablePartial2, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            java.lang.String str5 = dateTimeFormatter2.print(readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.Object obj0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 15, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 10, 10);
//        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 10, (java.lang.Object) (-1));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(10);
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property3.setCopy("hi!", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime3.year();
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35L) + "'", long2 == (-35L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1), "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 0L, (java.lang.Number) 5L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
        boolean boolean4 = dateTimeFormatter3.isOffsetParsed();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("Property[year]", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) -1, 101, (int) (byte) 100, 2019, 20, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("Property[year]", 0, 9, 24, '#', (int) (short) 10, 100, (int) (short) -1, false, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 100, (int) (short) 0, 0, 10, 0, 9, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-35L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        try {
//            int int6 = property3.compareTo(readableInstant5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.halfdays();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2019, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 5L, number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter2.printTo(appendable4, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 'a', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusSeconds(0);
//        org.joda.time.DurationFieldType durationFieldType5 = null;
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 101);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 15, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1500L + "'", long2 == 1500L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) '#');
        int int11 = dateTime8.getYearOfEra();
        org.joda.time.LocalTime localTime12 = dateTime8.toLocalTime();
        int[] intArray15 = new int[] { (-292275054), 101 };
        try {
            iSOChronology1.validate((org.joda.time.ReadablePartial) localTime12, intArray15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfDay must not be smaller than 0");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.withCenturyOfEra(15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 101, (-292275054), 10, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 101 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long6 = iSOChronology1.getDateTimeMillis((int) (byte) 0, (int) (short) 100, (int) (byte) 10, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray6 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParserArray6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(16, 2019, 10, (int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusMillis((int) 'a');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.getAsText();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.year();
        org.joda.time.DateTime dateTime12 = property11.getDateTime();
        org.joda.time.DateTime dateTime13 = property11.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((int) '#');
        int int16 = dateTime13.getYearOfEra();
        org.joda.time.LocalTime localTime17 = dateTime13.toLocalTime();
        org.joda.time.TimeOfDay timeOfDay18 = dateTime13.toTimeOfDay();
        try {
            int int19 = property3.compareTo((org.joda.time.ReadablePartial) timeOfDay18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        boolean boolean5 = dateTimeFormatter4.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder1.appendYearOfCentury((-1), (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            java.lang.String str4 = dateTimeFormatter2.print((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYear((int) (short) 0);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimePrinter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
//        int int5 = dateTime3.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.LocalDate localDate8 = dateTime7.toLocalDate();
//        org.joda.time.LocalDate localDate9 = dateTime7.toLocalDate();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertNotNull(localDate9);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 32399999L, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        int int3 = dateTimeZone1.getOffsetFromLocal((-9061010L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32400000 + "'", int3 == 32400000);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        boolean boolean4 = dateTime0.isEqual((long) 15);
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long7 = iSOChronology1.getDateTimeMillis(0L, (int) '4', 6, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfDay();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsText(locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) 'a', (int) (byte) 0, (int) '#', 0, 9, (int) (short) 1, (-1), dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.getAsText();
        org.joda.time.DurationField durationField8 = property3.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime5.getZone();
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        int int8 = dateTime1.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 167 + "'", int8 == 167);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 0, (java.lang.Number) (-1.0f), (java.lang.Number) 1500L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str4 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField6 = gregorianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) 100.0d, (org.joda.time.Chronology) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+09:00" + "'", str4.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-16T06:29:00.645+09:00", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) -1, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract(1560634131160L, (long) 15);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560634131145L + "'", long3 == 1560634131145L);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property4.getAsShortText(locale14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        boolean boolean18 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        int int19 = dateTime17.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime17.minus(readableDuration20);
//        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
//        org.joda.time.ReadableInterval readableInterval23 = null;
//        org.joda.time.ReadableInterval readableInterval24 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval23);
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval23);
//        org.joda.time.DateTime dateTime26 = dateTime21.toDateTime(chronology25);
//        int int27 = property4.getDifference((org.joda.time.ReadableInstant) dateTime26);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "29" + "'", str15.equals("29"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(readableInterval24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((long) 0);
//        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
//        int int4 = dateTime0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        java.io.Writer writer3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter0.printTo(writer3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 24, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        int int5 = property4.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 10, 10);
//        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
//        int int10 = dateTime8.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 24, dateTimeZone5);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560634131145L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560634131145L) + "'", long2 == (-1560634131145L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, 0);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime1.toString("", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime1.withWeekOfWeekyear((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        boolean boolean5 = dateTimeFormatter4.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFixedDecimal(dateTimeFieldType7, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) '4', 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.hourOfHalfday();
        try {
            long long12 = iSOChronology3.getDateTimeMillis((int) (byte) 10, 0, (int) (short) 100, 1, 24, 24, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+09:00" + "'", str2.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "28");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        java.lang.String str7 = property3.toString();
//        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = property3.addWrapFieldToCopy((int) 'a');
//        int int11 = property3.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-292275054) + "'", int11 == (-292275054));
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        java.lang.String str7 = property3.toString();
//        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay((int) ' ');
//        boolean boolean14 = dateTime8.isAfter((long) (short) 100);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = property3.addToCopy((int) (short) -1);
//        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DurationField durationField14 = iSOChronology1.halfdays();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField16 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9055607L) + "'", long11 == (-9055607L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay((int) (byte) 10);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendPattern("+09:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendWeekyear((int) (byte) 1, 4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        try {
            long long8 = iSOChronology1.getDateTimeMillis((long) 24, (int) 'a', 59, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withYearOfCentury(20);
//        org.joda.time.DateTime dateTime6 = dateTime0.withCenturyOfEra(0);
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2019, (long) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8076 + "'", int2 == 8076);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getName((long) 2000);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+09:00" + "'", str2.equals("+09:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+09:00" + "'", str6.equals("+09:00"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(9, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560634145593L + "'", long0 == 1560634145593L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime4.toCalendar(locale8);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMillis(4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        boolean boolean6 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, 100);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        long long20 = dateTimeZone16.convertLocalToUTC(100L, false, (-5462266L));
//        java.util.TimeZone timeZone21 = dateTimeZone16.toTimeZone();
//        org.joda.time.DateTime dateTime22 = dateTime13.withZone(dateTimeZone16);
//        try {
//            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-32399900L) + "'", long20 == (-32399900L));
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.yearOfCentury();
//        org.joda.time.DurationField durationField14 = iSOChronology1.years();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9054082L) + "'", long11 == (-9054082L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
//        int int8 = dateTime5.getYearOfEra();
//        org.joda.time.Instant instant9 = dateTime5.toInstant();
//        int int10 = dateTime5.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        boolean boolean9 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfDay(2019);
//        int int12 = dateTime7.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay13 = dateTime7.toTimeOfDay();
//        long long15 = iSOChronology5.set((org.joda.time.ReadablePartial) timeOfDay13, (long) (short) 1);
//        int[] intArray17 = iSOChronology1.get((org.joda.time.ReadablePartial) timeOfDay13, 0L);
//        org.joda.time.DurationField durationField18 = iSOChronology1.millis();
//        org.joda.time.DurationFieldType durationFieldType19 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField21 = new org.joda.time.field.ScaledDurationField(durationField18, durationFieldType19, 32400000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9053908L) + "'", long15 == (-9053908L));
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.toString();
        int int8 = property3.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        long long16 = dateTimeZone12.convertLocalToUTC(100L, false, (-5462266L));
        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone12);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-32399900L) + "'", long16 == (-32399900L));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-9061010L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-9061010) + "'", int1 == (-9061010));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        boolean boolean12 = dateTimeFormatterBuilder10.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        long long8 = durationField5.subtract((long) (byte) 10, 6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-18934127999990L) + "'", long8 == (-18934127999990L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra((int) (short) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.DateTime.Property property12 = dateTime8.property(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2019, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4038000 + "'", int2 == 4038000);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTimeField dateTimeField6 = property3.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType7, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
//        int int4 = dateTime2.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.minus(readableDuration5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
//        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 0);
//        org.joda.time.DurationField durationField11 = gregorianChronology0.years();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560643200000L + "'", long10 == 1560643200000L);
//        org.junit.Assert.assertNotNull(durationField11);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        int int7 = property3.getMinimumValueOverall();
        org.joda.time.DateTime dateTime9 = property3.addToCopy((-1L));
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) (-1L), dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+09:00" + "'", str12.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        try {
            long long7 = iSOChronology1.getDateTimeMillis((-292275054), (int) (short) 100, 16, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-292275054));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292275054) + "'", int1 == (-292275054));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        long long16 = dateTimeZone12.convertLocalToUTC(100L, false, (-5462266L));
        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime9.plus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime20.minusHours((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-32399900L) + "'", long16 == (-32399900L));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
        int int5 = dateTime0.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime0.era();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType4, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfSecond((int) ' ');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 23348976 + "'", int8 == 23348976);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str3 = dateTimeZone2.getID();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean14 = dateTime10.isEqual((long) 15);
//        org.joda.time.DateTime dateTime16 = dateTime10.minusMillis(0);
//        int int17 = dateTime10.getWeekOfWeekyear();
//        long long18 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime10.getZone();
//        long long21 = dateTimeZone2.getMillisKeepLocal(dateTimeZone19, (-1L));
//        java.lang.String str22 = dateTimeZone2.getID();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+09:00" + "'", str22.equals("+09:00"));
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
//        int int4 = property3.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 59 + "'", int4 == 59);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        try {
            org.joda.time.LocalTime localTime7 = dateTimeFormatter5.parseLocalTime("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(100, 292278993, 9, 10, 4, (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        org.joda.time.ReadableInterval readableInterval7 = null;
//        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval7);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval7);
//        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(chronology9);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime10.withSecondOfMinute(100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(readableInterval8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-32399900L), (long) 292278993);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 259879093L + "'", long2 == 259879093L);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        boolean boolean16 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime15.year();
//        int int18 = property17.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType19, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9049771L) + "'", long11 == (-9049771L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "(\"org.joda.time.JodaTimePermission\" \"hi!\")", 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 101, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
//        int int5 = dateTime0.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay6 = dateTime0.toTimeOfDay();
//        int int7 = dateTime0.getDayOfMonth();
//        org.joda.time.DateTime dateTime8 = dateTime0.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology1.add(readablePeriod2, 0L, 10);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 24);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField6 = gregorianChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfDay((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime1.withMillisOfDay((int) (byte) 0);
        int int8 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        boolean boolean15 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime14);
//        int int16 = dateTime14.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime14.minus(readableDuration17);
//        org.joda.time.LocalDate localDate19 = dateTime18.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
//        boolean boolean29 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime31 = dateTime27.withMillisOfDay(2019);
//        int int32 = dateTime27.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime27.toTimeOfDay();
//        long long35 = iSOChronology25.set((org.joda.time.ReadablePartial) timeOfDay33, (long) (short) 1);
//        int[] intArray37 = iSOChronology21.get((org.joda.time.ReadablePartial) timeOfDay33, 0L);
//        try {
//            iSOChronology1.validate((org.joda.time.ReadablePartial) localDate19, intArray37);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9049412L) + "'", long11 == (-9049412L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9049393L) + "'", long35 == (-9049393L));
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("0", (int) '#', 0, (int) (byte) 0, '4', 0, (int) (short) 0, (int) (byte) -1, false, 23347259);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+09:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime1.toGregorianCalendar();
//        boolean boolean7 = dateTime1.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.lang.String str6 = dateTime4.toString("28");
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withFieldAdded(durationFieldType7, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "28" + "'", str6.equals("28"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1560634131145L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.year();
//        int int9 = property8.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "2019-06-16T06:29:00.645+09:00");
//        org.joda.time.DateTime dateTime14 = dateTime1.withField(dateTimeFieldType10, 0);
//        int int15 = dateTime14.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 389 + "'", int15 == 389);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime5 = dateTime1.plusMinutes(15);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str3 = dateTimeZone2.getID();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean14 = dateTime10.isEqual((long) 15);
//        org.joda.time.DateTime dateTime16 = dateTime10.minusMillis(0);
//        int int17 = dateTime10.getWeekOfWeekyear();
//        long long18 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime10.getZone();
//        long long21 = dateTimeZone2.getMillisKeepLocal(dateTimeZone19, (-1L));
//        long long24 = dateTimeZone19.convertLocalToUTC(1L, true);
//        boolean boolean26 = dateTimeZone19.isStandardOffset((long) '#');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-32399999L) + "'", long24 == (-32399999L));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str20 = dateTimeZone19.getID();
//        org.joda.time.Chronology chronology21 = gregorianChronology17.withZone(dateTimeZone19);
//        org.joda.time.DurationField durationField22 = gregorianChronology17.centuries();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology17.dayOfWeek();
//        int int24 = dateTime15.get(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+09:00" + "'", str20.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime19 = property16.setCopy("Property[year]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[year]\" for centuryOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        long long11 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) (short) 1, 16, (int) (byte) 100);
        try {
            long long19 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, 9, 0, (int) (short) -1, 23348976, (-292275054), 8076);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61850303999900L) + "'", long11 == (-61850303999900L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+09:00");
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        int int6 = property5.get();
        jodaTimePermission1.checkGuard((java.lang.Object) property5);
        java.lang.String str8 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"+09:00\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"+09:00\")"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        long long7 = dateTimeZone1.adjustOffset((long) (-292275054), false);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone1.getShortName((long) 19, locale10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+09:00" + "'", str2.equals("+09:00"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-292275054L) + "'", long7 == (-292275054L));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime6 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.DateTime dateTime10 = property9.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, 100);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        long long22 = dateTimeZone18.convertLocalToUTC(100L, false, (-5462266L));
//        java.util.TimeZone timeZone23 = dateTimeZone18.toTimeZone();
//        org.joda.time.DateTime dateTime24 = dateTime15.withZone(dateTimeZone18);
//        try {
//            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(101, 32400000, (int) (short) 1, 24, (int) (short) 0, (int) (short) 10, dateTimeZone18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-32399900L) + "'", long22 == (-32399900L));
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2019, 32400000, (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendDayOfMonth(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.toString();
        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
        int int9 = property3.getLeapAmount();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime11.year();
        org.joda.time.DateTime dateTime14 = property13.getDateTime();
        org.joda.time.DateTime dateTime15 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes((int) '#');
        int int18 = dateTime15.getYearOfEra();
        org.joda.time.LocalTime localTime19 = dateTime15.toLocalTime();
        org.joda.time.TimeOfDay timeOfDay20 = dateTime15.toTimeOfDay();
        int int21 = property3.compareTo((org.joda.time.ReadableInstant) dateTime15);
        java.util.Locale locale23 = null;
        try {
            org.joda.time.DateTime dateTime24 = property3.setCopy("Property[year]", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[year]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime.Property property7 = dateTime6.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime5.withMillisOfDay(2019);
//        int int10 = dateTime5.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay11 = dateTime5.toTimeOfDay();
//        long long13 = iSOChronology3.set((org.joda.time.ReadablePartial) timeOfDay11, (long) (short) 1);
//        org.joda.time.DurationField durationField14 = iSOChronology3.weekyears();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology3.yearOfCentury();
//        try {
//            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0, (org.joda.time.Chronology) iSOChronology3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9047068L) + "'", long13 == (-9047068L));
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 10, 10);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusYears((int) (byte) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        boolean boolean14 = dateTime12.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        int int15 = dateTime13.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime13.minus(readableDuration16);
//        org.joda.time.LocalDate localDate18 = dateTime17.toLocalDate();
//        org.joda.time.LocalDate localDate19 = dateTime17.toLocalDate();
//        long long21 = gregorianChronology11.set((org.joda.time.ReadablePartial) localDate19, (long) (byte) 0);
//        int int22 = gregorianChronology11.getMinimumDaysInFirstWeek();
//        boolean boolean23 = dateTime10.equals((java.lang.Object) int22);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560643200000L + "'", long21 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter2.parseLocalDateTime("12");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter2.printTo(writer4, (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime5.getZone();
//        boolean boolean15 = dateTime5.isBeforeNow();
//        int int16 = dateTime5.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (-292275054));
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
//        try {
//            org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay((-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 259879093L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology1.add(readablePeriod2, 0L, 10);
        java.lang.String str6 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[+09:00]" + "'", str6.equals("ISOChronology[+09:00]"));
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        org.joda.time.DurationField durationField13 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        boolean boolean17 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime16.minus(readableDuration19);
//        org.joda.time.LocalDate localDate21 = dateTime20.toLocalDate();
//        org.joda.time.LocalDate localDate22 = dateTime20.toLocalDate();
//        long long24 = gregorianChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) (byte) 0);
//        int int25 = gregorianChronology14.getMinimumDaysInFirstWeek();
//        org.joda.time.JodaTimePermission jodaTimePermission27 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean28 = gregorianChronology14.equals((java.lang.Object) "hi!");
//        org.joda.time.DurationField durationField29 = gregorianChronology14.minutes();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField30 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField13, durationField29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560643200000L + "'", long24 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(durationField29);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = null;
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser3);
        boolean boolean5 = dateTimeFormatter4.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendMillisOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMinuteOfHour((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 10, 10);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime5.withEra((int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 23348976, (java.lang.Number) 1.0d, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfDay((int) (byte) 10);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime1.toCalendar(locale6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(calendar7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
        int int8 = property3.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DurationField durationField14 = iSOChronology1.halfdays();
//        org.joda.time.DurationField durationField15 = iSOChronology1.seconds();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9045181L) + "'", long11 == (-9045181L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        long long14 = offsetDateTimeField12.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-32400000L) + "'", long14 == (-32400000L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        boolean boolean4 = dateTime0.isEqual((long) 15);
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime0.toCalendar(locale7);
        org.joda.time.DateTime dateTime10 = dateTime0.plus((long) '#');
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronolgy();
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfDay();
        boolean boolean7 = dateTime4.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.withLaterOffsetAtOverlap();
//        int int5 = dateTime4.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29 + "'", int5 == 29);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(6, 0, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfHalfday(16);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfHour((-292275054), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((long) 0);
//        boolean boolean9 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime5.toYearMonthDay();
//        boolean boolean12 = dateTime5.isAfter(10L);
//        boolean boolean13 = dateTime5.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DurationField durationField14 = iSOChronology1.halfdays();
//        long long17 = durationField14.subtract((-9054082L), 23347259);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9043625L) + "'", long11 == (-9043625L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1008601597854082L) + "'", long17 == (-1008601597854082L));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1970001T090000+0900");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1970001T090000+0900' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
//        boolean boolean6 = dateTime2.isEqual((long) 15);
//        org.joda.time.DateTime dateTime8 = dateTime2.minusMillis(0);
//        int int9 = dateTime2.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfDay(2019);
//        int int15 = dateTime10.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime10.toTimeOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime2.withFields((org.joda.time.ReadablePartial) timeOfDay16);
//        org.joda.time.DateTime.Property property18 = dateTime17.centuryOfEra();
//        org.joda.time.DateTime dateTime19 = property18.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType20, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        int int6 = dateTime5.getMonthOfYear();
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra(9);
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61868802642935L) + "'", long6 == (-61868802642935L));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.toString();
        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
        int int9 = property3.getLeapAmount();
        java.lang.String str10 = property3.getAsShortText();
        org.joda.time.DateTime dateTime11 = property3.roundHalfFloorCopy();
        org.joda.time.Interval interval12 = property3.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(interval12);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology1.weekyears();
        long long7 = durationField4.subtract((long) 29, 3);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-94348799971L) + "'", long7 == (-94348799971L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16) + "'", int1 == (-16));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfSecond(59, 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        int int18 = dateTime17.getEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        int int4 = property3.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "2019-06-16T06:29:00.645+09:00");
        java.lang.Number number8 = illegalFieldValueException7.getUpperBound();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-18934160399990L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-9054395L), 23348976);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 100, 0, 0, (-9061010), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9061010 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        org.joda.time.DateTime dateTime7 = property3.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone0.getShortName((-9057091L), locale3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+09:00" + "'", str4.equals("+09:00"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 2019, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        int int4 = property3.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType5, 32400000, (int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32400000 for year must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        java.lang.Class<?> wildcardClass14 = property4.getClass();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-5462266L), 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-103783054L) + "'", long2 == (-103783054L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        long long4 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (-32399999L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-32399999L) + "'", long4 == (-32399999L));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
//        int int8 = dateTime5.getYearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str11 = dateTimeZone10.getID();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        boolean boolean16 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        int int17 = dateTime15.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.minus(readableDuration18);
//        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        long long23 = gregorianChronology13.set((org.joda.time.ReadablePartial) localDate21, (long) (byte) 0);
//        int int24 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str27 = dateTimeZone26.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone26);
//        org.joda.time.Chronology chronology29 = gregorianChronology13.withZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime30 = dateTime5.withZoneRetainFields(dateTimeZone26);
//        org.joda.time.DateTime dateTime32 = dateTime5.minusYears(100);
//        boolean boolean33 = dateTime32.isEqualNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560643200000L + "'", long23 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+09:00" + "'", str27.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes((int) '#');
        jodaTimePermission1.checkGuard((java.lang.Object) '#');
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("+09:00");
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        boolean boolean15 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.year();
        int int17 = property16.get();
        jodaTimePermission12.checkGuard((java.lang.Object) property16);
        boolean boolean19 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission12);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
//        java.lang.Appendable appendable6 = null;
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        boolean boolean9 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.year();
//        org.joda.time.DateTime dateTime11 = property10.getDateTime();
//        java.lang.String str13 = dateTime11.toString("28");
//        try {
//            dateTimeFormatter5.printTo(appendable6, (org.joda.time.ReadableInstant) dateTime11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "28" + "'", str13.equals("28"));
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        boolean boolean13 = dateTime9.isEqual((long) 15);
//        org.joda.time.DateTime dateTime15 = dateTime9.minusMillis(0);
//        int int16 = dateTime9.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        boolean boolean19 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime17.withMillisOfDay(2019);
//        int int22 = dateTime17.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime24 = dateTime9.withFields((org.joda.time.ReadablePartial) timeOfDay23);
//        int int25 = dateTime24.getYear();
//        org.joda.time.DateTime dateTime27 = dateTime24.minusMinutes(23347259);
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime27);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
//        java.lang.Appendable appendable6 = null;
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        boolean boolean9 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime8);
//        int int10 = dateTime8.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.minus(readableDuration11);
//        org.joda.time.DateTime dateTime15 = dateTime12.withDurationAdded((long) 10, 10);
//        try {
//            dateTimeFormatter5.printTo(appendable6, (org.joda.time.ReadableInstant) dateTime12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        boolean boolean6 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        int int8 = property7.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType9, 4, 24, 23347259);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.append(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.append(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder4.appendHourOfHalfday(23347259);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendSecondOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYear((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-16T06:29:19.934+09:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology1.weekyear();
//        org.joda.time.DurationField durationField16 = iSOChronology1.eras();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9039398L) + "'", long11 == (-9039398L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        int int13 = offsetDateTimeField12.getMinimumValue();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField12.getAsShortText(readablePartial14, (int) (byte) 1, locale16);
//        int int19 = offsetDateTimeField12.getMinimumValue((long) (byte) 100);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField12, 15, 0, (-292275054));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for year must be in the range [0,-292275054]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readableDuration9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        long long13 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate11, 32399999L);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.hourOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560675599999L + "'", long13 == 1560675599999L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        int int4 = property3.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
//        org.joda.time.DurationField durationField6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfDay(2019);
//        int int15 = dateTime10.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime10.toTimeOfDay();
//        long long18 = iSOChronology8.set((org.joda.time.ReadablePartial) timeOfDay16, (long) (short) 1);
//        org.joda.time.DurationField durationField19 = iSOChronology8.weekyears();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology8.minuteOfDay();
//        org.joda.time.DurationField durationField21 = iSOChronology8.halfdays();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField22 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType5, durationField6, durationField21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9038582L) + "'", long18 == (-9038582L));
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        int int4 = property3.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "2019-06-16T06:29:00.645+09:00");
        java.lang.String str8 = illegalFieldValueException7.toString();
        java.lang.String str9 = illegalFieldValueException7.getIllegalValueAsString();
        java.lang.Number number10 = illegalFieldValueException7.getUpperBound();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"2019-06-16T06:29:00.645+09:00\" for year is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"2019-06-16T06:29:00.645+09:00\" for year is not supported"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-16T06:29:00.645+09:00" + "'", str9.equals("2019-06-16T06:29:00.645+09:00"));
        org.junit.Assert.assertNull(number10);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str8 = dateTimeZone7.getID();
//        org.joda.time.Chronology chronology9 = gregorianChronology5.withZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        int int13 = dateTime11.getDayOfMonth();
//        org.joda.time.DateTime.Property property14 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        boolean boolean17 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        boolean boolean19 = dateTime15.isEqual((long) 15);
//        org.joda.time.DateTime dateTime21 = dateTime15.minusMillis(0);
//        int int22 = dateTime15.getWeekOfWeekyear();
//        long long23 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone24 = dateTime15.getZone();
//        long long26 = dateTimeZone7.getMillisKeepLocal(dateTimeZone24, (-1L));
//        try {
//            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((-16), (int) (short) 100, 16, 23348976, 8076, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23348976 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+09:00" + "'", str8.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str3 = dateTimeZone2.getID();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean14 = dateTime10.isEqual((long) 15);
//        org.joda.time.DateTime dateTime16 = dateTime10.minusMillis(0);
//        int int17 = dateTime10.getWeekOfWeekyear();
//        long long18 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime10.getZone();
//        long long21 = dateTimeZone2.getMillisKeepLocal(dateTimeZone19, (-1L));
//        int int23 = dateTimeZone2.getOffsetFromLocal((long) ' ');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        int int26 = cachedDateTimeZone24.getOffset((-9056532L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32400000 + "'", int23 == 32400000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32400000 + "'", int26 == 32400000);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
//        int int4 = dateTime2.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.minus(readableDuration5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
//        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 0);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        int int12 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560643200000L + "'", long10 == 1560643200000L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
//        int int8 = dateTime5.getYearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str11 = dateTimeZone10.getID();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        boolean boolean16 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        int int17 = dateTime15.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.minus(readableDuration18);
//        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        long long23 = gregorianChronology13.set((org.joda.time.ReadablePartial) localDate21, (long) (byte) 0);
//        int int24 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str27 = dateTimeZone26.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone26);
//        org.joda.time.Chronology chronology29 = gregorianChronology13.withZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime30 = dateTime5.withZoneRetainFields(dateTimeZone26);
//        boolean boolean31 = dateTime5.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560643200000L + "'", long23 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+09:00" + "'", str27.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((long) 0);
        org.joda.time.DateTime dateTime4 = dateTime0.withYear(32400000);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        java.lang.String str7 = property3.toString();
//        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = property3.addWrapFieldToCopy((int) 'a');
//        int int11 = dateTime10.getEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) '#');
        int int9 = dateTime6.getYearOfEra();
        org.joda.time.LocalTime localTime10 = dateTime6.toLocalTime();
        try {
            java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-9061010), 9, 100, (int) (byte) -1, 100, 99, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        int int13 = offsetDateTimeField12.getMinimumValue();
//        int int15 = offsetDateTimeField12.getLeapAmount(14365747759L);
//        boolean boolean16 = offsetDateTimeField12.isSupported();
//        try {
//            long long19 = offsetDateTimeField12.add((long) 16, 631152000004L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 631152000004");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime5 = dateTime1.withYearOfEra(9);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfMonth((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        int int7 = property3.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        int int11 = dateTime9.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.minus(readableDuration12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        boolean boolean16 = dateTime14.isEqual((long) 0);
//        boolean boolean17 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime13.toYearMonthDay();
//        long long19 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime13);
//        int int20 = property3.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292278993 + "'", int20 == 292278993);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
        int int8 = dateTime5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withWeekOfWeekyear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendPattern("+09:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(10, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", true, 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(1);
        try {
            long long5 = dateTimeFormatter0.parseMillis("2019-06-16T06:29:19.934+09:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-16T06:29:19.934+09:00\" is malformed at \"+09:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        boolean boolean3 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer4 = null;
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        boolean boolean7 = dateTime5.isEqual((long) 0);
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone2.getMillisKeepLocal(dateTimeZone6, (long) 16);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone6.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+09:00" + "'", str7.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 16L + "'", long10 == 16L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
        java.lang.Class<?> wildcardClass5 = iSOChronology1.getClass();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        java.util.Locale locale26 = null;
//        try {
//            int int27 = unsupportedDateTimeField24.getMaximumTextLength(locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str3 = dateTimeZone1.getName((-1560634131145L));
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone1.isLocalDateTimeGap(localDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        boolean boolean28 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        boolean boolean30 = dateTime26.isEqual((long) 15);
//        org.joda.time.DateTime dateTime32 = dateTime26.minusMillis(0);
//        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
//        int[] intArray36 = new int[] { (short) 100 };
//        java.util.Locale locale38 = null;
//        try {
//            int[] intArray39 = unsupportedDateTimeField24.set((org.joda.time.ReadablePartial) localTime33, 29, intArray36, "(\"org.joda.time.JodaTimePermission\" \"hi!\")", locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localTime33);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0", 19);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Property[year]", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("0", 19);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        try {
            long long7 = iSOChronology1.getDateTimeMillis((int) (short) -1, 2000, (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        boolean boolean27 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        boolean boolean29 = dateTime25.isEqual((long) 15);
//        org.joda.time.DateTime dateTime31 = dateTime25.minusMillis(0);
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology38);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        boolean boolean42 = dateTime40.isEqual((org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime44 = dateTime40.withMillisOfDay(2019);
//        int int45 = dateTime40.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay46 = dateTime40.toTimeOfDay();
//        long long48 = iSOChronology38.set((org.joda.time.ReadablePartial) timeOfDay46, (long) (short) 1);
//        int[] intArray50 = iSOChronology34.get((org.joda.time.ReadablePartial) timeOfDay46, 0L);
//        org.joda.time.DurationField durationField51 = iSOChronology34.millis();
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
//        boolean boolean54 = dateTime52.isEqual((org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.DateTime.Property property55 = dateTime53.year();
//        org.joda.time.DateTime dateTime56 = property55.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        org.joda.time.DateTime dateTime59 = dateTime56.withPeriodAdded(readablePeriod57, 100);
//        org.joda.time.ReadableDuration readableDuration60 = null;
//        org.joda.time.DateTime dateTime61 = dateTime59.plus(readableDuration60);
//        org.joda.time.DateTime.Property property62 = dateTime59.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay63 = dateTime59.toTimeOfDay();
//        int[] intArray65 = iSOChronology34.get((org.joda.time.ReadablePartial) timeOfDay63, (long) 9);
//        try {
//            int int66 = unsupportedDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) localTime32, intArray65);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(iSOChronology38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 20 + "'", int45 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9034299L) + "'", long48 == (-9034299L));
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(timeOfDay63);
//        org.junit.Assert.assertNotNull(intArray65);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("+09:00");
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        boolean boolean6 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime10 = property7.roundHalfEvenCopy();
        boolean boolean11 = jodaTimePermission3.equals((java.lang.Object) dateTime10);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        int int16 = dateTime15.getYear();
//        org.joda.time.DateTime dateTime18 = dateTime15.minusMinutes(23347259);
//        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendPattern("+09:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendFractionOfHour((int) '4', 8076);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        java.util.Locale locale25 = null;
//        try {
//            int int26 = unsupportedDateTimeField24.getMaximumTextLength(locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
//        java.util.Locale locale1 = null;
//        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "2019");
//        java.util.Locale locale5 = null;
//        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "+09:00", "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.year();
//        org.joda.time.DateTime dateTime13 = property12.getDateTime();
//        java.util.Locale locale14 = null;
//        int int15 = property12.getMaximumShortTextLength(locale14);
//        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "(\"org.joda.time.JodaTimePermission\" \"hi!\")", (java.lang.Object) locale14);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
//        long long8 = property3.remainder();
//        java.lang.String str9 = property3.getName();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 14365766002L + "'", long8 == 14365766002L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "year" + "'", str9.equals("year"));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone2);
        try {
            org.joda.time.LocalTime localTime7 = dateTimeFormatter0.parseLocalTime("1970001T090000+0900");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970001T090000+0900\" is malformed at \"T090000+0900\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1970001T090000+0900");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970001T090000+0900\" is malformed at \"0000+0900\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        java.util.Locale locale4 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 99, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay(100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DurationField durationField12 = iSOChronology1.weekyears();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.weekyearOfCentury();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        boolean boolean20 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.year();
//        int int22 = property21.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType23, 4, 24, 23347259);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField(dateTimeField14, dateTimeFieldType23, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9033096L) + "'", long11 == (-9033096L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology31);
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        boolean boolean35 = dateTime33.isEqual((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime33.withMillisOfDay(2019);
//        int int38 = dateTime33.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay39 = dateTime33.toTimeOfDay();
//        long long41 = iSOChronology31.set((org.joda.time.ReadablePartial) timeOfDay39, (long) (short) 1);
//        int[] intArray43 = iSOChronology27.get((org.joda.time.ReadablePartial) timeOfDay39, 0L);
//        org.joda.time.DurationField durationField44 = iSOChronology27.millis();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
//        boolean boolean47 = dateTime45.isEqual((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.DateTime.Property property48 = dateTime46.year();
//        org.joda.time.DateTime dateTime49 = property48.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.DateTime dateTime52 = dateTime49.withPeriodAdded(readablePeriod50, 100);
//        org.joda.time.ReadableDuration readableDuration53 = null;
//        org.joda.time.DateTime dateTime54 = dateTime52.plus(readableDuration53);
//        org.joda.time.DateTime.Property property55 = dateTime52.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay56 = dateTime52.toTimeOfDay();
//        int[] intArray58 = iSOChronology27.get((org.joda.time.ReadablePartial) timeOfDay56, (long) 9);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
//        org.joda.time.DateTimeField dateTimeField62 = iSOChronology61.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField63 = iSOChronology61.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone64);
//        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology65);
//        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now();
//        boolean boolean69 = dateTime67.isEqual((org.joda.time.ReadableInstant) dateTime68);
//        org.joda.time.DateTime dateTime71 = dateTime67.withMillisOfDay(2019);
//        int int72 = dateTime67.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay73 = dateTime67.toTimeOfDay();
//        long long75 = iSOChronology65.set((org.joda.time.ReadablePartial) timeOfDay73, (long) (short) 1);
//        int[] intArray77 = iSOChronology61.get((org.joda.time.ReadablePartial) timeOfDay73, 0L);
//        org.joda.time.DurationField durationField78 = iSOChronology61.millis();
//        org.joda.time.DateTime dateTime79 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.now();
//        boolean boolean81 = dateTime79.isEqual((org.joda.time.ReadableInstant) dateTime80);
//        org.joda.time.DateTime.Property property82 = dateTime80.year();
//        org.joda.time.DateTime dateTime83 = property82.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod84 = null;
//        org.joda.time.DateTime dateTime86 = dateTime83.withPeriodAdded(readablePeriod84, 100);
//        org.joda.time.ReadableDuration readableDuration87 = null;
//        org.joda.time.DateTime dateTime88 = dateTime86.plus(readableDuration87);
//        org.joda.time.DateTime.Property property89 = dateTime86.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay90 = dateTime86.toTimeOfDay();
//        int[] intArray92 = iSOChronology61.get((org.joda.time.ReadablePartial) timeOfDay90, (long) 9);
//        java.util.Locale locale94 = null;
//        try {
//            int[] intArray95 = unsupportedDateTimeField24.set((org.joda.time.ReadablePartial) timeOfDay56, 0, intArray92, "", locale94);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 20 + "'", int38 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-9033030L) + "'", long41 == (-9033030L));
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(timeOfDay56);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(iSOChronology65);
//        org.junit.Assert.assertNotNull(chronology66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 20 + "'", int72 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-9033014L) + "'", long75 == (-9033014L));
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertNotNull(property82);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(dateTime86);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertNotNull(property89);
//        org.junit.Assert.assertNotNull(timeOfDay90);
//        org.junit.Assert.assertNotNull(intArray92);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendClockhourOfHalfday(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendFractionOfDay((int) (byte) 100, 23347259);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.toString();
        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime13 = dateTime8.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder7.toPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendFractionOfSecond((-16), 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds((-1));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        int int8 = dateTime1.getYearOfCentury();
//        int int9 = dateTime1.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfMonth((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getWeekyear();
        org.joda.time.DateTime dateTime3 = dateTime0.withDayOfWeek(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime5.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int13 = offsetDateTimeField12.getMinimumValue();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField12.getAsText((long) 8076, locale15);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "74" + "'", str16.equals("74"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = iSOChronology1.get(readablePeriod4, (long) 2000, (long) 32400000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder10.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder16.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder37.append(dateTimeParser42);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray44 = new org.joda.time.format.DateTimeParser[] { dateTimeParser26, dateTimeParser30, dateTimeParser32, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.append(dateTimePrinter11, dateTimeParserArray44);
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        boolean boolean48 = dateTime46.isEqual((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime.Property property49 = dateTime47.year();
        int int50 = property49.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property49.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder1.appendFixedDecimal(dateTimeFieldType51, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder1.appendSecondOfMinute(101);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeParserArray44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(15, 19, 0, (-292275054), 15, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "29" + "'", str6.equals("29"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property3.roundHalfEvenCopy();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime6.toCalendar(locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(calendar8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType6, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getDurationField();
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = unsupportedDateTimeField24.getAsText((int) (byte) -1, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = unsupportedDateTimeField24.getAsText((-9061010), locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        java.lang.String str7 = property3.toString();
        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withEra(8076);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8076 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((-292275054));
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(4038000);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        int int14 = offsetDateTimeField12.getMaximumValue(0L);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        boolean boolean17 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime16);
//        boolean boolean19 = dateTime15.isEqual((long) 15);
//        org.joda.time.DateTime dateTime21 = dateTime15.minusMillis(0);
//        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology29);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        boolean boolean33 = dateTime31.isEqual((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime dateTime35 = dateTime31.withMillisOfDay(2019);
//        int int36 = dateTime31.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay37 = dateTime31.toTimeOfDay();
//        long long39 = iSOChronology29.set((org.joda.time.ReadablePartial) timeOfDay37, (long) (short) 1);
//        int[] intArray41 = iSOChronology25.get((org.joda.time.ReadablePartial) timeOfDay37, 0L);
//        try {
//            int[] intArray43 = offsetDateTimeField12.set((org.joda.time.ReadablePartial) localTime22, (int) (short) 1, intArray41, 389);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 389 for year must be in the range [24,103]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 103 + "'", int14 == 103);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-9031053L) + "'", long39 == (-9031053L));
//        org.junit.Assert.assertNotNull(intArray41);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology1.weekyear();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9031032L) + "'", long11 == (-9031032L));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(14365747759L, (-9054082L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-130068658201302238L) + "'", long2 == (-130068658201302238L));
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfDay(2019);
//        int int8 = dateTime3.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime3.toTimeOfDay();
//        long long11 = iSOChronology1.set((org.joda.time.ReadablePartial) timeOfDay9, (long) (short) 1);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology1.weekyear();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.year();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9030933L) + "'", long11 == (-9030933L));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
//        java.lang.String str4 = property3.getAsShortText();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime6.year();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime6.withPeriodAdded(readablePeriod9, 0);
//        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra((int) (byte) 100);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfEra((int) (short) 1);
//        org.joda.time.DateTime dateTime17 = dateTime15.withHourOfDay((int) (byte) 0);
//        try {
//            int int18 = property3.getDifference((org.joda.time.ReadableInstant) dateTime15);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 63681897599");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "29" + "'", str4.equals("29"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        int int6 = dateTime1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(10);
//        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localTime7);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        java.lang.StringBuffer stringBuffer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfDay(2019);
//        int int15 = dateTime10.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay16 = dateTime10.toTimeOfDay();
//        long long18 = iSOChronology8.set((org.joda.time.ReadablePartial) timeOfDay16, (long) (short) 1);
//        int[] intArray20 = iSOChronology4.get((org.joda.time.ReadablePartial) timeOfDay16, 0L);
//        org.joda.time.DurationField durationField21 = iSOChronology4.millis();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        boolean boolean24 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime.Property property25 = dateTime23.year();
//        org.joda.time.DateTime dateTime26 = property25.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime26.withPeriodAdded(readablePeriod27, 100);
//        org.joda.time.ReadableDuration readableDuration30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.plus(readableDuration30);
//        org.joda.time.DateTime.Property property32 = dateTime29.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime29.toTimeOfDay();
//        int[] intArray35 = iSOChronology4.get((org.joda.time.ReadablePartial) timeOfDay33, (long) 9);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) timeOfDay33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9030429L) + "'", long18 == (-9030429L));
//        org.junit.Assert.assertNotNull(intArray20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property6 = dateTime3.era();
        org.joda.time.DateTime dateTime8 = dateTime3.withMinuteOfHour((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T090000+0900" + "'", str4.equals("1970001T090000+0900"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((-292275054));
        org.joda.time.DateTime.Property property12 = dateTime7.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int14 = offsetDateTimeField12.getMaximumValue(0L);
        long long17 = offsetDateTimeField12.add((long) 4, 20);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField12.getAsShortText((long) (short) 1, locale19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = offsetDateTimeField12.getAsText(readablePartial21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 103 + "'", int14 == 103);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 631152000004L + "'", long17 == 631152000004L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "74" + "'", str20.equals("74"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.append(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.append(dateTimeParser14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder4.appendHourOfHalfday(23347259);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap21 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendTimeZoneName(strMap21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendTwoDigitWeekyear(23347259);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatterBuilder32.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder34.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter47.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder43.append(dateTimeParser48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder38.append(dateTimeParser48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder19.append(dateTimePrinter33, dateTimeParser48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendEraText();
        boolean boolean54 = dateTimeFormatterBuilder53.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder55.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder56.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter63 = dateTimeFormatterBuilder62.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder64.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder64.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder69.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder70.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder73.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser78 = dateTimeFormatter77.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder73.append(dateTimeParser78);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder68.append(dateTimeParser78);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser82 = dateTimeFormatter81.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter83 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser84 = dateTimeFormatter83.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder85.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder89 = dateTimeFormatterBuilder86.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder89.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter93 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser94 = dateTimeFormatter93.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder89.append(dateTimeParser94);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray96 = new org.joda.time.format.DateTimeParser[] { dateTimeParser78, dateTimeParser82, dateTimeParser84, dateTimeParser94 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder97 = dateTimeFormatterBuilder53.append(dateTimePrinter63, dateTimeParserArray96);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder98 = dateTimeFormatterBuilder18.append(dateTimePrinter33, dateTimeParserArray96);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNotNull(dateTimeParser48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimePrinter63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertNotNull(dateTimeParser78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
        org.junit.Assert.assertNotNull(dateTimeFormatter81);
        org.junit.Assert.assertNotNull(dateTimeParser82);
        org.junit.Assert.assertNotNull(dateTimeFormatter83);
        org.junit.Assert.assertNotNull(dateTimeParser84);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder89);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
        org.junit.Assert.assertNotNull(dateTimeFormatter93);
        org.junit.Assert.assertNotNull(dateTimeParser94);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder95);
        org.junit.Assert.assertNotNull(dateTimeParserArray96);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder97);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder98);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-292275054L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292275054) + "'", int1 == (-292275054));
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        try {
//            int int25 = unsupportedDateTimeField24.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology7);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime9.withMillisOfDay(2019);
//        int int14 = dateTime9.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay15 = dateTime9.toTimeOfDay();
//        long long17 = iSOChronology7.set((org.joda.time.ReadablePartial) timeOfDay15, (long) (short) 1);
//        int[] intArray19 = iSOChronology3.get((org.joda.time.ReadablePartial) timeOfDay15, 0L);
//        org.joda.time.DurationField durationField20 = iSOChronology3.millis();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        boolean boolean23 = dateTime21.isEqual((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime.Property property24 = dateTime22.year();
//        org.joda.time.DateTime dateTime25 = property24.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, 100);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.plus(readableDuration29);
//        org.joda.time.DateTime.Property property31 = dateTime28.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime28.toTimeOfDay();
//        int[] intArray34 = iSOChronology3.get((org.joda.time.ReadablePartial) timeOfDay32, (long) 9);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) timeOfDay32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-9029597L) + "'", long17 == (-9029597L));
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int13 = offsetDateTimeField12.getMinimumValue();
        int int15 = offsetDateTimeField12.getLeapAmount(14365747759L);
        boolean boolean16 = offsetDateTimeField12.isSupported();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        boolean boolean19 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property20 = dateTime18.year();
        int int21 = property20.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "2019-06-16T06:29:00.645+09:00");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType22, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
//        boolean boolean5 = dateTime1.isEqual((long) 15);
//        org.joda.time.DateTime dateTime7 = dateTime1.minusMillis(0);
//        int int8 = dateTime1.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime9.withMillisOfDay(2019);
//        int int14 = dateTime9.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay15 = dateTime9.toTimeOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime1.withFields((org.joda.time.ReadablePartial) timeOfDay15);
//        int int17 = dateTime16.getYear();
//        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) dateTime16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((-292275054));
//        org.joda.time.DateTime dateTime13 = dateTime7.withMillis(0L);
//        org.joda.time.DateTime dateTime15 = dateTime7.withMillisOfSecond(100);
//        boolean boolean17 = dateTime7.isAfter((-1560634131145L));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        int int8 = dateTime1.getYearOfCentury();
//        org.joda.time.DateTime.Property property9 = dateTime1.year();
//        org.joda.time.DateTime dateTime11 = dateTime1.plusYears(9);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readableDuration9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        long long13 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate11, 32399999L);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology1.dayOfWeek();
//        try {
//            long long19 = iSOChronology1.getDateTimeMillis(23348976, (int) (byte) 0, 3, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560675599999L + "'", long13 == 1560675599999L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        long long11 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) (short) 1, 16, (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.secondOfMinute();
        try {
            long long20 = gregorianChronology0.getDateTimeMillis(0, 24, 9, 0, 15, 0, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61850303999900L) + "'", long11 == (-61850303999900L));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property3.withMinimumValue();
        org.joda.time.DateTime dateTime8 = property3.setCopy(20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, 167, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        boolean boolean16 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime14.withMillisOfDay(2019);
//        int int19 = dateTime14.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime14.toTimeOfDay();
//        long long22 = iSOChronology12.set((org.joda.time.ReadablePartial) timeOfDay20, (long) (short) 1);
//        int[] intArray24 = iSOChronology8.get((org.joda.time.ReadablePartial) timeOfDay20, 0L);
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology8.centuryOfEra();
//        try {
//            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((int) (byte) 1, (int) (byte) 10, (int) '4', 103, 16, (int) (byte) -1, (int) '#', (org.joda.time.Chronology) iSOChronology8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 103 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-9029203L) + "'", long22 == (-9029203L));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        long long5 = dateTime2.getMillis();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
//        int int4 = dateTime2.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.minus(readableDuration5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
//        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 0);
//        int int11 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str14 = dateTimeZone13.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone13);
//        org.joda.time.DurationField durationField17 = gregorianChronology0.weeks();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560643200000L + "'", long10 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+09:00" + "'", str14.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendPattern("+09:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder20.append(dateTimeParser25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder15.append(dateTimeParser25);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        org.joda.time.DateTime.Property property7 = dateTime5.minuteOfHour();
//        long long8 = dateTime5.getMillis();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560634171327L + "'", long8 == 1560634171327L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.lang.String str6 = dateTimeFormatter2.print((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19700101" + "'", str6.equals("19700101"));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusSeconds(0);
//        int int5 = dateTime4.getCenturyOfEra();
//        int int6 = dateTime4.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property3.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.DateMidnight dateMidnight5 = dateTime1.toDateMidnight();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusDays((int) (short) 1);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, 100);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfSecond(0);
        org.joda.time.DateTime dateTime13 = dateTime6.minusMinutes((int) ' ');
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str3 = dateTimeZone2.getID();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean14 = dateTime10.isEqual((long) 15);
//        org.joda.time.DateTime dateTime16 = dateTime10.minusMillis(0);
//        int int17 = dateTime10.getWeekOfWeekyear();
//        long long18 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime10.getZone();
//        long long21 = dateTimeZone2.getMillisKeepLocal(dateTimeZone19, (-1L));
//        int int23 = dateTimeZone2.getOffsetFromLocal((long) ' ');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str26 = cachedDateTimeZone24.getNameKey((-32400000L));
//        int int28 = cachedDateTimeZone24.getStandardOffset((long) 292278993);
//        int int30 = cachedDateTimeZone24.getOffset((-9045181L));
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = cachedDateTimeZone24.getName(0L, locale32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32400000 + "'", int23 == 32400000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 32400000 + "'", int28 == 32400000);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32400000 + "'", int30 == 32400000);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+09:00" + "'", str33.equals("+09:00"));
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long6 = dateTimeZone2.convertLocalToUTC(100L, false, (-5462266L));
        java.util.TimeZone timeZone7 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-32399900L) + "'", long6 == (-32399900L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        int int14 = offsetDateTimeField12.getMaximumValue(0L);
//        long long17 = offsetDateTimeField12.add((long) 4, 20);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField12.getAsShortText((long) (short) 1, locale19);
//        boolean boolean22 = offsetDateTimeField12.isLeap(32399999L);
//        int int24 = offsetDateTimeField12.getLeapAmount((long) 15);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 103 + "'", int14 == 103);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 631152000004L + "'", long17 == 631152000004L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "74" + "'", str20.equals("74"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime2.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime2.plusSeconds(23348976);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy(103);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str2 = dateTimeZone1.getID();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.halfdayOfDay();
        boolean boolean7 = iSOChronology3.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+09:00" + "'", str2.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(23347259);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfYear((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
        int int5 = dateTime0.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime0.era();
        org.joda.time.DateTime dateTime8 = property6.addWrapFieldToCopy(3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.dayOfYear();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readableDuration9);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        long long13 = iSOChronology1.set((org.joda.time.ReadablePartial) localDate11, 32399999L);
//        org.joda.time.DateTimeZone dateTimeZone14 = iSOChronology1.getZone();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560675599999L + "'", long13 == 1560675599999L);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 100, 4, (-16), (int) '4', chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -16 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((long) 0);
//        boolean boolean9 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime5.toYearMonthDay();
//        boolean boolean12 = dateTime5.isAfter(10L);
//        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
//        boolean boolean14 = property13.isLeap();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-16T06:29:01.138+09:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-16T06:29:01.138+09:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        java.util.Locale locale29 = null;
//        try {
//            long long30 = unsupportedDateTimeField24.set((long) 103, "2019", locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("hi!", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("Property[year]", (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-16T06:29:19.934+09:00", false);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-16));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int14 = offsetDateTimeField12.getLeapAmount((long) 59);
        long long17 = offsetDateTimeField12.add((-9035882L), 4038000);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 127426972166964118L + "'", long17 == 127426972166964118L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(29, 32400000, 389, 19, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32400000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMillisOfSecond((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendWeekOfWeekyear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        int int1 = dateTime0.getWeekyear();
        org.joda.time.DateTime dateTime3 = dateTime0.withDayOfWeek(6);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) 10);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMillis((int) 'a');
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withDurationAdded(readableDuration8, 20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withPeriodAdded(readablePeriod17, (-292275054));
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
//        org.joda.time.DateTime dateTime22 = dateTime19.plusMonths(16);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField4 = iSOChronology1.weekyears();
        long long8 = iSOChronology1.add((long) (short) 1, (long) 9, 6);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 55L + "'", long8 == 55L);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        boolean boolean27 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime.Property property28 = dateTime26.year();
//        org.joda.time.DateTime dateTime29 = property28.getDateTime();
//        org.joda.time.DateTime dateTime30 = property28.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime32 = dateTime30.plusMinutes((int) '#');
//        int int33 = dateTime30.getYearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str36 = dateTimeZone35.getID();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((java.lang.Object) dateTime30, dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = dateTime30.toLocalDate();
//        boolean boolean39 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate38);
//        java.util.Locale locale41 = null;
//        try {
//            java.lang.String str42 = unsupportedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDate38, 2000, locale41);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+09:00" + "'", str36.equals("+09:00"));
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        java.lang.String str7 = property3.getAsString();
        org.joda.time.DateTime dateTime8 = property3.roundFloorCopy();
        java.util.Locale locale9 = null;
        int int10 = property3.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getWeekyear();
//        org.joda.time.DateTime dateTime3 = dateTime0.withDayOfWeek(6);
//        int int4 = dateTime3.getDayOfMonth();
//        int int5 = dateTime3.getWeekyear();
//        org.joda.time.DateTime.Property property6 = dateTime3.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        int int4 = property3.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType5, "2019-06-16T06:29:00.645+09:00");
//        java.lang.String str8 = illegalFieldValueException7.toString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException7.getDateTimeFieldType();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, (-292275054), (int) (short) 1, 2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for year must be in the range [1,2000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"2019-06-16T06:29:00.645+09:00\" for year is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"2019-06-16T06:29:00.645+09:00\" for year is not supported"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(16L, (long) (-292275054));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4676400864L) + "'", long2 == (-4676400864L));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        long long16 = dateTimeZone12.convertLocalToUTC(100L, false, (-5462266L));
//        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
//        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime9.plus(readableDuration19);
//        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-32399900L) + "'", long16 == (-32399900L));
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getDurationField();
//        long long28 = unsupportedDateTimeField24.add((-5462266L), 100);
//        boolean boolean29 = unsupportedDateTimeField24.isSupported();
//        try {
//            long long31 = unsupportedDateTimeField24.roundFloor((-5462785L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3155840937734L + "'", long28 == 3155840937734L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.era();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(1);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        boolean boolean4 = dateTime0.isEqual((long) 15);
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
        try {
            java.lang.String str8 = dateTime0.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
//        int int5 = dateTime0.getCenturyOfEra();
//        java.lang.String str6 = dateTime0.toString();
//        org.joda.time.DateTime dateTime8 = dateTime0.minusMonths((int) (byte) -1);
//        org.joda.time.DateTime dateTime11 = dateTime0.withDurationAdded(0L, 99);
//        org.joda.time.DateTime dateTime13 = dateTime0.withWeekyear(0);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-16T06:29:35.045+09:00" + "'", str6.equals("2019-06-16T06:29:35.045+09:00"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-18934160399990L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
//        boolean boolean29 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime28);
//        int int30 = dateTime28.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime28.minus(readableDuration31);
//        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
//        org.joda.time.LocalDate localDate34 = dateTime32.toLocalDate();
//        java.util.Locale locale36 = null;
//        try {
//            java.lang.String str37 = unsupportedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) localDate34, 292278993, locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate34);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        boolean boolean27 = unsupportedDateTimeField24.isSupported();
//        java.util.Locale locale29 = null;
//        try {
//            java.lang.String str30 = unsupportedDateTimeField24.getAsText((-9061010), locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime2);
//        int int4 = dateTime2.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime2.minus(readableDuration5);
//        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
//        org.joda.time.LocalDate localDate8 = dateTime6.toLocalDate();
//        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) (byte) 0);
//        int int11 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean14 = gregorianChronology0.equals((java.lang.Object) "hi!");
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560643200000L + "'", long10 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        long long10 = dateTimeZone2.getMillisKeepLocal(dateTimeZone6, (long) 16);
        java.lang.String str12 = dateTimeZone2.getShortName(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+09:00" + "'", str7.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 16L + "'", long10 == 16L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+09:00" + "'", str12.equals("+09:00"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfDay(100);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        boolean boolean18 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property19 = dateTime17.year();
//        int int20 = property19.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType21, 4, 24, 23347259);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        boolean boolean28 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime.Property property29 = dateTime27.year();
//        int int30 = property29.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8, dateTimeFieldType21, dateTimeFieldType31 };
//        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList33 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
//        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, dateTimeFieldTypeArray32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, false, false);
//        try {
//            org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList33, false, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int13 = offsetDateTimeField12.getMinimumValue();
        int int14 = offsetDateTimeField12.getMinimumValue();
        long long16 = offsetDateTimeField12.roundFloor((-1008601597854082L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1008623350800000L) + "'", long16 == (-1008623350800000L));
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        java.lang.String str14 = offsetDateTimeField12.getAsText((-1L));
//        long long17 = offsetDateTimeField12.add(16L, (long) 23348976);
//        boolean boolean19 = offsetDateTimeField12.isLeap((long) 292278993);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField12.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        boolean boolean25 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime24);
//        int int26 = dateTime24.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime24.minus(readableDuration27);
//        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        long long32 = gregorianChronology22.set((org.joda.time.ReadablePartial) localDate30, (long) (byte) 0);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate30, 6, locale34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField12.getAsText((long) (byte) 100, locale37);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "74" + "'", str14.equals("74"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 736822514908800016L + "'", long17 == 736822514908800016L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560643200000L + "'", long32 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "6" + "'", str35.equals("6"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "74" + "'", str38.equals("74"));
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '#');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendFractionOfSecond((int) (short) 0, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        try {
//            java.lang.String str26 = unsupportedDateTimeField24.getAsShortText((long) 29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = dateTime4.minusMinutes((int) ' ');
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime4.toMutableDateTime();
//        org.joda.time.TimeOfDay timeOfDay13 = dateTime4.toTimeOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(timeOfDay13);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime5.getZone();
//        java.lang.String str15 = dateTimeZone14.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        long long18 = dateTimeZone14.convertUTCToLocal((-9061010L));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+09:00" + "'", str15.equals("+09:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 23338990L + "'", long18 == 23338990L);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        int int6 = dateTime5.getMonthOfYear();
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfWeek((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime2 = dateTime0.toMutableDateTime();
//        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
//        java.lang.String str4 = dateTime0.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-16T06:29:36.867+09:00" + "'", str4.equals("2019-06-16T06:29:36.867+09:00"));
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTimeISO();
        int int6 = dateTime3.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970001T090000+0900" + "'", str4.equals("1970001T090000+0900"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32400000 + "'", int6 == 32400000);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(19, 29, (int) (byte) 1, (int) (byte) 100, 16, 19, 20, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean9 = dateTime5.isEqual((long) 15);
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(0);
//        int int12 = dateTime5.getWeekOfWeekyear();
//        long long13 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property4.getFieldType();
//        java.lang.String str15 = property4.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[minuteOfHour]" + "'", str15.equals("Property[minuteOfHour]"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime4 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateMidnight dateMidnight5 = dateTime1.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime(dateTimeZone3);
        boolean boolean5 = dateTime2.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder10.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder16.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder37.append(dateTimeParser42);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray44 = new org.joda.time.format.DateTimeParser[] { dateTimeParser26, dateTimeParser30, dateTimeParser32, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.append(dateTimePrinter11, dateTimeParserArray44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder1.appendTwoDigitYear(167);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeParserArray44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "2019-06-16T06:29:01.138+09:00", 32400000, 0);
        java.lang.String str6 = fixedDateTimeZone4.getName((-32399999L));
        int int8 = fixedDateTimeZone4.getOffset((-32400000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+09:00" + "'", str6.equals("+09:00"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32400000 + "'", int8 == 32400000);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = property3.addToCopy((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        boolean boolean13 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withMillisOfDay(2019);
//        int int16 = dateTime11.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay17 = dateTime11.toTimeOfDay();
//        long long19 = iSOChronology9.set((org.joda.time.ReadablePartial) timeOfDay17, (long) (short) 1);
//        org.joda.time.DurationField durationField20 = iSOChronology9.weekyears();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology9.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology9.minuteOfDay();
//        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) -1, (java.lang.Object) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology9.era();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9022508L) + "'", long19 == (-9022508L));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        boolean boolean27 = unsupportedDateTimeField24.isSupported();
//        try {
//            boolean boolean29 = unsupportedDateTimeField24.isLeap(16L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        boolean boolean27 = unsupportedDateTimeField24.isSupported();
//        try {
//            int int29 = unsupportedDateTimeField24.getMaximumValue(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((long) 0);
//        boolean boolean9 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime5.toYearMonthDay();
//        boolean boolean12 = dateTime5.isAfter(10L);
//        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
//        java.util.Locale locale14 = null;
//        int int15 = property13.getMaximumShortTextLength(locale14);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(8076);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        boolean boolean6 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType9, 4, 24, 23347259);
//        int int14 = offsetDateTimeField13.getMinimumValue();
//        int int16 = offsetDateTimeField13.getLeapAmount(14365747759L);
//        long long19 = offsetDateTimeField13.addWrapField((-9054395L), 100);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        boolean boolean22 = dateTime20.isEqual((org.joda.time.ReadableInstant) dateTime21);
//        int int23 = dateTime21.getDayOfMonth();
//        org.joda.time.DateTime.Property property24 = dateTime21.minuteOfHour();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        boolean boolean27 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime.Property property28 = dateTime26.year();
//        int int29 = property28.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "2019-06-16T06:29:00.645+09:00");
//        org.joda.time.DateTime dateTime34 = dateTime21.withField(dateTimeFieldType30, 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType30, (int) (byte) -1);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 631142945605L + "'", long19 == 631142945605L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("hi!", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("Property[year]", (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-16T06:29:19.934+09:00", false);
        java.io.DataOutput dataOutput11 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Property[year]", dataOutput11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 20);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getDurationField();
//        long long28 = unsupportedDateTimeField24.add((-5462266L), 100);
//        boolean boolean29 = unsupportedDateTimeField24.isSupported();
//        try {
//            int int31 = unsupportedDateTimeField24.get((-26L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3155840937734L + "'", long28 == 3155840937734L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019-06-16T06:29:16.612+09:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-16T06:29:16.612+09:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        int int6 = property3.getLeapAmount();
        org.joda.time.DateTime dateTime7 = property3.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDate(389, (-1), 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withHourOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatterBuilder10.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder12.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendFractionOfMinute(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder16.append(dateTimeParser26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder33.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder37.append(dateTimeParser42);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray44 = new org.joda.time.format.DateTimeParser[] { dateTimeParser26, dateTimeParser30, dateTimeParser32, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder1.append(dateTimePrinter11, dateTimeParserArray44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder1.appendSecondOfMinute(8076);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder47.appendTimeZoneOffset("2019-06-16T06:29:35.045+09:00", false, 19, 59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeParserArray44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter5);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYearOfEra((int) '4', 32400000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.yearOfCentury();
        org.joda.time.DurationField durationField10 = iSOChronology7.weekyears();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(20, (int) (short) 100, (-292275054), 10, 10, (-16), (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -16 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        int int6 = property3.getLeapAmount();
//        java.lang.String str7 = property3.toString();
//        org.joda.time.DateTime dateTime8 = property3.roundHalfFloorCopy();
//        int int9 = property3.getLeapAmount();
//        java.lang.String str10 = property3.getAsShortText();
//        org.joda.time.DateTime dateTime11 = property3.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[year]" + "'", str7.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes((-292275054));
        org.joda.time.DateTime dateTime13 = dateTime7.withMillis(0L);
        org.joda.time.DateTime dateTime15 = dateTime7.withMillisOfSecond(100);
        java.util.Locale locale16 = null;
        java.util.Calendar calendar17 = dateTime15.toCalendar(locale16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.withDurationAdded(readableDuration18, 3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(calendar17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 100);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        long long16 = dateTimeZone12.convertLocalToUTC(100L, false, (-5462266L));
//        java.util.TimeZone timeZone17 = dateTimeZone12.toTimeZone();
//        org.joda.time.DateTime dateTime18 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime9.toMutableDateTime();
//        int int20 = mutableDateTime19.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-32399900L) + "'", long16 == (-32399900L));
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '#');
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withYearOfCentury(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        int int13 = offsetDateTimeField12.getMinimumValue();
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField12.set(32400010L, "", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 100, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(10, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
        int int8 = dateTime5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone10.getName((-1008591728400000L), locale15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+09:00" + "'", str16.equals("+09:00"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str3 = dateTimeZone2.getID();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone2);
        long long8 = dateTimeZone2.adjustOffset((long) (short) 100, false);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("hi!", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("Property[year]", (int) (byte) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder6.addRecurringSavings("1", 23348976, 24, 8076, ' ', 1, 32400000, 389, false, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter5);
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYearOfEra((int) '4', 32400000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMillisOfSecond(0);
        boolean boolean14 = dateTimeFormatterBuilder10.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        boolean boolean27 = unsupportedDateTimeField24.isSupported();
//        try {
//            int int29 = unsupportedDateTimeField24.getMinimumValue((-9054082L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-16T06:29:30.885+09:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-16T06:29:30.885+09:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str10 = dateTimeZone9.getID();
        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology(chronology11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 1, 59, 23348976, 167, (int) (byte) -1, 4038000, 1, chronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 167 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+09:00" + "'", str10.equals("+09:00"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        org.joda.time.Chronology chronology8 = iSOChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(19, 15, 292278993, 2019, 99, chronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        int int14 = offsetDateTimeField12.getLeapAmount((long) 59);
//        long long16 = offsetDateTimeField12.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField17 = offsetDateTimeField12.getRangeDurationField();
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        boolean boolean28 = dateTime26.isEqual((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime30 = dateTime26.withMillisOfDay(2019);
//        int int31 = dateTime26.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime26.toTimeOfDay();
//        long long34 = iSOChronology24.set((org.joda.time.ReadablePartial) timeOfDay32, (long) (short) 1);
//        int[] intArray36 = iSOChronology20.get((org.joda.time.ReadablePartial) timeOfDay32, 0L);
//        int int37 = offsetDateTimeField12.getMaximumValue(readablePartial18, intArray36);
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
//        boolean boolean40 = dateTime38.isEqual((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime dateTime42 = dateTime38.withMillisOfDay(2019);
//        int int43 = dateTime38.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay44 = dateTime38.toTimeOfDay();
//        java.util.Locale locale45 = null;
//        try {
//            java.lang.String str46 = offsetDateTimeField12.getAsText((org.joda.time.ReadablePartial) timeOfDay44, locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-32400000L) + "'", long16 == (-32400000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-9019787L) + "'", long34 == (-9019787L));
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 103 + "'", int37 == 103);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 20 + "'", int43 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay44);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+09:00");
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        boolean boolean4 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        java.util.Locale locale7 = null;
        int int8 = property5.getMaximumShortTextLength(locale7);
        java.lang.String str9 = property5.getAsString();
        org.joda.time.DateTime dateTime10 = property5.getDateTime();
        org.joda.time.DateTime dateTime11 = property5.getDateTime();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime11);
        java.lang.Class<?> wildcardClass13 = dateTime11.getClass();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfMonth();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-18934160399990L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology6 = iSOChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        long long12 = dateTimeZone8.convertUTCToLocal((long) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, dateTimeZone8);
        try {
            long long21 = zonedChronology13.getDateTimeMillis(99, (int) ' ', 8076, (int) 'a', 6, 101, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+09:00" + "'", str9.equals("+09:00"));
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32400010L + "'", long12 == 32400010L);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        int int7 = property6.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
        java.lang.String str14 = offsetDateTimeField12.getAsText((-1L));
        boolean boolean15 = offsetDateTimeField12.isLenient();
        org.joda.time.DurationField durationField16 = offsetDateTimeField12.getDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "74" + "'", str14.equals("74"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) ' ', (int) 'a', 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hi! must be in the range [97,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField24.getLeapDurationField();
//        try {
//            long long29 = unsupportedDateTimeField24.add((long) 2019, (-18934127999990L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -18934127999990");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNull(durationField26);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        boolean boolean4 = dateTime0.isEqual((long) 15);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(0);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        boolean boolean10 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfDay(2019);
//        int int13 = dateTime8.getCenturyOfEra();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        org.joda.time.DateTime.Property property16 = dateTime15.centuryOfEra();
//        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DurationField durationField23 = iSOChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField23);
//        org.joda.time.DurationField durationField25 = unsupportedDateTimeField24.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = unsupportedDateTimeField24.getType();
//        boolean boolean27 = unsupportedDateTimeField24.isSupported();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        boolean boolean30 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime.Property property31 = dateTime29.year();
//        int int32 = property31.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField35 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField24, dateTimeFieldType33, 23348976);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 20 + "'", int13 == 20);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((long) 0);
//        boolean boolean9 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime6.withEra(23347259);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 23347259 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime0.withMillisOfDay(2019);
//        int int5 = dateTime0.getCenturyOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime0, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime0.millisOfDay();
//        int int9 = dateTime0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone1);
        int int3 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime dateTime5 = dateTime2.minus((long) 167);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 15);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        boolean boolean18 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property19 = dateTime17.year();
//        int int20 = property19.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType21, 4, 24, 23347259);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField25.getType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType26, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        int int8 = dateTime1.getYearOfCentury();
//        org.joda.time.DateTime.Property property9 = dateTime1.year();
//        boolean boolean11 = dateTime1.isEqual((-9031032L));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (int) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        boolean boolean5 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        int int7 = property6.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType8, 4, 24, 23347259);
//        java.lang.String str14 = offsetDateTimeField12.getAsText((-1L));
//        long long17 = offsetDateTimeField12.add(16L, (long) 23348976);
//        boolean boolean19 = offsetDateTimeField12.isLeap((long) 292278993);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField12.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        boolean boolean25 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime24);
//        int int26 = dateTime24.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime24.minus(readableDuration27);
//        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
//        org.joda.time.LocalDate localDate30 = dateTime28.toLocalDate();
//        long long32 = gregorianChronology22.set((org.joda.time.ReadablePartial) localDate30, (long) (byte) 0);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDate30, 6, locale34);
//        int int36 = offsetDateTimeField12.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "74" + "'", str14.equals("74"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 736822514908800016L + "'", long17 == 736822514908800016L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560643200000L + "'", long32 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "6" + "'", str35.equals("6"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone1);
        int int3 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime dateTime4 = dateTime2.withEarlierOffsetAtOverlap();
        java.util.Date date5 = dateTime4.toDate();
        int int6 = dateTime4.getWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusHours(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes((int) '#');
        int int8 = dateTime5.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours(9);
        java.lang.String str11 = dateTimeZone10.getID();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTime5, dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int15 = cachedDateTimeZone13.getOffset(1560643200000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+09:00" + "'", str11.equals("+09:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 32400000 + "'", int15 == 32400000);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("+09:00");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("+09:00");
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        int int9 = property8.get();
        jodaTimePermission4.checkGuard((java.lang.Object) property8);
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        int int1 = dateTimeFormatter0.getDefaultYear();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        boolean boolean6 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime5);
//        int int7 = dateTime5.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime5.minus(readableDuration8);
//        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
//        org.joda.time.LocalDate localDate11 = dateTime9.toLocalDate();
//        long long13 = gregorianChronology3.set((org.joda.time.ReadablePartial) localDate11, (long) (byte) 0);
//        try {
//            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560643200000L + "'", long13 == 1560643200000L);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '#', (-9054395L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-316903825) + "'", int2 == (-316903825));
    }
}

