import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test1() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test1");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
//        int int8 = dateTime1.getYearOfCentury();
//        int int9 = dateTime1.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 167 + "'", int9 == 167);
//    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test2");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("hi!", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test3() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test3");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = dateTime0.isEqual((org.joda.time.ReadableInstant) dateTime1);
//        int int3 = dateTime1.getDayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean8 = dateTime6.isEqual((long) 0);
//        boolean boolean9 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime6.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime12 = dateTime6.withHourOfDay((int) (short) 1);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test4");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        boolean boolean2 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute(20, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.weekyearOfCentury();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        boolean boolean16 = dateTime14.isEqual((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        int int18 = property17.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType19, 4, 24, 23347259);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendFraction(dateTimeFieldType19, 99, (int) (short) 1);
        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatterBuilder26.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendCenturyOfEra(2019, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendFractionOfHour((int) (byte) 100, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder32.append(dateTimeParser37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter27, dateTimeParser37);
        try {
            org.joda.time.DateTime dateTime41 = dateTimeFormatter39.parseDateTime("12");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimePrinter27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

//    @Test
//    public void test5() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test5");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str3 = dateTimeZone2.getID();
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
//        boolean boolean7 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int8 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        boolean boolean12 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean14 = dateTime10.isEqual((long) 15);
//        org.joda.time.DateTime dateTime16 = dateTime10.minusMillis(0);
//        int int17 = dateTime10.getWeekOfWeekyear();
//        long long18 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime10.getZone();
//        long long21 = dateTimeZone2.getMillisKeepLocal(dateTimeZone19, (-1L));
//        int int23 = dateTimeZone2.getOffsetFromLocal((long) ' ');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str26 = cachedDateTimeZone24.getNameKey((-32400000L));
//        int int28 = cachedDateTimeZone24.getStandardOffset((long) 292278993);
//        int int30 = cachedDateTimeZone24.getOffset((-9045181L));
//        int int32 = cachedDateTimeZone24.getStandardOffset(0L);
//        java.lang.String str33 = cachedDateTimeZone24.toString();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        long long40 = dateTimeZone36.convertLocalToUTC(100L, false, (-5462266L));
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone36.getName((long) 0, locale42);
//        long long45 = cachedDateTimeZone24.getMillisKeepLocal(dateTimeZone36, 23389960L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHours(9);
//        java.lang.String str49 = dateTimeZone48.getID();
//        org.joda.time.Chronology chronology50 = gregorianChronology46.withZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        boolean boolean53 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime52);
//        int int54 = dateTime52.getDayOfMonth();
//        org.joda.time.DateTime.Property property55 = dateTime52.minuteOfHour();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now();
//        boolean boolean58 = dateTime56.isEqual((org.joda.time.ReadableInstant) dateTime57);
//        boolean boolean60 = dateTime56.isEqual((long) 15);
//        org.joda.time.DateTime dateTime62 = dateTime56.minusMillis(0);
//        int int63 = dateTime56.getWeekOfWeekyear();
//        long long64 = property55.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime56);
//        org.joda.time.DateTimeZone dateTimeZone65 = dateTime56.getZone();
//        long long67 = dateTimeZone48.getMillisKeepLocal(dateTimeZone65, (-1L));
//        int int69 = dateTimeZone48.getOffsetFromLocal((long) ' ');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone70 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone48);
//        java.lang.String str72 = cachedDateTimeZone70.getNameKey((-32400000L));
//        int int74 = cachedDateTimeZone70.getStandardOffset((long) 292278993);
//        java.lang.String str75 = cachedDateTimeZone70.getID();
//        org.joda.time.DateTimeZone dateTimeZone77 = null;
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone77);
//        int int79 = dateTime78.getMonthOfYear();
//        org.joda.time.DateTime dateTime80 = dateTime78.withEarlierOffsetAtOverlap();
//        int int81 = cachedDateTimeZone70.getOffset((org.joda.time.ReadableInstant) dateTime80);
//        long long83 = cachedDateTimeZone24.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone70, 1560634171327L);
//        int int85 = cachedDateTimeZone24.getOffset(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+09:00" + "'", str3.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32400000 + "'", int23 == 32400000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 32400000 + "'", int28 == 32400000);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32400000 + "'", int30 == 32400000);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 32400000 + "'", int32 == 32400000);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+09:00" + "'", str33.equals("+09:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-32399900L) + "'", long40 == (-32399900L));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+09:00" + "'", str43.equals("+09:00"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 23389960L + "'", long45 == 23389960L);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+09:00" + "'", str49.equals("+09:00"));
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 16 + "'", int54 == 16);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 24 + "'", int63 == 24);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-1L) + "'", long67 == (-1L));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 32400000 + "'", int69 == 32400000);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone70);
//        org.junit.Assert.assertNull(str72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 32400000 + "'", int74 == 32400000);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "+09:00" + "'", str75.equals("+09:00"));
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 32400000 + "'", int81 == 32400000);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560634171327L + "'", long83 == 1560634171327L);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 32400000 + "'", int85 == 32400000);
//    }
//}

