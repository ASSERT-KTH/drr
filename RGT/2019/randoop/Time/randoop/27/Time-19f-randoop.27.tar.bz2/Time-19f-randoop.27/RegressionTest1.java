import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour((int) '#');
//        int int15 = dateTime11.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        int int11 = dateTime4.getMinuteOfHour();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.dayOfYear();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology19);
//        org.joda.time.DateTimeField dateTimeField23 = zonedChronology19.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, readableInstant26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 0, chronology27);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property32 = dateTime28.dayOfWeek();
//        org.joda.time.DateTime dateTime33 = property32.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField23, dateTimeFieldType34, 15);
//        int int37 = dateTime4.get(dateTimeFieldType34);
//        org.joda.time.DurationField durationField38 = null;
//        try {
//            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType34, durationField38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMinutes(360000000);
        org.joda.time.DateTime dateTime13 = dateTime4.withWeekOfWeekyear((int) ' ');
        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime4.toTimeOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(timeOfDay15);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        boolean boolean14 = dateTime11.isEqual((long) 365);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        java.lang.String str10 = dateTimeZone9.getID();
        org.joda.time.Chronology chronology11 = iSOChronology5.withZone(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 95, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = iSOChronology5.get(readablePeriod13, 360000376L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:35" + "'", str10.equals("+00:35"));
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 14400);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, 0L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        boolean boolean9 = dateTime7.isAfter(0L);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime7.toString("ISOChronology[-00:00:00.001]", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        int int8 = dateTime4.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        boolean boolean17 = dateTime15.isAfter((long) 'a');
//        int int18 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property19 = dateTime15.yearOfEra();
//        org.joda.time.DateTime dateTime20 = property19.getDateTime();
//        org.joda.time.DateTime dateTime22 = dateTime20.plusMillis((int) (short) 100);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
//        int int10 = dateTime7.getYear();
//        int int11 = dateTime7.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) 3168);
        java.lang.String str10 = cachedDateTimeZone4.getNameKey(3169L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = cachedDateTimeZone4.getShortName((long) (-14400001), locale12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-2001));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        try {
            long long31 = remainderDateTimeField28.set(0L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [0,14]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 4);
        java.lang.String str7 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
//        int int9 = property7.getMinimumValue();
//        java.lang.String str10 = property7.getAsString();
//        org.joda.time.DateTime dateTime11 = property7.roundHalfFloorCopy();
//        long long12 = property7.remainder();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 14400000L + "'", long12 == 14400000L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) 1, (int) ' ', 70, (-2001), 91, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime21 = property10.addToCopy(1969);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException13.getDateTimeFieldType();
        illegalFieldValueException10.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.Number number16 = illegalFieldValueException10.getLowerBound();
        java.lang.String str17 = illegalFieldValueException10.toString();
        illegalFieldValueException5.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.String str19 = illegalFieldValueException10.toString();
        java.lang.Number number20 = illegalFieldValueException10.getIllegalNumberValue();
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType14);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str19.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(8, 7, 16, (int) (short) 0, 100, 32, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone10);
        try {
            long long19 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, 109, (int) (byte) 100, (int) (byte) 10, (-70), 109, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven((long) 2000);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int33 = remainderDateTimeField28.get((long) 0);
        int int34 = remainderDateTimeField28.getMinimumValue();
        int int35 = remainderDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-1));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 99);
        int int13 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 32 + "'", int13 == 32);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfHalfday();
        java.lang.String str12 = zonedChronology7.toString();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology7.yearOfCentury();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.dayOfYear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology9.weekyear();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 0, chronology17);
        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property22 = dateTime18.dayOfWeek();
        org.joda.time.DateTime dateTime23 = property22.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType24, (int) (byte) -1, 91, 0);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField28.getMaximumShortTextLength(locale29);
        java.lang.String str32 = offsetDateTimeField28.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 0, chronology36);
        org.joda.time.DateTime dateTime39 = dateTime37.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime41 = dateTime39.plusWeeks(0);
        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime45 = dateTime44.toLocalTime();
        int[] intArray48 = new int[] { 14400, (byte) 1 };
        int int49 = offsetDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localTime45, intArray48);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localTime45);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 91 + "'", int49 == 91);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        int int68 = offsetDateTimeField26.getMaximumValue();
        org.joda.time.DurationField durationField69 = offsetDateTimeField26.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(durationField69);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        int int11 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property12 = dateTime4.minuteOfHour();
//        int int13 = dateTime4.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(19, ' ', 15, 8, 14400, false, (int) 'a');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder11.addCutover(360000000, 'a', 70, (int) (short) 100, 0, false, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 91, dateTimeZone1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DurationField durationField11 = zonedChronology7.halfdays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime4.plus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime4.plusMinutes(0);
        int int17 = dateTime4.getMinuteOfHour();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        long long30 = dividedDateTimeField24.getDifferenceAsLong(240L, 1L);
        long long33 = dividedDateTimeField24.set((long) 5, 5);
        long long36 = dividedDateTimeField24.add(31449600000L, 63000000L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-9899995L) + "'", long33 == (-9899995L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 56731449600000L + "'", long36 == 56731449600000L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        int int30 = dividedDateTimeField24.getDifference((long) 7, (long) 8);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfMonth(1);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime19.toYearMonthDay();
        boolean boolean21 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int7 = dateTimeZone5.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj3, dateTimeZone5);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks(0);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(99);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withDayOfWeek((-2001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2001 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 360000000 + "'", int7 == 360000000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        int int10 = property8.getLeapAmount();
//        org.joda.time.DateTime dateTime11 = property8.roundFloorCopy();
//        java.lang.String str12 = dateTime11.toString();
//        boolean boolean14 = dateTime11.isAfter((long) 99);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T00:00:00.000+100:00" + "'", str12.equals("1970-01-05T00:00:00.000+100:00"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
//        int int10 = dateTime9.getDayOfMonth();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        org.joda.time.DateTime.Property property14 = dateTime12.dayOfYear();
//        org.joda.time.DateTime dateTime16 = property14.addToCopy(399L);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone4.isLocalDateTimeGap(localDateTime5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str9 = dateTimeZone4.getShortName(96L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 14400000, dateTimeZone4);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) timeOfDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeOfDay11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        int int9 = property8.getMaximumValue();
        boolean boolean10 = property8.isLeap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        java.util.Locale locale28 = null;
        int int29 = dividedDateTimeField24.getMaximumShortTextLength(locale28);
        int int30 = dividedDateTimeField24.getMaximumValue();
        boolean boolean31 = dividedDateTimeField24.isSupported();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 95 + "'", int30 == 95);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology0.add(readablePeriod7, (long) (short) 0, (int) (byte) 1);
        try {
            long long15 = gregorianChronology0.getDateTimeMillis(0, 1969, 3168, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        long long64 = offsetDateTimeField26.roundHalfFloor(98L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-619200000L) + "'", long64 == (-619200000L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[dayOfWeek]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (-3092342396832L), 91);
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 0, chronology9);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime15.minusDays((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone18);
        try {
            long long24 = gregorianChronology0.getDateTimeMillis(1969, 4, 2019, 14400);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3092342396832L) + "'", long4 == (-3092342396832L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int5 = dateTimeZone3.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj1, dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        int int8 = dateTime7.getSecondOfMinute();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime7.toCalendar(locale9);
        int int11 = dateTime7.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 360000000 + "'", int5 == 360000000);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven((long) 2000);
        java.util.Locale locale32 = null;
        java.lang.String str33 = remainderDateTimeField28.getAsShortText(0, locale32);
        long long35 = remainderDateTimeField28.remainder((long) 12);
        java.util.Locale locale36 = null;
        int int37 = remainderDateTimeField28.getMaximumTextLength(locale36);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "0" + "'", str33.equals("0"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 12L + "'", long35 == 12L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
//        int int9 = dateTime8.getYear();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
//        boolean boolean13 = dateTime11.isBefore((long) 5);
//        org.joda.time.DateTime dateTime15 = dateTime11.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime.Property property16 = dateTime11.secondOfDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMinutes(360000000);
        org.joda.time.DateTime dateTime13 = dateTime4.withWeekOfWeekyear((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        java.util.Date date15 = dateTime13.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), 12L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-12L) + "'", long2 == (-12L));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.DurationField durationField46 = offsetDateTimeField26.getDurationField();
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField26.getAsText((long) 32, locale48);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long16 = fixedDateTimeZone14.nextTransition((long) (short) 1);
        int int18 = fixedDateTimeZone14.getOffset((long) 15);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 0, chronology22);
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property27 = dateTime23.dayOfWeek();
        java.util.Date date28 = dateTime23.toDate();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        int int30 = dateTime23.getMinuteOfHour();
        org.joda.time.LocalDateTime localDateTime31 = dateTime23.toLocalDateTime();
        boolean boolean32 = fixedDateTimeZone14.isLocalDateTimeGap(localDateTime31);
        boolean boolean33 = cachedDateTimeZone6.isLocalDateTimeGap(localDateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
//        org.joda.time.DateTime.Property property13 = dateTime4.minuteOfHour();
//        org.joda.time.DateTime dateTime15 = dateTime4.minusMinutes(2);
//        int int16 = dateTime15.getDayOfWeek();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DurationField durationField11 = property8.getDurationField();
        int int12 = property8.getMaximumValueOverall();
        int int13 = property8.getMinimumValue();
        org.joda.time.DurationField durationField14 = property8.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 14400, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.secondOfDay();
        int int22 = dateTime11.get(dateTimeField21);
        java.lang.Class<?> wildcardClass23 = dateTimeField21.getClass();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14400 + "'", int22 == 14400);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
//        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
//        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
//        long long30 = dividedDateTimeField24.getDifferenceAsLong(240L, 1L);
//        long long33 = dividedDateTimeField24.set((long) 5, 5);
//        org.joda.time.ReadableInstant readableInstant35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant35, readableInstant36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 0, chronology37);
//        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property42 = dateTime41.monthOfYear();
//        org.joda.time.DateTime.Property property43 = dateTime41.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant45 = null;
//        org.joda.time.ReadableInstant readableInstant46 = null;
//        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
//        org.joda.time.DateTime dateTime51 = dateTime48.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property52 = dateTime48.dayOfWeek();
//        org.joda.time.DateTime dateTime53 = property52.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property52.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
//        int int59 = dateTime41.get(dateTimeFieldType54);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField60 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24, dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-9899995L) + "'", long33 == (-9899995L));
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(31435200000L, 399L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31435200399L + "'", long2 == 31435200399L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.lang.String str9 = property8.getAsText();
//        int int10 = property8.getMaximumValue();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Monday" + "'", str9.equals("Monday"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 0, chronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.dayOfYear();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology10.weekyear();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property23 = dateTime19.dayOfWeek();
        org.joda.time.DateTime dateTime24 = property23.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType25, (int) (byte) -1, 91, 0);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField29.getMaximumShortTextLength(locale30);
        java.lang.String str33 = offsetDateTimeField29.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant35, readableInstant36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 0, chronology37);
        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property42 = dateTime38.dayOfWeek();
        java.util.Date date43 = dateTime38.toDate();
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime46 = dateTime38.withDurationAdded(readableDuration44, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay47 = dateTime38.toTimeOfDay();
        int int48 = offsetDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay47);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant50, readableInstant51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 0, chronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime57 = dateTime55.plusWeeks(0);
        org.joda.time.DateTime dateTime60 = dateTime57.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime61 = dateTime60.toLocalTime();
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localTime61, 32, locale63);
        boolean boolean65 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField29);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant67, readableInstant68);
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) 0, chronology69);
        org.joda.time.YearMonthDay yearMonthDay71 = dateTime70.toYearMonthDay();
        java.util.Locale locale72 = null;
        try {
            java.lang.String str73 = offsetDateTimeField29.getAsText((org.joda.time.ReadablePartial) yearMonthDay71, locale72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(timeOfDay47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 91 + "'", int48 == 91);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(localTime61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "32" + "'", str64.equals("32"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertNotNull(yearMonthDay71);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[ISOChronology[UTC], +100:00]", 5);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder0.addRecurringSavings("(\"org.joda.time.JodaTimePermission\" \"Mon\")", (int) (short) 10, (int) (byte) 1, (int) (byte) 100, '#', (int) (byte) 10, 32, (-91), true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (-3092342396832L), 91);
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(91, 0, (int) (short) 0, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3092342396832L) + "'", long4 == (-3092342396832L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withEra(7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey(0L);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10, (-14400001), 376, 1969, (int) (byte) 1, (org.joda.time.DateTimeZone) cachedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNull(str11);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
//        int int11 = dateTime9.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long9 = gregorianChronology1.getDateTimeMillis((int) (byte) -1, 19, 91, 1, 52, 1970, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology7.getZone();
        long long16 = zonedChronology7.add((-58665599891L), (long) 4, 1970);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone18.isLocalDateTimeGap(localDateTime19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfWeek();
        boolean boolean23 = zonedChronology7.equals((java.lang.Object) iSOChronology21);
        java.lang.String str24 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58665592011L) + "'", long16 == (-58665592011L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str24.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition(0L);
        int int8 = fixedDateTimeZone4.getStandardOffset(240L);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (-2001));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -2001");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        int int12 = dateTime10.getYear();
//        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (short) 100);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime10.plus(readablePeriod15);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfYear();
        boolean boolean16 = property15.isLeap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = property10.withMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("1970-01-05T04:00:00+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-05T04:00:00+100:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        long long72 = offsetDateTimeField26.roundFloor(0L);
        org.joda.time.DurationField durationField73 = offsetDateTimeField26.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-619200000L) + "'", long72 == (-619200000L));
        org.junit.Assert.assertNotNull(durationField73);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) 16, true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-359999984L) + "'", long10 == (-359999984L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-1));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DurationField durationField8 = zonedChronology7.hours();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "����-��" + "'", str7.equals("����-��"));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property10.getAsShortText(locale20);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = property10.getAsText(locale22);
//        java.lang.String str24 = property10.getAsShortText();
//        long long25 = property10.remainder();
//        int int26 = property10.getMinimumValue();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "5" + "'", str23.equals("5"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5" + "'", str24.equals("5"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 14400000L + "'", long25 == 14400000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant47, readableInstant48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 0, chronology49);
        org.joda.time.DateTime dateTime52 = dateTime50.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime54 = dateTime52.plusWeeks(0);
        org.joda.time.DateTime dateTime57 = dateTime54.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localTime58, 32, locale60);
        long long63 = offsetDateTimeField26.roundHalfCeiling((-52799039901896831L));
        boolean boolean65 = offsetDateTimeField26.isLeap((long) 95);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "32" + "'", str61.equals("32"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-52799041224000000L) + "'", long63 == (-52799041224000000L));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 1);
        boolean boolean13 = offsetDateTimeField11.isLeap(0L);
        int int14 = offsetDateTimeField11.getMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86400 + "'", int14 == 86400);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        long long95 = offsetDateTimeField26.roundCeiling((long) (byte) 100);
        org.joda.time.DurationField durationField96 = offsetDateTimeField26.getLeapDurationField();
        long long98 = offsetDateTimeField26.roundFloor((long) 8);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 31435200000L + "'", long95 == 31435200000L);
        org.junit.Assert.assertNotNull(durationField96);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + (-619200000L) + "'", long98 == (-619200000L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (-3092342396832L), 91);
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 0, chronology9);
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime15.minusDays((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.Chronology chronology19 = gregorianChronology0.withZone(dateTimeZone18);
        boolean boolean21 = dateTimeZone18.isStandardOffset((long) 16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3092342396832L) + "'", long4 == (-3092342396832L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "1969-12-31T16:00:00.100-08:00", 360000000, 8);
        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 360000000 + "'", int6 == 360000000);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        java.lang.String str18 = cachedDateTimeZone4.getShortName((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone4.getUncachedZone();
        long long21 = cachedDateTimeZone4.previousTransition((long) (byte) 0);
        boolean boolean22 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven((long) 2000);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int33 = remainderDateTimeField28.get((long) 0);
        long long35 = remainderDateTimeField28.remainder(0L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.dayOfMonth();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 240, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        int int8 = dateTime4.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        boolean boolean17 = dateTime15.isAfter((long) 'a');
//        int int18 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property19 = dateTime15.yearOfEra();
//        int int20 = property19.getMaximumValue();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292278993 + "'", int20 == 292278993);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException8.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException8.getFieldName();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.dayOfYear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology9.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology9.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter1.withZone(dateTimeZone14);
        org.joda.time.LocalDateTime localDateTime16 = null;
        boolean boolean17 = dateTimeZone14.isLocalDateTimeGap(localDateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.get((long) 10);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        org.joda.time.DurationField durationField66 = offsetDateTimeField26.getDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(durationField66);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 0, chronology7);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property12 = dateTime8.dayOfWeek();
        java.util.Date date13 = dateTime8.toDate();
        org.joda.time.DateTime.Property property14 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTimeISO();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        java.lang.String str17 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Mon\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Mon\")"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Mon\")" + "'", str17.equals("(\"org.joda.time.JodaTimePermission\" \"Mon\")"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-1));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((-3092342396832L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(4, (int) (short) 0, 1969);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(19, ' ', 15, 8, 14400, false, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("Property[dayOfMonth]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder11.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
//        int int9 = dateTime8.getYear();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
//        org.joda.time.DateTime dateTime13 = dateTime8.withWeekyear(14400);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay13 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime dateTime15 = dateTime4.plusMillis(1970);
        org.joda.time.DateTime.Property property16 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, 0);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant21);
        java.lang.Class<?> wildcardClass23 = chronology22.getClass();
        org.joda.time.DateTime dateTime24 = dateTime20.withChronology(chronology22);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, readableInstant22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 0, chronology23);
//        org.joda.time.DateTime dateTime26 = dateTime24.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property27 = dateTime24.dayOfYear();
//        int int28 = dateTime24.getMillisOfDay();
//        org.joda.time.DateTime dateTime30 = dateTime24.withMillisOfSecond(100);
//        org.joda.time.ReadableInstant readableInstant32 = null;
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
//        boolean boolean37 = dateTime35.isAfter((long) 'a');
//        int int38 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime35);
//        long long39 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime24);
//        java.util.Locale locale40 = null;
//        int int41 = property10.getMaximumShortTextLength(locale40);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 14400000 + "'", int28 == 14400000);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        long long15 = dateTime12.getMillis();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DurationField durationField11 = zonedChronology8.eras();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology8.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology8.getZone();
        long long15 = dateTimeZone13.convertUTCToLocal((long) 376);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 91, dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 360000376L + "'", long15 == 360000376L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = zonedChronology7.get(readablePeriod11, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T04:00:00+100:00" + "'", str2.equals("T04:00:00+100:00"));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
//        int int9 = dateTime8.getYear();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
//        boolean boolean13 = dateTime11.isBefore((long) 5);
//        org.joda.time.DateTime dateTime15 = dateTime11.plusMonths((int) (byte) 1);
//        int int16 = dateTime15.getSecondOfDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14400 + "'", int16 == 14400);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMinutes(360000000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = dateTimeZone13.isLocalDateTimeGap(localDateTime14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        java.lang.String str21 = dateTimeZone20.getID();
        org.joda.time.Chronology chronology22 = iSOChronology16.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology16);
        int int24 = dateTime11.getWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:35" + "'", str21.equals("+00:35"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2654 + "'", int24 == 2654);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset(31449600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekOfWeekyear();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (byte) -1, (-91), 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1270-01-05T04:00:00.000+100:00", "", 0, (-2001));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Monday");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-91), 16, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getMinuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTime(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
//        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        int int9 = dateTime7.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        int int8 = dateTime4.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        boolean boolean17 = dateTime15.isAfter((long) 'a');
//        int int18 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property19 = dateTime4.monthOfYear();
//        org.joda.time.DateTime.Property property20 = dateTime4.era();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-70));
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        try {
            long long8 = dateTimeFormatter5.parseMillis("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-70) + "'", int6.equals((-70)));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1270-01-05T04:00:00.000+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1270-01-05T04:00:00.000+100:00\" is malformed at \"70-01-05T04:00:00.000+100:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        int int10 = property8.getLeapAmount();
//        org.joda.time.DurationField durationField11 = property8.getDurationField();
//        int int12 = property8.getMaximumValueOverall();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        int int14 = property8.getDifference(readableInstant13);
//        java.lang.String str15 = property8.getAsText();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Monday" + "'", str15.equals("Monday"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        org.joda.time.DurationField durationField31 = dividedDateTimeField24.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertNull(durationField31);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        long long64 = offsetDateTimeField26.roundHalfEven((long) (-4));
        int int66 = offsetDateTimeField26.get((long) (-2001));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-619200000L) + "'", long64 == (-619200000L));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1969 + "'", int66 == 1969);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        long long72 = offsetDateTimeField26.roundFloor(0L);
        int int74 = offsetDateTimeField26.getLeapAmount((long) (byte) 10);
        try {
            long long77 = offsetDateTimeField26.set(3169L, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-619200000L) + "'", long72 == (-619200000L));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology7.year();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        java.util.Locale locale28 = null;
        int int29 = dividedDateTimeField24.getMaximumShortTextLength(locale28);
        long long32 = dividedDateTimeField24.add(3169L, (-58665599891L));
        long long35 = dividedDateTimeField24.addWrapField((-52799039901896831L), 0);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant37, readableInstant38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) 0, chronology39);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology43 = org.joda.time.chrono.ZonedChronology.getInstance(chronology39, dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology43.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField45 = zonedChronology43.dayOfYear();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology43);
        org.joda.time.DateTimeField dateTimeField47 = zonedChronology43.weekyear();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime55 = dateTime52.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property56 = dateTime52.dayOfWeek();
        org.joda.time.DateTime dateTime57 = property56.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property56.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, dateTimeFieldType58, (int) (byte) -1, 91, 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24, dateTimeFieldType58);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-52799039901896831L) + "'", long32 == (-52799039901896831L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-52799039901896831L) + "'", long35 == (-52799039901896831L));
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(zonedChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology8.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = zonedChronology8.add(readablePeriod14, 10L, (int) '4');
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
//        int int11 = dateTime10.getYear();
//        java.lang.String str12 = dateTime10.toString();
//        org.joda.time.DateTime dateTime14 = dateTime10.plusSeconds(95);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T00:00:00.000+100:00" + "'", str12.equals("1970-01-05T00:00:00.000+100:00"));
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Interval interval20 = property10.toInterval();
        org.joda.time.DateTime dateTime21 = property10.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
//        int int9 = dateTime8.getYear();
//        int int10 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        java.lang.String str13 = property11.getName();
//        java.util.Locale locale14 = null;
//        int int15 = property11.getMaximumTextLength(locale14);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfWeek" + "'", str13.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfDay();
        try {
            long long17 = zonedChronology7.getDateTimeMillis(0L, 4, (int) (short) 0, 52, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        long long71 = offsetDateTimeField26.roundFloor((long) 7);
        org.joda.time.DurationField durationField72 = offsetDateTimeField26.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-619200000L) + "'", long71 == (-619200000L));
        org.junit.Assert.assertNotNull(durationField72);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.dayOfYear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology9.secondOfMinute();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 1970, (org.joda.time.Chronology) zonedChronology9);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
//        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfMonth(1);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks(360000000);
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant17, readableInstant18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 0, chronology19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property23 = dateTime20.dayOfYear();
//        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
//        java.lang.String str25 = property23.getAsText();
//        boolean boolean26 = dateTime15.equals((java.lang.Object) property23);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "5" + "'", str25.equals("5"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.DurationField durationField48 = offsetDateTimeField26.getLeapDurationField();
        long long50 = offsetDateTimeField26.roundHalfEven((long) (byte) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, (int) 'a');
        int int54 = offsetDateTimeField52.getMinimumValue((long) 2019);
        try {
            long long57 = offsetDateTimeField52.add((long) (byte) -1, (long) 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4036 for dayOfWeek must be in the range [188,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-619200000L) + "'", long50 == (-619200000L));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 188 + "'", int54 == 188);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
//        org.joda.time.DateTime dateTime12 = property8.addToCopy((long) 1);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusYears(4);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 14400000 + "'", int15 == 14400000);
//        org.junit.Assert.assertNotNull(property16);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
//        int int10 = dateTime4.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property12 = dateTime4.centuryOfEra();
//        org.joda.time.DateTime dateTime13 = property12.getDateTime();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        int int11 = dateTime4.getMinuteOfHour();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.dayOfYear();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology19);
//        org.joda.time.DateTimeField dateTimeField23 = zonedChronology19.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, readableInstant26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 0, chronology27);
//        org.joda.time.DateTime dateTime31 = dateTime28.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property32 = dateTime28.dayOfWeek();
//        org.joda.time.DateTime dateTime33 = property32.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField23, dateTimeFieldType34, 15);
//        int int37 = dateTime4.get(dateTimeFieldType34);
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.ReadableInstant readableInstant40 = null;
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant39, readableInstant40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 0, chronology41);
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance(chronology41, dateTimeZone44);
//        org.joda.time.DurationField durationField46 = zonedChronology45.hours();
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeUtils.getZone(dateTimeZone47);
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
//        org.joda.time.DurationField durationField50 = iSOChronology49.months();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField51 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType34, durationField46, durationField50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        int int9 = property7.getMinimumValue();
        java.util.Locale locale10 = null;
        int int11 = property7.getMaximumShortTextLength(locale10);
        org.joda.time.DateTime dateTime12 = property7.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DurationField durationField11 = property8.getLeapDurationField();
        int int12 = property8.getMaximumValue();
        java.util.Locale locale13 = null;
        int int14 = property8.getMaximumShortTextLength(locale13);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property18 = dateTime14.dayOfWeek();
//        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
//        int int25 = dateTime7.get(dateTimeFieldType20);
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        int int12 = dateTime10.getHourOfDay();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime10.toYearMonthDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven((long) 2000);
        int int32 = remainderDateTimeField28.getMinimumValue((-14399502L));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property7.roundHalfCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withPeriodAdded(readablePeriod10, 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "����-��");
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(21L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone5.getUncachedZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
//        java.lang.String str9 = property7.getAsText();
//        org.joda.time.DateTime dateTime11 = property7.addToCopy(2019);
//        int int12 = property7.getMaximumValue();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "5" + "'", str9.equals("5"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 1);
        long long8 = fixedDateTimeZone4.previousTransition((-263361600091L));
        long long10 = fixedDateTimeZone4.nextTransition((-3086294396832L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-263361600091L) + "'", long8 == (-263361600091L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3086294396832L) + "'", long10 == (-3086294396832L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology16.dayOfYear();
        boolean boolean19 = property8.equals((java.lang.Object) zonedChronology16);
        org.joda.time.Interval interval20 = property8.toInterval();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(interval20);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime4.plus((long) (-91));
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology13, dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = zonedChronology17.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology17.dayOfYear();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology17);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology17);
//        org.joda.time.DateTime dateTime22 = dateTime21.withEarlierOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.String str24 = dateTime21.toString(dateTimeFormatter23);
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        java.lang.String str26 = dateTimeFormatter23.print(readableInstant25);
//        java.lang.String str27 = dateTime8.toString(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970-01-05T04:00:00+100:00" + "'", str24.equals("1970-01-05T04:00:00+100:00"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-05T04:00:00+100:00" + "'", str26.equals("1970-01-05T04:00:00+100:00"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-01-05T03:59:59+100:00" + "'", str27.equals("1970-01-05T03:59:59+100:00"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        java.util.Date date10 = dateTime4.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 188);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
//        int int10 = dateTime4.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTimeISO();
//        int int12 = mutableDateTime11.getDayOfWeek();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        int int8 = dateTime4.getMillisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
//        org.joda.time.LocalTime localTime11 = dateTime4.toLocalTime();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localTime11);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 0);
        long long2 = dateTime1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        int int9 = property7.getMinimumValue();
        java.util.Locale locale10 = null;
        int int11 = property7.getMaximumShortTextLength(locale10);
        org.joda.time.DateTime dateTime12 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, (int) '#');
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean21 = dateTime15.isAfter((long) 0);
        org.joda.time.DateTime dateTime23 = dateTime15.plus((long) (-4));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        long long16 = durationField13.subtract((long) (byte) -1, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean18 = dateTimeFormatter17.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withZoneUTC();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) -1, (java.lang.Object) dateTimeFormatter17);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32054399999L + "'", long16 == 32054399999L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfHalfday();
        java.lang.String str12 = zonedChronology7.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray15 = zonedChronology7.get(readablePeriod13, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology11 = gregorianChronology0.withZone(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (-1));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime4.withWeekyear((int) (short) 0);
        java.lang.String str10 = dateTime8.toString("365");
        org.joda.time.DateTime.Property property11 = dateTime8.secondOfMinute();
        java.lang.String str12 = property11.getAsShortText();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "365" + "'", str10.equals("365"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant47, readableInstant48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 0, chronology49);
        org.joda.time.DateTime dateTime52 = dateTime50.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime54 = dateTime52.plusWeeks(0);
        org.joda.time.DateTime dateTime57 = dateTime54.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localTime58, 32, locale60);
        long long63 = offsetDateTimeField26.roundHalfEven((long) (short) 10);
        java.util.Locale locale64 = null;
        int int65 = offsetDateTimeField26.getMaximumShortTextLength(locale64);
        try {
            long long68 = offsetDateTimeField26.add((long) (byte) 10, (-280L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1689 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "32" + "'", str61.equals("32"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-619200000L) + "'", long63 == (-619200000L));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.get((long) 10);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        int int67 = offsetDateTimeField26.getLeapAmount(32054399999L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
//        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
//        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
//        int int12 = dateTime6.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTimeISO();
//        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "Property[dayOfMonth]", (-1));
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
//        org.joda.time.LocalDateTime localDateTime19 = null;
//        boolean boolean20 = dateTimeZone18.isLocalDateTimeGap(localDateTime19);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, readableInstant24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 0, chronology25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance(chronology25, dateTimeZone28);
//        org.joda.time.DateTimeField dateTimeField30 = zonedChronology29.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField31 = zonedChronology29.dayOfYear();
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology29);
//        boolean boolean33 = cachedDateTimeZone21.equals((java.lang.Object) zonedChronology29);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone35 = dateTimeFormatter34.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14400 + "'", int12 == 14400);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.dayOfYear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology9.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology9.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter1.withZone(dateTimeZone14);
        try {
            org.joda.time.MutableDateTime mutableDateTime17 = dateTimeFormatter1.parseMutableDateTime("Mon");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Mon\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        int int20 = property10.getLeapAmount();
//        java.lang.String str21 = property10.getAsString();
//        org.joda.time.DateTime dateTime22 = property10.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime24 = property10.addToCopy(14400010);
//        int int25 = property10.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology7.centuryOfEra();
        org.joda.time.DurationField durationField15 = zonedChronology7.weekyears();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
//        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        int int20 = property10.getLeapAmount();
//        java.lang.String str21 = property10.getAsString();
//        boolean boolean22 = property10.isLeap();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-14400001));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14400001) + "'", int1 == (-14400001));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime10 = dateTime6.withWeekyear((int) (short) 0);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "04:00:00.000+100:00" + "'", str11.equals("04:00:00.000+100:00"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 0, chronology7);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property12 = dateTime8.dayOfWeek();
        java.util.Date date13 = dateTime8.toDate();
        org.joda.time.DateTime.Property property14 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTimeISO();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        org.joda.time.DateTime dateTime18 = dateTime8.plusMillis((int) '#');
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Mon\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Mon\")"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int31 = dividedDateTimeField24.getMinimumValue();
        long long34 = dividedDateTimeField24.addWrapField(0L, (int) (byte) 0);
        java.util.Locale locale36 = null;
        java.lang.String str37 = dividedDateTimeField24.getAsShortText((-1), locale36);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-1" + "'", str37.equals("-1"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int31 = dividedDateTimeField24.getMinimumValue();
        long long33 = dividedDateTimeField24.roundHalfCeiling((long) 0);
        int int35 = dividedDateTimeField24.getLeapAmount((long) 1970);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
//        int int10 = dateTime9.getDayOfMonth();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime12.toYearMonthDay();
//        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay13);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        int int11 = property10.getMinimumValue();
        int int12 = property10.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int31 = dividedDateTimeField24.getMinimumValue();
        long long33 = dividedDateTimeField24.roundHalfCeiling((long) 0);
        int int34 = dividedDateTimeField24.getDivisor();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException13.getDateTimeFieldType();
        illegalFieldValueException10.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.Number number16 = illegalFieldValueException10.getLowerBound();
        java.lang.String str17 = illegalFieldValueException10.toString();
        illegalFieldValueException5.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        illegalFieldValueException10.prependMessage("1969");
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType14);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.centuries();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology14, dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology18.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology18.dayOfYear();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology18);
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology18.weekyear();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology18.hourOfHalfday();
        org.joda.time.DurationField durationField24 = zonedChronology18.weekyears();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology18.era();
        boolean boolean26 = zonedChronology7.equals((java.lang.Object) dateTimeField25);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 0, chronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology15.dayOfYear();
        org.joda.time.DurationField durationField18 = zonedChronology15.months();
        org.joda.time.DateTime dateTime19 = dateTime7.withChronology((org.joda.time.Chronology) zonedChronology15);
        org.joda.time.DateTime.Property property20 = dateTime7.era();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (byte) 100);
        java.util.Date date12 = dateTime9.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property18 = dateTime14.dayOfWeek();
//        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
//        int int25 = dateTime7.get(dateTimeFieldType20);
//        long long26 = dateTime7.getMillis();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean5 = cachedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = iSOChronology4.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology4.years();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long14 = fixedDateTimeZone12.nextTransition((long) (short) 1);
        int int16 = fixedDateTimeZone12.getOffset((long) 15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 0, chronology20);
        org.joda.time.DateTime dateTime24 = dateTime21.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property25 = dateTime21.dayOfWeek();
        java.util.Date date26 = dateTime21.toDate();
        org.joda.time.DateTime.Property property27 = dateTime21.dayOfMonth();
        int int28 = dateTime21.getMinuteOfHour();
        org.joda.time.LocalDateTime localDateTime29 = dateTime21.toLocalDateTime();
        boolean boolean30 = fixedDateTimeZone12.isLocalDateTimeGap(localDateTime29);
        int[] intArray32 = iSOChronology4.get((org.joda.time.ReadablePartial) localDateTime29, (-12L));
        try {
            long long40 = iSOChronology4.getDateTimeMillis(188, 376, 360000000, 2, 292278993, 9, 188);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray32);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 99);
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
//        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property21 = dateTime20.monthOfYear();
//        org.joda.time.DateTime.Property property22 = dateTime20.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant24, readableInstant25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 0, chronology26);
//        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property31 = dateTime27.dayOfWeek();
//        org.joda.time.DateTime dateTime32 = property31.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
//        int int38 = dateTime20.get(dateTimeFieldType33);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType33, (int) ' ', 0, (int) 'a');
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType33);
//        int int45 = zeroIsMaxDateTimeField43.getMaximumValue((long) '4');
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        int int29 = dividedDateTimeField24.getDivisor();
        org.joda.time.DurationField durationField30 = dividedDateTimeField24.getRangeDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[ISOChronology[UTC], +100:00]", 5);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+100:00", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology16.dayOfYear();
        boolean boolean19 = property8.equals((java.lang.Object) zonedChronology16);
        java.util.Locale locale20 = null;
        int int21 = property8.getMaximumShortTextLength(locale20);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.Chronology chronology11 = zonedChronology7.withUTC();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = zonedChronology7.get(readablePeriod12, (long) 14400000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 360000000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime10 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.Interval interval20 = property10.toInterval();
        org.joda.time.DurationField durationField21 = property10.getRangeDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(interval20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "1969-12-31T16:00:00.100-08:00", 360000000, 8);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(98L);
        long long9 = fixedDateTimeZone4.adjustOffset((long) 95, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str6.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 95L + "'", long9 == 95L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime4.plus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMonths((-91));
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
//        int int9 = dateTime8.getYear();
//        int int10 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime8.era();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology7.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology7.minuteOfHour();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[ISOChronology[UTC], +100:00]", 5);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1270-01-05T04:00:00.000+100:00", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((-4));
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 0, 2019, 12, (int) 'a', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        long long64 = offsetDateTimeField26.roundHalfEven((long) (-4));
        try {
            long long67 = offsetDateTimeField26.addWrapField(240L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-619200000L) + "'", long64 == (-619200000L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.DurationField durationField46 = offsetDateTimeField26.getDurationField();
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant48, readableInstant49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 0, chronology50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime55 = dateTime53.plusWeeks(0);
        org.joda.time.DateTime dateTime58 = dateTime55.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime59 = dateTime58.toLocalTime();
        int int60 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime59);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) 3168);
        java.lang.String str10 = cachedDateTimeZone4.getNameKey(3169L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = cachedDateTimeZone4.getShortName((long) 0, locale12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) (byte) 1);
        int int10 = cachedDateTimeZone4.getStandardOffset(32054399999L);
        long long12 = cachedDateTimeZone4.nextTransition(0L);
        boolean boolean14 = cachedDateTimeZone4.isStandardOffset((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        java.util.Date date9 = dateTime4.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.secondOfDay();
//        int int22 = dateTime11.get(dateTimeField21);
//        int int23 = dateTime11.getYear();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(zonedChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14400 + "'", int22 == 14400);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
//        int int10 = dateTime4.getSecondOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTimeISO();
//        org.joda.time.DateTime.Property property12 = dateTime4.centuryOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime4.millisOfSecond();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        java.util.Locale locale28 = null;
        int int29 = dividedDateTimeField24.getMaximumShortTextLength(locale28);
        long long32 = dividedDateTimeField24.add(3169L, (-58665599891L));
        long long35 = dividedDateTimeField24.addWrapField((-52799039901896831L), 0);
        long long37 = dividedDateTimeField24.roundFloor((long) ' ');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-52799039901896831L) + "'", long32 == (-52799039901896831L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-52799039901896831L) + "'", long35 == (-52799039901896831L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        int int9 = property7.getMinimumValue();
        int int10 = property7.getMinimumValueOverall();
        org.joda.time.DurationField durationField11 = property7.getLeapDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(durationField11);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
//        java.util.Date date10 = dateTime9.toDate();
//        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
//        org.joda.time.DateTime dateTime21 = dateTime16.withMillisOfDay((int) (byte) 100);
//        org.joda.time.DateTime dateTime23 = dateTime21.minusDays((int) (byte) 100);
//        int int24 = property11.compareTo((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime26 = dateTime23.minusWeeks(365);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven((long) 2000);
        int int31 = remainderDateTimeField28.getMinimumValue();
        int int33 = remainderDateTimeField28.get((long) 0);
        int int35 = remainderDateTimeField28.get((long) (byte) 0);
        java.util.Locale locale36 = null;
        int int37 = remainderDateTimeField28.getMaximumShortTextLength(locale36);
        java.util.Locale locale38 = null;
        int int39 = remainderDateTimeField28.getMaximumShortTextLength(locale38);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("ZonedChronology[ISOChronology[UTC], +100:00]", 5);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder6.addCutover(19, 'a', 1969, (int) (byte) 100, (int) (short) -1, false, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "");
        java.lang.Number number29 = illegalFieldValueException28.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(number29);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
//        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
//        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
//        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
//        long long31 = dividedDateTimeField24.addWrapField((-1460L), 188);
//        org.joda.time.ReadableInstant readableInstant33 = null;
//        org.joda.time.ReadableInstant readableInstant34 = null;
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 0, chronology35);
//        org.joda.time.DateTime dateTime39 = dateTime36.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property40 = dateTime39.monthOfYear();
//        org.joda.time.DateTime.Property property41 = dateTime39.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant43 = null;
//        org.joda.time.ReadableInstant readableInstant44 = null;
//        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant43, readableInstant44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) 0, chronology45);
//        org.joda.time.DateTime dateTime49 = dateTime46.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property50 = dateTime46.dayOfWeek();
//        org.joda.time.DateTime dateTime51 = property50.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
//        int int57 = dateTime39.get(dateTimeFieldType52);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, "-00:00:00.001");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField60 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField24, dateTimeFieldType52);
//        long long62 = zeroIsMaxDateTimeField60.roundHalfEven((-619200000L));
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3601460L) + "'", long31 == (-3601460L));
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-619200000L) + "'", long62 == (-619200000L));
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        java.lang.String str10 = property8.getAsShortText();
//        org.joda.time.Interval interval11 = property8.toInterval();
//        int int12 = property8.getMaximumValue();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Mon" + "'", str10.equals("Mon"));
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 0, chronology6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance(chronology6, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology10.dayOfYear();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology10);
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology10.weekyear();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property23 = dateTime19.dayOfWeek();
        org.joda.time.DateTime dateTime24 = property23.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType25, (int) (byte) -1, 91, 0);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField29.getMaximumShortTextLength(locale30);
        java.lang.String str33 = offsetDateTimeField29.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant35, readableInstant36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 0, chronology37);
        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property42 = dateTime38.dayOfWeek();
        java.util.Date date43 = dateTime38.toDate();
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime46 = dateTime38.withDurationAdded(readableDuration44, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay47 = dateTime38.toTimeOfDay();
        int int48 = offsetDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay47);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant50, readableInstant51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 0, chronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime57 = dateTime55.plusWeeks(0);
        org.joda.time.DateTime dateTime60 = dateTime57.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime61 = dateTime60.toLocalTime();
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localTime61, 32, locale63);
        boolean boolean65 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField29);
        boolean boolean66 = offsetDateTimeField29.isLenient();
        try {
            long long69 = offsetDateTimeField29.add((long) (short) 1, 188);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2157 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(timeOfDay47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 91 + "'", int48 == 91);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(localTime61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "32" + "'", str64.equals("32"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.era();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.hourOfHalfday();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime.Property property13 = dateTime4.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime15 = dateTime4.withDayOfWeek((-70));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-3601460L), dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Chronology chronology6 = iSOChronology4.withZone(dateTimeZone5);
        org.joda.time.DurationField durationField7 = iSOChronology4.years();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long14 = fixedDateTimeZone12.nextTransition((long) (short) 1);
        int int16 = fixedDateTimeZone12.getOffset((long) 15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 0, chronology20);
        org.joda.time.DateTime dateTime24 = dateTime21.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property25 = dateTime21.dayOfWeek();
        java.util.Date date26 = dateTime21.toDate();
        org.joda.time.DateTime.Property property27 = dateTime21.dayOfMonth();
        int int28 = dateTime21.getMinuteOfHour();
        org.joda.time.LocalDateTime localDateTime29 = dateTime21.toLocalDateTime();
        boolean boolean30 = fixedDateTimeZone12.isLocalDateTimeGap(localDateTime29);
        int[] intArray32 = iSOChronology4.get((org.joda.time.ReadablePartial) localDateTime29, (-12L));
        java.lang.String str33 = iSOChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str33.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField26.getMaximumShortTextLength(locale29);
        long long32 = offsetDateTimeField26.roundHalfCeiling((long) 2000);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-619200000L) + "'", long32 == (-619200000L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = offsetDateTimeField26.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType71, "Property[dayOfWeek]");
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfWeek();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
//        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
//        int int10 = property8.getLeapAmount();
//        org.joda.time.DurationField durationField11 = property8.getDurationField();
//        int int12 = property8.getMaximumValueOverall();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        int int14 = property8.getDifference(readableInstant13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
//        org.joda.time.LocalDateTime localDateTime17 = null;
//        boolean boolean18 = dateTimeZone16.isLocalDateTimeGap(localDateTime17);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, readableInstant22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 0, chronology23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology23, dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = zonedChronology27.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField29 = zonedChronology27.dayOfYear();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology27);
//        boolean boolean31 = cachedDateTimeZone19.equals((java.lang.Object) zonedChronology27);
//        org.joda.time.DurationField durationField32 = zonedChronology27.hours();
//        boolean boolean33 = property8.equals((java.lang.Object) zonedChronology27);
//        org.joda.time.DateTime dateTime34 = property8.roundFloorCopy();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//    }
//}

