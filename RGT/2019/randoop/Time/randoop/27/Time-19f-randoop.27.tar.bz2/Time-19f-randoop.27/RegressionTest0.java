import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), (java.lang.Number) (-1), number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) 'a', (int) (short) -1, (-1), 0, (int) (short) 0, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0, 0, (int) (short) 1, (int) (short) 10, (int) (short) 0, (int) (short) 100, (int) (short) 10, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1.0d, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-1), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(99, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109 + "'", int2 == 109);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 360000000);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 99, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (byte) 0, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.minusYears(360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -359998031 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) property8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, (int) (byte) -1, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType12, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for weekyear must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        java.lang.Object obj5 = null;
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) chronology3, obj5);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter1.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 360000000L + "'", long0 == 360000000L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(99, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3168 + "'", int2 == 3168);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) (byte) 10, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 91 + "'", int3 == 91);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Object obj5 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int9 = dateTimeZone7.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj5, dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 1, (int) (short) 100, 365, (int) (short) 10, (int) (short) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 360000000 + "'", int9 == 360000000);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 109);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = property7.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime11 = property8.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        try {
            long long13 = zonedChronology7.getDateTimeMillis((long) 3168, (int) '4', (int) (byte) 0, (int) '#', 360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(12, 3168, 10, 2000, (int) (short) 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        boolean boolean9 = dateTime4.isBefore((long) '4');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime19 = dateTime14.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime14.plusMinutes(360000000);
        org.joda.time.DateTime dateTime23 = dateTime14.withWeekOfWeekyear((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int[] intArray27 = new int[] { 360000000, (short) 0 };
        try {
            zonedChronology7.validate((org.joda.time.ReadablePartial) yearMonthDay24, intArray27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for year must not be larger than 292278993");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime.Property property14 = dateTime11.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        try {
            long long19 = zonedChronology7.getDateTimeMillis((long) 52, (int) (byte) -1, (int) '4', 99, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(109, 0, 360000000, 100, (int) (short) -1, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        java.lang.String str7 = dateTimeZone2.getShortName((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+100:00" + "'", str7.equals("+100:00"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        long long16 = durationField13.subtract((long) (byte) -1, (int) (short) -1);
        long long19 = durationField13.subtract((long) 3168, 98L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 32054399999L + "'", long16 == 32054399999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3092342396832L) + "'", long19 == (-3092342396832L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (byte) -1, 0, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DurationField durationField15 = zonedChronology12.months();
        org.joda.time.Chronology chronology16 = zonedChronology12.withUTC();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(99, 3, 52, 360000000, 14400000, (org.joda.time.Chronology) zonedChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(5, (int) (short) 10, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str20 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "5" + "'", str20.equals("5"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', (int) (short) 1, (int) (short) 100, 10, 1, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime11.withDayOfMonth(1);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            int int16 = dateTime13.get(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DateTime dateTime11 = property8.roundFloorCopy();
        java.lang.Object obj12 = null;
        boolean boolean13 = property8.equals(obj12);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, 5, 100, 1970, 52, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1), 109, (int) (byte) 0, 0, 14400000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14400000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 0, chronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology15.dayOfYear();
        org.joda.time.DurationField durationField18 = zonedChronology15.months();
        org.joda.time.DateTime dateTime19 = dateTime7.withChronology((org.joda.time.Chronology) zonedChronology15);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        try {
            int[] intArray23 = zonedChronology15.get(readablePeriod20, (long) 70, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        java.lang.String str11 = property10.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[dayOfMonth]" + "'", str11.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1), (int) (short) -1, (int) (short) 10, 5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime6.plusMinutes(360000000);
        org.joda.time.DateTime dateTime15 = dateTime6.withWeekOfWeekyear((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime15.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField11, 91, 52, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 91 for minuteOfDay must be in the range [52,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, 1970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1970 + "'", int2 == 1970);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) (short) -1);
        java.lang.String str11 = dateTimeZone7.getShortName((long) 1);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(100, (int) '4', 15, (int) (byte) 100, (int) 'a', 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+100:00" + "'", str11.equals("+100:00"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("+00:35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:35\" is malformed at \":35\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        int int11 = dateTime4.getMinuteOfHour();
        int int12 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 360000000, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        java.util.Locale locale9 = null;
        int int10 = property7.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        long long12 = dateTime4.getMillis();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.String str2 = dateTimeFormatter0.print((long) (-2001));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-W02" + "'", str2.equals("1970-W02"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMinutes(360000000);
        java.util.Date date12 = dateTime11.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.Interval interval8 = property7.toInterval();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        int int11 = dateTime10.getYear();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withHourOfDay((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1970, 2000, 15, 52, 99, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 'a', 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("365", (int) (byte) 10, 32, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for 365 must be in the range [32,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        boolean boolean8 = cachedDateTimeZone5.equals((java.lang.Object) 14400000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime16 = null;
        boolean boolean17 = dateTimeZone15.isLocalDateTimeGap(localDateTime16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        java.lang.String str23 = dateTimeZone22.getID();
        org.joda.time.Chronology chronology24 = iSOChronology18.withZone(dateTimeZone22);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) zonedChronology7, (org.joda.time.Chronology) iSOChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:35" + "'", str23.equals("+00:35"));
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 99, 19, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.lang.String str9 = property8.getAsText();
        boolean boolean11 = property8.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Monday" + "'", str9.equals("Monday"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        int int13 = dateTime12.getMinuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime12.withMillis((long) (byte) 1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, 10);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime4.withWeekyear((int) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withPeriodAdded(readablePeriod9, 1970);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.DurationField durationField11 = property8.getRangeDurationField();
        org.joda.time.DateTime dateTime12 = property8.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getMinimumValueOverall();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.DateTime dateTime13 = property8.setCopy("1970-01-05T04:00:00+100:00", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-01-05T04:00:00+100:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        int int12 = dateTime10.getHourOfDay();
        int int13 = dateTime10.getSecondOfMinute();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(91);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-91) + "'", int1 == (-91));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int5 = dateTimeZone3.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj1, dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        boolean boolean8 = dateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 360000000 + "'", int5 == 360000000);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str15 = dateTime12.toString(dateTimeFormatter14);
        java.lang.StringBuffer stringBuffer16 = null;
        try {
            dateTimeFormatter14.printTo(stringBuffer16, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-05T04:00:00+100:00" + "'", str15.equals("1970-01-05T04:00:00+100:00"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, 5, (int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        int int10 = dateTime9.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfSecond(99);
        boolean boolean14 = dateTime9.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        int int7 = dateTime4.getMillisOfSecond();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(chronology10);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property18 = dateTime14.dayOfWeek();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        int int25 = dateTime7.get(dateTimeFieldType20);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 0, chronology29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance(chronology29, dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology33.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField35 = zonedChronology33.dayOfYear();
        org.joda.time.DurationField durationField36 = zonedChronology33.months();
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 0, chronology40);
        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property45 = dateTime41.dayOfWeek();
        org.joda.time.DateTime dateTime46 = property45.withMaximumValue();
        org.joda.time.DateTime dateTime47 = property45.roundHalfFloorCopy();
        org.joda.time.DurationField durationField48 = property45.getRangeDurationField();
        long long51 = durationField48.subtract((long) 109, (int) 'a');
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField52 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType20, durationField36, durationField48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-58665599891L) + "'", long51 == (-58665599891L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType10, (int) (short) 0, (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.monthOfYear();
        try {
            long long19 = zonedChronology7.getDateTimeMillis(0, 0, (int) '4', 99, 3168, 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-00:00:00.001\" is malformed at \":00:00.001\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) -1, 10);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        java.lang.String str10 = property8.getAsShortText();
        try {
            org.joda.time.DateTime dateTime12 = property8.setCopy("1970-W02");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1970-W02\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Mon" + "'", str10.equals("Mon"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        int int8 = dateTime4.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar18 = dateTime15.toGregorianCalendar();
        int int19 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2, 1970, (int) (byte) 0, 99, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology22.dayOfWeek();
        org.joda.time.DurationField durationField24 = zonedChronology22.months();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, chronology28);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance(chronology28, dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = zonedChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology32.dayOfYear();
        org.joda.time.DurationField durationField35 = zonedChronology32.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField36 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType10, durationField24, durationField35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(zonedChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 4, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970-W02", (int) '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for 1970-W02 must be in the range [0,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        int int10 = dateTime4.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTimeISO();
        org.joda.time.Chronology chronology12 = mutableDateTime11.getChronology();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property18 = dateTime14.dayOfWeek();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        int int25 = dateTime7.get(dateTimeFieldType20);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 0, chronology29);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance(chronology29, dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = zonedChronology33.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField35 = zonedChronology33.dayOfYear();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology33);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology33.weekyear();
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant39, readableInstant40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 0, chronology41);
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property46 = dateTime42.dayOfWeek();
        org.joda.time.DateTime dateTime47 = property46.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property46.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType48, (int) (byte) -1, 91, 0);
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant54, readableInstant55);
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) 0, chronology56);
        org.joda.time.DateTime dateTime60 = dateTime57.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property61 = dateTime57.dayOfWeek();
        org.joda.time.DateTime dateTime62 = property61.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property61.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Chronology chronology71 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant69, readableInstant70);
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) 0, chronology71);
        org.joda.time.DateTime dateTime75 = dateTime72.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property76 = dateTime72.dayOfWeek();
        org.joda.time.DateTime dateTime77 = property76.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property76.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray79 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType20, dateTimeFieldType48, dateTimeFieldType63, dateTimeFieldType78 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList80 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList80, dateTimeFieldTypeArray79);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList80, true, true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter84);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        long long9 = dateTime6.getMillis();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2000, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        try {
            long long31 = offsetDateTimeField26.add((long) 19, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2068 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean13 = dateTimeZone11.isStandardOffset((long) (short) -1);
        java.lang.String str15 = dateTimeZone11.getShortName((long) 1);
        org.joda.time.DateTime dateTime16 = dateTime9.withZone(dateTimeZone11);
        int int17 = dateTime16.getMillisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+100:00" + "'", str15.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean13 = dateTimeZone11.isStandardOffset((long) (short) -1);
        java.lang.String str15 = dateTimeZone11.getShortName((long) 1);
        org.joda.time.DateTime dateTime16 = dateTime9.withZone(dateTimeZone11);
        try {
            org.joda.time.DateTime dateTime21 = dateTime16.withTime((int) (short) 0, 2000, 8, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+100:00" + "'", str15.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withDayOfYear((-4));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withDayOfWeek((-4));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("Property[dayOfMonth]", 7, 360000000, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for Property[dayOfMonth] must be in the range [360000000,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"365\" is malformed at \"5\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, 2000, (int) ' ', 100, 19, 3168);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) 100, (int) (byte) -1, (int) (byte) 1, 'a', 70, (int) (byte) 10, 99, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime.Property property12 = dateTime4.yearOfEra();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfYear();
        int int10 = dateTime6.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime6.withMillisOfSecond(100);
        int int13 = dateTime12.getYearOfEra();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400000 + "'", int10 == 14400000);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        org.joda.time.DurationField durationField17 = zonedChronology12.hours();
        try {
            long long25 = zonedChronology12.getDateTimeMillis(3, 1, 0, 109, 2, 8, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 109 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property10 = dateTime6.dayOfWeek();
        java.util.Date date11 = dateTime6.toDate();
        org.joda.time.DateTime.Property property12 = dateTime6.dayOfMonth();
        org.joda.time.DateTime dateTime13 = dateTime6.toDateTimeISO();
        int int14 = dateTime13.getDayOfYear();
        org.joda.time.DateTime dateTime16 = dateTime13.withMinuteOfHour((int) '#');
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField26.getMaximumShortTextLength(locale29);
        java.util.Locale locale33 = null;
        try {
            long long34 = offsetDateTimeField26.set((long) (short) -1, "Property[dayOfMonth]", locale33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[dayOfMonth]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime4.plusMinutes(360000000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = dateTimeZone13.isLocalDateTimeGap(localDateTime14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        java.lang.String str21 = dateTimeZone20.getID();
        org.joda.time.Chronology chronology22 = iSOChronology16.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime((org.joda.time.Chronology) iSOChronology16);
        try {
            org.joda.time.DateTime dateTime25 = dateTime23.withHourOfDay(360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:35" + "'", str21.equals("+00:35"));
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField11, (int) (short) -1, 1, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekyear must be in the range [1,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        int int10 = dateTime8.getDayOfYear();
        try {
            org.joda.time.DateTime dateTime14 = dateTime8.withDate((int) (short) 0, (-91), 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -91 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(chronology3);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(91, (int) (short) 100, 91, (-4), (int) (short) 10, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 365, (long) (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1460L) + "'", long2 == (-1460L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology20.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology20.dayOfYear();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology20.minuteOfDay();
        org.joda.time.DateTime dateTime25 = dateTime12.toDateTime((org.joda.time.Chronology) zonedChronology20);
        try {
            long long31 = zonedChronology20.getDateTimeMillis((long) (-1), (int) (byte) -1, (-91), (int) 'a', 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException5.getDurationFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(99);
        org.joda.time.DateTime dateTime11 = dateTime9.withCenturyOfEra((int) ' ');
        int int12 = dateTime9.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (-91), true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-360000091L) + "'", long10 == (-360000091L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime13.toCalendar(locale14);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(calendar15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        org.joda.time.DateTime.Property property12 = dateTime8.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 0, 109, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [109,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(70);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-70) + "'", int1 == (-70));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.DurationField durationField11 = property8.getRangeDurationField();
        int int12 = property8.get();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime();
        int int12 = dateTime11.getMillisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour((int) '#');
        boolean boolean15 = dateTime14.isAfterNow();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(20L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DurationField durationField9 = zonedChronology7.months();
        long long12 = durationField9.subtract((-360000091L), (int) (short) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-263361600091L) + "'", long12 == (-263361600091L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology4.years();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 0, chronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.dayOfYear();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology14);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology14.weekyear();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 0, chronology22);
        org.joda.time.DateTime dateTime26 = dateTime23.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property27 = dateTime23.dayOfWeek();
        org.joda.time.DateTime dateTime28 = property27.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType29, (int) (byte) -1, 91, 0);
        java.util.Locale locale34 = null;
        int int35 = offsetDateTimeField33.getMaximumShortTextLength(locale34);
        java.lang.String str37 = offsetDateTimeField33.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant39, readableInstant40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 0, chronology41);
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property46 = dateTime42.dayOfWeek();
        java.util.Date date47 = dateTime42.toDate();
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.DateTime dateTime50 = dateTime42.withDurationAdded(readableDuration48, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay51 = dateTime42.toTimeOfDay();
        int int52 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay51);
        int[] intArray53 = null;
        try {
            iSOChronology4.validate((org.joda.time.ReadablePartial) timeOfDay51, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969" + "'", str37.equals("1969"));
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(timeOfDay51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 91 + "'", int52 == 91);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.add(0L, (long) 70);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 63000000L + "'", long27 == 63000000L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        long long95 = offsetDateTimeField26.roundCeiling((long) (byte) 100);
        java.util.Locale locale98 = null;
        try {
            long long99 = offsetDateTimeField26.set((long) (byte) 100, "Property[dayOfMonth]", locale98);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[dayOfMonth]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 31435200000L + "'", long95 == 31435200000L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withMillisOfSecond((int) ' ');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Monday", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Monday/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime13 = dateTime4.withEra(0);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withMonthOfYear((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology8.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray16 = zonedChronology8.get(readablePeriod14, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property18 = dateTime14.dayOfWeek();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.era();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekOfWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.DurationField durationField31 = offsetDateTimeField26.getDurationField();
        try {
            long long34 = offsetDateTimeField26.add(63000000L, (-2001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        java.lang.String str11 = zonedChronology7.toString();
        try {
            long long17 = zonedChronology7.getDateTimeMillis(63000000L, (-70), 3, 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property21 = dateTime17.dayOfWeek();
        org.joda.time.DateTime dateTime22 = property21.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property21.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        org.joda.time.DateTime.Property property28 = dateTime12.property(dateTimeFieldType23);
        org.joda.time.DateTime dateTime29 = property28.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        org.joda.time.DurationFieldType durationFieldType66 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField68 = new org.joda.time.field.ScaledDurationField(durationField65, durationFieldType66, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        try {
            long long96 = offsetDateTimeField26.addWrapField((long) 100, (-2001));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        int int11 = dateTime4.getDayOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean7 = gregorianChronology1.equals((java.lang.Object) cachedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        try {
            long long17 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, 0, 1970, 99, (int) (short) 1, 70, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1970-01-05T04:00:00.100+100:00", (java.lang.Number) 21L, (java.lang.Number) 52, (java.lang.Number) (byte) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \":00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        int int12 = dateTime10.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePeriod3, (long) 3, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology20.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology20.dayOfYear();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology20.minuteOfDay();
        org.joda.time.DateTime dateTime25 = dateTime12.toDateTime((org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTime dateTime28 = dateTime12.withDurationAdded((long) 19, 3);
        org.joda.time.DateTime dateTime30 = dateTime12.withHourOfDay(2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (-14399901L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 0, chronology35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology39 = org.joda.time.chrono.ZonedChronology.getInstance(chronology35, dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = zonedChronology39.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField41 = zonedChronology39.dayOfYear();
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology39);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology39);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.minuteOfDay();
        org.joda.time.DateTime dateTime56 = dateTime43.toDateTime((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.LocalTime localTime57 = dateTime56.toLocalTime();
        java.util.Locale locale58 = null;
        try {
            java.lang.String str59 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localTime57, locale58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(zonedChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localTime57);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DurationField durationField13 = zonedChronology12.centuries();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) ' ', (-1), 0, (int) ' ', 19, (org.joda.time.Chronology) zonedChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((-2001), 12, 5, (-4), (int) (short) 1, (int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        java.lang.Object obj6 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int10 = dateTimeZone8.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj6, dateTimeZone8);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(0);
        boolean boolean14 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime11);
        int int15 = dateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 360000000 + "'", int10 == 360000000);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1970 + "'", int15 == 1970);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        illegalFieldValueException2.prependMessage("1969-12-31T16:00:00.100-08:00");
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DurationField durationField11 = property8.getDurationField();
        int int12 = property8.getMaximumValueOverall();
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = property8.getDifference(readableInstant13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = dateTimeZone16.isLocalDateTimeGap(localDateTime17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, readableInstant22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 0, chronology23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology23, dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology27.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology27.dayOfYear();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology27);
        boolean boolean31 = cachedDateTimeZone19.equals((java.lang.Object) zonedChronology27);
        org.joda.time.DurationField durationField32 = zonedChronology27.hours();
        boolean boolean33 = property8.equals((java.lang.Object) zonedChronology27);
        int int34 = property8.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.DurationField durationField46 = offsetDateTimeField26.getDurationField();
        long long48 = offsetDateTimeField26.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-619200000L) + "'", long48 == (-619200000L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField26.getMaximumShortTextLength(locale29);
        try {
            long long33 = offsetDateTimeField26.set((long) (-2001), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.minusHours((int) (short) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks(0);
        int int17 = dateTime14.getMonthOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("32", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("hi!", 0, (int) (short) -1, 3, 'a', (int) (byte) 1, 0, (int) (short) 1, false, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str15 = dateTime12.toString(dateTimeFormatter14);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant17, readableInstant18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 0, chronology19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance(chronology19, dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology23.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology23.dayOfYear();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology23);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology23.weekyear();
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 0, chronology31);
        org.joda.time.DateTime dateTime35 = dateTime32.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property36 = dateTime32.dayOfWeek();
        org.joda.time.DateTime dateTime37 = property36.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType38, (int) (byte) -1, 91, 0);
        java.util.Locale locale43 = null;
        int int44 = offsetDateTimeField42.getMaximumShortTextLength(locale43);
        java.lang.String str46 = offsetDateTimeField42.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant48, readableInstant49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 0, chronology50);
        org.joda.time.DateTime dateTime53 = dateTime51.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime55 = dateTime53.plusWeeks(0);
        org.joda.time.DateTime dateTime58 = dateTime55.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime59 = dateTime58.toLocalTime();
        int[] intArray62 = new int[] { 14400, (byte) 1 };
        int int63 = offsetDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) localTime59, intArray62);
        org.joda.time.ReadableInstant readableInstant65 = null;
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.Chronology chronology67 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant65, readableInstant66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) 0, chronology67);
        org.joda.time.DateTime dateTime70 = dateTime68.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime72 = dateTime70.plusWeeks(0);
        org.joda.time.DateTime dateTime75 = dateTime72.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime76 = dateTime75.toLocalTime();
        int[] intArray77 = new int[] {};
        int int78 = offsetDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localTime76, intArray77);
        java.lang.String str79 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) localTime76);
        java.lang.String str81 = dateTimeFormatter14.print((long) 70);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-01-05T04:00:00+100:00" + "'", str15.equals("1970-01-05T04:00:00+100:00"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1969" + "'", str46.equals("1969"));
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localTime59);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 91 + "'", int63 == 91);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(localTime76);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "����-��-��T08:00:00" + "'", str79.equals("����-��-��T08:00:00"));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1970-01-05T04:00:00+100:00" + "'", str81.equals("1970-01-05T04:00:00+100:00"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.secondOfDay();
        int int22 = dateTime11.get(dateTimeField21);
        int int23 = dateTime11.getMonthOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14400 + "'", int22 == 14400);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DurationField durationField8 = zonedChronology7.centuries();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        int int11 = dateTime10.getYear();
        java.lang.String str12 = dateTime10.toString();
        java.lang.Object obj14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int18 = dateTimeZone16.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj14, dateTimeZone16);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
        org.joda.time.DateTime dateTime21 = dateTime10.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime21.withDayOfMonth((int) (byte) 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T00:00:00.000+100:00" + "'", str12.equals("1970-01-05T00:00:00.000+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 360000000 + "'", int18 == 360000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        long long95 = offsetDateTimeField26.roundCeiling((long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField96 = offsetDateTimeField26.getWrappedField();
        org.joda.time.DurationField durationField97 = offsetDateTimeField26.getLeapDurationField();
        java.lang.String str99 = offsetDateTimeField26.getAsShortText((long) (-2001));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 31435200000L + "'", long95 == 31435200000L);
        org.junit.Assert.assertNotNull(dateTimeField96);
        org.junit.Assert.assertNotNull(durationField97);
        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "1969" + "'", str99.equals("1969"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology7.getZone();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = zonedChronology7.get(readablePeriod13, (long) 52, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DurationField durationField8 = zonedChronology7.centuries();
        java.lang.String str9 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str9.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone8.isLocalDateTimeGap(localDateTime9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.dayOfYear();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology19);
        boolean boolean23 = cachedDateTimeZone11.equals((java.lang.Object) zonedChronology19);
        org.joda.time.DurationField durationField24 = zonedChronology19.hours();
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((int) (byte) 0, 2000, 2000, 8, 14400, (-4), (int) (byte) -1, (org.joda.time.Chronology) zonedChronology19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14400 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime12.era();
        java.lang.Object obj15 = null;
        boolean boolean16 = property14.equals(obj15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        int int9 = property7.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime11 = property7.setCopy((-4));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -4 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        int int10 = dateTime9.getDayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
        int int13 = dateTime9.getDayOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        org.joda.time.DurationField durationField15 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone17.isLocalDateTimeGap(localDateTime18);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology21 = iSOChronology20.withUTC();
        org.joda.time.DurationField durationField22 = iSOChronology20.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField23 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType10, durationField15, durationField22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-58665599891L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -58665599891");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.secondOfDay();
        int int22 = dateTime11.get(dateTimeField21);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime11.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14400 + "'", int22 == 14400);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str12 = dateTimeZone7.getShortName(96L);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 14400000, dateTimeZone7);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadablePartial) timeOfDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeOfDay14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isParser();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-70));
        java.io.Writer writer6 = null;
        try {
            dateTimeFormatter5.printTo(writer6, (-14399901L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        boolean boolean94 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay42);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(100L, 1);
        java.lang.String str13 = dateTime12.toString();
        org.joda.time.DateTime dateTime14 = dateTime12.withTimeAtStartOfDay();
        int int15 = dateTime14.getDayOfMonth();
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfSecond(99);
        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
        int int19 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str13.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-14399901L) + "'", long18 == (-14399901L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        org.joda.time.DurationField durationField71 = null;
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime74 = null;
        boolean boolean75 = dateTimeZone73.isLocalDateTimeGap(localDateTime74);
        org.joda.time.chrono.ISOChronology iSOChronology76 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone73);
        org.joda.time.Chronology chronology77 = iSOChronology76.withUTC();
        org.joda.time.DurationField durationField78 = iSOChronology76.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField79 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType70, durationField71, durationField78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(iSOChronology76);
        org.junit.Assert.assertNotNull(chronology77);
        org.junit.Assert.assertNotNull(durationField78);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
        org.joda.time.Chronology chronology9 = zonedChronology7.withUTC();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        try {
            int[] intArray12 = zonedChronology7.get(readablePeriod10, (long) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(399L, (-14399901L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-14399502L) + "'", long2 == (-14399502L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        int int10 = dateTime9.getDayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime9.withYear(91);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        int int9 = property8.getMaximumValue();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 0, chronology13);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTimeISO();
        java.lang.Object obj16 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int20 = dateTimeZone18.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(obj16, dateTimeZone18);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks(0);
        boolean boolean24 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = null;
        java.lang.String str26 = dateTime21.toString(dateTimeFormatter25);
        long long27 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 360000000 + "'", int20 == 360000000);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-09T08:00:00.000+100:00" + "'", str26.equals("1970-01-09T08:00:00.000+100:00"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Monday");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Monday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 1);
        int int13 = offsetDateTimeField11.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) -1, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.minusWeeks(32);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        int int65 = offsetDateTimeField26.getOffset();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumShortTextLength(locale66);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        java.util.Locale locale20 = null;
        java.lang.String str21 = property10.getAsShortText(locale20);
        java.util.Locale locale23 = null;
        try {
            org.joda.time.DateTime dateTime24 = property10.setCopy("Mon", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Mon\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int33 = dividedDateTimeField24.getDifference((long) 52, (long) (short) -1);
        long long35 = dividedDateTimeField24.roundFloor((long) 70);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime13 = dateTime4.withDurationAdded((-14399502L), (-2001));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 4, (-70));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-280L) + "'", long2 == (-280L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) 14400000, (java.lang.Number) (-91));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate11);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        int int16 = property15.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(14400000, (int) (byte) 0, (-91), (-70), 91, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableInstant readableInstant10 = null;
        try {
            int int11 = dateTime4.compareTo(readableInstant10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        boolean boolean17 = dateTime15.isAfter((long) 'a');
        int int18 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.minusYears((-4));
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        try {
            long long31 = offsetDateTimeField26.addWrapField((long) (byte) 10, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekyearOfCentury();
        try {
            long long18 = zonedChronology7.getDateTimeMillis((int) (byte) -1, (int) (byte) 100, (int) (short) 1, 52, 0, (int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(99);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime7.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        try {
            long long50 = offsetDateTimeField26.add(0L, (long) 360000000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360001970 for weekyear must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology7.yearOfCentury();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks(0);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((-360000000L), 365);
        org.joda.time.DateTime dateTime13 = dateTime8.minusYears(0);
        org.joda.time.DateTime.Property property14 = dateTime13.monthOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime8 = property7.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTimeField dateTimeField10 = property7.getField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) '#');
        java.lang.String str9 = dateTimeZone8.getID();
        org.joda.time.Chronology chronology10 = iSOChronology4.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField11 = iSOChronology4.millis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:35" + "'", str9.equals("+00:35"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) '4', (-91));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime4.toGregorianCalendar();
        int int8 = dateTime4.getDayOfMonth();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("5");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"5/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTime0.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.hourOfHalfday();
        boolean boolean8 = iSOChronology4.equals((java.lang.Object) false);
        java.lang.String str9 = iSOChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str9.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        int int10 = dateTime4.getSecondOfDay();
        org.joda.time.Chronology chronology11 = dateTime4.getChronology();
        boolean boolean13 = dateTime4.isEqual((long) (byte) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone3.isLocalDateTimeGap(localDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        try {
            long long33 = offsetDateTimeField26.set((long) 12, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970-01-05T04:00:00+100:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970-01-05T04:00:00+100:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        java.util.Locale locale20 = null;
        java.lang.String str21 = property10.getAsShortText(locale20);
        int int22 = property10.getLeapAmount();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.year();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number8 = illegalFieldValueException2.getLowerBound();
        java.lang.String str9 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int31 = dividedDateTimeField24.getMinimumValue();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 0, chronology35);
        org.joda.time.DateTime dateTime39 = dateTime36.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property40 = dateTime36.dayOfWeek();
        java.util.Date date41 = dateTime36.toDate();
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.DateTime dateTime44 = dateTime36.withDurationAdded(readableDuration42, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay45 = dateTime36.toTimeOfDay();
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = dividedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) timeOfDay45, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(timeOfDay45);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(32, 91, 70, 0, (int) (short) -1, (-4), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[dayOfWeek]", (java.lang.Number) (byte) 10, (java.lang.Number) 109, (java.lang.Number) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        long long29 = dividedDateTimeField24.remainder(31435200000L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 31449600000L + "'", long29 == 31449600000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(240, 52, 2000, (-91), 109, 1970, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -91 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property10 = dateTime6.dayOfWeek();
        java.util.Date date11 = dateTime6.toDate();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime6.withDurationAdded(readableDuration12, (int) (byte) 100);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 2000, 14400000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
        int int12 = dateTime6.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTimeISO();
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "5", 2000);
        java.io.Writer writer17 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, readableInstant20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 0, chronology21);
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(100L, 1);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.DateTime dateTime27 = dateTime25.withTimeAtStartOfDay();
        int int28 = dateTime27.getDayOfMonth();
        org.joda.time.DateTime dateTime30 = dateTime27.withMillisOfSecond(99);
        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
        try {
            dateTimeFormatter0.printTo(writer17, (org.joda.time.ReadableInstant) dateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14400 + "'", int12 == 14400);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-2001) + "'", int16 == (-2001));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str26.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-14399901L) + "'", long31 == (-14399901L));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime11.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime6.toGregorianCalendar();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(19, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime12.era();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime12.withPeriodAdded(readablePeriod15, (int) (short) 1);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.centuries();
        org.joda.time.DurationField durationField14 = zonedChronology7.weeks();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType15, (-2001));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.halfdayOfDay();
        org.joda.time.Chronology chronology10 = zonedChronology7.withUTC();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "����-��-��T08:00:00");
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 0, chronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.dayOfYear();
        org.joda.time.DurationField durationField17 = zonedChronology14.eras();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(0, 4, 0, 109, (-4), 3, 0, (org.joda.time.Chronology) zonedChronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 109 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra(1970);
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology16.dayOfYear();
        boolean boolean19 = property8.equals((java.lang.Object) zonedChronology16);
        org.joda.time.DurationField durationField20 = zonedChronology16.halfdays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withTime((int) (byte) 1, (-2001), 3168, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2001 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) 3168);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal((long) 91);
        java.lang.Class<?> wildcardClass11 = cachedDateTimeZone4.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Monday", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Monday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology0.add(readablePeriod7, (long) (short) 0, (int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = gregorianChronology0.get(readablePeriod11, (long) 91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        java.util.Date date15 = dateTime14.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        java.lang.Object obj6 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int10 = dateTimeZone8.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj6, dateTimeZone8);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(0);
        boolean boolean14 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property23 = dateTime22.monthOfYear();
        org.joda.time.DateTime.Property property24 = dateTime22.secondOfDay();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, chronology28);
        org.joda.time.DateTime dateTime32 = dateTime29.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property33 = dateTime29.dayOfWeek();
        org.joda.time.DateTime dateTime34 = property33.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) (-91), (java.lang.Number) (-3092342396832L), (java.lang.Number) 109);
        int int40 = dateTime22.get(dateTimeFieldType35);
        try {
            org.joda.time.DateTime dateTime42 = dateTime4.withField(dateTimeFieldType35, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 360000000 + "'", int10 == 360000000);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        int int10 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime8.withMinuteOfHour(15);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970-01-05T00:00:00.000+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        boolean boolean17 = dateTime15.isAfter((long) 'a');
        int int18 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime15);
        int int19 = dateTime15.getHourOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology9.dayOfYear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology9);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology9.weekyear();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology9.hourOfHalfday();
        org.joda.time.DurationField durationField15 = zonedChronology9.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay13 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime dateTime15 = dateTime4.plusMillis(1970);
        org.joda.time.DateTime dateTime17 = dateTime15.plusDays(2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField26.getMaximumShortTextLength(locale29);
        boolean boolean31 = offsetDateTimeField26.isSupported();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-263361600091L), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-526723200182L) + "'", long2 == (-526723200182L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour((int) '#');
        org.joda.time.DateTime.Property property15 = dateTime11.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.String str17 = dateTime11.toString(dateTimeFormatter16);
        org.joda.time.ReadWritableInstant readWritableInstant18 = null;
        try {
            int int21 = dateTimeFormatter16.parseInto(readWritableInstant18, "ZonedChronology[ISOChronology[UTC], +100:00]", 14400);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-W02" + "'", str17.equals("1970-W02"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime7.monthOfYear();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance(chronology12, dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology16.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology16.dayOfYear();
        boolean boolean19 = property8.equals((java.lang.Object) zonedChronology16);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        long long23 = zonedChronology16.add(readablePeriod20, (long) 3168, 0);
        org.joda.time.DurationField durationField24 = zonedChronology16.weeks();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3168L + "'", long23 == 3168L);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        int int10 = dateTime9.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfSecond(99);
        boolean boolean13 = dateTime12.isAfterNow();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("04:00:00.000+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"04:00:00.000+100:00\" is malformed at \":00:00.000+100:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        long long30 = dividedDateTimeField24.getDifferenceAsLong(240L, 1L);
        org.joda.time.DurationField durationField31 = dividedDateTimeField24.getDurationField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        int int14 = dateTime12.getYear();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.lang.String str5 = dateTimeZone1.getShortName((long) 91);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        long long69 = offsetDateTimeField26.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField26.getType();
        long long72 = offsetDateTimeField26.roundHalfEven((long) 109);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-619200000L) + "'", long69 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-619200000L) + "'", long72 == (-619200000L));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 2);
        org.joda.time.TimeOfDay timeOfDay8 = dateTime4.toTimeOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str7 = dateTimeZone2.getShortName(96L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 14400000, dateTimeZone2);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.DateTime dateTime13 = dateTime11.withCenturyOfEra(1970);
        org.joda.time.Instant instant14 = dateTime13.toInstant();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) 1);
        java.lang.Object obj12 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int16 = dateTimeZone14.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj12, dateTimeZone14);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, readableInstant20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 0, chronology21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology21, dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology25.dayOfYear();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology25);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        org.joda.time.DateTime dateTime30 = dateTime17.withFields((org.joda.time.ReadablePartial) localDate29);
        int int31 = offsetDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDate29);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 360000000 + "'", int16 == 360000000);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        int int11 = dateTime10.getYear();
        java.lang.String str12 = dateTime10.toString();
        java.lang.Object obj14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int18 = dateTimeZone16.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj14, dateTimeZone16);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
        org.joda.time.DateTime dateTime21 = dateTime10.withZone(dateTimeZone16);
        long long24 = dateTimeZone16.adjustOffset(360000000L, true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T00:00:00.000+100:00" + "'", str12.equals("1970-01-05T00:00:00.000+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 360000000 + "'", int18 == 360000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 360000000L + "'", long24 == 360000000L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 0, chronology32);
        org.joda.time.DateTime dateTime36 = dateTime33.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property37 = dateTime33.dayOfWeek();
        java.util.Date date38 = dateTime33.toDate();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.withDurationAdded(readableDuration39, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime33.toTimeOfDay();
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant45, readableInstant46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) 0, chronology47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology51 = org.joda.time.chrono.ZonedChronology.getInstance(chronology47, dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = zonedChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = zonedChronology51.dayOfYear();
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology51);
        org.joda.time.DateTimeField dateTimeField55 = zonedChronology51.weekyear();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime63 = dateTime60.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property64 = dateTime60.dayOfWeek();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property64.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, dateTimeFieldType66, (int) (byte) -1, 91, 0);
        java.util.Locale locale71 = null;
        int int72 = offsetDateTimeField70.getMaximumShortTextLength(locale71);
        java.lang.String str74 = offsetDateTimeField70.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 0, chronology78);
        org.joda.time.DateTime dateTime81 = dateTime79.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime83 = dateTime81.plusWeeks(0);
        org.joda.time.DateTime dateTime86 = dateTime83.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime87 = dateTime86.toLocalTime();
        int[] intArray90 = new int[] { 14400, (byte) 1 };
        int int91 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) localTime87, intArray90);
        int[] intArray93 = offsetDateTimeField26.addWrapPartial((org.joda.time.ReadablePartial) timeOfDay42, (int) (short) 100, intArray90, (int) (short) 0);
        long long95 = offsetDateTimeField26.roundCeiling((long) (byte) 100);
        org.joda.time.DateTimeField dateTimeField96 = offsetDateTimeField26.getWrappedField();
        org.joda.time.DurationField durationField97 = offsetDateTimeField26.getLeapDurationField();
        long long99 = offsetDateTimeField26.roundHalfFloor(100L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(zonedChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1969" + "'", str74.equals("1969"));
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localTime87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 91 + "'", int91 == 91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 31435200000L + "'", long95 == 31435200000L);
        org.junit.Assert.assertNotNull(dateTimeField96);
        org.junit.Assert.assertNotNull(durationField97);
        org.junit.Assert.assertTrue("'" + long99 + "' != '" + (-619200000L) + "'", long99 == (-619200000L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        long long30 = remainderDateTimeField28.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int5 = dateTimeZone3.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj1, dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        int int8 = dateTime7.getSecondOfMinute();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime7.toCalendar(locale9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime7.withDurationAdded(readableDuration11, (-1));
        org.joda.time.DateTime dateTime15 = dateTime7.plusMinutes(109);
        try {
            org.joda.time.DateTime dateTime19 = dateTime15.withDate(70, 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 360000000 + "'", int5 == 360000000);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        boolean boolean7 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay6 = dateTime4.toTimeOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime10 = dateTime7.withWeekyear(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 32, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology20.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology20.dayOfYear();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology20.minuteOfDay();
        org.joda.time.DateTime dateTime25 = dateTime12.toDateTime((org.joda.time.Chronology) zonedChronology20);
        org.joda.time.DateTime dateTime28 = dateTime12.withDurationAdded((long) 19, 3);
        java.util.Locale locale29 = null;
        java.util.Calendar calendar30 = dateTime28.toCalendar(locale29);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(calendar30);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
        int int12 = dateTime6.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTimeISO();
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "Property[dayOfMonth]", (-1));
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone18.isLocalDateTimeGap(localDateTime19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, readableInstant24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 0, chronology25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance(chronology25, dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = zonedChronology29.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField31 = zonedChronology29.dayOfYear();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology29);
        boolean boolean33 = cachedDateTimeZone21.equals((java.lang.Object) zonedChronology29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone21);
        try {
            org.joda.time.LocalTime localTime36 = dateTimeFormatter34.parseLocalTime("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14400 + "'", int12 == 14400);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean5 = cachedDateTimeZone4.isFixed();
        long long7 = cachedDateTimeZone4.previousTransition(0L);
        int int9 = cachedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        int int10 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime8.plusHours((int) (byte) 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number8 = illegalFieldValueException5.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException5.getDurationFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-4));
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance(chronology5, dateTimeZone8);
        long long13 = dateTimeZone8.convertLocalToUTC(0L, false, (long) 360000000);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) (-4), dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-360000000L) + "'", long13 == (-360000000L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property13 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
        org.joda.time.DateTime dateTime15 = property13.roundHalfFloorCopy();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) '4', (int) (byte) 0, 8, (-91), 91, chronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -91 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        long long10 = gregorianChronology0.add((long) '4', (-58665592011L), 1970);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-115571216261618L) + "'", long10 == (-115571216261618L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("32", (-4), 3, 5, ' ', 0, 1970, (int) (byte) 10, false, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.get((long) 10);
        int int65 = offsetDateTimeField26.getMaximumValue();
        long long67 = offsetDateTimeField26.roundHalfFloor((long) '4');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-619200000L) + "'", long67 == (-619200000L));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 0, chronology7);
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillisOfDay((int) (byte) 100);
        int int14 = dateTime8.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTimeISO();
        int int18 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "5", 2000);
        int int21 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "hi!", 14400000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 14400 + "'", int14 == 14400);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2001) + "'", int18 == (-2001));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-14400001) + "'", int21 == (-14400001));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str7 = dateTimeZone2.getShortName(96L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 14400000, dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone2.isLocalDateTimeGap(localDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.get((long) 10);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.lang.String str67 = offsetDateTimeField26.getAsText((long) (short) 10);
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField26.getAsShortText(21L, locale69);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1969" + "'", str67.equals("1969"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1969" + "'", str70.equals("1969"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        int int12 = dateTime10.getYear();
//        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (short) 100);
//        int int15 = dateTime14.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 376 + "'", int15 == 376);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTimeISO();
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour((int) '#');
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant47, readableInstant48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) 0, chronology49);
        org.joda.time.DateTime dateTime52 = dateTime50.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime54 = dateTime52.plusWeeks(0);
        org.joda.time.DateTime dateTime57 = dateTime54.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localTime58, 32, locale60);
        long long63 = offsetDateTimeField26.roundHalfEven((long) (short) 10);
        java.util.Locale locale66 = null;
        try {
            long long67 = offsetDateTimeField26.set((long) 12, "+100:00", locale66);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+100:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "32" + "'", str61.equals("32"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-619200000L) + "'", long63 == (-619200000L));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 365, number2, (java.lang.Number) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime15 = dateTime13.withYearOfEra((int) (short) 100);
        int int16 = dateTime15.getMillisOfDay();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 14400010 + "'", int16 == 14400010);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.DurationField durationField31 = offsetDateTimeField26.getDurationField();
        long long33 = offsetDateTimeField26.roundHalfCeiling(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField26.getType();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-619200000L) + "'", long33 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (-4));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.DurationField durationField31 = offsetDateTimeField26.getDurationField();
        long long33 = offsetDateTimeField26.roundHalfCeiling(0L);
        long long35 = offsetDateTimeField26.roundHalfCeiling((-360000000L));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-619200000L) + "'", long33 == (-619200000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-619200000L) + "'", long35 == (-619200000L));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.minuteOfHour();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        boolean boolean14 = gregorianChronology8.equals((java.lang.Object) cachedDateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.Chronology chronology16 = gregorianChronology7.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        long long18 = cachedDateTimeZone13.nextTransition(32054399999L);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(2, 10, 95, 100, (int) (short) 10, 365, 360000000, (org.joda.time.DateTimeZone) cachedDateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32054399999L + "'", long18 == 32054399999L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        int int11 = dateTime10.getYear();
        java.lang.String str12 = dateTime10.toString();
        java.lang.Object obj14 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int18 = dateTimeZone16.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(obj14, dateTimeZone16);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone16);
        org.joda.time.DateTime dateTime21 = dateTime10.withZone(dateTimeZone16);
        int int22 = dateTime21.getDayOfWeek();
        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-05T00:00:00.000+100:00" + "'", str12.equals("1970-01-05T00:00:00.000+100:00"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 360000000 + "'", int18 == 360000000);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-14400000L) + "'", long23 == (-14400000L));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 'a');
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("����-��-��T08:00:00", 5, (-4), (-91));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for ����-��-��T08:00:00 must be in the range [-4,-91]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Object obj1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int5 = dateTimeZone3.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj1, dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 10, dateTimeZone3);
        int int8 = dateTime7.getSecondOfMinute();
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime7.toCalendar(locale9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime7.withDurationAdded(readableDuration11, (-1));
        org.joda.time.DateTime.Property property14 = dateTime7.era();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 360000000 + "'", int5 == 360000000);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.halfdayOfDay();
        try {
            long long13 = iSOChronology4.getDateTimeMillis((long) (short) -1, 3168, 99, (-4), 109);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3168 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 0, chronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology15.dayOfYear();
        org.joda.time.DurationField durationField18 = zonedChronology15.months();
        org.joda.time.DateTime dateTime19 = dateTime7.withChronology((org.joda.time.Chronology) zonedChronology15);
        org.joda.time.DateTime dateTime21 = dateTime7.plusWeeks((-70));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance(chronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.dayOfYear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology8);
        int int13 = dateTime12.getMinuteOfDay();
        org.joda.time.DateTime dateTime14 = dateTime12.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 240 + "'", int13 == 240);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) cachedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology0.add(readablePeriod7, (long) (short) 0, (int) (byte) 1);
        org.joda.time.Chronology chronology11 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 10L, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.addWrapField((long) (short) 100, (int) (short) 0);
        long long30 = dividedDateTimeField24.getDifferenceAsLong((long) 360000000, 20L);
        int int31 = dividedDateTimeField24.getMinimumValue();
        long long34 = dividedDateTimeField24.addWrapField(0L, (int) (byte) 0);
        int int36 = dividedDateTimeField24.get((long) 365);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 0, chronology40);
        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime46 = dateTime41.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime dateTime48 = dateTime41.plusMinutes(360000000);
        org.joda.time.DateTime dateTime50 = dateTime41.withWeekOfWeekyear((int) ' ');
        org.joda.time.YearMonthDay yearMonthDay51 = dateTime50.toYearMonthDay();
        java.util.Locale locale52 = null;
        try {
            java.lang.String str53 = dividedDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay51, locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 399L + "'", long30 == 399L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(yearMonthDay51);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, (-3092342396832L), 91);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology0.get(readablePeriod5, (long) 10, (-14399502L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3092342396832L) + "'", long4 == (-3092342396832L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.DurationField durationField11 = zonedChronology7.minutes();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray14 = zonedChronology7.get(readablePeriod12, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks(0);
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours(360000000);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        java.util.Date date10 = dateTime5.toDate();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfYear();
        long long20 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime22 = dateTime16.withCenturyOfEra(12);
        java.lang.String str23 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime22);
        java.lang.String str25 = dateTimeFormatter0.print((-58665599891L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1270-01-05T04:00:00.000+100:00" + "'", str23.equals("1270-01-05T04:00:00.000+100:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1968-02-26T04:00:00.109+100:00" + "'", str25.equals("1968-02-26T04:00:00.109+100:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[dayOfWeek]" + "'", str9.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.yearOfCentury();
        try {
            long long18 = zonedChronology7.getDateTimeMillis((long) (byte) 0, 14400, 15, (int) ' ', 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14400 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays(109);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 100, 14400000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [14400000,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology4.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        org.joda.time.DateTime dateTime15 = dateTime14.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for hi! is not supported"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.Object obj3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int7 = dateTimeZone5.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj3, dateTimeZone5);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks(0);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(99);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime12);
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection16 = jodaTimePermission15.newPermissionCollection();
        boolean boolean17 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission15);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 360000000 + "'", int7 == 360000000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(permissionCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DurationField durationField11 = property8.getDurationField();
        int int12 = property8.getMaximumValueOverall();
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = property8.getDifference(readableInstant13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = dateTimeZone16.isLocalDateTimeGap(localDateTime17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, readableInstant22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 0, chronology23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology23, dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology27.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology27.dayOfYear();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology27);
        boolean boolean31 = cachedDateTimeZone19.equals((java.lang.Object) zonedChronology27);
        org.joda.time.DurationField durationField32 = zonedChronology27.hours();
        boolean boolean33 = property8.equals((java.lang.Object) zonedChronology27);
        org.joda.time.ReadablePartial readablePartial34 = null;
        try {
            int[] intArray36 = zonedChronology27.get(readablePartial34, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1970-01-05T04:00:00+100:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property39 = dateTime35.dayOfWeek();
        java.util.Date date40 = dateTime35.toDate();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime35.withDurationAdded(readableDuration41, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime35.toTimeOfDay();
        int int45 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay44);
        org.joda.time.DurationField durationField46 = offsetDateTimeField26.getDurationField();
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant48, readableInstant49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 0, chronology50);
        org.joda.time.DateTime dateTime54 = dateTime51.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property55 = dateTime51.dayOfWeek();
        java.util.Date date56 = dateTime51.toDate();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime51.withDurationAdded(readableDuration57, (int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay60 = dateTime51.toTimeOfDay();
        java.util.Locale locale62 = null;
        java.lang.String str63 = offsetDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) timeOfDay60, (int) (short) 1, locale62);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 91 + "'", int45 == 91);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(timeOfDay60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1" + "'", str63.equals("1"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 12, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property17 = dateTime13.dayOfWeek();
        java.util.Date date18 = dateTime13.toDate();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean22 = dateTimeZone20.isStandardOffset((long) (short) -1);
        java.lang.String str24 = dateTimeZone20.getShortName((long) 1);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime13.toMutableDateTime(dateTimeZone20);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 0, chronology29);
        org.joda.time.DateTime dateTime33 = dateTime30.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property34 = dateTime30.dayOfWeek();
        java.util.Date date35 = dateTime30.toDate();
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime30.withDurationAdded(readableDuration36, (int) (byte) 100);
        org.joda.time.DateTime.Property property39 = dateTime30.minuteOfHour();
        org.joda.time.DateTime dateTime41 = dateTime30.minusMinutes(2);
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime41);
        boolean boolean43 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime41);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+100:00" + "'", str24.equals("+100:00"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.months();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.monthOfYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        java.lang.String str8 = dateTime7.toString();
        org.joda.time.DateTime dateTime9 = dateTime7.withTimeAtStartOfDay();
        java.util.Date date10 = dateTime9.toDate();
        org.joda.time.DateTime.Property property11 = dateTime9.yearOfEra();
        int int12 = property11.getMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str8.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime14 = dateTime9.withMillisOfDay((int) (byte) 100);
        int int15 = dateTime9.getSecondOfDay();
        org.joda.time.Chronology chronology16 = dateTime9.getChronology();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-4), (-4), 1970, (int) 'a', 14400, chronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 14400 + "'", int15 == 14400);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        int int8 = cachedDateTimeZone4.getOffset((long) 4);
        long long10 = cachedDateTimeZone4.previousTransition((long) 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8L + "'", long10 == 8L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 1);
        long long8 = fixedDateTimeZone4.previousTransition((-263361600091L));
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 0, chronology12);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(100L, 1);
        java.lang.String str17 = dateTime16.toString();
        org.joda.time.DateTime dateTime18 = dateTime16.withTimeAtStartOfDay();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        boolean boolean20 = fixedDateTimeZone4.equals((java.lang.Object) dateTime18);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-263361600091L) + "'", long8 == (-263361600091L));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str17.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(99);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(95);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology22.dayOfYear();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology22.weekyear();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology22.hourOfHalfday();
        org.joda.time.DurationField durationField28 = zonedChronology22.weekyears();
        org.joda.time.DateTime dateTime29 = dateTime14.withChronology((org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTime dateTime31 = dateTime29.plusMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.weekyears();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray16 = zonedChronology7.get(readablePeriod14, (-58665592011L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType22, 15);
        long long27 = dividedDateTimeField24.getDifferenceAsLong((long) (short) 0, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField24);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumTextLength(locale29);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime dateTime11 = dateTime4.plus(100L);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance(chronology15, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology19.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology19.secondOfDay();
        int int22 = dateTime11.get(dateTimeField21);
        org.joda.time.DateTime dateTime24 = dateTime11.plusMinutes((-70));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 14400 + "'", int22 == 14400);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology7.weekyearOfCentury();
        try {
            long long15 = zonedChronology7.getDateTimeMillis(1, (int) ' ', (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks(0);
        java.util.Date date9 = dateTime6.toDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.joda.time.DateTime dateTime12 = property8.addToCopy((long) 1);
        int int13 = dateTime12.getYearOfCentury();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 70 + "'", int13 == 70);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (-360000091L), (java.lang.Number) 12, (java.lang.Number) (-1.0f));
        java.lang.String str31 = illegalFieldValueException30.getIllegalStringValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-70));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 70 + "'", int1 == 70);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        java.util.Locale locale66 = null;
        int int67 = offsetDateTimeField26.getMaximumTextLength(locale66);
        int int68 = offsetDateTimeField26.getMaximumValue();
        java.lang.String str70 = offsetDateTimeField26.getAsText(96L);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = offsetDateTimeField26.getType();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1969" + "'", str70.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 3168);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.DurationField durationField65 = offsetDateTimeField26.getLeapDurationField();
        int int66 = offsetDateTimeField26.getOffset();
        java.util.Locale locale69 = null;
        try {
            long long70 = offsetDateTimeField26.set((long) 2, "", locale69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        try {
            org.joda.time.DateTime dateTime17 = dateTime14.withEra(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 0, chronology4);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property9 = dateTime5.dayOfWeek();
        java.util.Date date10 = dateTime5.toDate();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property19 = dateTime16.dayOfYear();
        long long20 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime22 = dateTime16.withCenturyOfEra(12);
        java.lang.String str23 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime22);
        java.lang.String str25 = dateTimeFormatter0.print((-58665599891L));
        java.lang.StringBuffer stringBuffer26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer26, readableInstant27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1270-01-05T04:00:00.000+100:00" + "'", str23.equals("1270-01-05T04:00:00.000+100:00"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1968-02-26T04:00:00.109+100:00" + "'", str25.equals("1968-02-26T04:00:00.109+100:00"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-4));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.DateTime dateTime9 = dateTime5.minusMonths(10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        long long64 = offsetDateTimeField26.roundHalfEven((long) (-4));
        try {
            long long67 = offsetDateTimeField26.add((long) 14400, (-14400001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -14398032 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-619200000L) + "'", long64 == (-619200000L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Mon");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Mon' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.withDayOfYear(2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        int int6 = dateTime4.getMinuteOfHour();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        int int11 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property12 = dateTime4.minuteOfHour();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 0, chronology16);
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(100L, 1);
        java.lang.String str21 = dateTime20.toString();
        org.joda.time.DateTime dateTime22 = dateTime20.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        boolean boolean26 = dateTimeZone24.isStandardOffset((long) (short) -1);
        java.lang.String str28 = dateTimeZone24.getShortName((long) 1);
        org.joda.time.DateTime dateTime29 = dateTime22.withZone(dateTimeZone24);
        long long30 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime31 = property12.withMaximumValue();
        org.joda.time.DateTime.Property property32 = dateTime31.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-05T04:00:00.100+100:00" + "'", str21.equals("1970-01-05T04:00:00.100+100:00"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+100:00" + "'", str28.equals("+100:00"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 240L + "'", long30 == 240L);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        int int4 = dateTimeZone2.getOffsetFromLocal(10L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(obj0, dateTimeZone2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 0, chronology11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology15.dayOfYear();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology15);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology15.weekyear();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, readableInstant22);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 0, chronology23);
        org.joda.time.DateTime dateTime27 = dateTime24.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property28 = dateTime24.dayOfWeek();
        org.joda.time.DateTime dateTime29 = property28.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) -1, 91, 0);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField34.getMaximumShortTextLength(locale35);
        java.lang.String str38 = offsetDateTimeField34.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, readableInstant41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 0, chronology42);
        org.joda.time.DateTime dateTime45 = dateTime43.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime47 = dateTime45.plusWeeks(0);
        org.joda.time.DateTime dateTime50 = dateTime47.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime51 = dateTime50.toLocalTime();
        int[] intArray54 = new int[] { 14400, (byte) 1 };
        int int55 = offsetDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localTime51, intArray54);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 0, chronology59);
        org.joda.time.DateTime dateTime62 = dateTime60.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime64 = dateTime62.plusWeeks(0);
        org.joda.time.DateTime dateTime67 = dateTime64.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime68 = dateTime67.toLocalTime();
        int[] intArray69 = new int[] {};
        int int70 = offsetDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localTime68, intArray69);
        int int72 = offsetDateTimeField34.getMinimumValue(0L);
        org.joda.time.DurationField durationField73 = offsetDateTimeField34.getLeapDurationField();
        java.util.Locale locale74 = null;
        int int75 = offsetDateTimeField34.getMaximumTextLength(locale74);
        long long77 = offsetDateTimeField34.roundHalfFloor((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = offsetDateTimeField34.getType();
        try {
            org.joda.time.DateTime dateTime80 = dateTime5.withField(dateTimeFieldType78, 240);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 240 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localTime51);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 91 + "'", int55 == 91);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(localTime68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 91 + "'", int72 == 91);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-619200000L) + "'", long77 == (-619200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTime dateTime10 = property8.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[dayOfWeek]" + "'", str9.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 0, chronology10);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology10, dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, 1970, 14400010, 2, (int) (byte) 10, 70, 19, (org.joda.time.Chronology) zonedChronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        boolean boolean14 = gregorianChronology8.equals((java.lang.Object) cachedDateTimeZone13);
        long long17 = cachedDateTimeZone13.convertLocalToUTC((long) 3168, false);
        boolean boolean18 = dateTime7.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3169L + "'", long17 == 3169L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DurationField durationField10 = zonedChronology7.eras();
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.clockhourOfHalfday();
        java.lang.String str12 = zonedChronology7.toString();
        try {
            long long17 = zonedChronology7.getDateTimeMillis(2000, (-2001), 1, (-14400001));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -14400001 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        java.lang.String str18 = cachedDateTimeZone4.getShortName((long) (byte) 100);
        java.util.Locale locale20 = null;
        java.lang.String str21 = cachedDateTimeZone4.getName((long) (short) 1, locale20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-00:00:00.001" + "'", str21.equals("-00:00:00.001"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.weekOfWeekyear();
        org.joda.time.Chronology chronology8 = iSOChronology4.withUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.withDurationAdded(readableDuration10, (int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime4.plus(readableDuration13);
        int int15 = dateTime14.getMinuteOfHour();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getMinimumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        java.util.Locale locale12 = null;
        java.lang.String str13 = property8.getAsText(locale12);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Monday" + "'", str13.equals("Monday"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay((int) (byte) 100);
        int int10 = dateTime4.getSecondOfDay();
        org.joda.time.Chronology chronology11 = dateTime4.getChronology();
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14400 + "'", int10 == 14400);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str6 = dateTimeZone1.getShortName(96L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        boolean boolean13 = dateTime11.isBefore((long) 5);
        org.joda.time.DateTime dateTime15 = dateTime11.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths(2000);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.clockhourOfHalfday();
        java.lang.String str10 = zonedChronology7.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], +100:00]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], +100:00]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 70, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 0, chronology18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology22.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology22.dayOfYear();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology22.weekyear();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology22.hourOfHalfday();
        org.joda.time.DurationField durationField28 = zonedChronology22.weekyears();
        org.joda.time.DateTime dateTime29 = dateTime14.withChronology((org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTime dateTime31 = dateTime14.minusSeconds((int) (byte) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            long long4 = dateTimeFormatter2.parseMillis("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property10 = dateTime9.monthOfYear();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology14, dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology18.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology18.dayOfYear();
        boolean boolean21 = property10.equals((java.lang.Object) zonedChronology18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        long long25 = zonedChronology18.add(readablePeriod22, (long) 3168, 0);
        boolean boolean26 = jodaTimePermission1.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3168L + "'", long25 == 3168L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
        int int8 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime12 = dateTime4.withWeekyear((-70));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14400000 + "'", int8 == 14400000);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) 0, chronology51);
        org.joda.time.DateTime dateTime54 = dateTime52.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks(0);
        org.joda.time.DateTime dateTime59 = dateTime56.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
        int[] intArray61 = new int[] {};
        int int62 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray61);
        int int64 = offsetDateTimeField26.getMinimumValue(0L);
        int int65 = offsetDateTimeField26.getOffset();
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant68, readableInstant69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) 0, chronology70);
        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology74 = org.joda.time.chrono.ZonedChronology.getInstance(chronology70, dateTimeZone73);
        org.joda.time.DateTimeField dateTimeField75 = zonedChronology74.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField76 = zonedChronology74.dayOfYear();
        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology74);
        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) zonedChronology74);
        org.joda.time.ReadableInstant readableInstant80 = null;
        org.joda.time.ReadableInstant readableInstant81 = null;
        org.joda.time.Chronology chronology82 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant80, readableInstant81);
        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime((long) 0, chronology82);
        org.joda.time.DateTimeZone dateTimeZone85 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology86 = org.joda.time.chrono.ZonedChronology.getInstance(chronology82, dateTimeZone85);
        org.joda.time.DateTimeField dateTimeField87 = zonedChronology86.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField88 = zonedChronology86.dayOfYear();
        org.joda.time.DateTime dateTime89 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology86);
        org.joda.time.DateTimeField dateTimeField90 = zonedChronology86.minuteOfDay();
        org.joda.time.DateTime dateTime91 = dateTime78.toDateTime((org.joda.time.Chronology) zonedChronology86);
        org.joda.time.LocalTime localTime92 = dateTime91.toLocalTime();
        int int93 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime92);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localTime60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 91 + "'", int64 == 91);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(zonedChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(chronology82);
        org.junit.Assert.assertNotNull(dateTimeZone85);
        org.junit.Assert.assertNotNull(zonedChronology86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertNotNull(dateTimeField88);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(dateTimeField90);
        org.junit.Assert.assertNotNull(dateTime91);
        org.junit.Assert.assertNotNull(localTime92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 91 + "'", int93 == 91);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime4.minusMonths(19);
        org.joda.time.LocalDate localDate9 = dateTime4.toLocalDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        int int10 = property8.getLeapAmount();
        org.joda.time.DurationField durationField11 = property8.getDurationField();
        long long14 = durationField11.subtract((-3092342396832L), (long) (-70));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-3086294396832L) + "'", long14 == (-3086294396832L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology7.hourOfHalfday();
        org.joda.time.DurationField durationField13 = zonedChronology7.centuries();
        org.joda.time.DurationField durationField14 = zonedChronology7.weeks();
        java.lang.Class<?> wildcardClass15 = zonedChronology7.getClass();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        int int48 = offsetDateTimeField26.getMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 0, chronology5);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(100L, 1);
        org.joda.time.DateTime dateTime11 = dateTime6.withMillisOfDay((int) (byte) 100);
        int int12 = dateTime6.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTimeISO();
        int int16 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime13, "Property[dayOfMonth]", (-1));
        boolean boolean17 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 14400 + "'", int12 == 14400);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.DurationField durationField48 = offsetDateTimeField26.getLeapDurationField();
        long long50 = offsetDateTimeField26.roundHalfEven((long) (byte) 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, (int) 'a');
        long long54 = offsetDateTimeField52.roundFloor(0L);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-619200000L) + "'", long50 == (-619200000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-619200000L) + "'", long54 == (-619200000L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfWeek();
        java.util.Date date9 = dateTime4.toDate();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property18 = dateTime15.dayOfYear();
        long long19 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        int int20 = property10.getLeapAmount();
        java.lang.String str21 = property10.getAsString();
        long long22 = property10.remainder();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 14400000L + "'", long22 == 14400000L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 14400010);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(0L);
        java.lang.String str8 = cachedDateTimeZone4.getNameKey((long) 3168);
        int int10 = cachedDateTimeZone4.getOffsetFromLocal((long) 91);
        int int12 = cachedDateTimeZone4.getOffsetFromLocal((-58665592011L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("Mon");
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission5.newPermissionCollection();
        java.lang.String str7 = jodaTimePermission5.toString();
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Mon\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Mon\")"));
        org.junit.Assert.assertNotNull(permissionCollection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Mon\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"Mon\")"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "5", (int) ' ', (int) (byte) 0);
        long long23 = fixedDateTimeZone21.nextTransition((long) (short) 1);
        int int25 = fixedDateTimeZone21.getOffset((long) 15);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 0, chronology29);
        org.joda.time.DateTime dateTime33 = dateTime30.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property34 = dateTime30.dayOfWeek();
        java.util.Date date35 = dateTime30.toDate();
        org.joda.time.DateTime.Property property36 = dateTime30.dayOfMonth();
        int int37 = dateTime30.getMinuteOfHour();
        org.joda.time.LocalDateTime localDateTime38 = dateTime30.toLocalDateTime();
        boolean boolean39 = fixedDateTimeZone21.isLocalDateTimeGap(localDateTime38);
        boolean boolean40 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime38);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (-3086294396832L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3086294396832L) + "'", long2 == (-3086294396832L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 0, chronology8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfYear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology12);
        boolean boolean16 = cachedDateTimeZone4.equals((java.lang.Object) zonedChronology12);
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology12.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(14400, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((int) (byte) 0);
        int int9 = dateTime8.getYear();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(14400);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusHours((-91));
        boolean boolean15 = dateTime14.isBeforeNow();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 0, chronology3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.DateTimeField dateTimeField11 = zonedChronology7.weekyear();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 0, chronology15);
        org.joda.time.DateTime dateTime19 = dateTime16.withDurationAdded(100L, 1);
        org.joda.time.DateTime.Property property20 = dateTime16.dayOfWeek();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType22, (int) (byte) -1, 91, 0);
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField26.getMaximumShortTextLength(locale27);
        java.lang.String str30 = offsetDateTimeField26.getAsText(98L);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) 0, chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime39 = dateTime37.plusWeeks(0);
        org.joda.time.DateTime dateTime42 = dateTime39.withDurationAdded((-360000000L), 365);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray46 = new int[] { 14400, (byte) 1 };
        int int47 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray46);
        org.joda.time.DurationField durationField48 = offsetDateTimeField26.getLeapDurationField();
        try {
            long long51 = offsetDateTimeField26.add((long) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfWeek must be in the range [91,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 91 + "'", int47 == 91);
        org.junit.Assert.assertNotNull(durationField48);
    }
}

