import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 10.0f, "Property[millisOfDay]");
        illegalFieldValueException17.prependMessage("278");
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        java.lang.Class<?> wildcardClass3 = julianChronology0.getClass();
        java.lang.String str4 = julianChronology0.toString();
        org.joda.time.DurationField durationField5 = julianChronology0.hours();
        try {
            long long11 = julianChronology0.getDateTimeMillis(0L, (int) (short) 10, 1, 34, 86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        boolean boolean4 = property3.isLeap();
        org.joda.time.DateTime dateTime5 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withWeekyear((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        java.lang.String str14 = delegatedDateTimeField13.toString();
        int int16 = delegatedDateTimeField13.get(31L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 23 + "'", int16 == 23);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra((int) ' ', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendTimeZoneShortName();
        boolean boolean17 = dateTimeFormatterBuilder16.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendMinuteOfHour(975);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology22);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.minuteOfDay();
        java.lang.String str26 = gJChronology22.toString();
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) gJChronology22);
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) localDate27, 6, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str26.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(6, 976, 31, (int) 'a', 11, 12775, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, (int) (byte) -1, 975, 1969, 7, (int) 'a', 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        long long15 = delegatedDateTimeField13.roundHalfEven(0L);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = copticChronology16.weekyears();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology16, dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        org.joda.time.Chronology chronology24 = zonedChronology21.withZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = zonedChronology21.getZone();
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology21.centuryOfEra();
        org.joda.time.DurationField durationField27 = zonedChronology21.hours();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder28.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(10L, chronology35);
        org.joda.time.DateTime.Property property37 = dateTime36.millisOfDay();
        boolean boolean38 = property37.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property37.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder33.appendShortText(dateTimeFieldType39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter42 = dateTimeFormatter41.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.append(dateTimePrinter42);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.appendFractionOfDay(16, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder48.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(10L, chronology55);
        org.joda.time.DateTime.Property property57 = dateTime56.millisOfDay();
        boolean boolean58 = property57.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property57.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder53.appendShortText(dateTimeFieldType59);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField66 = gJChronology65.millis();
        org.joda.time.DurationField durationField67 = gJChronology65.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType59, durationField67);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder47.appendSignedDecimal(dateTimeFieldType59, (int) (short) 1, 800);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, durationField27, dateTimeFieldType59);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimePrinter42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.Interval interval5 = localDate3.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        long long6 = dateTimeZone1.convertLocalToUTC(19523904L, false, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 48323904L + "'", long6 == 48323904L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1970, (java.lang.Number) 1.0f, (java.lang.Number) 1969);
        java.lang.Number number17 = illegalFieldValueException16.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1969 + "'", number17.equals(1969));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.plus(readablePeriod8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = copticChronology10.weekyears();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology10, dateTimeZone14);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.Chronology chronology18 = zonedChronology15.withZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime4.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime21 = dateTime19.withWeekyear(100);
        org.joda.time.Chronology chronology22 = dateTime21.getChronology();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600010 + "'", int5 == 57600010);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        int int9 = localDate1.size();
        org.joda.time.LocalDate localDate11 = localDate1.minusWeeks((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder20.appendShortText(dateTimeFieldType26);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 1970, (java.lang.Number) 1.0f, (java.lang.Number) 1969);
        try {
            int int32 = localDate14.get(dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        try {
            int int23 = unsupportedDateTimeField20.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear((int) (byte) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder20.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.appendOptional(dateTimeParser21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendTwoDigitYear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("365");
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone4.equals(obj6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffset((long) 7);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField20.getDurationField();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField20.getAsText((int) (byte) 0, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology19);
        org.joda.time.LocalDate localDate22 = localDate20.plusMonths((int) (short) 1);
        int int23 = localDate18.compareTo((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate localDate25 = localDate18.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property26 = localDate25.dayOfWeek();
        org.joda.time.LocalDate localDate27 = property26.roundCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology29);
        org.joda.time.LocalDate localDate32 = localDate30.plusMonths((int) (short) 1);
        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate32);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology36);
        org.joda.time.LocalDate localDate39 = localDate37.plusMonths((int) (short) 1);
        int int40 = localDate35.compareTo((org.joda.time.ReadablePartial) localDate37);
        boolean boolean41 = partial33.isMatch((org.joda.time.ReadablePartial) localDate35);
        int[] intArray42 = partial33.getValues();
        int[] intArray44 = delegatedDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDate27, 57600010, intArray42, 0);
        java.util.Locale locale46 = null;
        java.lang.String str47 = delegatedDateTimeField13.getAsText((long) (-1), locale46);
        boolean boolean48 = delegatedDateTimeField13.isSupported();
        try {
            long long51 = delegatedDateTimeField13.set((long) 36600000, "JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[UTC]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "22" + "'", str47.equals("22"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.Chronology chronology8 = zonedChronology5.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology5.centuryOfEra();
        org.joda.time.DurationField durationField11 = zonedChronology5.hours();
        java.lang.String str12 = zonedChronology5.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[CopticChronology[UTC], America/Los_Angeles]" + "'", str12.equals("ZonedChronology[CopticChronology[UTC], America/Los_Angeles]"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) (-61219469221024L), "Property[millisOfDay]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.Chronology chronology8 = zonedChronology5.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology5.getZone();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = copticChronology10.weekyears();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology10, dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = copticChronology10.dayOfMonth();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        boolean boolean21 = property20.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType22);
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField25 = copticChronology24.weekyears();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology26.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology24, dateTimeZone28);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology24.dayOfMonth();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(10L, chronology32);
        org.joda.time.DateTime.Property property34 = dateTime33.millisOfDay();
        boolean boolean35 = property34.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property34.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField37.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField23, dateTimeFieldType38, 1, 16, 1735);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) zonedChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField23, (-1));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
//        int int9 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
//        long long11 = property10.remainder();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate1.withPeriodAdded(readablePeriod9, (int) (short) -1);
        int int12 = localDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        try {
            boolean boolean18 = localDate10.isBefore((org.joda.time.ReadablePartial) localTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get(10L);
        java.util.Locale locale38 = null;
        int int39 = offsetDateTimeField32.getMaximumShortTextLength(locale38);
        int int41 = offsetDateTimeField32.get((long) 100);
        long long44 = offsetDateTimeField32.add(1970L, (long) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 24 + "'", int41 == 24);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86401970L + "'", long44 == 86401970L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) 1);
        int int11 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate8);
        boolean boolean12 = partial4.isMatch((org.joda.time.ReadablePartial) localDate6);
        try {
            int int14 = partial4.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        long long24 = unsupportedDateTimeField20.getDifferenceAsLong((long) 1, (long) (byte) -1);
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = unsupportedDateTimeField20.getAsText((long) 1969, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        int int9 = localDate1.size();
        org.joda.time.DateTime dateTime10 = localDate1.toDateTimeAtMidnight();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime2.plusMinutes(10);
        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = copticChronology3.weekyears();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology3, dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology9.getZone();
        org.joda.time.Chronology chronology11 = zonedChronology8.withZone(dateTimeZone10);
        boolean boolean12 = gJChronology0.equals((java.lang.Object) chronology11);
        org.joda.time.Chronology chronology13 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField14 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial4.minus(readablePeriod5);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = partial6.toString("", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear((int) (byte) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder20.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.appendOptional(dateTimeParser21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendTwoDigitWeekyear(86400030, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField13.getAsShortText((int) ' ', locale18);
        org.joda.time.DurationField durationField20 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        boolean boolean31 = property30.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatter34.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.append(dateTimePrinter35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfDay(16, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType52, (int) (short) 1, 800);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, durationField20, dateTimeFieldType52, 976);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate68 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology67);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter69.withZone(dateTimeZone70);
        org.joda.time.format.DateTimeParser dateTimeParser72 = dateTimeFormatter71.getParser();
        boolean boolean73 = localDate68.equals((java.lang.Object) dateTimeFormatter71);
        org.joda.time.LocalDate.Property property74 = localDate68.dayOfYear();
        boolean boolean75 = property74.isLeap();
        org.joda.time.LocalDate localDate77 = property74.addWrapFieldToCopy(1970);
        java.util.Locale locale79 = null;
        java.lang.String str80 = remainderDateTimeField66.getAsText((org.joda.time.ReadablePartial) localDate77, 800, locale79);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimePrinter35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimeFormatter71);
        org.junit.Assert.assertNotNull(dateTimeParser72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "800" + "'", str80.equals("800"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("57600010", (java.lang.Number) (short) 1, (java.lang.Number) 1, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, chronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        boolean boolean17 = property16.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.millis();
        org.joda.time.DurationField durationField26 = gJChronology24.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 976, 36600000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatterBuilder30.toFormatter();
        java.util.Locale locale32 = dateTimeFormatter31.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNull(locale32);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
        org.joda.time.LocalDate localDate12 = property9.addToCopy(100);
        org.joda.time.LocalDate.Property property13 = localDate12.yearOfEra();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        long long18 = instant1.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant1.plus(readableDuration19);
        boolean boolean21 = instant1.isBeforeNow();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.minuteOfDay();
        org.joda.time.DurationField durationField8 = copticChronology0.seconds();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int21 = skipDateTimeField19.get(1L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 23 + "'", int21 == 23);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology4.add(readablePeriod5, 0L, (int) (short) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        org.joda.time.DateTime dateTime6 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks(100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(0);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfMonth();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 60480060000L + "'", long11 == 60480060000L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundHalfFloor(2440588L);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField32.getAsText((int) (byte) 0, locale41);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
//        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
//        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
//        java.lang.String str11 = property9.getAsShortText();
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) '4');
//        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology14);
//        org.joda.time.LocalDate localDate17 = localDate15.plusMonths((int) (short) 1);
//        int int18 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate15);
//        int int19 = property9.compareTo((org.joda.time.ReadablePartial) localDate15);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = property9.getAsShortText(locale20);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(interval5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimePrinter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "279" + "'", str11.equals("279"));
//        org.junit.Assert.assertNotNull(copticChronology14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "279" + "'", str21.equals("279"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
//        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
//        boolean boolean11 = property10.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
//        java.util.Locale locale15 = null;
//        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) '4');
//        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology19);
//        org.joda.time.LocalDate localDate22 = localDate20.plusMonths((int) (short) 1);
//        int int23 = localDate18.compareTo((org.joda.time.ReadablePartial) localDate20);
//        org.joda.time.LocalDate localDate25 = localDate18.plusWeeks((int) (short) 1);
//        org.joda.time.LocalDate.Property property26 = localDate25.dayOfWeek();
//        org.joda.time.LocalDate localDate27 = property26.roundCeilingCopy();
//        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology29);
//        org.joda.time.LocalDate localDate32 = localDate30.plusMonths((int) (short) 1);
//        org.joda.time.Partial partial33 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate32);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) '4');
//        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology36);
//        org.joda.time.LocalDate localDate39 = localDate37.plusMonths((int) (short) 1);
//        int int40 = localDate35.compareTo((org.joda.time.ReadablePartial) localDate37);
//        boolean boolean41 = partial33.isMatch((org.joda.time.ReadablePartial) localDate35);
//        int[] intArray42 = partial33.getValues();
//        int[] intArray44 = delegatedDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDate27, 57600010, intArray42, 0);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = delegatedDateTimeField13.getAsText((long) (-1), locale46);
//        java.lang.String str49 = delegatedDateTimeField13.getAsShortText(60480060000L);
//        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone51 = julianChronology50.getZone();
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology50);
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = dateTimeZone54.getName(0L, locale56);
//        org.joda.time.DateTime dateTime58 = localDate52.toDateTimeAtStartOfDay(dateTimeZone54);
//        int int59 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate52);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(zonedChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(copticChronology19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(copticChronology29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(copticChronology36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "22" + "'", str47.equals("22"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "22" + "'", str49.equals("22"));
//        org.junit.Assert.assertNotNull(julianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Coordinated Universal Time" + "'", str57.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 30 + "'", int59 == 30);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
//        int int9 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusWeeks(36600000);
//        org.joda.time.DateTime.Property property12 = dateTime8.millisOfDay();
//        int int13 = dateTime8.getSecondOfMinute();
//        org.joda.time.DateTime.Property property14 = dateTime8.yearOfCentury();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        boolean boolean4 = property3.isLeap();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, chronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime18 = dateTime16.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime18.withTime(1, (int) (short) 0, (int) (byte) 1, (int) (byte) 0);
        boolean boolean25 = dateTime23.isEqual((-1L));
        org.joda.time.DateTime dateTime27 = dateTime23.plusHours((int) (byte) 100);
        int int28 = property3.compareTo((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(31L, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime((org.joda.time.Chronology) julianChronology3);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withFieldAdded(durationFieldType5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        java.util.Date date18 = instant1.toDate();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.fromDateFields(date18);
        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks(0);
        int int22 = localDate21.size();
        org.joda.time.LocalDate localDate24 = localDate21.withYearOfCentury(3);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology25);
        org.joda.time.LocalDate localDate28 = localDate26.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Interval interval30 = localDate26.toInterval(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter31.getPrinter();
        boolean boolean33 = localDate26.equals((java.lang.Object) dateTimePrinter32);
        org.joda.time.LocalDate.Property property34 = localDate26.dayOfYear();
        org.joda.time.LocalDate localDate35 = property34.roundHalfCeilingCopy();
        boolean boolean36 = localDate21.isEqual((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.DateTime dateTime37 = localDate35.toDateTimeAtMidnight();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(interval30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimePrinter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.DurationField durationField4 = copticChronology2.halfdays();
        org.joda.time.DateTime dateTime5 = instant1.toDateTime((org.joda.time.Chronology) copticChronology2);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = copticChronology0.add(readablePeriod5, 0L, (int) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(12);
        org.joda.time.DateTime dateTime8 = property3.setCopy(0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"32\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, chronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime16);
        boolean boolean18 = gJChronology4.equals((java.lang.Object) dateTime16);
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 36600000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        java.lang.String str7 = localDate1.toString();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.plus(readableDuration18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime21 = dateTime19.toDateTime();
        org.joda.time.DateTime dateTime26 = dateTime21.withTime(1, (int) (short) 0, (int) (byte) 1, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(10L, chronology31);
        org.joda.time.DateTime.Property property33 = dateTime32.millisOfDay();
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime35 = dateTime32.plus(readableDuration34);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfDay();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime41 = dateTime38.plus(readableDuration40);
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime32, (org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTime.Property property43 = dateTime32.dayOfMonth();
        int int44 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime45 = dateTime21.withZoneRetainFields(dateTimeZone29);
        org.joda.time.DateMidnight dateMidnight46 = localDate1.toDateMidnight(dateTimeZone29);
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        int int50 = dateMidnight46.compareTo((org.joda.time.ReadableInstant) dateTime49);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 36600000 + "'", int44 == 36600000);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateMidnight46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 12775);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-209763000000000L) + "'", long1 == (-209763000000000L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int[] intArray41 = new int[] { '#', 365, 10, (-1), 12775, 12 };
        int[] intArray43 = delegatedDateTimeField13.addWrapPartial(readablePartial33, 1735, intArray41, 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        int int10 = localDate8.getDayOfMonth();
        org.joda.time.LocalDate localDate12 = localDate8.minusMonths(86399999);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        boolean boolean14 = localDate8.isSupported(durationFieldType13);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology35);
        org.joda.time.LocalDate localDate38 = localDate36.plusMonths((int) (short) 1);
        int int39 = localDate34.compareTo((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate41 = localDate34.plusWeeks((int) (short) 1);
        int int42 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate41);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 30 + "'", int42 == 30);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        int int5 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.monthOfYear();
        org.joda.time.DateTime.Property property7 = dateTime4.year();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
//        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
//        boolean boolean16 = property15.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField21 = copticChronology20.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology20, dateTimeZone24);
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology20.dayOfMonth();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
//        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
//        boolean boolean31 = property30.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField33.getType();
//        java.util.Locale locale35 = null;
//        int int36 = delegatedDateTimeField33.getMaximumTextLength(locale35);
//        int int38 = delegatedDateTimeField33.get(1L);
//        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology39);
//        org.joda.time.LocalDate localDate42 = localDate40.plusMonths((int) (short) 1);
//        org.joda.time.Partial partial43 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate40);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray44 = partial43.getFieldTypes();
//        org.joda.time.Chronology chronology45 = partial43.getChronology();
//        int int46 = delegatedDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) partial43);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = delegatedDateTimeField18.getAsText((org.joda.time.ReadablePartial) partial43, locale47);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(zonedChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 23 + "'", int38 == 23);
//        org.junit.Assert.assertNotNull(copticChronology39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 30 + "'", int46 == 30);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9" + "'", str48.equals("9"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        int int9 = localDate1.size();
        org.joda.time.LocalDate localDate11 = localDate1.minusWeeks((int) 'a');
        org.joda.time.DateTimeField dateTimeField13 = localDate1.getField((int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(10L, chronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.millisOfDay();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readableDuration27);
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime19, (org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime();
        int int31 = dateTimeZone16.getOffset((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime30.withDurationAdded(readableDuration32, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder35.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(10L, chronology42);
        org.joda.time.DateTime.Property property44 = dateTime43.millisOfDay();
        boolean boolean45 = property44.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder40.appendShortText(dateTimeFieldType46);
        org.joda.time.DateTime.Property property48 = dateTime34.property(dateTimeFieldType46);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType46, 0, 6, 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 36600000 + "'", int31 == 36600000);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(property48);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology11);
        org.joda.time.LocalDate localDate14 = localDate12.plusMonths((int) (short) 1);
        org.joda.time.Partial partial15 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate14);
        int int16 = localDate14.getWeekyear();
        org.joda.time.LocalDate localDate18 = localDate14.minusDays(1735);
        int int19 = property9.compareTo((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.LocalDate localDate20 = property9.withMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1735 + "'", int16 == 1735);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.months();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime2.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology14.getZone();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) dateTime2, dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology17);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((int) (byte) 10);
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = copticChronology16.weekyears();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = gJChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology16, dateTimeZone20);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        org.joda.time.Chronology chronology24 = zonedChronology21.withZone(dateTimeZone23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.secondOfMinute();
        int int28 = dateTime13.get(dateTimeField27);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(36600000L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        int int7 = dateTime2.getWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime2.plusHours((int) '#');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone4.equals(obj6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) 1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[year=1735, monthOfYear=10, dayOfMonth=8]" + "'", str10.equals("[year=1735, monthOfYear=10, dayOfMonth=8]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalDate.Property property1 = localDate0.centuryOfEra();
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology21);
        org.joda.time.LocalDate localDate24 = localDate22.plusMonths((int) (short) 1);
        org.joda.time.Partial partial25 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology28);
        org.joda.time.LocalDate localDate31 = localDate29.plusMonths((int) (short) 1);
        int int32 = localDate27.compareTo((org.joda.time.ReadablePartial) localDate29);
        boolean boolean33 = partial25.isMatch((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = copticChronology34.weekyears();
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology36.getZone();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
        org.joda.time.chrono.ZonedChronology zonedChronology39 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology34, dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = copticChronology34.dayOfMonth();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(10L, chronology42);
        org.joda.time.DateTime.Property property44 = dateTime43.millisOfDay();
        boolean boolean45 = property44.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40, dateTimeFieldType46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = delegatedDateTimeField47.getType();
        java.util.Locale locale49 = null;
        int int50 = delegatedDateTimeField47.getMaximumTextLength(locale49);
        org.joda.time.Instant instant52 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(10L, chronology54);
        org.joda.time.DateTime.Property property56 = dateTime55.millisOfDay();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime58 = dateTime55.plus(readableDuration57);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime(10L, chronology60);
        org.joda.time.DateTime.Property property62 = dateTime61.millisOfDay();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.DateTime dateTime64 = dateTime61.plus(readableDuration63);
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime55, (org.joda.time.ReadableInstant) dateTime64);
        org.joda.time.DateTime.Property property66 = dateTime55.dayOfMonth();
        boolean boolean67 = instant52.isAfter((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.Chronology chronology68 = instant52.getChronology();
        java.util.Date date69 = instant52.toDate();
        org.joda.time.LocalDate localDate70 = org.joda.time.LocalDate.fromDateFields(date69);
        org.joda.time.LocalDate localDate72 = localDate70.minusWeeks(0);
        int[] intArray73 = new int[] {};
        int int74 = delegatedDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDate72, intArray73);
        try {
            int int75 = unsupportedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDate27, intArray73);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(zonedChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        long long24 = unsupportedDateTimeField20.getDifferenceAsLong((long) 1, (long) (byte) -1);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField20.getRangeDurationField();
        java.util.Locale locale26 = null;
        try {
            int int27 = unsupportedDateTimeField20.getMaximumShortTextLength(locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("279", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"279/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 'a');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder5.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendTimeZoneOffset("GregorianChronology[America/Los_Angeles]", true, (int) (short) 1, 34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder16.appendWeekOfWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(24, 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.Chronology chronology20 = gJChronology4.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        try {
            long long10 = gJChronology0.getDateTimeMillis((int) '4', 16, 86400030, 1969, 0, 34, 30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.clockhourOfDay();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = julianChronology8.withUTC();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, chronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology8, dateTimeField14, (int) '#');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField16);
        org.joda.time.DateTimeField dateTimeField18 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, dateTimeField18, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, chronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        boolean boolean17 = property16.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.millis();
        org.joda.time.DurationField durationField26 = gJChronology24.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 976, 36600000);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType18, 1735, 16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1735 for millisOfDay must be in the range [16,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay(31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        try {
            java.lang.String str23 = unsupportedDateTimeField20.getAsShortText((long) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology1.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.minuteOfDay();
        java.lang.String str5 = gJChronology1.toString();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(1L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(12775);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 12775");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(4492800016L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 'a');
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        long long8 = dateTimeZone2.adjustOffset(0L, false);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        java.lang.String str5 = gregorianChronology2.toString();
        org.joda.time.DurationField durationField6 = gregorianChronology2.hours();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone4.equals(obj6);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = fixedDateTimeZone4.nextTransition((long) 57600010);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 57600010L + "'", long10 == 57600010L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology1.getZone();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) 1735, (org.joda.time.Chronology) gJChronology1);
        int int4 = localDate3.getMonthOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        java.lang.String str14 = delegatedDateTimeField13.toString();
        java.lang.String str15 = delegatedDateTimeField13.getName();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology18);
        org.joda.time.LocalDate localDate21 = localDate19.plusMonths((int) (short) 1);
        int int22 = localDate17.compareTo((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.LocalDate localDate24 = localDate17.plusWeeks((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.LocalDate localDate27 = localDate17.withPeriodAdded(readablePeriod25, (int) (short) -1);
        int[] intArray29 = null;
        try {
            int[] intArray31 = delegatedDateTimeField13.set((org.joda.time.ReadablePartial) localDate27, 1, intArray29, 976);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 976 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfDay" + "'", str15.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate27);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withSecondOfMinute(10);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime4.getZone();
        org.joda.time.LocalTime localTime9 = dateTime4.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime4.withHourOfDay(1);
        int int12 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600010 + "'", int5 == 57600010);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 960 + "'", int12 == 960);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(36600000, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        java.lang.Class<?> wildcardClass3 = julianChronology0.getClass();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withZone(dateTimeZone7);
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        boolean boolean10 = localDate5.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.LocalDate.Property property11 = localDate5.dayOfYear();
        boolean boolean12 = julianChronology0.equals((java.lang.Object) property11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        long long24 = unsupportedDateTimeField20.getDifferenceAsLong((long) 1, (long) (byte) -1);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField20.getRangeDurationField();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField20.getAsText((int) 'a', locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        java.lang.String str22 = unsupportedDateTimeField20.getName();
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField20.getAsText(0, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "millisOfDay" + "'", str22.equals("millisOfDay"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ISOChronology[America/Los_Angeles]");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 36600000L, (java.lang.Number) 36600000L, (java.lang.Number) 1560640590323L);
        java.lang.String str25 = illegalFieldValueException24.getIllegalValueAsString();
        java.lang.Number number26 = illegalFieldValueException24.getUpperBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "36600000" + "'", str25.equals("36600000"));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1560640590323L + "'", number26.equals(1560640590323L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfDay();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        org.joda.time.DateTime dateTime6 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks(100);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField20.getDurationField();
        long long25 = durationField22.subtract(0L, 2440588L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-77019098746022000L) + "'", long25 == (-77019098746022000L));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        org.joda.time.DurationField durationField20 = skipDateTimeField19.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial4.getFieldTypes();
        int[] intArray9 = new int[] { 365, '#', 57600010 };
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        java.lang.Object obj12 = null;
        boolean boolean13 = gJChronology10.equals(obj12);
        java.lang.String str14 = gJChronology10.toString();
        try {
            org.joda.time.Partial partial15 = new org.joda.time.Partial(dateTimeFieldTypeArray5, intArray9, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str14.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology3);
        org.joda.time.LocalDate localDate6 = localDate4.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.Interval interval8 = localDate4.toInterval(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        boolean boolean11 = localDate4.equals((java.lang.Object) dateTimePrinter10);
        int int12 = localDate4.getDayOfWeek();
        org.joda.time.LocalDate localDate14 = localDate4.plusDays((int) (byte) 1);
        try {
            dateTimeFormatter1.printTo(writer2, (org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("millisOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"millisOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime13.dayOfMonth();
        boolean boolean25 = instant10.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.Chronology chronology26 = instant10.getChronology();
        java.util.Date date27 = instant10.toDate();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromDateFields(date27);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks(0);
        int int31 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology32 = localDate1.getChronology();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.LocalDate localDate35 = localDate1.withPeriodAdded(readablePeriod33, 69);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(localDate35);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField18.getAsShortText((long) (short) 1, locale21);
        org.joda.time.DateTimeField dateTimeField23 = delegatedDateTimeField18.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "23" + "'", str22.equals("23"));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendDayOfYear((int) (short) 10);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField68 = copticChronology67.weekyears();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone70 = gJChronology69.getZone();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeUtils.getZone(dateTimeZone70);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology67, dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = copticChronology67.dayOfMonth();
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(10L, chronology75);
        org.joda.time.DateTime.Property property77 = dateTime76.millisOfDay();
        boolean boolean78 = property77.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property77.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField80 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73, dateTimeFieldType79);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField80.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) 86399999, "1969-12-31T��:��");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType81);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, durationField60, dateTimeFieldType81, 36600000);
        org.joda.time.DurationField durationField88 = dividedDateTimeField87.getRangeDurationField();
        try {
            long long91 = dividedDateTimeField87.addWrapField((long) 86399999, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
        org.junit.Assert.assertNotNull(durationField88);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        java.lang.String str9 = localDate1.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1686-06-15" + "'", str9.equals("1686-06-15"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        boolean boolean4 = property3.isLeap();
        java.lang.String str5 = property3.getAsText();
        org.joda.time.DateTime dateTime6 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths(1735);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600010" + "'", str5.equals("57600010"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("1969-12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31\" is malformed at \"-12-31\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.String str2 = dateTimeFormatter0.print(19523904L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T21" + "'", str2.equals("1969-12-31T21"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime.Property property7 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        int int9 = dateTime8.getYearOfCentury();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        long long24 = unsupportedDateTimeField20.getDifferenceAsLong((long) 1, (long) (byte) -1);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField20.getRangeDurationField();
        int int28 = unsupportedDateTimeField20.getDifference((long) 'a', 0L);
        try {
            long long30 = unsupportedDateTimeField20.roundHalfFloor((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology41);
        org.joda.time.LocalDate localDate44 = localDate42.plusMonths((int) (short) 1);
        org.joda.time.LocalDate.Property property45 = localDate44.yearOfCentury();
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, 23, locale47);
        int int50 = offsetDateTimeField32.getMinimumValue((long) 24);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "23" + "'", str48.equals("23"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 16 + "'", int50 == 16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial4.minus(readablePeriod5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.Partial partial9 = partial6.withFieldAddWrapped(durationFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(partial6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) copticChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("millisOfDay", "57600010");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone4.equals(obj6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long10 = cachedDateTimeZone8.nextTransition((long) 6);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6L + "'", long10 == 6L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        int int34 = offsetDateTimeField32.get(0L);
        long long36 = offsetDateTimeField32.roundCeiling((long) (short) -1);
        boolean boolean37 = offsetDateTimeField32.isSupported();
        java.lang.String str39 = offsetDateTimeField32.getAsText((long) 86399999);
        int int41 = offsetDateTimeField32.getLeapAmount((long) 2019);
        long long43 = offsetDateTimeField32.roundHalfEven((long) (short) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "24" + "'", str39.equals("24"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        try {
            long long22 = unsupportedDateTimeField20.roundCeiling((long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology33);
        org.joda.time.LocalDate localDate36 = localDate34.plusMonths((int) (short) 1);
        org.joda.time.Partial partial37 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.Partial partial39 = partial37.minus(readablePeriod38);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) partial37, 0, locale41);
        java.util.Locale locale43 = null;
        int int44 = delegatedDateTimeField13.getMaximumTextLength(locale43);
        boolean boolean45 = delegatedDateTimeField13.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withZone(dateTimeZone15);
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withZone(dateTimeZone19);
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean23 = dateTimeFormatter22.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray26 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17, dateTimeParser21, dateTimeParser25 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder9.append(dateTimePrinter13, dateTimeParserArray26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean29 = dateTimeFormatter28.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser31);
        org.joda.time.format.DateTimeParser dateTimeParser33 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeParserArray26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.Instant instant5 = instant0.withDurationAdded(8L, 800);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant0.plus(readableDuration6);
        boolean boolean8 = instant7.isEqualNow();
        org.joda.time.Instant instant11 = instant7.withDurationAdded(2440488L, 2);
        org.joda.time.DateTime dateTime12 = instant7.toDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        boolean boolean4 = property3.isLeap();
        org.joda.time.DateTime dateTime5 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(976);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField42 = gJChronology41.millis();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology41.millisOfDay();
        org.joda.time.LocalDate localDate44 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology41);
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField32.getAsText((org.joda.time.ReadablePartial) localDate44, 1970, locale46);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970" + "'", str47.equals("1970"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime13.dayOfMonth();
        boolean boolean25 = instant10.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.Chronology chronology26 = instant10.getChronology();
        java.util.Date date27 = instant10.toDate();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromDateFields(date27);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks(0);
        int int31 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology32 = localDate1.getChronology();
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology35);
        org.joda.time.LocalDate localDate38 = localDate36.plusMonths((int) (short) 1);
        int int39 = localDate34.compareTo((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate localDate41 = localDate34.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property42 = localDate41.dayOfWeek();
        org.joda.time.LocalDate localDate43 = property42.roundCeilingCopy();
        org.joda.time.LocalDate localDate44 = property42.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate46 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology45);
        org.joda.time.LocalDate localDate48 = localDate46.plusMonths((int) (short) 1);
        org.joda.time.Partial partial49 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate53 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology52);
        org.joda.time.LocalDate localDate55 = localDate53.plusMonths((int) (short) 1);
        int int56 = localDate51.compareTo((org.joda.time.ReadablePartial) localDate53);
        boolean boolean57 = partial49.isMatch((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = partial49.getFieldType(1);
        org.joda.time.LocalDate.Property property60 = localDate44.property(dateTimeFieldType59);
        int int61 = localDate1.get(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(copticChronology52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 12 + "'", int61 == 12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Pacific Standard Time");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("1735-10-08", "1969-12-31", false, (int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        int int10 = localDate8.getDayOfMonth();
        org.joda.time.LocalDate localDate12 = localDate8.minusMonths(86399999);
        org.joda.time.LocalDate localDate14 = localDate12.plusWeeks((int) '4');
        org.joda.time.LocalDate localDate16 = localDate14.minusDays(1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, chronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L, chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readableDuration13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = dateTime14.toDateTime();
        int int17 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime26 = dateTime23.plus(readableDuration25);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.plus(readableDuration31);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTime dateTime34 = dateTime32.toDateTime();
        int int35 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime16, (org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36600000 + "'", int17 == 36600000);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 36600000 + "'", int35 == 36600000);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfEvenCopy();
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withSecondOfMinute(10);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime4.getZone();
        org.joda.time.LocalTime localTime9 = dateTime4.toLocalTime();
        org.joda.time.DateTime.Property property10 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime12 = dateTime4.minusDays((-1));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57600010 + "'", int5 == 57600010);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(localTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        try {
            long long22 = unsupportedDateTimeField20.roundHalfFloor((long) 86400030);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        int int9 = localDate1.size();
        org.joda.time.LocalDate localDate11 = localDate1.minusWeeks((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, (int) '4');
        int int15 = localDate11.getMonthOfYear();
        org.joda.time.LocalDate.Property property16 = localDate11.yearOfEra();
        int int17 = property16.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.Chronology chronology8 = zonedChronology5.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime24 = dateTime13.toDateTimeISO();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime13, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        int int34 = offsetDateTimeField32.get(0L);
        long long36 = offsetDateTimeField32.roundCeiling((long) (short) -1);
        boolean boolean37 = offsetDateTimeField32.isSupported();
        java.lang.String str39 = offsetDateTimeField32.getAsText((long) 86399999);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField32.getAsShortText((int) (byte) 1, locale41);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "24" + "'", str39.equals("24"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        long long18 = instant1.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant1.plus(readableDuration19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Instant instant22 = instant1.plus(readableDuration21);
        org.joda.time.DateTime dateTime23 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime2.dayOfMonth();
        int int14 = property13.getMaximumValue();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property13.getAsShortText(locale15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31" + "'", str16.equals("31"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, chronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        boolean boolean17 = property16.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.millis();
        org.joda.time.DurationField durationField26 = gJChronology24.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 976, 36600000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfHour((int) (byte) 100, 69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology5);
        org.joda.time.LocalDate localDate8 = localDate6.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Interval interval10 = localDate6.toInterval(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        boolean boolean13 = localDate6.equals((java.lang.Object) dateTimePrinter12);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology15 = julianChronology14.withUTC();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(10L, chronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology14, dateTimeField20, (int) '#');
        boolean boolean23 = localDate6.equals((java.lang.Object) dateTimeField20);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField20);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField24.getAsText((long) 1969, locale26);
        long long30 = skipUndoDateTimeField24.set(1L, 1970);
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology31);
        org.joda.time.LocalDate localDate34 = localDate32.plusMonths((int) (short) 1);
        org.joda.time.Partial partial35 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.Interval interval36 = localDate34.toInterval();
        int int37 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) localDate34);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57601969" + "'", str27.equals("57601969"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-57598030L) + "'", long30 == (-57598030L));
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(interval36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        boolean boolean15 = property9.equals((java.lang.Object) gregorianChronology13);
        java.lang.String str16 = gregorianChronology13.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str16.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, 1, 1970, 57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField6, (int) '#');
        java.util.Locale locale9 = null;
        int int10 = skipUndoDateTimeField8.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) 1);
        int int11 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate8);
        boolean boolean12 = partial4.isMatch((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray13 = partial4.getFieldTypes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray13);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology1.getZone();
        java.lang.Object obj3 = null;
        boolean boolean4 = gJChronology1.equals(obj3);
        java.lang.String str5 = gJChronology1.toString();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.minuteOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField6);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str5.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendTwoDigitYear(57600010);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfHalfday(976);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        int int9 = localDate1.size();
        org.joda.time.LocalDate localDate11 = localDate1.minusWeeks((int) 'a');
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        int int17 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.minusMinutes((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.plus(readablePeriod20);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = copticChronology22.weekyears();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology24.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology22, dateTimeZone26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology28.getZone();
        org.joda.time.Chronology chronology30 = zonedChronology27.withZone(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = dateTime16.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime33 = dateTime16.plusSeconds(24);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime16.toTimeOfDay();
        try {
            int int35 = localDate11.compareTo((org.joda.time.ReadablePartial) timeOfDay34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57600010 + "'", int17 == 57600010);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        int int34 = offsetDateTimeField32.get(0L);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology37);
        org.joda.time.LocalDate localDate40 = localDate38.plusMonths((int) (short) 1);
        int int41 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.LocalDate localDate43 = localDate36.plusWeeks((int) (short) 1);
        int int44 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate36);
        long long46 = offsetDateTimeField32.roundHalfCeiling((long) 10);
        java.util.Locale locale48 = null;
        java.lang.String str49 = offsetDateTimeField32.getAsText(3, locale48);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 31 + "'", int44 == 31);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "3" + "'", str49.equals("3"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray4 = localDate3.getFieldTypes();
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths((int) (short) 1);
        int int11 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate8);
        java.lang.String str12 = localDate6.toString();
        boolean boolean13 = localDate3.isEqual((org.joda.time.ReadablePartial) localDate6);
        try {
            java.lang.String str15 = localDate6.toString("Property[millisOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray4);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = copticChronology3.weekyears();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology3, dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology9.getZone();
        org.joda.time.Chronology chronology11 = zonedChronology8.withZone(dateTimeZone10);
        boolean boolean12 = gJChronology0.equals((java.lang.Object) chronology11);
        org.joda.time.Chronology chronology13 = gJChronology0.withUTC();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial4.minus(readablePeriod5);
        org.joda.time.Chronology chronology7 = partial6.getChronology();
        int int9 = partial6.getValue(0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1686 + "'", int9 == 1686);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(10L, chronology14);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
        boolean boolean17 = property16.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField25 = gJChronology24.millis();
        org.joda.time.DurationField durationField26 = gJChronology24.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField27 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 976, 36600000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder6.appendLiteral(' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        boolean boolean15 = property14.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.appendShortText(dateTimeFieldType16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField23 = gJChronology22.millis();
        org.joda.time.DurationField durationField24 = gJChronology22.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 36600000L, (java.lang.Number) 36600000L, (java.lang.Number) 1560640590323L);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType16, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        boolean boolean6 = property5.isLeap();
        org.joda.time.DateTime dateTime7 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfCentury((int) ' ');
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(2440588L, (int) (short) 100);
        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "19330103T114738-0800" + "'", str13.equals("19330103T114738-0800"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withDayOfMonth((int) (short) 1);
        org.joda.time.DateTime.Property property5 = dateTime2.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        int int9 = dateTime8.getDayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime8.plusWeeks(36600000);
        org.joda.time.DateTime.Property property12 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime14 = property12.setCopy("0");
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime14.toYearMonthDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        int int11 = dateTime2.get(dateTimeField10);
        long long12 = dateTime2.getMillis();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600010 + "'", int11 == 57600010);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfDay();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = copticChronology7.weekyears();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology9.getZone();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology7, dateTimeZone11);
        org.joda.time.DateTime dateTime13 = localDate6.toDateTimeAtStartOfDay(dateTimeZone11);
        int int14 = dateTime13.getDayOfMonth();
        org.joda.time.DateTime dateTime16 = dateTime13.plusWeeks(36600000);
        org.joda.time.DateTime.Property property17 = dateTime13.millisOfDay();
        boolean boolean18 = dateTime2.equals((java.lang.Object) property17);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendDayOfYear((int) (short) 10);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField68 = copticChronology67.weekyears();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone70 = gJChronology69.getZone();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeUtils.getZone(dateTimeZone70);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology67, dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = copticChronology67.dayOfMonth();
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(10L, chronology75);
        org.joda.time.DateTime.Property property77 = dateTime76.millisOfDay();
        boolean boolean78 = property77.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property77.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField80 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73, dateTimeFieldType79);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField80.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) 86399999, "1969-12-31T��:��");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType81);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, durationField60, dateTimeFieldType81, 36600000);
        int int88 = dividedDateTimeField87.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial6 = partial4.minus(readablePeriod5);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) partial6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = partial6.getFieldTypes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, chronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.minusMinutes((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = copticChronology15.weekyears();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology15, dateTimeZone19);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology21.getZone();
        org.joda.time.Chronology chronology23 = zonedChronology20.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime9.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime4.withZoneRetainFields(dateTimeZone22);
        boolean boolean26 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600010 + "'", int10 == 57600010);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        int int34 = offsetDateTimeField32.get(0L);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology37);
        org.joda.time.LocalDate localDate40 = localDate38.plusMonths((int) (short) 1);
        int int41 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.LocalDate localDate43 = localDate36.plusWeeks((int) (short) 1);
        int int44 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate36);
        long long46 = offsetDateTimeField32.remainder((long) 36600000);
        java.lang.String str48 = offsetDateTimeField32.getAsShortText((long) 0);
        org.joda.time.LocalDate localDate50 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate52 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology51);
        org.joda.time.LocalDate localDate54 = localDate52.plusMonths((int) (short) 1);
        int int55 = localDate50.compareTo((org.joda.time.ReadablePartial) localDate52);
        org.joda.time.LocalDate localDate57 = localDate50.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant59 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, chronology61);
        org.joda.time.DateTime.Property property63 = dateTime62.millisOfDay();
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.plus(readableDuration64);
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(10L, chronology67);
        org.joda.time.DateTime.Property property69 = dateTime68.millisOfDay();
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.DateTime dateTime71 = dateTime68.plus(readableDuration70);
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime62, (org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateTime.Property property73 = dateTime62.dayOfMonth();
        boolean boolean74 = instant59.isAfter((org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.Chronology chronology75 = instant59.getChronology();
        java.util.Date date76 = instant59.toDate();
        org.joda.time.LocalDate localDate77 = org.joda.time.LocalDate.fromDateFields(date76);
        org.joda.time.LocalDate localDate79 = localDate77.minusWeeks(0);
        int int80 = localDate50.compareTo((org.joda.time.ReadablePartial) localDate77);
        org.joda.time.Chronology chronology81 = localDate50.getChronology();
        int[] intArray83 = null;
        java.util.Locale locale85 = null;
        try {
            int[] intArray86 = offsetDateTimeField32.set((org.joda.time.ReadablePartial) localDate50, 1, intArray83, "279", locale85);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 279 for millisOfDay must be in the range [16,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 31 + "'", int44 == 31);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 36600000L + "'", long46 == 36600000L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "24" + "'", str48.equals("24"));
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertNotNull(localDate52);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(chronology81);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((-1));
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 31);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        long long18 = dateTimeZone15.getMillisKeepLocal(dateTimeZone16, 0L);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        java.lang.String str20 = dateTimeZone15.getID();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime5.toMutableDateTime(dateTimeZone15);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology22);
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.secondOfMinute();
        int int25 = mutableDateTime21.get(dateTimeField24);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfCentury(10, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear((int) (byte) 10, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder15.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder20.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder14.appendOptional(dateTimeParser21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendFractionOfSecond(0, 365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder22.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime13.dayOfMonth();
        boolean boolean25 = instant10.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.Chronology chronology26 = instant10.getChronology();
        java.util.Date date27 = instant10.toDate();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromDateFields(date27);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks(0);
        int int31 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology32 = localDate1.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = localDate1.getFieldType((int) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, "JulianChronology[UTC]");
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
        java.lang.String str11 = property9.getAsShortText();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology14);
        org.joda.time.LocalDate localDate17 = localDate15.plusMonths((int) (short) 1);
        int int18 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate15);
        int int19 = property9.compareTo((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        org.joda.time.LocalTime localTime25 = dateTime23.toLocalTime();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology26.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = localDate20.toDateTime(localTime25, dateTimeZone27);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate33 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology32);
        org.joda.time.LocalDate localDate35 = localDate33.plusMonths((int) (short) 1);
        int int36 = localDate31.compareTo((org.joda.time.ReadablePartial) localDate33);
        org.joda.time.LocalDate localDate38 = localDate31.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property39 = localDate38.dayOfWeek();
        org.joda.time.LocalDate localDate40 = property39.roundCeilingCopy();
        org.joda.time.LocalDate localDate42 = property39.addToCopy(100);
        org.joda.time.LocalDate.Property property43 = localDate42.yearOfCentury();
        org.joda.time.LocalDate localDate44 = property43.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(10L, chronology49);
        org.joda.time.DateTime.Property property51 = dateTime50.millisOfDay();
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.plus(readableDuration52);
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(10L, chronology55);
        org.joda.time.DateTime.Property property57 = dateTime56.millisOfDay();
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.DateTime dateTime59 = dateTime56.plus(readableDuration58);
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime50, (org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime61 = dateTime59.toDateTime();
        int int62 = dateTimeZone47.getOffset((org.joda.time.ReadableInstant) dateTime61);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone47);
        org.joda.time.DateTime dateTime64 = localDate44.toDateTimeAtCurrentTime(dateTimeZone47);
        try {
            org.joda.time.DateTime dateTime65 = localDate15.toDateTime(localTime25, dateTimeZone47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "165" + "'", str11.equals("165"));
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 36600000 + "'", int62 == 36600000);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTime64);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        long long18 = instant1.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant1.plus(readableDuration19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Instant instant22 = instant1.plus(readableDuration21);
        org.joda.time.Instant instant24 = instant1.plus((long) 10);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertNotNull(instant24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        int int18 = delegatedDateTimeField13.get(1L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField13.getAsShortText(2440488L, locale20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 23 + "'", int18 == 23);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "23" + "'", str21.equals("23"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560640590323L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate1.withPeriodAdded(readablePeriod9, (int) (byte) 1);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology14);
        org.joda.time.LocalDate localDate17 = localDate15.plusMonths((int) (short) 1);
        int int18 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate15);
        boolean boolean19 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = copticChronology20.weekyears();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology20, dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = copticChronology20.dayOfMonth();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        boolean boolean31 = property30.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField33.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 10.0f, "Property[millisOfDay]");
        int int38 = localDate1.indexOf(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = partial4.getFormatter();
//        java.lang.String str6 = partial4.toString();
//        java.lang.String str7 = partial4.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1785-03-18" + "'", str6.equals("1785-03-18"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1785-03-18" + "'", str7.equals("1785-03-18"));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        boolean boolean4 = property3.isLeap();
        java.lang.String str5 = property3.getAsText();
        org.joda.time.DateTime dateTime6 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime8.minusMinutes(36600000);
        int int11 = dateTime8.getSecondOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600010" + "'", str5.equals("57600010"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57632 + "'", int11 == 57632);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        long long24 = unsupportedDateTimeField20.getDifferenceAsLong((long) 1, (long) (byte) -1);
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField20.getRangeDurationField();
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = unsupportedDateTimeField20.getAsShortText(57600010, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.Chronology chronology8 = zonedChronology5.withZone(dateTimeZone7);
        org.joda.time.DurationField durationField9 = zonedChronology5.hours();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology5.millisOfDay();
        org.joda.time.Chronology chronology11 = zonedChronology5.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField13.getAsShortText((int) ' ', locale18);
        org.joda.time.DurationField durationField20 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        boolean boolean31 = property30.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatter34.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.append(dateTimePrinter35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfDay(16, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType52, (int) (short) 1, 800);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, durationField20, dateTimeFieldType52, 976);
        int int67 = remainderDateTimeField66.getMaximumValue();
        int int68 = remainderDateTimeField66.getMinimumValue();
        long long70 = remainderDateTimeField66.roundCeiling((long) (short) 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimePrinter35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 975 + "'", int67 == 975);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        int int34 = offsetDateTimeField32.get(0L);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology37);
        org.joda.time.LocalDate localDate40 = localDate38.plusMonths((int) (short) 1);
        int int41 = localDate36.compareTo((org.joda.time.ReadablePartial) localDate38);
        org.joda.time.LocalDate localDate43 = localDate36.plusWeeks((int) (short) 1);
        int int44 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate36);
        long long47 = offsetDateTimeField32.add((long) '4', (long) (byte) 0);
        long long49 = offsetDateTimeField32.roundHalfFloor((long) (short) 10);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField32.getAsText(0, locale51);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 24 + "'", int34 == 24);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 31 + "'", int44 == 31);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField13.getAsShortText((int) ' ', locale18);
        org.joda.time.DurationField durationField20 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(10L, chronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.millisOfDay();
        boolean boolean31 = property30.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatter34.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.append(dateTimePrinter35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfDay(16, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder40.appendSignedDecimal(dateTimeFieldType52, (int) (short) 1, 800);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, durationField20, dateTimeFieldType52, 976);
        int int67 = remainderDateTimeField66.getMaximumValue();
        org.joda.time.DurationField durationField68 = remainderDateTimeField66.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "32" + "'", str19.equals("32"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimePrinter35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 975 + "'", int67 == 975);
        org.junit.Assert.assertNull(durationField68);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        boolean boolean15 = property9.equals((java.lang.Object) gregorianChronology13);
        try {
            long long21 = gregorianChronology13.getDateTimeMillis((long) 365, 0, 365, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        boolean boolean13 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime15 = dateTime11.withWeekOfWeekyear(4);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime2.toDateTimeISO();
        int int14 = dateTime13.getHourOfDay();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = copticChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.Partial partial42 = new org.joda.time.Partial(dateTimeFieldType40, 1686);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        java.util.Date date18 = instant1.toDate();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.fromDateFields(date18);
        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks(0);
        int int22 = localDate21.size();
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology23);
        org.joda.time.LocalDate localDate26 = localDate24.plusMonths((int) (short) 1);
        org.joda.time.Partial partial27 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.Partial partial29 = partial27.minus(readablePeriod28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder30.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfDay();
        boolean boolean40 = property39.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property39.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder35.appendShortText(dateTimeFieldType41);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField44 = copticChronology43.weekyears();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = gJChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone46);
        org.joda.time.chrono.ZonedChronology zonedChronology48 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology43, dateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = copticChronology43.dayOfMonth();
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(10L, chronology51);
        org.joda.time.DateTime.Property property53 = dateTime52.millisOfDay();
        boolean boolean54 = property53.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property53.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49, dateTimeFieldType55);
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField58 = copticChronology57.weekyears();
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone60 = gJChronology59.getZone();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
        org.joda.time.chrono.ZonedChronology zonedChronology62 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology57, dateTimeZone61);
        org.joda.time.DateTimeField dateTimeField63 = copticChronology57.dayOfMonth();
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(10L, chronology65);
        org.joda.time.DateTime.Property property67 = dateTime66.millisOfDay();
        boolean boolean68 = property67.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property67.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField63, dateTimeFieldType69);
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = delegatedDateTimeField70.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField56, dateTimeFieldType71, 1, 16, 1735);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder42.appendShortText(dateTimeFieldType71);
        int int77 = partial29.indexOf(dateTimeFieldType71);
        boolean boolean78 = localDate21.isSupported(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(partial29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(zonedChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(zonedChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime13.dayOfMonth();
        boolean boolean25 = instant10.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.Chronology chronology26 = instant10.getChronology();
        java.util.Date date27 = instant10.toDate();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromDateFields(date27);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks(0);
        int int31 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology32 = localDate1.getChronology();
        org.joda.time.LocalDate localDate34 = localDate1.minusWeeks((int) (short) 1);
        int int35 = localDate1.getWeekyear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1970 + "'", int35 == 1970);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10L, chronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(10L, chronology10);
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readableDuration13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime5.dayOfMonth();
        int int17 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime5);
        long long18 = dateTime5.getMillis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36600000 + "'", int17 == 36600000);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendTwoDigitYear(57632, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        java.lang.String str5 = gregorianChronology2.toString();
        int int6 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((-1));
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.withPeriodAdded(readablePeriod8, 31);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        long long18 = dateTimeZone15.getMillisKeepLocal(dateTimeZone16, 0L);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        java.lang.String str20 = dateTimeZone15.getID();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime5.toMutableDateTime(dateTimeZone15);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(10L, chronology23);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime24.plus(readableDuration26);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(10L, chronology29);
        org.joda.time.DateTime.Property property31 = dateTime30.millisOfDay();
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime30.plus(readableDuration32);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime35 = dateTime33.toDateTime();
        org.joda.time.DateTime dateTime40 = dateTime35.withTime(1, (int) (short) 0, (int) (byte) 1, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(10L, chronology45);
        org.joda.time.DateTime.Property property47 = dateTime46.millisOfDay();
        org.joda.time.ReadableDuration readableDuration48 = null;
        org.joda.time.DateTime dateTime49 = dateTime46.plus(readableDuration48);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(10L, chronology51);
        org.joda.time.DateTime.Property property53 = dateTime52.millisOfDay();
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.DateTime dateTime55 = dateTime52.plus(readableDuration54);
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime46, (org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime.Property property57 = dateTime46.dayOfMonth();
        int int58 = dateTimeZone43.getOffset((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTime dateTime59 = dateTime35.withZoneRetainFields(dateTimeZone43);
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(10L, chronology61);
        org.joda.time.DateTime.Property property63 = dateTime62.millisOfDay();
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.DateTime dateTime65 = dateTime62.plus(readableDuration64);
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(10L, chronology67);
        org.joda.time.DateTime.Property property69 = dateTime68.millisOfDay();
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.DateTime dateTime71 = dateTime68.plus(readableDuration70);
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime62, (org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateTime dateTime73 = dateTime62.toDateTimeISO();
        int int74 = dateTime59.compareTo((org.joda.time.ReadableInstant) dateTime62);
        boolean boolean75 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(10L, chronology77);
        org.joda.time.DateTime.Property property79 = dateTime78.millisOfDay();
        org.joda.time.ReadableDuration readableDuration80 = null;
        org.joda.time.DateTime dateTime81 = dateTime78.plus(readableDuration80);
        org.joda.time.Chronology chronology83 = null;
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime(10L, chronology83);
        org.joda.time.DateTime.Property property85 = dateTime84.millisOfDay();
        org.joda.time.ReadableDuration readableDuration86 = null;
        org.joda.time.DateTime dateTime87 = dateTime84.plus(readableDuration86);
        org.joda.time.Chronology chronology88 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime78, (org.joda.time.ReadableInstant) dateTime87);
        org.joda.time.DateTime dateTime89 = dateTime87.toDateTime();
        int int90 = dateTime89.getSecondOfMinute();
        boolean boolean91 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime89);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 36600000 + "'", int58 == 36600000);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(chronology88);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(8L, 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology0.equals(obj2);
        java.lang.String str4 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.yearOfEra();
        org.joda.time.DurationField durationField7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10L, chronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
        boolean boolean18 = property17.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 1970, (java.lang.Number) 1.0f, (java.lang.Number) 1969);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, durationField7, dateTimeFieldType19);
        org.joda.time.DurationField durationField26 = delegatedDateTimeField25.getRangeDurationField();
        java.lang.String str28 = delegatedDateTimeField25.getAsText((long) 3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1969" + "'", str28.equals("1969"));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
//        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial4.getFieldTypes();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.Partial partial8 = partial4.withPeriodAdded(readablePeriod6, 16);
//        java.lang.String str9 = partial4.toStringList();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology10);
//        org.joda.time.LocalDate localDate13 = localDate11.plusMonths((int) (short) 1);
//        org.joda.time.Partial partial14 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate11);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray15 = partial14.getFieldTypes();
//        org.joda.time.Chronology chronology16 = partial14.getChronology();
//        org.joda.time.Partial partial17 = partial4.withChronologyRetainFields(chronology16);
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField19 = copticChronology18.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology20.getZone();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology18, dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.dayOfMonth();
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, chronology26);
//        org.joda.time.DateTime.Property property28 = dateTime27.millisOfDay();
//        boolean boolean29 = property28.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType30);
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField33 = copticChronology32.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone35 = gJChronology34.getZone();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology32, dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField38 = copticChronology32.dayOfMonth();
//        org.joda.time.Chronology chronology40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(10L, chronology40);
//        org.joda.time.DateTime.Property property42 = dateTime41.millisOfDay();
//        boolean boolean43 = property42.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38, dateTimeFieldType44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = delegatedDateTimeField45.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField31, dateTimeFieldType46, 1, 16, 1735);
//        java.lang.String str51 = offsetDateTimeField50.getName();
//        long long53 = offsetDateTimeField50.roundCeiling((long) (byte) 10);
//        int int55 = offsetDateTimeField50.get(10L);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField(chronology16, (org.joda.time.DateTimeField) offsetDateTimeField50);
//        int int58 = offsetDateTimeField50.get((long) 24);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
//        org.junit.Assert.assertNotNull(partial8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[year=1785, monthOfYear=3, dayOfMonth=18]" + "'", str9.equals("[year=1785, monthOfYear=3, dayOfMonth=18]"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(partial17);
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(zonedChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "millisOfDay" + "'", str51.equals("millisOfDay"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 86400000L + "'", long53 == 86400000L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 24 + "'", int55 == 24);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 24 + "'", int58 == 24);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology33);
        org.joda.time.LocalDate localDate36 = localDate34.plusMonths((int) (short) 1);
        org.joda.time.Partial partial37 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.Partial partial39 = partial37.minus(readablePeriod38);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) partial37, 0, locale41);
        java.util.Locale locale43 = null;
        int int44 = delegatedDateTimeField13.getMaximumTextLength(locale43);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(partial39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime4 = dateTime2.toDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        int int7 = dateTime2.getWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime2.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology9.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        long long16 = dateTimeZone13.getMillisKeepLocal(dateTimeZone14, 0L);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField18 = gJChronology17.minutes();
        org.joda.time.DateTime dateTime19 = dateTime2.toDateTime((org.joda.time.Chronology) gJChronology17);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.Instant instant10 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.plus(readableDuration21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime13.dayOfMonth();
        boolean boolean25 = instant10.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.Chronology chronology26 = instant10.getChronology();
        java.util.Date date27 = instant10.toDate();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.fromDateFields(date27);
        org.joda.time.LocalDate localDate30 = localDate28.minusWeeks(0);
        int int31 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology32 = localDate1.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = localDate1.getFieldType((int) (byte) 1);
        org.joda.time.LocalDate.Property property35 = localDate1.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime20 = dateTime13.withTime((int) 'a', 11, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(10L, chronology6);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10L, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime7.dayOfMonth();
        int int19 = property3.compareTo((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime20 = property3.roundHalfCeilingCopy();
        int int21 = dateTime20.getDayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 36600000L, (java.lang.Number) 36600000L, (java.lang.Number) 1560640590323L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 100.0f, "America/Los_Angeles");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
        org.joda.time.LocalDate.Property property9 = localDate1.dayOfYear();
        org.joda.time.LocalDate localDate10 = property9.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
        boolean boolean15 = property9.equals((java.lang.Object) gregorianChronology13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = copticChronology5.weekyears();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology5, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = copticChronology5.dayOfMonth();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(10L, chronology13);
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        boolean boolean16 = property15.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property15.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType17);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        try {
            long long22 = skipDateTimeField19.set((long) 7, 36600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36600000 for millisOfDay must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        int int6 = fixedDateTimeZone4.getOffset((long) 7);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((long) 23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[year=1735, monthOfYear=10, dayOfMonth=8]" + "'", str9.equals("[year=1735, monthOfYear=10, dayOfMonth=8]"));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.Interval interval5 = localDate1.toInterval(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
//        boolean boolean8 = localDate1.equals((java.lang.Object) dateTimePrinter7);
//        int int9 = localDate1.getDayOfWeek();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField11 = copticChronology10.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology10, dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = copticChronology10.dayOfMonth();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, chronology18);
//        org.joda.time.DateTime.Property property20 = dateTime19.millisOfDay();
//        boolean boolean21 = property20.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType22);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField23.getType();
//        java.util.Locale locale25 = null;
//        int int26 = delegatedDateTimeField23.getMaximumTextLength(locale25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = delegatedDateTimeField23.getAsShortText((int) ' ', locale28);
//        org.joda.time.DurationField durationField30 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder31.appendHourOfHalfday((int) ' ');
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(10L, chronology38);
//        org.joda.time.DateTime.Property property40 = dateTime39.millisOfDay();
//        boolean boolean41 = property40.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType42);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimePrinter dateTimePrinter45 = dateTimeFormatter44.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder43.append(dateTimePrinter45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendFractionOfDay(16, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder49.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder51.appendHourOfHalfday((int) ' ');
//        org.joda.time.Chronology chronology58 = null;
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(10L, chronology58);
//        org.joda.time.DateTime.Property property60 = dateTime59.millisOfDay();
//        boolean boolean61 = property60.isLeap();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property60.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder56.appendShortText(dateTimeFieldType62);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType62, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField69 = gJChronology68.millis();
//        org.joda.time.DurationField durationField70 = gJChronology68.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField70);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, (int) (short) 1, 800);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField76 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField23, durationField30, dateTimeFieldType62, 976);
//        java.lang.String str78 = delegatedDateTimeField23.getAsText((long) (byte) 0);
//        boolean boolean79 = localDate1.equals((java.lang.Object) delegatedDateTimeField23);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(localDate3);
//        org.junit.Assert.assertNotNull(interval5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimePrinter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(zonedChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "32" + "'", str29.equals("32"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimePrinter45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(durationField70);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "23" + "'", str78.equals("23"));
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3, 31, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = copticChronology1.weekyears();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology1, dateTimeZone5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology7.getZone();
        org.joda.time.Chronology chronology9 = zonedChronology6.withZone(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.secondOfMinute();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(31L, (org.joda.time.Chronology) julianChronology10);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        org.joda.time.DurationField durationField22 = unsupportedDateTimeField20.getDurationField();
        try {
            long long24 = unsupportedDateTimeField20.roundFloor((long) 34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology36);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = copticChronology39.weekyears();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology41.getZone();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology39, dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = copticChronology39.dayOfMonth();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(10L, chronology47);
        org.joda.time.DateTime.Property property49 = dateTime48.millisOfDay();
        boolean boolean50 = property49.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property49.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45, dateTimeFieldType51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = delegatedDateTimeField52.getType();
        java.util.Locale locale54 = null;
        int int55 = delegatedDateTimeField52.getMaximumTextLength(locale54);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate59 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology58);
        org.joda.time.LocalDate localDate61 = localDate59.plusMonths((int) (short) 1);
        int int62 = localDate57.compareTo((org.joda.time.ReadablePartial) localDate59);
        org.joda.time.LocalDate localDate64 = localDate57.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfWeek();
        org.joda.time.LocalDate localDate66 = property65.roundCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate69 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology68);
        org.joda.time.LocalDate localDate71 = localDate69.plusMonths((int) (short) 1);
        org.joda.time.Partial partial72 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate71);
        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology75 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate76 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology75);
        org.joda.time.LocalDate localDate78 = localDate76.plusMonths((int) (short) 1);
        int int79 = localDate74.compareTo((org.joda.time.ReadablePartial) localDate76);
        boolean boolean80 = partial72.isMatch((org.joda.time.ReadablePartial) localDate74);
        int[] intArray81 = partial72.getValues();
        int[] intArray83 = delegatedDateTimeField52.addWrapPartial((org.joda.time.ReadablePartial) localDate66, 57600010, intArray81, 0);
        int[] intArray85 = offsetDateTimeField32.addWrapField((org.joda.time.ReadablePartial) localDate37, (int) (short) 0, intArray83, 1969);
        long long87 = offsetDateTimeField32.roundHalfCeiling(19523904L);
        int int89 = offsetDateTimeField32.getLeapAmount((long) (byte) -1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(zonedChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(copticChronology68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(copticChronology75);
        org.junit.Assert.assertNotNull(localDate76);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 0L + "'", long87 == 0L);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("Pacific Standard Time", "[year=1735, monthOfYear=10, dayOfMonth=8]", (int) (short) 1, (int) 'a');
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.Chronology chronology7 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.isFixed();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        java.lang.String str7 = localDate1.toString();
        int int8 = localDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.LocalDate localDate11 = localDate1.withPeriodAdded(readablePeriod9, (int) (byte) 1);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology14);
        org.joda.time.LocalDate localDate17 = localDate15.plusMonths((int) (short) 1);
        int int18 = localDate13.compareTo((org.joda.time.ReadablePartial) localDate15);
        boolean boolean19 = localDate1.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.LocalDate localDate21 = localDate13.plusDays(3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(10L, chronology20);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfDay();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readableDuration23);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, chronology26);
        org.joda.time.DateTime.Property property28 = dateTime27.millisOfDay();
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.plus(readableDuration29);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property32 = dateTime21.dayOfMonth();
        boolean boolean33 = instant18.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.Chronology chronology34 = instant18.getChronology();
        java.util.Date date35 = instant18.toDate();
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.fromDateFields(date35);
        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks(0);
        int[] intArray39 = new int[] {};
        int int40 = delegatedDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDate38, intArray39);
        long long43 = delegatedDateTimeField13.set((long) 23, "11");
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField45 = gJChronology44.millis();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology44.millisOfDay();
        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology44);
        int[] intArray49 = null;
        try {
            int[] intArray51 = delegatedDateTimeField13.set((org.joda.time.ReadablePartial) localDate47, 31, intArray49, 1686);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1686 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1036799977L) + "'", long43 == (-1036799977L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(localDate47);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField13.getType();
        java.util.Locale locale15 = null;
        int int16 = delegatedDateTimeField13.getMaximumTextLength(locale15);
        org.joda.time.Instant instant18 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(10L, chronology20);
        org.joda.time.DateTime.Property property22 = dateTime21.millisOfDay();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readableDuration23);
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(10L, chronology26);
        org.joda.time.DateTime.Property property28 = dateTime27.millisOfDay();
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.plus(readableDuration29);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property32 = dateTime21.dayOfMonth();
        boolean boolean33 = instant18.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.Chronology chronology34 = instant18.getChronology();
        java.util.Date date35 = instant18.toDate();
        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.fromDateFields(date35);
        org.joda.time.LocalDate localDate38 = localDate36.minusWeeks(0);
        int[] intArray39 = new int[] {};
        int int40 = delegatedDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDate38, intArray39);
        int int42 = delegatedDateTimeField13.getMaximumValue((long) 8);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int int44 = delegatedDateTimeField13.getMaximumValue(readablePartial43);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int int46 = delegatedDateTimeField13.getMaximumValue(readablePartial45);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 30 + "'", int42 == 30);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 30 + "'", int44 == 30);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 30 + "'", int46 == 30);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        boolean boolean6 = localDate1.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.LocalDate.Property property7 = localDate1.dayOfYear();
        boolean boolean8 = property7.isLeap();
        org.joda.time.DurationField durationField9 = property7.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(durationField9);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
//        int int9 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusWeeks(36600000);
//        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime11.withMinuteOfHour(800);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 800 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTimeZoneOffset("3", "1735", false, 86399999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        org.joda.time.chrono.CopticChronology copticChronology36 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology36);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = copticChronology39.weekyears();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology41.getZone();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology39, dateTimeZone43);
        org.joda.time.DateTimeField dateTimeField45 = copticChronology39.dayOfMonth();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(10L, chronology47);
        org.joda.time.DateTime.Property property49 = dateTime48.millisOfDay();
        boolean boolean50 = property49.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property49.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45, dateTimeFieldType51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = delegatedDateTimeField52.getType();
        java.util.Locale locale54 = null;
        int int55 = delegatedDateTimeField52.getMaximumTextLength(locale54);
        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate59 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology58);
        org.joda.time.LocalDate localDate61 = localDate59.plusMonths((int) (short) 1);
        int int62 = localDate57.compareTo((org.joda.time.ReadablePartial) localDate59);
        org.joda.time.LocalDate localDate64 = localDate57.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property65 = localDate64.dayOfWeek();
        org.joda.time.LocalDate localDate66 = property65.roundCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology68 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate69 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology68);
        org.joda.time.LocalDate localDate71 = localDate69.plusMonths((int) (short) 1);
        org.joda.time.Partial partial72 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate71);
        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology75 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate76 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology75);
        org.joda.time.LocalDate localDate78 = localDate76.plusMonths((int) (short) 1);
        int int79 = localDate74.compareTo((org.joda.time.ReadablePartial) localDate76);
        boolean boolean80 = partial72.isMatch((org.joda.time.ReadablePartial) localDate74);
        int[] intArray81 = partial72.getValues();
        int[] intArray83 = delegatedDateTimeField52.addWrapPartial((org.joda.time.ReadablePartial) localDate66, 57600010, intArray81, 0);
        int[] intArray85 = offsetDateTimeField32.addWrapField((org.joda.time.ReadablePartial) localDate37, (int) (short) 0, intArray83, 1969);
        java.lang.String str87 = offsetDateTimeField32.getAsShortText((long) 24);
        long long89 = offsetDateTimeField32.roundHalfFloor(52L);
        int int90 = offsetDateTimeField32.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertNotNull(copticChronology36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(zonedChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(localDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(copticChronology68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(localDate71);
        org.junit.Assert.assertNotNull(copticChronology75);
        org.junit.Assert.assertNotNull(localDate76);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "24" + "'", str87.equals("24"));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 31 + "'", int90 == 31);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(10L, chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readableDuration10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readableDuration16);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(10L, chronology19);
        org.joda.time.DateTime.Property property21 = dateTime20.millisOfDay();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.plus(readableDuration22);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(10L, chronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.millisOfDay();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime26.plus(readableDuration28);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime31 = dateTime29.toDateTime();
        org.joda.time.DateTime dateTime36 = dateTime31.withTime(1, (int) (short) 0, (int) (byte) 1, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 10, (int) (short) 10);
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(10L, chronology41);
        org.joda.time.DateTime.Property property43 = dateTime42.millisOfDay();
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.plus(readableDuration44);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(10L, chronology47);
        org.joda.time.DateTime.Property property49 = dateTime48.millisOfDay();
        org.joda.time.ReadableDuration readableDuration50 = null;
        org.joda.time.DateTime dateTime51 = dateTime48.plus(readableDuration50);
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime42, (org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime.Property property53 = dateTime42.dayOfMonth();
        int int54 = dateTimeZone39.getOffset((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime dateTime55 = dateTime31.withZoneRetainFields(dateTimeZone39);
        org.joda.time.DateTime dateTime56 = dateTime15.withZone(dateTimeZone39);
        try {
            org.joda.time.DateTime dateTime58 = dateTime56.withSecondOfMinute(86400030);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400030 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 36600000 + "'", int54 == 36600000);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology0.dayOfMonth();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(10L, chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.millisOfDay();
        boolean boolean11 = property10.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property10.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = copticChronology14.weekyears();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology14, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology14.dayOfMonth();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(10L, chronology22);
        org.joda.time.DateTime.Property property24 = dateTime23.millisOfDay();
        boolean boolean25 = property24.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField27.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField13, dateTimeFieldType28, 1, 16, 1735);
        java.lang.String str33 = offsetDateTimeField32.getName();
        long long35 = offsetDateTimeField32.roundCeiling((long) (byte) 10);
        int int37 = offsetDateTimeField32.get((long) (short) 1);
        long long39 = offsetDateTimeField32.roundCeiling(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField32.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime(10L, chronology48);
        org.joda.time.DateTime.Property property50 = dateTime49.millisOfDay();
        boolean boolean51 = property50.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property50.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder46.appendShortText(dateTimeFieldType52);
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.millis();
        org.joda.time.DurationField durationField60 = gJChronology58.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField61 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType52, durationField60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder64.appendDayOfYear((int) (short) 10);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField68 = copticChronology67.weekyears();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone70 = gJChronology69.getZone();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeUtils.getZone(dateTimeZone70);
        org.joda.time.chrono.ZonedChronology zonedChronology72 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology67, dateTimeZone71);
        org.joda.time.DateTimeField dateTimeField73 = copticChronology67.dayOfMonth();
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(10L, chronology75);
        org.joda.time.DateTime.Property property77 = dateTime76.millisOfDay();
        boolean boolean78 = property77.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property77.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField80 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73, dateTimeFieldType79);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField80.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException84 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType81, (java.lang.Number) 86399999, "1969-12-31T��:��");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder66.appendText(dateTimeFieldType81);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField87 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, durationField60, dateTimeFieldType81, 36600000);
        long long89 = dividedDateTimeField87.remainder((long) 100);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(zonedChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 100L + "'", long89 == 100L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = copticChronology2.weekyears();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, dateTimeZone6);
        org.joda.time.DateTime dateTime8 = localDate1.toDateTimeAtStartOfDay(dateTimeZone6);
        try {
            org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1, (java.lang.Number) 7, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.withPeriodAdded(readablePeriod1, 57600010);
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfCentury((int) ' ');
//        long long7 = dateTime6.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1985207658922L + "'", long7 == 1985207658922L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 86399999, (java.lang.Number) 86400000L, (java.lang.Number) (-1L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.millis();
        org.joda.time.DurationField durationField19 = gJChronology17.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField19);
        boolean boolean21 = unsupportedDateTimeField20.isLenient();
        java.lang.String str22 = unsupportedDateTimeField20.getName();
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = copticChronology23.weekyears();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology25.getZone();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology23, dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = copticChronology23.dayOfMonth();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        java.lang.String str32 = delegatedDateTimeField30.getAsShortText((long) '#');
        org.joda.time.DurationField durationField33 = delegatedDateTimeField30.getLeapDurationField();
        org.joda.time.Instant instant35 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(10L, chronology37);
        org.joda.time.DateTime.Property property39 = dateTime38.millisOfDay();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime41 = dateTime38.plus(readableDuration40);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(10L, chronology43);
        org.joda.time.DateTime.Property property45 = dateTime44.millisOfDay();
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime44.plus(readableDuration46);
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime38, (org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime.Property property49 = dateTime38.dayOfMonth();
        boolean boolean50 = instant35.isAfter((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.Chronology chronology51 = instant35.getChronology();
        java.util.Date date52 = instant35.toDate();
        org.joda.time.LocalDate localDate53 = org.joda.time.LocalDate.fromDateFields(date52);
        org.joda.time.LocalDate localDate55 = localDate53.minusWeeks(0);
        java.util.Locale locale57 = null;
        java.lang.String str58 = delegatedDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate55, (int) (short) 100, locale57);
        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate55);
        try {
            int int60 = unsupportedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDate55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "millisOfDay" + "'", str22.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "23" + "'", str32.equals("23"));
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(10L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10L, chronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.plus(readableDuration12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime4.dayOfMonth();
        boolean boolean16 = instant1.isAfter((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology17 = instant1.getChronology();
        java.util.Date date18 = instant1.toDate();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.fromDateFields(date18);
        org.joda.time.LocalDate localDate21 = localDate19.minusWeeks(0);
        int int22 = localDate21.size();
        org.joda.time.LocalDate localDate24 = localDate21.withYearOfCentury(3);
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology25);
        org.joda.time.LocalDate localDate28 = localDate26.plusMonths((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.Interval interval30 = localDate26.toInterval(dateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = dateTimeFormatter31.getPrinter();
        boolean boolean33 = localDate26.equals((java.lang.Object) dateTimePrinter32);
        org.joda.time.LocalDate.Property property34 = localDate26.dayOfYear();
        org.joda.time.LocalDate localDate35 = property34.roundHalfCeilingCopy();
        boolean boolean36 = localDate21.isEqual((org.joda.time.ReadablePartial) localDate35);
        int int37 = localDate21.getDayOfYear();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(interval30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimePrinter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 365 + "'", int37 == 365);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.plusMonths((int) (short) 1);
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial4.getFieldTypes();
        org.joda.time.Chronology chronology6 = partial4.getChronology();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial4);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10L, chronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder5.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendTimeZoneOffset("GregorianChronology[America/Los_Angeles]", true, (int) (short) 1, 34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder16.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder22.appendTimeZoneOffset("1970", "", false, (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusMonths((int) (short) 1);
        int int6 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate3);
        org.joda.time.LocalDate localDate8 = localDate1.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
        org.joda.time.DateMidnight dateMidnight11 = localDate10.toDateMidnight();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = copticChronology0.weekyears();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology0, dateTimeZone4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology6.getZone();
        org.joda.time.Chronology chronology8 = zonedChronology5.withZone(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = copticChronology11.weekyears();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology11, dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology17.getZone();
        org.joda.time.Chronology chronology19 = zonedChronology16.withZone(dateTimeZone18);
        org.joda.time.DurationField durationField20 = zonedChronology16.hours();
        org.joda.time.DateTimeField dateTimeField21 = zonedChronology16.millisOfDay();
        boolean boolean22 = julianChronology9.equals((java.lang.Object) dateTimeField21);
        org.joda.time.DateTimeField dateTimeField23 = julianChronology9.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = copticChronology3.weekyears();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology3, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology3.dayOfMonth();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(10L, chronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        boolean boolean14 = property13.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType15);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = copticChronology17.weekyears();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology17, dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = copticChronology17.dayOfMonth();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(10L, chronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.millisOfDay();
        boolean boolean28 = property27.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23, dateTimeFieldType29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = delegatedDateTimeField30.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType31, 1, 16, 1735);
        java.lang.String str36 = offsetDateTimeField35.getName();
        long long38 = offsetDateTimeField35.roundCeiling((long) (byte) 10);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology39);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DurationField durationField43 = copticChronology42.weekyears();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone45 = gJChronology44.getZone();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology42, dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = copticChronology42.dayOfMonth();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(10L, chronology50);
        org.joda.time.DateTime.Property property52 = dateTime51.millisOfDay();
        boolean boolean53 = property52.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property52.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = delegatedDateTimeField55.getType();
        java.util.Locale locale57 = null;
        int int58 = delegatedDateTimeField55.getMaximumTextLength(locale57);
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology61 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate62 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology61);
        org.joda.time.LocalDate localDate64 = localDate62.plusMonths((int) (short) 1);
        int int65 = localDate60.compareTo((org.joda.time.ReadablePartial) localDate62);
        org.joda.time.LocalDate localDate67 = localDate60.plusWeeks((int) (short) 1);
        org.joda.time.LocalDate.Property property68 = localDate67.dayOfWeek();
        org.joda.time.LocalDate localDate69 = property68.roundCeilingCopy();
        org.joda.time.chrono.CopticChronology copticChronology71 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate72 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology71);
        org.joda.time.LocalDate localDate74 = localDate72.plusMonths((int) (short) 1);
        org.joda.time.Partial partial75 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate74);
        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((long) '4');
        org.joda.time.chrono.CopticChronology copticChronology78 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate79 = org.joda.time.LocalDate.now((org.joda.time.Chronology) copticChronology78);
        org.joda.time.LocalDate localDate81 = localDate79.plusMonths((int) (short) 1);
        int int82 = localDate77.compareTo((org.joda.time.ReadablePartial) localDate79);
        boolean boolean83 = partial75.isMatch((org.joda.time.ReadablePartial) localDate77);
        int[] intArray84 = partial75.getValues();
        int[] intArray86 = delegatedDateTimeField55.addWrapPartial((org.joda.time.ReadablePartial) localDate69, 57600010, intArray84, 0);
        int[] intArray88 = offsetDateTimeField35.addWrapField((org.joda.time.ReadablePartial) localDate40, (int) (short) 0, intArray86, 1969);
        java.lang.String str90 = offsetDateTimeField35.getAsShortText((long) 24);
        org.joda.time.field.SkipDateTimeField skipDateTimeField91 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField35);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "millisOfDay" + "'", str36.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 86400000L + "'", long38 == 86400000L);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNotNull(copticChronology61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(copticChronology71);
        org.junit.Assert.assertNotNull(localDate72);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertNotNull(copticChronology78);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertNotNull(localDate81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "24" + "'", str90.equals("24"));
    }
}

