import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("107", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(45);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-52));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.Period period8 = new org.joda.time.Period(4, 10, 0, 0, 45, (int) (short) -1, 0, 35);
        org.joda.time.Period period9 = period8.toPeriod();
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType5);
        org.joda.time.Period period8 = period2.minusMillis((int) (short) 0);
        org.joda.time.Period period10 = period2.minusWeeks((int) '#');
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant11, readableInstant12, periodType13);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType28, "");
        int int31 = period14.indexOf(durationFieldType28);
        org.joda.time.field.PreciseDurationField preciseDurationField33 = new org.joda.time.field.PreciseDurationField(durationFieldType28, 1560629796559L);
        org.joda.time.Period period35 = period2.withField(durationFieldType28, (-244058));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(mutablePeriod15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period35);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField5.getAsText((-3), locale14);
//        java.util.Locale locale18 = null;
//        try {
//            long long19 = offsetDateTimeField5.set(2L, "UTC", locale18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for clockhourOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-3" + "'", str15.equals("-3"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        boolean boolean23 = unsupportedDurationField21.isSupported();
        try {
            long long26 = unsupportedDurationField21.getMillis(10, 106L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 10);
        org.joda.time.Period period3 = period1.minusMillis((int) (short) 100);
        org.joda.time.Period period5 = period3.minusSeconds((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(31104000000000000L, "hi!");
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone11.getUncachedZone();
        java.util.Locale locale16 = null;
        java.lang.String str17 = cachedDateTimeZone11.getName((long) (byte) -1, locale16);
        int int19 = cachedDateTimeZone11.getOffset((long) (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.001" + "'", str17.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test012");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.remainder(0L);
//        boolean boolean12 = offsetDateTimeField5.isLeap(0L);
//        long long14 = offsetDateTimeField5.roundHalfCeiling(79L);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-18062L) + "'", long14 == (-18062L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType17, 1560629796559L);
        long long25 = preciseDurationField22.getMillis((long) 1, (long) (byte) 100);
        long long28 = preciseDurationField22.getDifferenceAsLong((long) (byte) 100, 0L);
        java.lang.String str29 = preciseDurationField22.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560629796559L + "'", long25 == 1560629796559L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DurationField[years]" + "'", str29.equals("DurationField[years]"));
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        org.joda.time.PeriodType periodType11 = null;
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType11, chronology12);
//        org.joda.time.Period period14 = period13.toPeriod();
//        int[] intArray15 = period14.getValues();
//        org.joda.time.DurationFieldType[] durationFieldTypeArray16 = period14.getFieldTypes();
//        org.joda.time.Period period18 = period14.minusWeeks(0);
//        int[] intArray19 = period14.getValues();
//        int int20 = offsetDateTimeField5.getMinimumValue(readablePartial8, intArray19);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField5.getDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(durationFieldTypeArray16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = fixedDateTimeZone4.previousTransition(11L);
        long long15 = fixedDateTimeZone4.nextTransition(240L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 11L + "'", long13 == 11L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 240L + "'", long15 == 240L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        boolean boolean23 = unsupportedDurationField21.isSupported();
        try {
            long long25 = unsupportedDurationField21.getMillis((-53));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) ' ');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField5.getAsText((-97), locale13);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField5.getAsShortText(readablePartial15, 35, locale17);
//        long long20 = offsetDateTimeField5.roundFloor(0L);
//        java.util.Locale locale21 = null;
//        int int22 = offsetDateTimeField5.getMaximumShortTextLength(locale21);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-97" + "'", str14.equals("-97"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "35" + "'", str18.equals("35"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-18062L) + "'", long20 == (-18062L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField5.getAsText((-97), locale13);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
//        java.lang.String str17 = offsetDateTimeField5.toString();
//        long long19 = offsetDateTimeField5.roundHalfFloor((long) 18062);
//        long long21 = offsetDateTimeField5.roundHalfCeiling((long) 3);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1);
//        long long29 = offsetDateTimeField27.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField30 = offsetDateTimeField27.getLeapDurationField();
//        long long32 = offsetDateTimeField27.remainder(0L);
//        boolean boolean34 = offsetDateTimeField27.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial35 = null;
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField27.getAsText(readablePartial35, 23765, locale37);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField27.getAsShortText(readablePartial39, 360000000, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField27.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 0, 0, 23765);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType43, 18062, (int) ' ', (-3880));
//        int int53 = offsetDateTimeField5.getMinimumValue((long) 107);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-97" + "'", str14.equals("-97"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str17.equals("DateTimeField[clockhourOfDay]"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-18062L) + "'", long19 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-18062L) + "'", long21 == (-18062L));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-18062L) + "'", long29 == (-18062L));
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18062L + "'", long32 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "23765" + "'", str38.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "360000000" + "'", str42.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        java.lang.String str11 = offsetDateTimeField5.getAsText(45L);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getDurationField();
//        long long15 = offsetDateTimeField5.add((-210866846400000L), 0L);
//        long long17 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "25" + "'", str11.equals("25"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-210866846400000L) + "'", long15 == (-210866846400000L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-18062L) + "'", long17 == (-18062L));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.Chronology chronology22 = lenientChronology20.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str28 = fixedDateTimeZone27.toString();
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone27.getName((long) '#', locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.clockhourOfHalfday();
        org.joda.time.DurationField durationField36 = gregorianChronology32.weekyears();
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology32);
        boolean boolean38 = lenientChronology20.equals((java.lang.Object) gregorianChronology32);
        org.joda.time.DateTimeField dateTimeField39 = lenientChronology20.yearOfEra();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.001" + "'", str31.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeField39);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Period period7 = period5.plusYears(0);
        int int8 = period7.getMillis();
        org.joda.time.Period period10 = period7.withMinutes((int) (short) 1);
        org.joda.time.Period period12 = period7.minusDays((int) (short) 10);
        org.joda.time.Period period13 = period12.toPeriod();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-3) + "'", int8 == (-3));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMillisRemoved();
        java.lang.String str3 = periodType2.getName();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType5 = periodType4.withMonthsRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.DateTimeUtils.getPeriodType(periodType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType10, chronology11);
        org.joda.time.Period period13 = period12.toPeriod();
        int int14 = period12.getDays();
        org.joda.time.Duration duration15 = period12.toStandardDuration();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) period12);
        org.joda.time.format.PeriodFormatter periodFormatter17 = null;
        java.lang.String str18 = period16.toString(periodFormatter17);
        org.joda.time.DurationFieldType durationFieldType20 = period16.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType20, "");
        boolean boolean23 = periodType7.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField24 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        int int25 = periodType6.indexOf(durationFieldType20);
        boolean boolean26 = periodType2.isSupported(durationFieldType20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType20, "org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported");
        boolean boolean29 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException28);
        illegalFieldValueException28.prependMessage("YearMonthDayTime");
        java.lang.Number number32 = illegalFieldValueException28.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MillisNoMillis" + "'", str3.equals("MillisNoMillis"));
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PT-0.003S" + "'", str18.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "");
        java.lang.String str15 = illegalFieldValueException14.getFieldName();
        java.lang.String str16 = illegalFieldValueException14.getIllegalStringValue();
        java.lang.Number number17 = illegalFieldValueException14.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
        int int16 = periodType15.size();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType15, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.PeriodType periodType20 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType20);
        org.joda.time.Period period23 = period21.multipliedBy(7);
        int int24 = period21.getMillis();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-3) + "'", int24 == (-3));
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test030");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField5.getAsText((-97), locale13);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
//        java.lang.String str17 = offsetDateTimeField5.toString();
//        long long19 = offsetDateTimeField5.roundHalfFloor((long) 18062);
//        long long21 = offsetDateTimeField5.roundHalfCeiling((long) 3);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        java.util.Locale locale23 = null;
//        try {
//            java.lang.String str24 = offsetDateTimeField5.getAsShortText(readablePartial22, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-97" + "'", str14.equals("-97"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str17.equals("DateTimeField[clockhourOfDay]"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-18062L) + "'", long19 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-18062L) + "'", long21 == (-18062L));
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        try {
            long long21 = gregorianChronology9.getDateTimeMillis((int) (short) 0, 0, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType14, chronology15);
        org.joda.time.Period period17 = period16.toPeriod();
        int[] intArray18 = period17.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray19 = period17.getFieldTypes();
        org.joda.time.Period period21 = period17.plusMinutes((int) (short) 100);
        int[] intArray23 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period17, (long) (byte) 10);
        org.joda.time.DurationField durationField24 = gregorianChronology10.days();
        org.joda.time.ReadablePartial readablePartial25 = null;
        try {
            int[] intArray27 = gregorianChronology10.get(readablePartial25, 6911899900L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(durationFieldTypeArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period6 = period4.minusSeconds((int) (byte) 1);
        int int7 = period4.getYears();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        org.joda.time.MutablePeriod mutablePeriod12 = period11.toMutablePeriod();
        org.joda.time.Period period14 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.Period period18 = period14.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType20 = period18.getFieldType((int) (short) 0);
        int int21 = period11.indexOf(durationFieldType20);
        org.joda.time.Period period23 = period4.withField(durationFieldType20, 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(mutablePeriod12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "P-1W" + "'", str16.equals("P-1W"));
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(period23);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.roundHalfEven(3023999999L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3023981938L + "'", long10 == 3023981938L);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone11.getUncachedZone();
        boolean boolean15 = cachedDateTimeZone11.isFixed();
        java.lang.String str17 = cachedDateTimeZone11.getNameKey((long) (byte) 0);
        int int19 = cachedDateTimeZone11.getStandardOffset(100L);
        int int21 = cachedDateTimeZone11.getOffsetFromLocal((-60479999900L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str23 = lenientChronology22.toString();
        long long29 = lenientChronology22.getDateTimeMillis((long) (byte) 10, 10, 4, (int) '4', (int) (short) -1);
        org.joda.time.DurationField durationField30 = lenientChronology22.halfdays();
        org.joda.time.Chronology chronology31 = lenientChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = lenientChronology22.millisOfDay();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str23.equals("LenientChronology[GregorianChronology[]]"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 36291998L + "'", long29 == 36291998L);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        try {
            int int26 = unsupportedDurationField21.getValue(0L, (-8380800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) "P-1W");
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyearOfCentury();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType26, chronology27);
        org.joda.time.Period period29 = period28.toPeriod();
        int int30 = period28.getDays();
        org.joda.time.Duration duration31 = period28.toStandardDuration();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.days();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration31, periodType33);
        boolean boolean35 = unsupportedDurationField21.equals((java.lang.Object) period34);
        int[] intArray36 = period34.getValues();
        org.joda.time.Period period38 = period34.plusMinutes(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(period38);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType17, 1560629796559L);
        long long25 = preciseDurationField22.getValueAsLong((-3024000000L), (long) 7);
        long long28 = preciseDurationField22.add((long) (byte) -1, 4);
        long long31 = preciseDurationField22.add(6911899900L, (int) ' ');
        long long34 = preciseDurationField22.getValueAsLong(1L, 0L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 6242519186235L + "'", long28 == 6242519186235L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 49947065389788L + "'", long31 == 49947065389788L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12);
        int int14 = period13.getWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Period period2 = new org.joda.time.Period(97L, periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology15.getZone();
        try {
            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) dateTimeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test045");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor((long) (-97));
//        long long9 = offsetDateTimeField5.roundFloor((long) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        long long16 = iSOChronology12.add(0L, 0L, 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str22 = fixedDateTimeZone21.toString();
//        long long24 = fixedDateTimeZone21.convertUTCToLocal((long) (byte) 1);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = fixedDateTimeZone21.getName((long) (byte) 0, locale26);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
//        org.joda.time.Period period31 = org.joda.time.Period.weeks((int) (short) -1);
//        org.joda.time.format.PeriodFormatter periodFormatter32 = null;
//        java.lang.String str33 = period31.toString(periodFormatter32);
//        org.joda.time.Period period35 = period31.plusMonths(0);
//        int[] intArray38 = iSOChronology12.get((org.joda.time.ReadablePeriod) period35, (-210866760000000L), (long) (short) 0);
//        try {
//            int[] intArray40 = offsetDateTimeField5.set(readablePartial10, 0, intArray38, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfDay must be in the range [2,25]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-18062L) + "'", long9 == (-18062L));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2L + "'", long24 == 2L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.001" + "'", str27.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "P-1W" + "'", str33.equals("P-1W"));
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str6 = fixedDateTimeZone5.toString();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        org.joda.time.Chronology chronology17 = gregorianChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.monthOfYear();
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 1);
//        long long27 = offsetDateTimeField25.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField28 = offsetDateTimeField25.getLeapDurationField();
//        long long30 = offsetDateTimeField25.remainder(0L);
//        boolean boolean32 = offsetDateTimeField25.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField25.getAsText(readablePartial33, 23765, locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField25.getAsShortText(readablePartial37, 360000000, locale39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField25.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType41, 0, 0, 23765);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-18062L) + "'", long27 == (-18062L));
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 18062L + "'", long30 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "23765" + "'", str36.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "360000000" + "'", str40.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.Chronology chronology26 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.PeriodType periodType29 = null;
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType29, chronology30);
        org.joda.time.Period period32 = period31.toPeriod();
        int int33 = period31.getDays();
        boolean boolean34 = fixedDateTimeZone19.equals((java.lang.Object) int33);
        java.util.TimeZone timeZone35 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.util.TimeZone timeZone41 = fixedDateTimeZone40.toTimeZone();
        long long44 = fixedDateTimeZone40.adjustOffset((long) (byte) 0, true);
        long long46 = fixedDateTimeZone40.previousTransition(3395L);
        long long50 = fixedDateTimeZone40.convertLocalToUTC((long) 45, true, (-1L));
        long long52 = fixedDateTimeZone19.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone40, 6911899900L);
        java.lang.String str54 = fixedDateTimeZone40.getNameKey(52L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 3395L + "'", long46 == 3395L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 44L + "'", long50 == 44L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 6911899900L + "'", long52 == 6911899900L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 33, "Coordinated Universal Time");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("PeriodType[Millis]", "PT-0.003S");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        illegalFieldValueException6.prependMessage("hi!");
        java.lang.Number number11 = illegalFieldValueException6.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT-0.003S" + "'", str7.equals("PT-0.003S"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("P-1W", (java.lang.Number) 3, (java.lang.Number) 1, (java.lang.Number) (-1.0f));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.previousTransition(0L);
        long long9 = fixedDateTimeZone4.nextTransition(12L);
        java.lang.String str10 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getMonths();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period8 = period4.withPeriodType(periodType7);
        org.joda.time.Period period10 = period8.minusMillis(360000000);
        try {
            org.joda.time.Period period12 = period10.withWeeks((-2385));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-244058), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-244023L) + "'", long2 == (-244023L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) (-97));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-87L) + "'", long2 == (-87L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        long long33 = decoratedDurationField29.getMillis(0);
        long long34 = decoratedDurationField29.getUnitMillis();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 86400000L + "'", long34 == 86400000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.plusMinutes((int) (short) 100);
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType12, chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        int[] intArray16 = period15.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period15.getFieldTypes();
        org.joda.time.Period period19 = period15.minusYears((int) (short) 10);
        org.joda.time.Period period20 = period5.plus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period22 = period19.withYears(3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.Period period25 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        int[] intArray27 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period25, (long) 7);
        org.joda.time.Period period29 = period25.minusWeeks(45);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Duration duration31 = period25.toDurationTo(readableInstant30);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(duration31);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        int int32 = decoratedDurationField29.getValue((long) 0);
        long long35 = decoratedDurationField29.subtract(31104000000000000L, 0);
        long long38 = decoratedDurationField29.getDifferenceAsLong(36291998L, (long) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31104000000000000L + "'", long35 == 31104000000000000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekyear();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType27, chronology28);
        org.joda.time.Period period30 = period29.toPeriod();
        int int31 = period29.getDays();
        int[] intArray33 = iSOChronology22.get((org.joda.time.ReadablePeriod) period29, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology22.hourOfHalfday();
        boolean boolean36 = iSOChronology22.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str42 = fixedDateTimeZone41.toString();
        long long44 = fixedDateTimeZone41.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale46 = null;
        java.lang.String str47 = fixedDateTimeZone41.getName((long) (byte) 0, locale46);
        org.joda.time.Chronology chronology48 = iSOChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType51, chronology52);
        org.joda.time.Period period54 = period53.toPeriod();
        int int55 = period53.getDays();
        boolean boolean56 = fixedDateTimeZone41.equals((java.lang.Object) int55);
        java.util.TimeZone timeZone57 = fixedDateTimeZone41.toTimeZone();
        org.joda.time.Chronology chronology58 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        int int60 = fixedDateTimeZone41.getStandardOffset(5233L);
        java.lang.Class<?> wildcardClass61 = fixedDateTimeZone41.getClass();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2L + "'", long44 == 2L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.001" + "'", str47.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getStandardOffset((long) (-53));
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        org.joda.time.ReadableInstant readableInstant16 = null;
        int int17 = fixedDateTimeZone15.getOffset(readableInstant16);
        long long19 = fixedDateTimeZone15.nextTransition((long) 45);
        long long21 = dateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 45L + "'", long19 == 45L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str27 = fixedDateTimeZone26.toString();
        java.util.Locale locale29 = null;
        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime31);
        org.joda.time.Chronology chronology33 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        java.lang.String str34 = fixedDateTimeZone26.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PeriodType[Millis]", "7", 360000000, (int) '#');
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("MillisNoMillis");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'MillisNoMillis' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        int int16 = cachedDateTimeZone11.getOffset(200L);
        long long19 = cachedDateTimeZone11.convertLocalToUTC(3024000000L, true);
        int int21 = cachedDateTimeZone11.getStandardOffset((-53L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3023999999L + "'", long19 == 3023999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology30 = zonedChronology17.withUTC();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.PeriodType periodType33 = periodType32.withWeeksRemoved();
        boolean boolean34 = zonedChronology17.equals((java.lang.Object) periodType33);
        java.lang.String str35 = zonedChronology17.toString();
        org.joda.time.DateTimeField dateTimeField36 = zonedChronology17.weekyear();
        try {
            long long42 = zonedChronology17.getDateTimeMillis((long) 23765, (int) (byte) 10, (int) (short) 10, (-52), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str35.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Weeks weeks12 = period11.toStandardWeeks();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType20, chronology21);
        org.joda.time.Period period23 = period22.toPeriod();
        int int24 = period22.getDays();
        org.joda.time.Duration duration25 = period22.toStandardDuration();
        org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) period22);
        org.joda.time.format.PeriodFormatter periodFormatter27 = null;
        java.lang.String str28 = period26.toString(periodFormatter27);
        org.joda.time.DurationFieldType durationFieldType30 = period26.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(durationFieldType30, "");
        int int33 = period16.indexOf(durationFieldType30);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField34 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType30);
        java.lang.String str35 = unsupportedDurationField34.toString();
        org.joda.time.DurationFieldType durationFieldType36 = unsupportedDurationField34.getType();
        int int37 = period11.indexOf(durationFieldType36);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType41 = null;
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType41, chronology42);
        org.joda.time.Period period44 = period43.toPeriod();
        int int45 = period43.getDays();
        org.joda.time.Duration duration46 = period43.toStandardDuration();
        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period43);
        org.joda.time.format.PeriodFormatter periodFormatter48 = null;
        java.lang.String str49 = period47.toString(periodFormatter48);
        org.joda.time.DurationFieldType durationFieldType51 = period47.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(durationFieldType51, "");
        boolean boolean54 = periodType38.isSupported(durationFieldType51);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField55 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType51);
        int int56 = period11.indexOf(durationFieldType51);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField57 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType51);
        java.lang.String str58 = unsupportedDurationField57.toString();
        boolean boolean59 = unsupportedDurationField57.isSupported();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PT-0.003S" + "'", str28.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UnsupportedDurationField[years]" + "'", str35.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(duration46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "PT-0.003S" + "'", str49.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "UnsupportedDurationField[years]" + "'", str58.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("P-1W");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P-1W/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.remainder(0L);
//        java.lang.String str11 = offsetDateTimeField5.getName();
//        long long13 = offsetDateTimeField5.roundHalfCeiling((-244023L));
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText((int) (byte) 1, locale15);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "clockhourOfDay" + "'", str11.equals("clockhourOfDay"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-18062L) + "'", long13 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getMonths();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.PeriodType periodType11 = periodType9.withMinutesRemoved();
        org.joda.time.PeriodType periodType12 = periodType9.withSecondsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant7, readableInstant8, periodType9);
        org.joda.time.PeriodType periodType14 = periodType9.withMillisRemoved();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
        org.joda.time.Period period22 = period21.toPeriod();
        int int23 = period21.getDays();
        org.joda.time.Duration duration24 = period21.toStandardDuration();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant16, (org.joda.time.ReadableDuration) duration24);
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration24);
        org.joda.time.Weeks weeks27 = period26.toStandardWeeks();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant28, readableInstant29, periodType30);
        org.joda.time.MutablePeriod mutablePeriod32 = period31.toMutablePeriod();
        org.joda.time.PeriodType periodType35 = null;
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType35, chronology36);
        org.joda.time.Period period38 = period37.toPeriod();
        int int39 = period37.getDays();
        org.joda.time.Duration duration40 = period37.toStandardDuration();
        org.joda.time.Period period41 = new org.joda.time.Period((java.lang.Object) period37);
        org.joda.time.format.PeriodFormatter periodFormatter42 = null;
        java.lang.String str43 = period41.toString(periodFormatter42);
        org.joda.time.DurationFieldType durationFieldType45 = period41.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(durationFieldType45, "");
        int int48 = period31.indexOf(durationFieldType45);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType45);
        java.lang.String str50 = unsupportedDurationField49.toString();
        org.joda.time.DurationFieldType durationFieldType51 = unsupportedDurationField49.getType();
        int int52 = period26.indexOf(durationFieldType51);
        boolean boolean53 = periodType14.isSupported(durationFieldType51);
        boolean boolean54 = period4.isSupported(durationFieldType51);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(weeks27);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(mutablePeriod32);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(duration40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "PT-0.003S" + "'", str43.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "UnsupportedDurationField[years]" + "'", str50.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        int int8 = period4.getMinutes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        int int17 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str23 = fixedDateTimeZone22.toString();
        java.util.Locale locale25 = null;
        java.lang.String str26 = fixedDateTimeZone22.getName((long) '#', locale25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DurationField durationField28 = gregorianChronology27.weekyears();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
        org.joda.time.Chronology chronology30 = gregorianChronology9.withZone(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.001" + "'", str26.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withSecondsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType7 = periodType2.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        int int3 = periodType2.size();
        org.joda.time.PeriodType periodType4 = periodType2.withSecondsRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period(2L, periodType1, chronology3);
        org.joda.time.PeriodType periodType5 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology9.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        long long22 = iSOChronology18.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str28 = fixedDateTimeZone27.toString();
        long long30 = fixedDateTimeZone27.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale32 = null;
        java.lang.String str33 = fixedDateTimeZone27.getName((long) (byte) 0, locale32);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.joda.time.chrono.ZonedChronology zonedChronology35 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology18, (org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.joda.time.Period period37 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter38 = null;
        java.lang.String str39 = period37.toString(periodFormatter38);
        org.joda.time.Period period41 = period37.plusMonths(0);
        int[] intArray44 = iSOChronology18.get((org.joda.time.ReadablePeriod) period41, (-210866760000000L), (long) (short) 0);
        boolean boolean45 = gregorianChronology9.equals((java.lang.Object) intArray44);
        try {
            long long51 = gregorianChronology9.getDateTimeMillis(82800000L, 97, 10, (int) (byte) 1, (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2L + "'", long30 == 2L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.001" + "'", str33.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
        org.junit.Assert.assertNotNull(zonedChronology35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "P-1W" + "'", str39.equals("P-1W"));
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType8, chronology9);
        org.joda.time.Period period11 = period10.toPeriod();
        int[] intArray12 = period11.getValues();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePeriod) period11, (long) (byte) 100, (long) (byte) 0);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone17 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Period period19 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter20 = null;
        java.lang.String str21 = period19.toString(periodFormatter20);
        org.joda.time.Period period23 = period19.plusMonths(0);
        int[] intArray26 = iSOChronology0.get((org.joda.time.ReadablePeriod) period23, (-210866760000000L), (long) (short) 0);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField28 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "P-1W" + "'", str21.equals("P-1W"));
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        long long10 = offsetDateTimeField5.add((long) 97, (-2385));
//        boolean boolean11 = offsetDateTimeField5.isSupported();
//        boolean boolean12 = offsetDateTimeField5.isSupported();
//        boolean boolean14 = offsetDateTimeField5.isLeap((-59108893199000L));
//        try {
//            long long17 = offsetDateTimeField5.add(0L, (-4681889389677L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -4681889389677 * 3600000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-8585999903L) + "'", long10 == (-8585999903L));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        long long16 = cachedDateTimeZone11.convertUTCToLocal((long) 10);
        int int18 = cachedDateTimeZone11.getOffset((long) (short) -1);
        java.util.Locale locale20 = null;
        java.lang.String str21 = cachedDateTimeZone11.getShortName(0L, locale20);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.001" + "'", str21.equals("+00:00:00.001"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.BufferedReader bufferedReader4 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler5 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file6 = null;
        java.io.File[] fileArray7 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = zoneInfoCompiler5.compile(file6, fileArray7);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = zoneInfoCompiler0.compile(file4, fileArray7);
        java.io.BufferedReader bufferedReader10 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(strMap9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType8, chronology9);
        org.joda.time.Period period11 = period10.toPeriod();
        int[] intArray12 = period11.getValues();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePeriod) period11, (long) (byte) 100, (long) (byte) 0);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology17.getZone();
        org.joda.time.Period period32 = org.joda.time.Period.weeks((int) (byte) 10);
        org.joda.time.Period period34 = period32.minusMillis((int) (short) 100);
        org.joda.time.Period period36 = period34.minusSeconds((int) (byte) 100);
        long long39 = zonedChronology17.add((org.joda.time.ReadablePeriod) period36, 864000000L, 1);
        org.joda.time.Period period41 = period36.withMonths(97);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 6911899900L + "'", long39 == 6911899900L);
        org.junit.Assert.assertNotNull(period41);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.remainder(0L);
//        java.lang.String str11 = offsetDateTimeField5.toString();
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        java.util.Locale locale13 = null;
//        try {
//            java.lang.String str14 = offsetDateTimeField5.getAsShortText(readablePartial12, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str11.equals("DateTimeField[clockhourOfDay]"));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 1);
//        long long8 = offsetDateTimeField6.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField9 = offsetDateTimeField6.getLeapDurationField();
//        long long11 = offsetDateTimeField6.remainder(0L);
//        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField6.getAsText(readablePartial14, 23765, locale16);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField6.getAsShortText(readablePartial18, 360000000, locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField6.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 0, 0, 23765);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-18062L) + "'", long8 == (-18062L));
//        org.junit.Assert.assertNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 18062L + "'", long11 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "23765" + "'", str17.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "360000000" + "'", str21.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 10, (-97), 2, 10, 97, (-3), 360000000, 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "UTC", "GregorianChronology[]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "-97", "13");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 1);
//        long long8 = offsetDateTimeField6.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField9 = offsetDateTimeField6.getLeapDurationField();
//        long long11 = offsetDateTimeField6.remainder(0L);
//        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField6.getAsText(readablePartial14, 23765, locale16);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField6.getAsShortText(readablePartial18, 360000000, locale20);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField6.getType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-18062L) + "'", long8 == (-18062L));
//        org.junit.Assert.assertNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 18062L + "'", long11 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "23765" + "'", str17.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "360000000" + "'", str21.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        org.joda.time.DurationField durationField33 = decoratedDurationField29.getWrappedField();
        long long36 = decoratedDurationField29.subtract(9615401784000000L, 65023199947L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-5608389073636800000L) + "'", long36 == (-5608389073636800000L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((-60479999900L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.add(0L, (long) 33);
        org.joda.time.DurationFieldType durationFieldType33 = decoratedDurationField29.getType();
        java.lang.String str34 = decoratedDurationField29.getName();
        long long35 = decoratedDurationField29.getUnitMillis();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2851200000L + "'", long32 == 2851200000L);
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "years" + "'", str34.equals("years"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3395, (-53), (-52));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-53) + "'", int3 == (-53));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long8 = offsetDateTimeField5.roundHalfFloor(113730005L);
//        int int9 = offsetDateTimeField5.getMinimumValue();
//        org.joda.time.DurationField durationField10 = offsetDateTimeField5.getRangeDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 115181938L + "'", long8 == 115181938L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField5.getAsText((-97), locale13);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
//        java.lang.String str17 = offsetDateTimeField5.toString();
//        long long19 = offsetDateTimeField5.roundHalfFloor((long) 18062);
//        long long21 = offsetDateTimeField5.roundHalfCeiling((long) 3);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1);
//        long long29 = offsetDateTimeField27.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField30 = offsetDateTimeField27.getLeapDurationField();
//        long long32 = offsetDateTimeField27.remainder(0L);
//        boolean boolean34 = offsetDateTimeField27.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial35 = null;
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField27.getAsText(readablePartial35, 23765, locale37);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField27.getAsShortText(readablePartial39, 360000000, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField27.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 0, 0, 23765);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType43, 18062, (int) ' ', (-3880));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone56 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str57 = fixedDateTimeZone56.toString();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = fixedDateTimeZone56.getName((long) '#', locale59);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone56);
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology61.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology61.clockhourOfHalfday();
//        org.joda.time.DurationField durationField65 = gregorianChronology61.weekyears();
//        int int66 = gregorianChronology61.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField67 = gregorianChronology61.days();
//        org.joda.time.PeriodType periodType70 = null;
//        org.joda.time.Chronology chronology71 = null;
//        org.joda.time.Period period72 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType70, chronology71);
//        org.joda.time.Period period73 = period72.toPeriod();
//        int int74 = period72.getDays();
//        org.joda.time.Duration duration75 = period72.toStandardDuration();
//        org.joda.time.Period period76 = new org.joda.time.Period((java.lang.Object) period72);
//        org.joda.time.format.PeriodFormatter periodFormatter77 = null;
//        java.lang.String str78 = period76.toString(periodFormatter77);
//        org.joda.time.DurationFieldType durationFieldType80 = period76.getFieldType(0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField81 = new org.joda.time.field.DecoratedDurationField(durationField67, durationFieldType80);
//        long long84 = decoratedDurationField81.getMillis((long) (byte) 1, 0L);
//        long long85 = decoratedDurationField81.getUnitMillis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, (org.joda.time.DurationField) decoratedDurationField81);
//        java.util.Locale locale87 = null;
//        try {
//            int int88 = unsupportedDateTimeField86.getMaximumTextLength(locale87);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-97" + "'", str14.equals("-97"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str17.equals("DateTimeField[clockhourOfDay]"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-18062L) + "'", long19 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-18062L) + "'", long21 == (-18062L));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-18062L) + "'", long29 == (-18062L));
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18062L + "'", long32 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "23765" + "'", str38.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "360000000" + "'", str42.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00:00.001" + "'", str60.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(period73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(duration75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "PT-0.003S" + "'", str78.equals("PT-0.003S"));
//        org.junit.Assert.assertNotNull(durationFieldType80);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 86400000L + "'", long84 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 86400000L + "'", long85 == 86400000L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getMonths();
        org.joda.time.Period period5 = period2.withWeeks((int) (byte) -1);
        int[] intArray6 = period2.getValues();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsShortText(0, locale7);
        boolean boolean9 = offsetDateTimeField5.isSupported();
        int int10 = offsetDateTimeField5.getMaximumValue();
        long long13 = offsetDateTimeField5.add(10L, (long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 115200010L + "'", long13 == 115200010L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) 0, 40, 0, (-1));
        org.joda.time.Duration duration5 = period4.toStandardDuration();
        org.junit.Assert.assertNotNull(duration5);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test098");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.remainder(0L);
//        boolean boolean12 = offsetDateTimeField5.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsText(readablePartial13, 23765, locale15);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField5.getAsShortText(readablePartial17, 360000000, locale19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str27 = fixedDateTimeZone26.toString();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.clockhourOfHalfday();
//        org.joda.time.DurationField durationField35 = gregorianChronology31.weekyears();
//        int int36 = gregorianChronology31.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField37 = gregorianChronology31.days();
//        org.joda.time.PeriodType periodType40 = null;
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.Period period42 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType40, chronology41);
//        org.joda.time.Period period43 = period42.toPeriod();
//        int int44 = period42.getDays();
//        org.joda.time.Duration duration45 = period42.toStandardDuration();
//        org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) period42);
//        org.joda.time.format.PeriodFormatter periodFormatter47 = null;
//        java.lang.String str48 = period46.toString(periodFormatter47);
//        org.joda.time.DurationFieldType durationFieldType50 = period46.getFieldType(0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField51 = new org.joda.time.field.DecoratedDurationField(durationField37, durationFieldType50);
//        java.lang.String str52 = decoratedDurationField51.getName();
//        boolean boolean53 = decoratedDurationField51.isSupported();
//        long long56 = decoratedDurationField51.getMillis((long) (short) 10, 3395L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, (org.joda.time.DurationField) decoratedDurationField51);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "23765" + "'", str16.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "360000000" + "'", str20.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(duration45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PT-0.003S" + "'", str48.equals("PT-0.003S"));
//        org.junit.Assert.assertNotNull(durationFieldType50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "years" + "'", str52.equals("years"));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 864000000L + "'", long56 == 864000000L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsShortText(0, locale7);
        int int9 = offsetDateTimeField5.getOffset();
        boolean boolean10 = offsetDateTimeField5.isSupported();
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str23 = lenientChronology22.toString();
        long long29 = lenientChronology22.getDateTimeMillis((long) (byte) 10, 10, 4, (int) '4', (int) (short) -1);
        org.joda.time.DurationField durationField30 = lenientChronology22.halfdays();
        org.joda.time.DateTimeField dateTimeField31 = lenientChronology22.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str23.equals("LenientChronology[GregorianChronology[]]"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 36291998L + "'", long29 == 36291998L);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test101");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        long long11 = offsetDateTimeField5.roundHalfFloor((long) (short) 0);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField5.getAsText((-97), locale13);
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField5.getMaximumShortTextLength(locale15);
//        java.lang.String str17 = offsetDateTimeField5.toString();
//        long long19 = offsetDateTimeField5.roundHalfFloor((long) 18062);
//        long long21 = offsetDateTimeField5.roundHalfCeiling((long) 3);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 1);
//        long long29 = offsetDateTimeField27.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField30 = offsetDateTimeField27.getLeapDurationField();
//        long long32 = offsetDateTimeField27.remainder(0L);
//        boolean boolean34 = offsetDateTimeField27.isLeap(0L);
//        org.joda.time.ReadablePartial readablePartial35 = null;
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField27.getAsText(readablePartial35, 23765, locale37);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField27.getAsShortText(readablePartial39, 360000000, locale41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField27.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType43, 0, 0, 23765);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType43, 18062, (int) ' ', (-3880));
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone56 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str57 = fixedDateTimeZone56.toString();
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = fixedDateTimeZone56.getName((long) '#', locale59);
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone56);
//        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology61.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology61.clockhourOfHalfday();
//        org.joda.time.DurationField durationField65 = gregorianChronology61.weekyears();
//        int int66 = gregorianChronology61.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField67 = gregorianChronology61.days();
//        org.joda.time.PeriodType periodType70 = null;
//        org.joda.time.Chronology chronology71 = null;
//        org.joda.time.Period period72 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType70, chronology71);
//        org.joda.time.Period period73 = period72.toPeriod();
//        int int74 = period72.getDays();
//        org.joda.time.Duration duration75 = period72.toStandardDuration();
//        org.joda.time.Period period76 = new org.joda.time.Period((java.lang.Object) period72);
//        org.joda.time.format.PeriodFormatter periodFormatter77 = null;
//        java.lang.String str78 = period76.toString(periodFormatter77);
//        org.joda.time.DurationFieldType durationFieldType80 = period76.getFieldType(0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField81 = new org.joda.time.field.DecoratedDurationField(durationField67, durationFieldType80);
//        long long84 = decoratedDurationField81.getMillis((long) (byte) 1, 0L);
//        long long85 = decoratedDurationField81.getUnitMillis();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, (org.joda.time.DurationField) decoratedDurationField81);
//        org.joda.time.ReadablePartial readablePartial87 = null;
//        java.util.Locale locale89 = null;
//        try {
//            java.lang.String str90 = unsupportedDateTimeField86.getAsText(readablePartial87, (-3), locale89);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-97" + "'", str14.equals("-97"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str17.equals("DateTimeField[clockhourOfDay]"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-18062L) + "'", long19 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-18062L) + "'", long21 == (-18062L));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-18062L) + "'", long29 == (-18062L));
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18062L + "'", long32 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "23765" + "'", str38.equals("23765"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "360000000" + "'", str42.equals("360000000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00:00.001" + "'", str60.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(period73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(duration75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "PT-0.003S" + "'", str78.equals("PT-0.003S"));
//        org.junit.Assert.assertNotNull(durationFieldType80);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 86400000L + "'", long84 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 86400000L + "'", long85 == 86400000L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str23 = lenientChronology22.toString();
        java.lang.String str24 = lenientChronology22.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str23.equals("LenientChronology[GregorianChronology[]]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str24.equals("LenientChronology[GregorianChronology[]]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        long long12 = fixedDateTimeZone4.nextTransition((long) 33);
        int int14 = fixedDateTimeZone4.getOffsetFromLocal(1L);
        java.lang.String str16 = fixedDateTimeZone4.getNameKey((-345600000L));
        java.lang.String str17 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 33L + "'", long12 == 33L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        java.lang.String str16 = gregorianChronology9.toString();
        org.joda.time.DurationField durationField17 = gregorianChronology9.halfdays();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[]" + "'", str16.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str23 = lenientChronology22.toString();
        long long31 = lenientChronology22.getDateTimeMillis(97, 0, (int) (byte) -1, 7, 0, (int) (short) 1, 1);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str40 = fixedDateTimeZone39.toString();
        java.util.Locale locale42 = null;
        java.lang.String str43 = fixedDateTimeZone39.getName((long) '#', locale42);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology44.clockhourOfHalfday();
        org.joda.time.DurationField durationField48 = gregorianChronology44.weekyears();
        int int49 = gregorianChronology44.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField50 = gregorianChronology44.days();
        org.joda.time.Period period51 = new org.joda.time.Period(0L, (long) 35, periodType34, (org.joda.time.Chronology) gregorianChronology44);
        org.joda.time.chrono.LenientChronology lenientChronology52 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology44);
        org.joda.time.DateTimeField dateTimeField53 = lenientChronology52.dayOfMonth();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone58 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str59 = fixedDateTimeZone58.toString();
        long long61 = fixedDateTimeZone58.convertUTCToLocal((long) (byte) 1);
        java.lang.String str63 = fixedDateTimeZone58.getName((long) (short) 1);
        org.joda.time.Chronology chronology64 = lenientChronology52.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone58);
        org.joda.time.Chronology chronology65 = lenientChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone58);
        org.joda.time.LocalDateTime localDateTime66 = null;
        boolean boolean67 = fixedDateTimeZone58.isLocalDateTimeGap(localDateTime66);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str23.equals("LenientChronology[GregorianChronology[]]"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-59108893199000L) + "'", long31 == (-59108893199000L));
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00:00.001" + "'", str43.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(lenientChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2L + "'", long61 == 2L);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "+00:00:00.001" + "'", str63.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor(0L);
//        org.joda.time.DurationField durationField8 = offsetDateTimeField5.getLeapDurationField();
//        long long10 = offsetDateTimeField5.remainder(0L);
//        boolean boolean12 = offsetDateTimeField5.isLeap(0L);
//        long long14 = offsetDateTimeField5.roundHalfCeiling(79L);
//        int int16 = offsetDateTimeField5.getMinimumValue((-864000001L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18062L + "'", long10 == 18062L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-18062L) + "'", long14 == (-18062L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test108");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        long long7 = offsetDateTimeField5.roundHalfFloor((long) (-97));
//        long long9 = offsetDateTimeField5.roundHalfCeiling(65023200000L);
//        long long11 = offsetDateTimeField5.roundHalfFloor(107L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-18062L) + "'", long7 == (-18062L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 65023181938L + "'", long9 == 65023181938L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-18062L) + "'", long11 == (-18062L));
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
//        org.joda.time.DateTimeField dateTimeField6 = offsetDateTimeField5.getWrappedField();
//        long long9 = offsetDateTimeField5.getDifferenceAsLong(0L, (-864000004L));
//        java.lang.String str11 = offsetDateTimeField5.getAsText(45L);
//        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getDurationField();
//        long long14 = offsetDateTimeField5.roundHalfFloor(35L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 240L + "'", long9 == 240L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "25" + "'", str11.equals("25"));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-18062L) + "'", long14 == (-18062L));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("360000000");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology30 = zonedChronology17.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str36 = fixedDateTimeZone35.toString();
        long long38 = fixedDateTimeZone35.convertUTCToLocal((long) (byte) 1);
        boolean boolean39 = fixedDateTimeZone35.isFixed();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.Chronology chronology42 = gregorianChronology40.withZone(dateTimeZone41);
        boolean boolean43 = zonedChronology17.equals((java.lang.Object) chronology42);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.PeriodType periodType48 = null;
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType48, chronology49);
        org.joda.time.Period period51 = period50.toPeriod();
        int int52 = period50.getDays();
        org.joda.time.Duration duration53 = period50.toStandardDuration();
        org.joda.time.Period period54 = new org.joda.time.Period(readableInstant45, (org.joda.time.ReadableDuration) duration53);
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant44, (org.joda.time.ReadableDuration) duration53);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration53, readableInstant56);
        boolean boolean58 = zonedChronology17.equals((java.lang.Object) readableInstant56);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2L + "'", long38 == 2L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(duration53);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        java.lang.String str11 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.Period period8 = new org.joda.time.Period(40, (-1), 97, 0, 1, 107, (int) (short) 1, (int) (byte) 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "UTC", "GregorianChronology[]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "+52:00", "PeriodType[YearDayTime]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }
}

