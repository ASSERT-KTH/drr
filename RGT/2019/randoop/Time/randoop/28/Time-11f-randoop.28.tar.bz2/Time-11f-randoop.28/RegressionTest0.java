import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) 100.0f, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100L, (java.lang.Number) (short) 100, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 100, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d), (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.Period period1 = org.joda.time.Period.years((-1));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.forFields(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "Coordinated Universal Time");
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        java.lang.String str2 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[Millis]" + "'", str2.equals("PeriodType[Millis]"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
        java.lang.Throwable[] throwableArray2 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', (int) (byte) 1, 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10L, (java.lang.Number) 0L, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        int int9 = period8.getDays();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PT-0.003S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        try {
            long long19 = gregorianChronology10.getDateTimeMillis(10, (int) (byte) 10, 4, (int) '#', (int) (short) -1, (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long8 = iSOChronology0.getDateTimeMillis(33, 4, (int) (short) 0, 0, 1, 100, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PeriodType[Millis]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (short) 100, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(35, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(33);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0f, "PeriodType[Millis]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long3 = dateTimeZone1.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekOfWeekyear must be in the range [-1,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        try {
            long long25 = gregorianChronology15.getDateTimeMillis((int) (byte) 0, (int) 'a', (int) (short) 0, (int) (byte) 1, (int) '#', (int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866846400000L) + "'", long1 == (-210866846400000L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 1, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((-1L), locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (short) -1, (int) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        try {
            long long17 = gregorianChronology9.getDateTimeMillis(100, 0, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        try {
            long long17 = iSOChronology0.getDateTimeMillis(0L, (int) (byte) 0, (int) (byte) -1, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(0);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) -1, (java.lang.Number) 0L, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560629771343L + "'", long0 == 1560629771343L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period6);
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period10.toString(periodFormatter11);
        org.joda.time.DurationFieldType durationFieldType14 = period10.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType14, "");
        boolean boolean17 = periodType1.isSupported(durationFieldType14);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT-0.003S" + "'", str12.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            int int24 = unsupportedDurationField21.getDifference(45L, 200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType11, chronology12);
        org.joda.time.Period period14 = period13.toPeriod();
        int int15 = period13.getDays();
        org.joda.time.Duration duration16 = period13.toStandardDuration();
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period13);
        org.joda.time.format.PeriodFormatter periodFormatter18 = null;
        java.lang.String str19 = period17.toString(periodFormatter18);
        org.joda.time.DurationFieldType durationFieldType21 = period17.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "");
        boolean boolean24 = periodType8.isSupported(durationFieldType21);
        boolean boolean25 = period4.isSupported(durationFieldType21);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT-0.003S" + "'", str19.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 0, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(45);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long24 = unsupportedDurationField21.getValueAsLong((long) (byte) 0, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        org.joda.time.Period period10 = period8.minusSeconds((int) (byte) -1);
        try {
            org.joda.time.Minutes minutes11 = period10.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology10 = gregorianChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekyearOfCentury();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) (short) 100, 33, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hi! must be in the range [33,33]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, periodType1, chronology4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Seconds seconds7 = period6.toStandardSeconds();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(seconds7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withMonthsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(0, 0, (-1), (int) (short) 100, (int) (byte) 0, (int) (short) 10, 0, (int) 'a', periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        int int13 = period8.getYears();
        int int14 = period8.getYears();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) '4', (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period3 = period1.withMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period1.get(durationFieldType4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long24 = unsupportedDurationField21.getMillis((int) (byte) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withDaysRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType2.getFieldType(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Period period4 = new org.joda.time.Period(10, (int) (short) -1, (int) (byte) 10, (int) (byte) 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.PeriodType periodType20 = null;
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType20, chronology21);
        org.joda.time.Period period23 = period22.toPeriod();
        int int24 = period22.getDays();
        org.joda.time.Duration duration25 = period22.toStandardDuration();
        org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) period22);
        org.joda.time.format.PeriodFormatter periodFormatter27 = null;
        java.lang.String str28 = period26.toString(periodFormatter27);
        org.joda.time.Period period29 = period17.withFields((org.joda.time.ReadablePeriod) period26);
        org.joda.time.Weeks weeks30 = period29.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PT-0.003S" + "'", str28.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(weeks30);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, (long) (-3));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-210866846400000L), "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getMonths();
        org.joda.time.Period period5 = period2.withWeeks((int) (byte) -1);
        org.joda.time.Period period7 = period2.plusMinutes(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        int int2 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("P-1W", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P-1W/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.joda.time.Period period5 = period1.withMillis(45);
        org.joda.time.Period period7 = period5.plusMillis((int) '4');
        int int8 = period7.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "P-1W" + "'", str3.equals("P-1W"));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-52), (-53), (int) '#');
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.Period period4 = period2.withHours((-3));
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) -1, 33, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [33,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period10 = period9.negated();
        org.joda.time.Period period12 = period10.minusWeeks((int) (byte) -1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getHours();
        int int7 = period4.getYears();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        try {
            long long26 = unsupportedDurationField21.getMillis((long) (short) 0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("+00:00:00.001");
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.plusMinutes((int) (short) 100);
        java.lang.String str10 = period5.toString();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType10, chronology11);
        org.joda.time.Period period13 = period12.toPeriod();
        int[] intArray14 = period13.getValues();
        try {
            iSOChronology6.validate(readablePartial7, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) "P-1W");
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(97L, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3395L + "'", long2 == 3395L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            int int23 = unsupportedDurationField21.getValue((-60479999900L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long24 = unsupportedDurationField21.getValueAsLong((long) (short) 100, (long) 33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(45, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) -1, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getMonths();
        org.joda.time.Period period5 = period2.plusHours((int) (short) 1);
        org.joda.time.Period period7 = period2.withHours((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone1.getOffset(readableInstant3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 360000000 + "'", int4 == 360000000);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.MutablePeriod mutablePeriod5 = period4.toMutablePeriod();
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType8, chronology9);
        org.joda.time.Period period11 = period10.toPeriod();
        int int12 = period10.getDays();
        org.joda.time.Duration duration13 = period10.toStandardDuration();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period10);
        org.joda.time.format.PeriodFormatter periodFormatter15 = null;
        java.lang.String str16 = period14.toString(periodFormatter15);
        org.joda.time.DurationFieldType durationFieldType18 = period14.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType18, "");
        int int21 = period4.indexOf(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        java.lang.String str23 = unsupportedDurationField22.toString();
        org.joda.time.DurationField durationField24 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long27 = durationField24.subtract((long) (short) -1, (int) (byte) 0);
        int int28 = unsupportedDurationField22.compareTo(durationField24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str34 = fixedDateTimeZone33.toString();
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone33.getName((long) '#', locale36);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DurationField durationField39 = gregorianChronology38.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField40 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) unsupportedDurationField22, durationField39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(mutablePeriod5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PT-0.003S" + "'", str16.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDurationField[years]" + "'", str23.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00:00.001" + "'", str37.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(86400000L, (-4L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-345600000L) + "'", long2 == (-345600000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        long long21 = gregorianChronology15.add(33L, (long) 100, (int) '4');
        try {
            long long26 = gregorianChronology15.getDateTimeMillis(0, 35, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 5233L + "'", long21 == 5233L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, dateTimeFieldType13, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        org.joda.time.Period period32 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType34 = periodType33.withWeeksRemoved();
        org.joda.time.PeriodType periodType35 = periodType33.withMinutesRemoved();
        org.joda.time.Period period36 = period32.withPeriodType(periodType35);
        try {
            org.joda.time.Period period37 = new org.joda.time.Period((java.lang.Object) durationField15, periodType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("years");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'years' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        int int6 = fixedDateTimeZone4.getOffset((long) 10);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) "UnsupportedDurationField[years]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.days();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9, periodType11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3L) + "'", long13 == (-3L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
        int int15 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField16 = gregorianChronology10.days();
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
        org.joda.time.Period period22 = period21.toPeriod();
        int int23 = period21.getDays();
        org.joda.time.Duration duration24 = period21.toStandardDuration();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period21);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period25.toString(periodFormatter26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType29);
        org.joda.time.DurationField durationField31 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField32 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField16, durationField31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT-0.003S" + "'", str27.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType29);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long24 = unsupportedDurationField21.getDifferenceAsLong(97L, 9L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 100, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) -1, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period2.toString(periodFormatter9);
        org.joda.time.Seconds seconds11 = period2.toStandardSeconds();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.053S" + "'", str10.equals("PT-0.053S"));
        org.junit.Assert.assertNotNull(seconds11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "P-1W");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.previousTransition(0L);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = fixedDateTimeZone4.getOffset(readableInstant8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, periodType1, chronology4);
        org.joda.time.Period period7 = period5.minusYears((int) (byte) 10);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.dayOfWeek();
        org.joda.time.DurationField durationField17 = gregorianChronology9.weeks();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        int int12 = period11.getDays();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType26, chronology27);
        org.joda.time.Period period29 = period28.toPeriod();
        int int30 = period28.getDays();
        org.joda.time.Duration duration31 = period28.toStandardDuration();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.days();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration31, periodType33);
        boolean boolean35 = unsupportedDurationField21.equals((java.lang.Object) period34);
        try {
            org.joda.time.Period period37 = period34.withMinutes((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period(2L, periodType3, chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = periodType3.getFieldType((-53));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyear();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.Weeks weeks15 = period14.toStandardWeeks();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(weeks15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekyear();
        org.joda.time.DurationField durationField13 = gregorianChronology9.hours();
        org.joda.time.DurationField durationField14 = gregorianChronology9.days();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        try {
            int int10 = period8.getValue(360000000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 360000000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        try {
            long long25 = unsupportedDurationField21.add((long) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((-1L), locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getName((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
//        java.lang.String str6 = fixedDateTimeZone5.toString();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
//        int int15 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField16 = gregorianChronology10.days();
//        org.joda.time.PeriodType periodType19 = null;
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
//        org.joda.time.Period period22 = period21.toPeriod();
//        int int23 = period21.getDays();
//        org.joda.time.Duration duration24 = period21.toStandardDuration();
//        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period21);
//        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
//        java.lang.String str27 = period25.toString(periodFormatter26);
//        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
//        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType29);
//        java.lang.String str31 = decoratedDurationField30.getName();
//        int int33 = decoratedDurationField30.getValue(1560629771343L);
//        long long36 = decoratedDurationField30.getDifferenceAsLong((long) (short) 10, (-210866846400000L));
//        int int39 = decoratedDurationField30.getValue((long) (short) 0, 9L);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = dateTimeZone44.getName((-1L), locale46);
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
//        org.joda.time.Chronology chronology49 = iSOChronology40.withZone(dateTimeZone44);
//        org.joda.time.DurationField durationField50 = iSOChronology40.eras();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField51 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) decoratedDurationField30, durationField50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(duration24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT-0.003S" + "'", str27.equals("PT-0.003S"));
//        org.junit.Assert.assertNotNull(durationFieldType29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 18062 + "'", int33 == 18062);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2440588L + "'", long36 == 2440588L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Coordinated Universal Time" + "'", str47.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-210866846400000L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210866846399900L) + "'", long2 == (-210866846399900L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
        int int15 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField16 = gregorianChronology10.days();
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
        org.joda.time.Period period22 = period21.toPeriod();
        int int23 = period21.getDays();
        org.joda.time.Duration duration24 = period21.toStandardDuration();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period21);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period25.toString(periodFormatter26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType29);
        java.lang.String str31 = decoratedDurationField30.getName();
        int int33 = decoratedDurationField30.getValue(1560629771343L);
        long long36 = decoratedDurationField30.getDifferenceAsLong((long) (short) 10, (-210866846400000L));
        int int39 = decoratedDurationField30.getValue((long) (short) 0, 9L);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) decoratedDurationField30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT-0.003S" + "'", str27.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "years" + "'", str31.equals("years"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 18062 + "'", int33 == 18062);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2440588L + "'", long36 == 2440588L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        org.joda.time.Period period10 = period8.minusSeconds((int) (byte) -1);
        int int11 = period8.getSeconds();
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT-0.003S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((int) (byte) 0, (int) (byte) 1, (int) (short) 1, (int) '4', 10, (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.minusYears((int) (short) 10);
        try {
            org.joda.time.DurationFieldType durationFieldType11 = period9.getFieldType((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[Hours]", "+00:00:00.001");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        int int1 = periodType0.size();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType6, chronology7);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period8.getDays();
        org.joda.time.Duration duration11 = period8.toStandardDuration();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration11);
        org.joda.time.Weeks weeks14 = period13.toStandardWeeks();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant15, readableInstant16, periodType17);
        org.joda.time.MutablePeriod mutablePeriod19 = period18.toMutablePeriod();
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType22, chronology23);
        org.joda.time.Period period25 = period24.toPeriod();
        int int26 = period24.getDays();
        org.joda.time.Duration duration27 = period24.toStandardDuration();
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period24);
        org.joda.time.format.PeriodFormatter periodFormatter29 = null;
        java.lang.String str30 = period28.toString(periodFormatter29);
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType32, "");
        int int35 = period18.indexOf(durationFieldType32);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField36 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType32);
        java.lang.String str37 = unsupportedDurationField36.toString();
        org.joda.time.DurationFieldType durationFieldType38 = unsupportedDurationField36.getType();
        int int39 = period13.indexOf(durationFieldType38);
        boolean boolean40 = periodType0.isSupported(durationFieldType38);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(weeks14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(mutablePeriod19);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PT-0.003S" + "'", str30.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDurationField[years]" + "'", str37.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        try {
            long long17 = iSOChronology0.getDateTimeMillis((long) (-1), (int) ' ', 33, (int) 'a', (-53));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        java.lang.String str16 = cachedDateTimeZone11.getNameKey((-210866760000000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        try {
            long long20 = unsupportedDurationField17.getDifferenceAsLong((long) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("years");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"years\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Period period1 = org.joda.time.Period.months(360000000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("P-1W");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'P-1W' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) -1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(11L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        int int8 = period4.getWeeks();
        org.joda.time.Period period10 = period4.withWeeks(1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 7, 4, (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PeriodType[Millis]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMonthsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        int int4 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "P-1W" + "'", str3.equals("P-1W"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.DurationField durationField17 = gregorianChronology9.months();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology9.minuteOfDay();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType26, chronology27);
        org.joda.time.Period period29 = period28.toPeriod();
        int int30 = period28.getDays();
        org.joda.time.Duration duration31 = period28.toStandardDuration();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.days();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration31, periodType33);
        boolean boolean35 = unsupportedDurationField21.equals((java.lang.Object) period34);
        try {
            long long38 = unsupportedDurationField21.getDifferenceAsLong((long) (byte) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 97L, (java.lang.Number) 5233L, (java.lang.Number) (-210866760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 0);
        int[] intArray2 = period1.getValues();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(intArray2);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((-1L), locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.Chronology chronology9 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
//        org.joda.time.Period period12 = org.joda.time.Period.weeks((int) (short) -1);
//        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
//        java.lang.String str14 = period12.toString(periodFormatter13);
//        org.joda.time.Period period16 = period12.withMillis(45);
//        int[] intArray19 = iSOChronology0.get((org.joda.time.ReadablePeriod) period12, 45L, (long) 45);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableInstant21);
//        int int23 = period22.getMonths();
//        org.joda.time.Period period24 = period12.withFields((org.joda.time.ReadablePeriod) period22);
//        org.joda.time.Period period26 = period12.plusYears((int) '4');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1W" + "'", str14.equals("P-1W"));
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period26);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant16, readableInstant17, periodType18);
        org.joda.time.MutablePeriod mutablePeriod20 = period19.toMutablePeriod();
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType23, chronology24);
        org.joda.time.Period period26 = period25.toPeriod();
        int int27 = period25.getDays();
        org.joda.time.Duration duration28 = period25.toStandardDuration();
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period25);
        org.joda.time.format.PeriodFormatter periodFormatter30 = null;
        java.lang.String str31 = period29.toString(periodFormatter30);
        org.joda.time.DurationFieldType durationFieldType33 = period29.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(durationFieldType33, "");
        int int36 = period19.indexOf(durationFieldType33);
        org.joda.time.PeriodType periodType39 = null;
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType39, chronology40);
        org.joda.time.Period period42 = period41.toPeriod();
        int int43 = period41.getDays();
        org.joda.time.Duration duration44 = period41.toStandardDuration();
        org.joda.time.Period period45 = new org.joda.time.Period((java.lang.Object) period41);
        org.joda.time.format.PeriodFormatter periodFormatter46 = null;
        java.lang.String str47 = period45.toString(periodFormatter46);
        org.joda.time.DurationFieldType durationFieldType49 = period45.getFieldType(0);
        org.joda.time.Period period51 = period19.withFieldAdded(durationFieldType49, 0);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField15, durationFieldType49, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(mutablePeriod20);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PT-0.003S" + "'", str31.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(duration44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PT-0.003S" + "'", str47.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType49);
        org.junit.Assert.assertNotNull(period51);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType28, chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        int int32 = period30.getDays();
        org.joda.time.Duration duration33 = period30.toStandardDuration();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.days();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration33, periodType35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant39, periodType40);
        boolean boolean42 = unsupportedDurationField21.equals((java.lang.Object) readableInstant39);
        try {
            int int45 = unsupportedDurationField21.getValue(44L, (long) (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period3 = period1.withMinutes((int) (short) 0);
        org.joda.time.Period period5 = period3.plusDays((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        int int8 = period3.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField11 = gregorianChronology10.weekyears();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.Period period14 = period12.plusMinutes((int) (short) 0);
        org.joda.time.Weeks weeks15 = period12.toStandardWeeks();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(weeks15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        java.lang.Class<?> wildcardClass2 = chronology1.getClass();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType6, chronology7);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period8.getDays();
        org.joda.time.Duration duration11 = period8.toStandardDuration();
        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period8);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType16, "");
        boolean boolean19 = periodType3.isSupported(durationFieldType16);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType16);
        int int21 = periodType2.indexOf(durationFieldType16);
        java.lang.String str22 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PT-0.003S" + "'", str14.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Hours" + "'", str22.equals("Hours"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone11.getUncachedZone();
        long long14 = cachedDateTimeZone11.previousTransition((-210866846399900L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210866846399900L) + "'", long14 == (-210866846399900L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) "P-1W");
        org.joda.time.DurationField durationField6 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        try {
            int int24 = unsupportedDurationField21.getValue((long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.Period period22 = period3.minusMonths(360000000);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period11 = period9.withDays(33);
        org.joda.time.Period period13 = period11.withMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period3 = period1.withMinutes((int) (short) 0);
        int int5 = period3.getValue(4);
        org.joda.time.Period period7 = period3.withMinutes(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        java.lang.String str24 = unsupportedDurationField21.getName();
        try {
            long long27 = unsupportedDurationField21.add(9L, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "years" + "'", str24.equals("years"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) "P-1W");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        java.lang.String str9 = dateTimeZone7.getShortName((long) 'a');
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.097" + "'", str9.equals("+00:00:00.097"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.Period period3 = new org.joda.time.Period(97L, periodType2);
        org.joda.time.Period period4 = new org.joda.time.Period((-1L), periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 10, 18062, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, periodType1, chronology4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        java.lang.String str8 = periodType7.toString();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType7);
        try {
            org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[Hours]" + "'", str8.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-25199995L), (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-25200005L) + "'", long2 == (-25200005L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType22, chronology23);
        org.joda.time.Period period25 = period24.toPeriod();
        int int26 = period24.getDays();
        org.joda.time.Duration duration27 = period24.toStandardDuration();
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period24);
        org.joda.time.format.PeriodFormatter periodFormatter29 = null;
        java.lang.String str30 = period28.toString(periodFormatter29);
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType32, "");
        int int35 = period19.get(durationFieldType32);
        try {
            org.joda.time.Period period37 = period19.withMillis((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PT-0.003S" + "'", str30.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, 3024000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3024000000L) + "'", long2 == (-3024000000L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.Period period16 = new org.joda.time.Period((int) (byte) 1, (int) (short) 10, (int) (byte) 10, 0);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        long long20 = gregorianChronology9.add((org.joda.time.ReadablePeriod) period16, (-25199995L), 33);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology9.era();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 113730005L + "'", long20 == 113730005L);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getStandardOffset((long) (-53));
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyear();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.lang.String str28 = cachedDateTimeZone26.getNameKey(1L);
        int int30 = cachedDateTimeZone26.getOffset((long) (byte) 100);
        org.joda.time.Chronology chronology31 = gregorianChronology10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        int int33 = cachedDateTimeZone26.getStandardOffset(44L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Hours");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Hours/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(113730005L, 45L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113729960L + "'", long2 == 113729960L);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((-1L), locale3);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone1.getName(0L, locale7);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusWeeks((int) '4');
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        org.joda.time.DurationField durationField33 = decoratedDurationField29.getWrappedField();
        long long36 = decoratedDurationField29.add((-1L), 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str23 = fixedDateTimeZone22.toString();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        java.util.TimeZone timeZone25 = fixedDateTimeZone22.toTimeZone();
        boolean boolean26 = iSOChronology0.equals((java.lang.Object) timeZone25);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period13 = period11.plusYears((int) (short) 100);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        try {
            long long24 = zonedChronology17.getDateTimeMillis((long) (short) 0, (int) 'a', (int) ' ', (int) (byte) 1, (-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) '4');
        int int2 = period1.getWeeks();
        org.joda.time.Period period4 = period1.minusMonths(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.Period period10 = period6.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType12 = period10.getFieldType((int) (short) 0);
        int int13 = period3.indexOf(durationFieldType12);
        org.joda.time.Period period15 = period3.withMonths((int) (byte) 10);
        try {
            org.joda.time.Weeks weeks16 = period15.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P-1W" + "'", str8.equals("P-1W"));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.Chronology chronology26 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.PeriodType periodType29 = null;
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType29, chronology30);
        org.joda.time.Period period32 = period31.toPeriod();
        int int33 = period31.getDays();
        boolean boolean34 = fixedDateTimeZone19.equals((java.lang.Object) int33);
        java.util.TimeZone timeZone35 = fixedDateTimeZone19.toTimeZone();
        int int37 = fixedDateTimeZone19.getOffsetFromLocal(100L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            int int24 = unsupportedDurationField21.getDifference(33L, (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period10 = period9.negated();
        org.joda.time.DurationFieldType[] durationFieldTypeArray11 = period9.getFieldTypes();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldTypeArray11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) 113729960L, (java.lang.Number) (-60479999900L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        try {
            long long24 = unsupportedDurationField21.add(11L, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period4.toDurationTo(readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.indexOf(durationFieldType8);
        org.joda.time.Period period11 = period4.plusYears((int) (short) 10);
        org.joda.time.Period period13 = period11.withMillis(33);
        org.joda.time.Period period15 = period13.multipliedBy(100);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.Period period4 = new org.joda.time.Period((long) ' ', (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.Chronology chronology5 = iSOChronology1.withUTC();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology1.set(readablePartial6, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 1, 7, 0, '4', (int) ' ', (-52), 18062, true, (int) 'a');
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PeriodType[Millis]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period13 = period11.minusMinutes((int) (byte) 100);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        int int6 = fixedDateTimeZone4.getOffset((long) 10);
        long long9 = fixedDateTimeZone4.adjustOffset(1L, true);
        int int11 = fixedDateTimeZone4.getStandardOffset((long) 360000000);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 1, periodType1, chronology4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        java.lang.String str8 = periodType7.toString();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType7);
        try {
            org.joda.time.DurationFieldType durationFieldType11 = period5.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[Hours]" + "'", str8.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType22, chronology23);
        org.joda.time.Period period25 = period24.toPeriod();
        int int26 = period24.getDays();
        org.joda.time.Duration duration27 = period24.toStandardDuration();
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period24);
        org.joda.time.format.PeriodFormatter periodFormatter29 = null;
        java.lang.String str30 = period28.toString(periodFormatter29);
        org.joda.time.DurationFieldType durationFieldType32 = period28.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType32, "");
        int int35 = period19.get(durationFieldType32);
        try {
            org.joda.time.Period period37 = period19.minusMonths(35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PT-0.003S" + "'", str30.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.DurationField durationField15 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-3L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period6 = period4.minusSeconds((int) (byte) 1);
        org.joda.time.Period period8 = period6.minusDays((-1));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        try {
            long long26 = unsupportedDurationField21.getDifferenceAsLong((-3024000000L), 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        long long12 = fixedDateTimeZone4.nextTransition((long) 33);
        long long14 = fixedDateTimeZone4.previousTransition((long) (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 33L + "'", long12 == 33L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("MillisNoMillis", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType12, chronology13);
        org.joda.time.Period period15 = period14.toPeriod();
        int int16 = period14.getDays();
        org.joda.time.Duration duration17 = period14.toStandardDuration();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.days();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant8, (org.joda.time.ReadableDuration) duration17, periodType19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant23, periodType24);
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((int) (byte) 1, 97, (int) (byte) 10, 45, 18062, 360000000, (-1), 0, periodType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 1, 7, 0, '4', (int) ' ', (-52), 18062, true, (int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("PT-0.003S", (int) (byte) 100, 18062, 0, ' ', 0, 97, 0, true, (int) (short) -1);
        java.io.DataOutput dataOutput24 = null;
        try {
            dateTimeZoneBuilder0.writeTo("MillisNoMillis", dataOutput24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType28, chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        int int32 = period30.getDays();
        org.joda.time.Duration duration33 = period30.toStandardDuration();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.days();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration33, periodType35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant39, periodType40);
        boolean boolean42 = unsupportedDurationField21.equals((java.lang.Object) readableInstant39);
        try {
            long long44 = unsupportedDurationField21.getValueAsLong((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 1, 7, 0, '4', (int) ' ', (-52), 18062, true, (int) 'a');
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("Hours", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-53), (long) 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2385) + "'", int2 == (-2385));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        int int10 = fixedDateTimeZone4.getStandardOffset(97L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        try {
            long long7 = iSOChronology0.getDateTimeMillis((int) (byte) 1, (-53), 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.minuteOfHour();
        try {
            long long16 = gregorianChronology9.getDateTimeMillis(18062, (int) ' ', (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((-1L), locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.Chronology chronology9 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
//        org.joda.time.Period period12 = org.joda.time.Period.weeks((int) (short) -1);
//        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
//        java.lang.String str14 = period12.toString(periodFormatter13);
//        org.joda.time.Period period16 = period12.withMillis(45);
//        int[] intArray19 = iSOChronology0.get((org.joda.time.ReadablePeriod) period12, 45L, (long) 45);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableInstant21);
//        int int23 = period22.getMonths();
//        org.joda.time.Period period24 = period12.withFields((org.joda.time.ReadablePeriod) period22);
//        int int25 = period12.getYears();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1W" + "'", str14.equals("P-1W"));
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType4, chronology5);
        org.joda.time.Period period7 = period6.toPeriod();
        int int8 = period6.getDays();
        org.joda.time.Duration duration9 = period6.toStandardDuration();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration9);
        long long12 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3L) + "'", long12 == (-3L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone4.getShortName(11L, locale11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.001" + "'", str12.equals("+00:00:00.001"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Period period2 = new org.joda.time.Period(97L, periodType1);
        org.joda.time.Period period4 = period2.plusDays((int) (short) 1);
        try {
            org.joda.time.Period period6 = period4.plusHours(97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        int int3 = periodType2.size();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GregorianChronology[]", 45, (int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45 for GregorianChronology[] must be in the range [35,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", "");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 0, (long) (-52));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter2 = null;
        java.lang.String str3 = period1.toString(periodFormatter2);
        org.joda.time.Period period5 = period1.withWeeks(4);
        org.joda.time.Seconds seconds6 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "P-1W" + "'", str3.equals("P-1W"));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) periodType12);
        java.lang.String str16 = fixedDateTimeZone4.getNameKey((long) (-2385));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period(2L, periodType3, chronology5);
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.Period period16 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        org.joda.time.Period period18 = period16.minusSeconds((int) (byte) -1);
        org.joda.time.Period period19 = period16.negated();
        try {
            org.joda.time.Period period20 = period7.plus((org.joda.time.ReadablePeriod) period19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        long long18 = unsupportedDurationField17.getUnitMillis();
        java.lang.String str19 = unsupportedDurationField17.getName();
        try {
            long long21 = unsupportedDurationField17.getMillis((-345600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "years" + "'", str19.equals("years"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period4.toDurationTo(readableInstant6);
        org.joda.time.Period period9 = period4.plusYears(35);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PT-0.003S");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT-0.003S" + "'", str3.equals("PT-0.003S"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMillisRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(obj0, periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        long long18 = unsupportedDurationField17.getUnitMillis();
        try {
            long long21 = unsupportedDurationField17.getMillis((long) 45, (-4L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Period period1 = new org.joda.time.Period((-210866846399900L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DurationField durationField23 = lenientChronology22.millis();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.weekyear();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType6, chronology7);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period8.getDays();
        int[] intArray12 = iSOChronology1.get((org.joda.time.ReadablePeriod) period8, 0L);
        org.joda.time.Period period14 = period8.withSeconds((int) (byte) -1);
        org.joda.time.Duration duration15 = period14.toStandardDuration();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration15);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-25200005L), 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-176400035L) + "'", long2 == (-176400035L));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period3 = period1.withMinutes((int) (short) 0);
        int int5 = period3.getValue(4);
        org.joda.time.Period period7 = period3.plusWeeks((int) (byte) 10);
        org.joda.time.Seconds seconds8 = period7.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType17, (int) '#', (int) (short) 10, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        try {
            long long25 = unsupportedDurationField21.getMillis((long) (short) -1, (-345600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        int int6 = fixedDateTimeZone4.getOffset((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean8 = cachedDateTimeZone7.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Period period7 = period4.multipliedBy(100);
        org.joda.time.Period period9 = period7.plusWeeks((-1));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weekyears();
        int int15 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField16 = gregorianChronology10.days();
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
        org.joda.time.Period period22 = period21.toPeriod();
        int int23 = period21.getDays();
        org.joda.time.Duration duration24 = period21.toStandardDuration();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period21);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period25.toString(periodFormatter26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField30 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType29);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyear();
        org.joda.time.PeriodType periodType36 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType36, chronology37);
        org.joda.time.Period period39 = period38.toPeriod();
        int int40 = period38.getDays();
        int[] intArray42 = iSOChronology31.get((org.joda.time.ReadablePeriod) period38, 0L);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology31.hourOfHalfday();
        org.joda.time.DurationField durationField44 = iSOChronology31.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField16, durationField44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT-0.003S" + "'", str27.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Period period2 = new org.joda.time.Period(97L, periodType1);
        java.lang.String str3 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[Days]" + "'", str3.equals("PeriodType[Days]"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.nextTransition((long) 'a');
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        long long18 = unsupportedDurationField17.getUnitMillis();
        try {
            long long21 = unsupportedDurationField17.getMillis((int) (short) -1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560629796559L + "'", long1 == 1560629796559L);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period5.toDurationTo(readableInstant7);
        org.joda.time.Period period10 = period5.plusWeeks(1);
        org.joda.time.DurationFieldType durationFieldType12 = period5.getFieldType((int) (byte) 0);
        org.joda.time.Period period14 = period5.minusMinutes(97);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period5.toDurationFrom(readableInstant15);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType18 = periodType17.withWeeksRemoved();
        org.joda.time.PeriodType periodType19 = periodType17.withMinutesRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration16, periodType19);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withDaysRemoved();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) periodType12);
        java.lang.String str14 = fixedDateTimeZone4.getID();
        java.lang.String str16 = fixedDateTimeZone4.getNameKey((long) (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis(0, 86400000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '#', periodType1);
        try {
            org.joda.time.Period period5 = period3.plusMonths((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.Chronology chronology26 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.PeriodType periodType29 = null;
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType29, chronology30);
        org.joda.time.Period period32 = period31.toPeriod();
        int int33 = period31.getDays();
        boolean boolean34 = fixedDateTimeZone19.equals((java.lang.Object) int33);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.Period period10 = period6.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType12 = period10.getFieldType((int) (short) 0);
        int int13 = period3.indexOf(durationFieldType12);
        org.joda.time.Period period15 = period3.withMonths((int) (byte) 10);
        org.joda.time.Period period17 = period15.minusMonths((int) (short) 0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P-1W" + "'", str8.equals("P-1W"));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(2L, (-210866846400000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210866846399998L) + "'", long2 == (-210866846399998L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 100, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getMonths();
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.format.PeriodFormatter periodFormatter8 = null;
        java.lang.String str9 = period7.toString(periodFormatter8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT-0.003S" + "'", str9.equals("PT-0.003S"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology15.getZone();
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone18.isLocalDateTimeGap(localDateTime19);
        long long23 = dateTimeZone18.convertLocalToUTC(5233L, false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5232L + "'", long23 == 5232L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekyear();
        org.joda.time.DurationField durationField13 = gregorianChronology9.hours();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = gregorianChronology9.withZone(dateTimeZone14);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField19 = iSOChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.monthOfYear();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology18.clockhourOfHalfday();
        boolean boolean22 = iSOChronology17.equals((java.lang.Object) dateTimeField21);
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType25, chronology26);
        org.joda.time.Period period28 = period27.toPeriod();
        int[] intArray29 = period28.getValues();
        int[] intArray32 = iSOChronology17.get((org.joda.time.ReadablePeriod) period28, (long) (byte) 100, (long) (byte) 0);
        try {
            gregorianChronology9.validate(readablePartial16, intArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekyear();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType27, chronology28);
        org.joda.time.Period period30 = period29.toPeriod();
        int int31 = period29.getDays();
        int[] intArray33 = iSOChronology22.get((org.joda.time.ReadablePeriod) period29, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology22.hourOfHalfday();
        boolean boolean36 = iSOChronology22.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str42 = fixedDateTimeZone41.toString();
        long long44 = fixedDateTimeZone41.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale46 = null;
        java.lang.String str47 = fixedDateTimeZone41.getName((long) (byte) 0, locale46);
        org.joda.time.Chronology chronology48 = iSOChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType51, chronology52);
        org.joda.time.Period period54 = period53.toPeriod();
        int int55 = period53.getDays();
        boolean boolean56 = fixedDateTimeZone41.equals((java.lang.Object) int55);
        java.util.TimeZone timeZone57 = fixedDateTimeZone41.toTimeZone();
        org.joda.time.Chronology chronology58 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        long long60 = fixedDateTimeZone41.previousTransition((long) (short) 0);
        long long63 = fixedDateTimeZone41.convertLocalToUTC((long) 107, false);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2L + "'", long44 == 2L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.001" + "'", str47.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 106L + "'", long63 == 106L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.Period period25 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        int[] intArray27 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period25, (long) 7);
        org.joda.time.Period period29 = period25.plusSeconds((int) '#');
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getMonths();
        org.joda.time.Period period5 = period2.plusHours((int) (short) 1);
        org.joda.time.PeriodType periodType6 = period2.getPeriodType();
        int int7 = period2.getMinutes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("UTC", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 1, 7, 0, '4', (int) ' ', (-52), 18062, true, (int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("PT-0.003S", (int) (byte) 100, 18062, 0, ' ', 0, 97, 0, true, (int) (short) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder0.setFixedSavings("", 0);
        java.io.DataOutput dataOutput27 = null;
        try {
            dateTimeZoneBuilder25.writeTo("ZonedChronology[ISOChronology[UTC], ]", dataOutput27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType14, (-3), (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableInstant2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusHours((int) (short) 1);
        org.joda.time.PeriodType periodType7 = period3.getPeriodType();
        org.joda.time.PeriodType periodType8 = periodType7.withDaysRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(5232L, periodType8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (short) 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType5);
        try {
            int int8 = period6.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfDay();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType10 = periodType9.withYearsRemoved();
        org.joda.time.PeriodType periodType11 = periodType9.withMillisRemoved();
        java.lang.String str12 = periodType11.getName();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withMonthsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType19, chronology20);
        org.joda.time.Period period22 = period21.toPeriod();
        int int23 = period21.getDays();
        org.joda.time.Duration duration24 = period21.toStandardDuration();
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period21);
        org.joda.time.format.PeriodFormatter periodFormatter26 = null;
        java.lang.String str27 = period25.toString(periodFormatter26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(durationFieldType29, "");
        boolean boolean32 = periodType16.isSupported(durationFieldType29);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField33 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType29);
        int int34 = periodType15.indexOf(durationFieldType29);
        boolean boolean35 = periodType11.isSupported(durationFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(durationFieldType29, "org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported");
        boolean boolean38 = periodType4.isSupported(durationFieldType29);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "MillisNoMillis" + "'", str12.equals("MillisNoMillis"));
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PT-0.003S" + "'", str27.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        try {
            org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.DurationField durationField17 = gregorianChronology9.months();
        long long20 = durationField17.subtract(2L, (-53));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 139276800002L + "'", long20 == 139276800002L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str27 = fixedDateTimeZone26.toString();
        java.util.Locale locale29 = null;
        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime31);
        org.joda.time.Chronology chronology33 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        java.lang.String str34 = fixedDateTimeZone26.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        int int37 = fixedDateTimeZone26.getOffsetFromLocal(97L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GregorianChronology[]", (-53), 4, 18062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -53 for GregorianChronology[] must be in the range [4,18062]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str3 = dateTimeZone1.getName(35L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        org.joda.time.Chronology chronology17 = gregorianChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(7, (int) (byte) 0);
        long long23 = fixedDateTimeZone16.getMillisKeepLocal(dateTimeZone21, (long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-25199995L) + "'", long23 == (-25199995L));
        org.junit.Assert.assertNotNull(gregorianChronology24);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.secondOfDay();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 33, 18052L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (short) 1, 7, 0, '4', (int) ' ', (-52), 18062, true, (int) 'a');
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("UTC", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Period period1 = org.joda.time.Period.hours(360000000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Period period7 = period5.plusYears(0);
        org.joda.time.Period period9 = period5.multipliedBy(4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period6 = period4.minusSeconds((int) (byte) 1);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = period4.normalizedStandard(periodType7);
        try {
            org.joda.time.Period period11 = period9.withMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.Period period21 = period19.plusDays(100);
        org.joda.time.Days days22 = period19.toStandardDays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(days22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology30 = zonedChronology17.withUTC();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.PeriodType periodType33 = periodType32.withWeeksRemoved();
        boolean boolean34 = zonedChronology17.equals((java.lang.Object) periodType33);
        try {
            long long39 = zonedChronology17.getDateTimeMillis(0, (int) (short) 0, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.plusMinutes((int) (short) 100);
        org.joda.time.Period period11 = period9.withWeeks((int) (short) 10);
        int[] intArray12 = period11.getValues();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Period period2 = new org.joda.time.Period(18052L, 9L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "Coordinated Universal Time", "Coordinated Universal Time");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-3));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3) + "'", int1 == (-3));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        long long6 = iSOChronology2.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str12 = fixedDateTimeZone11.toString();
        long long14 = fixedDateTimeZone11.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale16 = null;
        java.lang.String str17 = fixedDateTimeZone11.getName((long) (byte) 0, locale16);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str20 = zonedChronology19.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str26 = fixedDateTimeZone25.toString();
        long long28 = fixedDateTimeZone25.convertUTCToLocal((long) (byte) 1);
        int int30 = fixedDateTimeZone25.getStandardOffset((-210866846400000L));
        boolean boolean31 = zonedChronology19.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology32 = zonedChronology19.withUTC();
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.PeriodType periodType34 = org.joda.time.DateTimeUtils.getPeriodType(periodType33);
        org.joda.time.PeriodType periodType35 = periodType34.withWeeksRemoved();
        boolean boolean36 = zonedChronology19.equals((java.lang.Object) periodType35);
        org.joda.time.Period period37 = period1.withPeriodType(periodType35);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.001" + "'", str17.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str20.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2L + "'", long28 == 2L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.dayTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str7 = fixedDateTimeZone6.toString();
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone6.getName((long) '#', locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.clockhourOfHalfday();
        org.joda.time.DurationField durationField15 = gregorianChronology11.weekyears();
        int int16 = gregorianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 1, periodType1, (org.joda.time.Chronology) gregorianChronology11);
        try {
            long long22 = gregorianChronology11.getDateTimeMillis(100, 97, 4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.Period period10 = period2.plusDays(45);
        org.joda.time.Period period12 = period2.minusDays(1);
        int int13 = period12.getYears();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("years");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"years/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 97);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.Period period6 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.Period period10 = period6.plusMonths(0);
        org.joda.time.DurationFieldType durationFieldType12 = period10.getFieldType((int) (short) 0);
        int int13 = period3.indexOf(durationFieldType12);
        org.joda.time.Period period15 = period3.withMonths((int) (byte) 10);
        org.joda.time.Period period17 = period3.minusYears(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P-1W" + "'", str8.equals("P-1W"));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType23, chronology24);
        org.joda.time.Period period26 = period25.toPeriod();
        int int27 = period25.getDays();
        org.joda.time.Duration duration28 = period25.toStandardDuration();
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period25);
        org.joda.time.format.PeriodFormatter periodFormatter30 = null;
        java.lang.String str31 = period29.toString(periodFormatter30);
        org.joda.time.DurationFieldType durationFieldType33 = period29.getFieldType(0);
        org.joda.time.Period period35 = period3.withFieldAdded(durationFieldType33, 0);
        org.joda.time.Period period37 = period35.plusYears((-1));
        org.joda.time.Period period39 = period35.withWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PT-0.003S" + "'", str31.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekyear();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType27, chronology28);
        org.joda.time.Period period30 = period29.toPeriod();
        int int31 = period29.getDays();
        int[] intArray33 = iSOChronology22.get((org.joda.time.ReadablePeriod) period29, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology22.hourOfHalfday();
        boolean boolean36 = iSOChronology22.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str42 = fixedDateTimeZone41.toString();
        long long44 = fixedDateTimeZone41.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale46 = null;
        java.lang.String str47 = fixedDateTimeZone41.getName((long) (byte) 0, locale46);
        org.joda.time.Chronology chronology48 = iSOChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType51, chronology52);
        org.joda.time.Period period54 = period53.toPeriod();
        int int55 = period53.getDays();
        boolean boolean56 = fixedDateTimeZone41.equals((java.lang.Object) int55);
        java.util.TimeZone timeZone57 = fixedDateTimeZone41.toTimeZone();
        org.joda.time.Chronology chronology58 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        long long60 = fixedDateTimeZone41.previousTransition((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41, (int) (byte) 1);
        long long65 = fixedDateTimeZone41.adjustOffset((long) 0, true);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2L + "'", long44 == 2L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.001" + "'", str47.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        int int27 = fixedDateTimeZone23.getOffset((long) 100);
        org.joda.time.Chronology chronology28 = zonedChronology17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.Chronology chronology29 = zonedChronology17.withUTC();
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.PeriodType periodType34 = null;
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType34, chronology35);
        org.joda.time.Period period37 = period36.toPeriod();
        int int38 = period36.getDays();
        org.joda.time.Duration duration39 = period36.toStandardDuration();
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant31, (org.joda.time.ReadableDuration) duration39);
        org.joda.time.Period period41 = new org.joda.time.Period(readableInstant30, (org.joda.time.ReadableDuration) duration39);
        org.joda.time.Weeks weeks42 = period41.toStandardWeeks();
        boolean boolean43 = zonedChronology17.equals((java.lang.Object) weeks42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(duration39);
        org.junit.Assert.assertNotNull(weeks42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period4.toDurationTo(readableInstant6);
        org.joda.time.Period period9 = period4.plusWeeks(1);
        org.joda.time.DurationFieldType durationFieldType11 = period4.getFieldType((int) (byte) 0);
        org.joda.time.Period period13 = period4.minusMinutes(97);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period4.toDurationFrom(readableInstant14);
        try {
            org.joda.time.DurationFieldType durationFieldType17 = period4.getFieldType(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        int int33 = decoratedDurationField29.getValue((-10L));
        long long36 = decoratedDurationField29.getMillis(33L, (long) '4');
        long long38 = decoratedDurationField29.getMillis((long) 360000000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2851200000L + "'", long36 == 2851200000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 31104000000000000L + "'", long38 == 31104000000000000L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        java.lang.String str11 = gregorianChronology9.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[]" + "'", str11.equals("GregorianChronology[]"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        long long16 = cachedDateTimeZone11.convertUTCToLocal((long) 10);
        boolean boolean17 = cachedDateTimeZone11.isFixed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 11L + "'", long16 == 11L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period2.toString(periodFormatter9);
        int int11 = period2.getWeeks();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.053S" + "'", str10.equals("PT-0.053S"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        java.lang.String str5 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[]" + "'", str5.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-53), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-53) + "'", int2 == (-53));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 10, 107, 97, (int) (short) -1, (int) (byte) 100, 33, 18062, (int) '4');
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PT-0.003S");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.Period period4 = new org.joda.time.Period(33, (int) (byte) -1, 97, 0);
        try {
            org.joda.time.Period period6 = period4.multipliedBy(360000000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 33 * 360000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "years");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int int3 = period2.getMonths();
        org.joda.time.Period period5 = period2.plusHours((int) (short) 1);
        org.joda.time.PeriodType periodType6 = period2.getPeriodType();
        boolean boolean8 = periodType6.equals((java.lang.Object) (-52));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-97), (int) (byte) 100, (-3), 107);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getMonths();
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.Period period9 = period7.minusMonths(45);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology9.getZone();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.minuteOfHour();
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology12.era();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(lenientChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.Period period10 = period4.minusMonths(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        int int32 = decoratedDurationField29.getValue(1560629771343L);
        boolean boolean33 = decoratedDurationField29.isPrecise();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 18062 + "'", int32 == 18062);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Period period2 = new org.joda.time.Period(97L, periodType1);
        org.joda.time.Period period4 = period2.plusDays((int) (short) 1);
        int int5 = period4.size();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Period period19 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter20 = null;
        java.lang.String str21 = period19.toString(periodFormatter20);
        org.joda.time.Period period23 = period19.plusMonths(0);
        int[] intArray26 = iSOChronology0.get((org.joda.time.ReadablePeriod) period23, (-210866760000000L), (long) (short) 0);
        int int27 = period23.getMinutes();
        int int28 = period23.getHours();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType31, chronology32);
        org.joda.time.Period period34 = period33.toPeriod();
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period33.toDurationTo(readableInstant35);
        org.joda.time.Period period38 = period33.plusWeeks(1);
        org.joda.time.PeriodType periodType41 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone46 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str47 = fixedDateTimeZone46.toString();
        java.util.Locale locale49 = null;
        java.lang.String str50 = fixedDateTimeZone46.getName((long) '#', locale49);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone46);
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.clockhourOfHalfday();
        org.joda.time.DurationField durationField55 = gregorianChronology51.weekyears();
        int int56 = gregorianChronology51.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField57 = gregorianChronology51.days();
        org.joda.time.Period period58 = new org.joda.time.Period(0L, (long) 35, periodType41, (org.joda.time.Chronology) gregorianChronology51);
        org.joda.time.PeriodType periodType61 = null;
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType61, chronology62);
        org.joda.time.Period period64 = period63.toPeriod();
        int int65 = period63.getDays();
        org.joda.time.Duration duration66 = period63.toStandardDuration();
        org.joda.time.Period period67 = new org.joda.time.Period((java.lang.Object) period63);
        org.joda.time.format.PeriodFormatter periodFormatter68 = null;
        java.lang.String str69 = period67.toString(periodFormatter68);
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(durationFieldType71, "");
        int int74 = period58.get(durationFieldType71);
        int int75 = period38.indexOf(durationFieldType71);
        boolean boolean76 = period23.equals((java.lang.Object) period38);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "P-1W" + "'", str21.equals("P-1W"));
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "+00:00:00.001" + "'", str50.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(duration66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "PT-0.003S" + "'", str69.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType8, chronology9);
        org.joda.time.Period period11 = period10.toPeriod();
        int[] intArray12 = period11.getValues();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePeriod) period11, (long) (byte) 100, (long) (byte) 0);
        org.joda.time.Period period17 = period11.plusYears((-53));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        org.joda.time.Period period8 = new org.joda.time.Period(2L, periodType5, chronology7);
        org.joda.time.Period period9 = period3.withPeriodType(periodType5);
        org.joda.time.Period period10 = new org.joda.time.Period(0L, periodType5);
        org.joda.time.Period period11 = period10.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) "P-1W");
        java.lang.String str6 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[]" + "'", str6.equals("ISOChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.Period period4 = new org.joda.time.Period((int) 'a', (-52), 0, 7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.withMillis(1);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        int int6 = fixedDateTimeZone4.getStandardOffset(3024000000L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str27 = fixedDateTimeZone26.toString();
        java.util.Locale locale29 = null;
        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime31);
        org.joda.time.Chronology chronology33 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        int int35 = fixedDateTimeZone26.getOffsetFromLocal(0L);
        int int37 = fixedDateTimeZone26.getOffsetFromLocal((-60479999900L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType23, chronology24);
        org.joda.time.Period period26 = period25.toPeriod();
        int int27 = period25.getDays();
        org.joda.time.Duration duration28 = period25.toStandardDuration();
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period25);
        org.joda.time.format.PeriodFormatter periodFormatter30 = null;
        java.lang.String str31 = period29.toString(periodFormatter30);
        org.joda.time.DurationFieldType durationFieldType33 = period29.getFieldType(0);
        org.joda.time.Period period35 = period3.withFieldAdded(durationFieldType33, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(durationFieldType33, "PeriodType[Millis]");
        java.lang.Number number38 = illegalFieldValueException37.getIllegalNumberValue();
        org.joda.time.PeriodType periodType41 = null;
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType41, chronology42);
        org.joda.time.Period period44 = period43.toPeriod();
        int int45 = period43.getDays();
        org.joda.time.Duration duration46 = period43.toStandardDuration();
        org.joda.time.Period period47 = new org.joda.time.Period((java.lang.Object) period43);
        org.joda.time.format.PeriodFormatter periodFormatter48 = null;
        java.lang.String str49 = period47.toString(periodFormatter48);
        org.joda.time.DurationFieldType durationFieldType51 = period47.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(durationFieldType51, "");
        java.lang.String str54 = illegalFieldValueException53.getFieldName();
        illegalFieldValueException37.addSuppressed((java.lang.Throwable) illegalFieldValueException53);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PT-0.003S" + "'", str31.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(duration46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "PT-0.003S" + "'", str49.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "years" + "'", str54.equals("years"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekyear();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.lang.String str28 = cachedDateTimeZone26.getNameKey(1L);
        int int30 = cachedDateTimeZone26.getOffset((long) (byte) 100);
        org.joda.time.Chronology chronology31 = gregorianChronology10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        boolean boolean33 = cachedDateTimeZone26.equals((java.lang.Object) 1560629771343L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withSecondsRemoved();
        java.lang.String str4 = periodType3.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Millis" + "'", str4.equals("Millis"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-210866846400000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Period period1 = new org.joda.time.Period(200L);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.Period period4 = period1.minusDays(0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.joda.time.Chronology chronology7 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone23.getName((long) '#', locale26);
        org.joda.time.Chronology chronology28 = zonedChronology17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        try {
            long long36 = zonedChronology17.getDateTimeMillis(360000000, 10, (-2385), (int) (byte) 10, (-2385), (int) (byte) 10, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2385 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.001" + "'", str27.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) dateTimeField4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = iSOChronology0.get(readablePeriod6, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.Period period14 = period8.minusYears(35);
        int int15 = period8.getHours();
        org.joda.time.Period period17 = period8.plusMonths(35);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str23 = fixedDateTimeZone22.toString();
        java.util.Locale locale25 = null;
        java.lang.String str26 = fixedDateTimeZone22.getName((long) '#', locale25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.clockhourOfHalfday();
        org.joda.time.DurationField durationField31 = gregorianChronology27.weekyears();
        int int32 = gregorianChronology27.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField33 = gregorianChronology27.days();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology27.year();
        org.joda.time.Period period43 = new org.joda.time.Period((int) (byte) 1, (int) (short) 1, 100, (int) '#', 10, (int) (byte) 10, (int) 'a', (int) (short) 0);
        int[] intArray45 = gregorianChronology27.get((org.joda.time.ReadablePeriod) period43, (long) 7);
        org.joda.time.Period period47 = period43.minusWeeks(45);
        org.joda.time.Period period49 = period47.minusDays(35);
        org.joda.time.Period period50 = period8.minus((org.joda.time.ReadablePeriod) period47);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.001" + "'", str26.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period50);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekyear();
        org.joda.time.PeriodType periodType27 = null;
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType27, chronology28);
        org.joda.time.Period period30 = period29.toPeriod();
        int int31 = period29.getDays();
        int[] intArray33 = iSOChronology22.get((org.joda.time.ReadablePeriod) period29, 0L);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology22.hourOfHalfday();
        boolean boolean36 = iSOChronology22.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str42 = fixedDateTimeZone41.toString();
        long long44 = fixedDateTimeZone41.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale46 = null;
        java.lang.String str47 = fixedDateTimeZone41.getName((long) (byte) 0, locale46);
        org.joda.time.Chronology chronology48 = iSOChronology22.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType51, chronology52);
        org.joda.time.Period period54 = period53.toPeriod();
        int int55 = period53.getDays();
        boolean boolean56 = fixedDateTimeZone41.equals((java.lang.Object) int55);
        java.util.TimeZone timeZone57 = fixedDateTimeZone41.toTimeZone();
        org.joda.time.Chronology chronology58 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        java.lang.String str60 = fixedDateTimeZone41.getName(1560629796559L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2L + "'", long44 == 2L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.001" + "'", str47.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+00:00:00.001" + "'", str60.equals("+00:00:00.001"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.Period period22 = period3.withWeeks((int) (short) 100);
        org.joda.time.Period period24 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period26 = period24.withMinutes((int) (short) 0);
        org.joda.time.Period period28 = period26.minusMonths((int) ' ');
        boolean boolean29 = period3.equals((java.lang.Object) period26);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(4, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 40 + "'", int2 == 40);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology9.year();
        org.joda.time.DurationField durationField17 = gregorianChronology9.months();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology9.getZone();
        java.lang.String str19 = gregorianChronology9.toString();
        org.joda.time.Chronology chronology20 = gregorianChronology9.withUTC();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[]" + "'", str19.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.minuteOfHour();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported");
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.minusYears((int) (short) 10);
        org.joda.time.Period period10 = period9.toPeriod();
        org.joda.time.Period period12 = period9.minusHours((int) ' ');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        int int33 = decoratedDurationField29.getValue((-10L));
        int int36 = decoratedDurationField29.getDifference((long) (short) -1, (long) 35);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) 1, (long) (byte) 1);
        boolean boolean27 = unsupportedDurationField21.equals((java.lang.Object) (byte) 1);
        try {
            long long30 = unsupportedDurationField21.getMillis((int) (byte) 10, (-210866846399998L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfSecond();
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType6, chronology7);
        org.joda.time.Period period10 = period8.minusSeconds((int) (byte) 1);
        int int11 = period8.getYears();
        long long14 = iSOChronology0.add((org.joda.time.ReadablePeriod) period8, 86400000L, (-53));
        try {
            long long20 = iSOChronology0.getDateTimeMillis(200L, 0, (int) (byte) 10, 360000000, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400159L + "'", long14 == 86400159L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        int int33 = decoratedDurationField29.getValue((-10L));
        long long36 = decoratedDurationField29.getMillis(33L, (long) '4');
        int int39 = decoratedDurationField29.getValue((long) 18062, 2L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2851200000L + "'", long36 == 2851200000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 1, periodType3, chronology6);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        java.lang.String str10 = periodType9.toString();
        org.joda.time.Period period11 = period7.normalizedStandard(periodType9);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType9);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[Hours]" + "'", str10.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.PeriodType periodType26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType26, chronology27);
        org.joda.time.Period period29 = period28.toPeriod();
        int int30 = period28.getDays();
        org.joda.time.Duration duration31 = period28.toStandardDuration();
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant23, (org.joda.time.ReadableDuration) duration31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.days();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration31, periodType33);
        boolean boolean35 = unsupportedDurationField21.equals((java.lang.Object) period34);
        try {
            long long38 = unsupportedDurationField21.add((-864000004L), (-25199995L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        long long3 = dateTimeZone1.convertUTCToLocal(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone1.isLocalDateTimeGap(localDateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.dayTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str19 = fixedDateTimeZone18.toString();
        java.util.Locale locale21 = null;
        java.lang.String str22 = fixedDateTimeZone18.getName((long) '#', locale21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.clockhourOfHalfday();
        org.joda.time.DurationField durationField27 = gregorianChronology23.weekyears();
        int int28 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) 1, periodType13, (org.joda.time.Chronology) gregorianChronology23);
        try {
            org.joda.time.Period period30 = new org.joda.time.Period((java.lang.Object) gregorianChronology9, (org.joda.time.Chronology) gregorianChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.001" + "'", str22.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withDaysRemoved();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) periodType12);
        int int15 = fixedDateTimeZone4.getOffset((long) (-3));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        int int5 = dateTimeZone1.getOffset(readableInstant4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        long long16 = cachedDateTimeZone11.previousTransition(35L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        long long4 = dateTimeZone1.convertLocalToUTC((long) 18062, true);
        java.lang.String str6 = dateTimeZone1.getName((-25200005L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 18052L + "'", long4 == 18052L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long30 = decoratedDurationField29.getUnitMillis();
        int int32 = decoratedDurationField29.getValue(9L);
        int int34 = decoratedDurationField29.getValue((long) (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86400000L + "'", long30 == 86400000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 7, 3395L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23765 + "'", int2 == 23765);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.Period period13 = period7.plusYears(7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        long long33 = decoratedDurationField29.getMillis(0);
        long long35 = decoratedDurationField29.getMillis((long) (-97));
        org.joda.time.DurationFieldType durationFieldType36 = decoratedDurationField29.getType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-8380800000L) + "'", long35 == (-8380800000L));
        org.junit.Assert.assertNotNull(durationFieldType36);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period6 = period4.minusSeconds((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays((int) '#');
        org.joda.time.Period period9 = period8.normalizedStandard();
        try {
            org.joda.time.DurationFieldType durationFieldType11 = period8.getFieldType((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -53");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationField durationField23 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long26 = durationField23.subtract((long) (short) -1, (int) (byte) 0);
        int int27 = unsupportedDurationField21.compareTo(durationField23);
        try {
            long long30 = unsupportedDurationField21.getDifferenceAsLong(45L, 5232L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Period period1 = org.joda.time.Period.years(107);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        long long34 = decoratedDurationField29.getValueAsLong(0L);
        long long35 = decoratedDurationField29.getUnitMillis();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86400000L + "'", long35 == 86400000L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Period period7 = period5.plusYears(0);
        org.joda.time.Period period9 = period7.plusSeconds(18062);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology17.year();
        try {
            long long25 = zonedChronology17.getDateTimeMillis((long) 97, (int) '4', 0, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType28, chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        int int32 = period30.getDays();
        org.joda.time.Duration duration33 = period30.toStandardDuration();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.days();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration33, periodType35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant39, periodType40);
        boolean boolean42 = unsupportedDurationField21.equals((java.lang.Object) readableInstant39);
        try {
            long long45 = unsupportedDurationField21.add(3024000000L, (long) (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ZonedChronology[ISOChronology[UTC], ]", "Coordinated Universal Time", (int) 'a', 360000000);
        int int6 = fixedDateTimeZone4.getOffset(1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        java.lang.String str33 = decoratedDurationField29.toString();
        long long36 = decoratedDurationField29.add((-210866760000000L), 113729960L);
        long long39 = decoratedDurationField29.getDifferenceAsLong((long) (byte) 1, (long) (-97));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9615401784000000L + "'", long36 == 9615401784000000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Period period7 = period5.plusYears(0);
        int int8 = period7.getMillis();
        org.joda.time.Period period10 = period7.withMinutes((int) (short) 1);
        org.joda.time.Period period12 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
        java.lang.String str14 = period12.toString(periodFormatter13);
        org.joda.time.Period period16 = period12.withWeeks(4);
        org.joda.time.Period period18 = period12.plusWeeks((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType20 = period12.getFieldType((int) (short) 1);
        org.joda.time.Period period22 = period10.withField(durationFieldType20, 40);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-3) + "'", int8 == (-3));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1W" + "'", str14.equals("P-1W"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField11 = gregorianChronology10.weekyears();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 100, (org.joda.time.Chronology) gregorianChronology10);
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("YearMonthDayTime");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"YearMonthDayTime\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"YearMonthDayTime\")"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        int int32 = decoratedDurationField29.getValue(1560629771343L);
        long long35 = decoratedDurationField29.getDifferenceAsLong((long) (short) 10, (-210866846400000L));
        int int38 = decoratedDurationField29.getValue((long) (short) 0, 9L);
        try {
            long long41 = decoratedDurationField29.add((long) 3, 139276800002L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 139276800002 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 18062 + "'", int32 == 18062);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2440588L + "'", long35 == 2440588L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '4', (long) (byte) -1);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(2L, periodType4, chronology6);
        org.joda.time.Period period8 = period2.withPeriodType(periodType4);
        org.joda.time.Period period10 = period2.plusDays(45);
        org.joda.time.Period period12 = period2.minusDays(1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.Hours hours6 = period4.toStandardHours();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "");
        java.lang.String str15 = illegalFieldValueException14.getFieldName();
        java.lang.String str16 = illegalFieldValueException14.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException14.getDurationFieldType();
        java.lang.String str18 = illegalFieldValueException14.getIllegalStringValue();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str13 = cachedDateTimeZone11.getNameKey(1L);
        long long15 = cachedDateTimeZone11.nextTransition(2L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType22, (-2385), 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        java.lang.String str5 = iSOChronology0.toString();
        org.joda.time.DurationField durationField6 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        java.lang.String str30 = decoratedDurationField29.getName();
        boolean boolean31 = decoratedDurationField29.isSupported();
        long long33 = decoratedDurationField29.getMillis(0);
        long long35 = decoratedDurationField29.getMillis((long) (-97));
        long long38 = decoratedDurationField29.subtract((-1L), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "years" + "'", str30.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-8380800000L) + "'", long35 == (-8380800000L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-864000001L) + "'", long38 == (-864000001L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period4.toDurationTo(readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.indexOf(durationFieldType8);
        org.joda.time.Period period11 = period4.plusYears((int) (short) 10);
        org.joda.time.Period period13 = period11.withMillis(33);
        org.joda.time.Period period15 = period11.withSeconds(35);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        java.lang.String str1 = periodType0.toString();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType0.isSupported(durationFieldType3);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[Hours]" + "'", str1.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period9, (java.lang.Object) 31104000000000000L);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.PreciseDurationField preciseDurationField22 = new org.joda.time.field.PreciseDurationField(durationFieldType17, 1560629796559L);
        long long25 = preciseDurationField22.getValueAsLong((-3024000000L), (long) 7);
        long long28 = preciseDurationField22.getMillis(0, (long) 360000000);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str6 = fixedDateTimeZone5.toString();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone5.getName((long) '#', locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Period period11 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType14, chronology15);
        org.joda.time.Period period17 = period16.toPeriod();
        int[] intArray18 = period17.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray19 = period17.getFieldTypes();
        org.joda.time.Period period21 = period17.plusMinutes((int) (short) 100);
        int[] intArray23 = gregorianChronology10.get((org.joda.time.ReadablePeriod) period17, (long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial24 = null;
        try {
            long long26 = gregorianChronology10.set(readablePartial24, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(durationFieldTypeArray19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DurationField durationField12 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period11 = period9.minusSeconds((int) (short) 0);
        org.joda.time.Minutes minutes12 = period11.toStandardMinutes();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(minutes12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        java.lang.String str3 = dateTimeZone1.getShortName((long) 'a');
        long long7 = dateTimeZone1.convertLocalToUTC(200L, false, 106L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.097" + "'", str3.equals("+00:00:00.097"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 103L + "'", long7 == 103L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType3, chronology4);
        org.joda.time.Period period6 = period5.toPeriod();
        int int7 = period5.getDays();
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period5);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period9.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType13, "");
        boolean boolean16 = periodType0.isSupported(durationFieldType13);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField17 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        long long18 = unsupportedDurationField17.getUnitMillis();
        try {
            long long21 = unsupportedDurationField17.getMillis(97, (-4L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT-0.003S" + "'", str11.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unsupportedDurationField17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-2385), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) -1);
        org.joda.time.Period period3 = period1.withMinutes((int) (short) 0);
        org.joda.time.Period period5 = period3.plusDays((int) (byte) 10);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.days();
        org.joda.time.Period period8 = new org.joda.time.Period(97L, periodType7);
        org.joda.time.Period period10 = period8.plusDays((int) (short) 1);
        org.joda.time.Period period11 = period5.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period13 = period5.withMillis(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-25200005L));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology30 = zonedChronology17.withUTC();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.PeriodType periodType33 = periodType32.withWeeksRemoved();
        boolean boolean34 = zonedChronology17.equals((java.lang.Object) periodType33);
        java.lang.String str35 = zonedChronology17.toString();
        try {
            long long41 = zonedChronology17.getDateTimeMillis(8380800033L, (int) (short) 100, (int) (short) -1, 7, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str35.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Duration duration7 = period4.toStandardDuration();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType12, "");
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField15 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType12);
        try {
            long long18 = unsupportedDurationField15.add(103L, (-25199995L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.003S" + "'", str10.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(unsupportedDurationField15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.LenientChronology lenientChronology22 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField23 = lenientChronology22.minuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        boolean boolean26 = lenientChronology22.equals((java.lang.Object) gregorianChronology24);
        java.lang.String str27 = lenientChronology22.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(lenientChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "LenientChronology[GregorianChronology[]]" + "'", str27.equals("LenientChronology[GregorianChronology[]]"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.Period period16 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period17 = new org.joda.time.Period(0L, periodType3, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology15.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.days();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str12 = fixedDateTimeZone11.toString();
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone11.getName((long) '#', locale14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.Period period17 = new org.joda.time.Period((-1L), (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(0L, periodType4, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DurationField durationField19 = gregorianChronology16.millis();
        org.joda.time.Period period20 = new org.joda.time.Period(3395L, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str26 = fixedDateTimeZone25.toString();
        java.util.Locale locale28 = null;
        java.lang.String str29 = fixedDateTimeZone25.getName((long) '#', locale28);
        org.joda.time.LocalDateTime localDateTime30 = null;
        boolean boolean31 = fixedDateTimeZone25.isLocalDateTimeGap(localDateTime30);
        long long33 = fixedDateTimeZone25.nextTransition((long) 33);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str42 = fixedDateTimeZone41.toString();
        java.util.Locale locale44 = null;
        java.lang.String str45 = fixedDateTimeZone41.getName((long) '#', locale44);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology46.clockhourOfHalfday();
        org.joda.time.DurationField durationField50 = gregorianChronology46.weekyears();
        int int51 = gregorianChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField52 = gregorianChronology46.days();
        org.joda.time.Period period53 = new org.joda.time.Period(0L, (long) 35, periodType36, (org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.chrono.LenientChronology lenientChronology54 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.DateTimeField dateTimeField55 = lenientChronology54.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone60 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str61 = fixedDateTimeZone60.toString();
        java.util.Locale locale63 = null;
        java.lang.String str64 = fixedDateTimeZone60.getName((long) '#', locale63);
        org.joda.time.LocalDateTime localDateTime65 = null;
        boolean boolean66 = fixedDateTimeZone60.isLocalDateTimeGap(localDateTime65);
        org.joda.time.Chronology chronology67 = lenientChronology54.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone60);
        java.lang.String str68 = fixedDateTimeZone60.toString();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone69 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone60);
        long long71 = fixedDateTimeZone25.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone60, (long) 4);
        boolean boolean72 = period20.equals((java.lang.Object) long71);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.001" + "'", str29.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 33L + "'", long33 == 33L);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+00:00:00.001" + "'", str45.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(lenientChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "+00:00:00.001" + "'", str64.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
        org.junit.Assert.assertNotNull(cachedDateTimeZone69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 4L + "'", long71 == 4L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.hourOfHalfday();
        org.joda.time.DurationField durationField11 = gregorianChronology9.minutes();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str17 = fixedDateTimeZone16.toString();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.Chronology chronology19 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str25 = fixedDateTimeZone24.toString();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        java.util.TimeZone timeZone27 = fixedDateTimeZone24.toTimeZone();
        boolean boolean29 = fixedDateTimeZone24.isStandardOffset((long) 7);
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance(chronology19, (org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(zonedChronology30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        long long12 = fixedDateTimeZone4.nextTransition((long) 33);
        int int14 = fixedDateTimeZone4.getOffsetFromLocal(1L);
        boolean boolean15 = fixedDateTimeZone4.isFixed();
        long long17 = fixedDateTimeZone4.convertUTCToLocal(10L);
        java.util.TimeZone timeZone18 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 33L + "'", long12 == 33L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName((-1L), locale6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.Chronology chronology9 = iSOChronology0.withZone(dateTimeZone4);
//        org.joda.time.DurationField durationField10 = iSOChronology0.eras();
//        org.joda.time.Period period12 = org.joda.time.Period.weeks((int) (short) -1);
//        org.joda.time.format.PeriodFormatter periodFormatter13 = null;
//        java.lang.String str14 = period12.toString(periodFormatter13);
//        org.joda.time.Period period16 = period12.withMillis(45);
//        int[] intArray19 = iSOChronology0.get((org.joda.time.ReadablePeriod) period12, 45L, (long) 45);
//        int int20 = period12.getWeeks();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(period12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "P-1W" + "'", str14.equals("P-1W"));
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        org.joda.time.DurationField durationField33 = decoratedDurationField29.getWrappedField();
        int int36 = decoratedDurationField29.getDifference((-1L), 100L);
        long long39 = decoratedDurationField29.getDifferenceAsLong((-3L), 1560629771343L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-18062L) + "'", long39 == (-18062L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.nextTransition((long) 'a');
        java.lang.String str15 = cachedDateTimeZone11.getNameKey(1560629771343L);
        int int17 = cachedDateTimeZone11.getStandardOffset((long) ' ');
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 23765, (-3024000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3023976235L) + "'", long2 == (-3023976235L));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType5, chronology6);
        org.joda.time.Period period8 = period7.toPeriod();
        int int9 = period7.getDays();
        int[] intArray11 = iSOChronology0.get((org.joda.time.ReadablePeriod) period7, 0L);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.hourOfHalfday();
        boolean boolean14 = iSOChronology0.equals((java.lang.Object) "PT-0.003S");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str20 = fixedDateTimeZone19.toString();
        long long22 = fixedDateTimeZone19.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone19.getName((long) (byte) 0, locale24);
        org.joda.time.Chronology chronology26 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DurationField durationField27 = iSOChronology0.halfdays();
        org.joda.time.Chronology chronology28 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2L + "'", long22 == 2L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.001" + "'", str25.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int int6 = period4.getDays();
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period4.getFieldTypes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.PeriodType periodType28 = null;
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType28, chronology29);
        org.joda.time.Period period31 = period30.toPeriod();
        int int32 = period30.getDays();
        org.joda.time.Duration duration33 = period30.toStandardDuration();
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration33);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.days();
        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant24, (org.joda.time.ReadableDuration) duration33, periodType35);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period41 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration33, readableInstant39, periodType40);
        boolean boolean42 = unsupportedDurationField21.equals((java.lang.Object) readableInstant39);
        try {
            long long45 = unsupportedDurationField21.add(102L, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(duration33);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableInstant3);
        int int5 = period4.getMonths();
        org.joda.time.Period period7 = period4.plusHours((int) (short) 1);
        org.joda.time.PeriodType periodType8 = period4.getPeriodType();
        org.joda.time.PeriodType periodType9 = periodType8.withDaysRemoved();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDayTime();
        int int13 = periodType12.size();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.clockhourOfDay();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 'a', (long) (short) 0, periodType12, (org.joda.time.Chronology) iSOChronology14);
        boolean boolean17 = periodType9.equals((java.lang.Object) (short) 0);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str27 = fixedDateTimeZone26.toString();
        java.util.Locale locale29 = null;
        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime31);
        org.joda.time.Chronology chronology33 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTimeField dateTimeField34 = lenientChronology20.millisOfDay();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField10 = gregorianChronology9.weekyears();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology9.getZone();
        java.lang.Class<?> wildcardClass12 = dateTimeZone11.getClass();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long13 = cachedDateTimeZone11.previousTransition(100L);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone11.getUncachedZone();
        boolean boolean15 = cachedDateTimeZone11.isFixed();
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone11.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone17 = cachedDateTimeZone11.getUncachedZone();
        long long19 = dateTimeZone17.convertUTCToLocal(11L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 12L + "'", long19 == 12L);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationField durationField23 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long26 = durationField23.subtract((long) (short) -1, (int) (byte) 0);
        int int27 = unsupportedDurationField21.compareTo(durationField23);
        boolean boolean28 = unsupportedDurationField21.isPrecise();
        try {
            long long31 = unsupportedDurationField21.getDifferenceAsLong((long) (byte) 100, 1560629796559L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        int[] intArray6 = period5.getValues();
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period5.getFieldTypes();
        org.joda.time.Period period9 = period5.minusHours(33);
        org.joda.time.Period period10 = period5.toPeriod();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = zonedChronology17.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        long long26 = fixedDateTimeZone23.convertUTCToLocal((long) (byte) 1);
        int int28 = fixedDateTimeZone23.getStandardOffset((-210866846400000L));
        boolean boolean29 = zonedChronology17.equals((java.lang.Object) (-210866846400000L));
        org.joda.time.Chronology chronology30 = zonedChronology17.withUTC();
        org.joda.time.PeriodType periodType31 = null;
        org.joda.time.PeriodType periodType32 = org.joda.time.DateTimeUtils.getPeriodType(periodType31);
        org.joda.time.PeriodType periodType33 = periodType32.withWeeksRemoved();
        boolean boolean34 = zonedChronology17.equals((java.lang.Object) periodType33);
        java.lang.String str35 = zonedChronology17.toString();
        try {
            long long41 = zonedChronology17.getDateTimeMillis((long) (short) 100, (int) '4', (int) 'a', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str18.equals("ZonedChronology[ISOChronology[UTC], ]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2L + "'", long26 == 2L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str35.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        org.joda.time.DurationFieldType durationFieldType23 = unsupportedDurationField21.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) 2440588L, (java.lang.Number) 18052L, (java.lang.Number) 3024000000L);
        java.lang.String str28 = illegalFieldValueException27.getIllegalStringValue();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType2, chronology3);
        org.joda.time.Period period5 = period4.toPeriod();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period4.toDurationTo(readableInstant6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period4.indexOf(durationFieldType8);
        org.joda.time.Period period11 = period4.plusYears((int) (short) 10);
        org.joda.time.Period period13 = period11.withMillis(33);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        java.lang.String str15 = periodType14.toString();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str24 = fixedDateTimeZone23.toString();
        java.util.Locale locale26 = null;
        java.lang.String str27 = fixedDateTimeZone23.getName((long) '#', locale26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.clockhourOfHalfday();
        org.joda.time.DurationField durationField32 = gregorianChronology28.weekyears();
        int int33 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField34 = gregorianChronology28.days();
        org.joda.time.Period period35 = new org.joda.time.Period(0L, (long) 35, periodType18, (org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.chrono.LenientChronology lenientChronology36 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology28);
        try {
            org.joda.time.Period period37 = new org.joda.time.Period((java.lang.Object) 33, periodType14, (org.joda.time.Chronology) gregorianChronology28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PeriodType[Hours]" + "'", str15.equals("PeriodType[Hours]"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.001" + "'", str27.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(lenientChronology36);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.PeriodType periodType23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType23, chronology24);
        org.joda.time.Period period26 = period25.toPeriod();
        int int27 = period25.getDays();
        org.joda.time.Duration duration28 = period25.toStandardDuration();
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period25);
        org.joda.time.format.PeriodFormatter periodFormatter30 = null;
        java.lang.String str31 = period29.toString(periodFormatter30);
        org.joda.time.DurationFieldType durationFieldType33 = period29.getFieldType(0);
        org.joda.time.Period period35 = period3.withFieldAdded(durationFieldType33, 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(durationFieldType33, "PeriodType[Millis]");
        java.lang.String str38 = illegalFieldValueException37.getFieldName();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PT-0.003S" + "'", str31.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "years" + "'", str38.equals("years"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = cachedDateTimeZone11.isLocalDateTimeGap(localDateTime12);
        boolean boolean15 = cachedDateTimeZone11.isStandardOffset(0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        java.lang.String str3 = periodType2.getName();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "StandardNoWeeks" + "'", str3.equals("StandardNoWeeks"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        long long5 = durationField2.subtract((long) (byte) 100, (int) (short) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str11 = fixedDateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = fixedDateTimeZone10.getName((long) '#', locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.clockhourOfHalfday();
        org.joda.time.DurationField durationField19 = gregorianChronology15.weekyears();
        int int20 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField21 = gregorianChronology15.days();
        org.joda.time.PeriodType periodType24 = null;
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType24, chronology25);
        org.joda.time.Period period27 = period26.toPeriod();
        int int28 = period26.getDays();
        org.joda.time.Duration duration29 = period26.toStandardDuration();
        org.joda.time.Period period30 = new org.joda.time.Period((java.lang.Object) period26);
        org.joda.time.format.PeriodFormatter periodFormatter31 = null;
        java.lang.String str32 = period30.toString(periodFormatter31);
        org.joda.time.DurationFieldType durationFieldType34 = period30.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField35 = new org.joda.time.field.DecoratedDurationField(durationField21, durationFieldType34);
        java.lang.String str36 = decoratedDurationField35.getName();
        boolean boolean37 = decoratedDurationField35.isSupported();
        long long39 = decoratedDurationField35.getMillis(0);
        long long41 = decoratedDurationField35.getMillis((long) (-97));
        int int44 = decoratedDurationField35.getDifference((long) '#', 18052L);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, (org.joda.time.DurationField) decoratedDurationField35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60479999900L) + "'", long5 == (-60479999900L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.001" + "'", str14.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(duration29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PT-0.003S" + "'", str32.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "years" + "'", str36.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-8380800000L) + "'", long41 == (-8380800000L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(0L, 0L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str10 = fixedDateTimeZone9.toString();
        long long12 = fixedDateTimeZone9.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone9.getName((long) (byte) 0, locale14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField19 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.001" + "'", str15.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.MutablePeriod mutablePeriod4 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType7, chronology8);
        org.joda.time.Period period10 = period9.toPeriod();
        int int11 = period9.getDays();
        org.joda.time.Duration duration12 = period9.toStandardDuration();
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period9);
        org.joda.time.format.PeriodFormatter periodFormatter14 = null;
        java.lang.String str15 = period13.toString(periodFormatter14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        int int20 = period3.indexOf(durationFieldType17);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField21 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        java.lang.String str22 = unsupportedDurationField21.toString();
        boolean boolean23 = unsupportedDurationField21.isSupported();
        java.lang.String str24 = unsupportedDurationField21.toString();
        try {
            long long27 = unsupportedDurationField21.add(0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(mutablePeriod4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT-0.003S" + "'", str15.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "UnsupportedDurationField[years]" + "'", str22.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "UnsupportedDurationField[years]" + "'", str24.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getValueAsLong((-8380800000L), (-210866760000000L));
        int int34 = decoratedDurationField29.getValue(100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-97L) + "'", long32 == (-97L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(0L, (long) (byte) 1, periodType3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        int int3 = period2.getMinutes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str8 = fixedDateTimeZone7.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = fixedDateTimeZone7.getName((long) '#', locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.DurationField durationField16 = gregorianChronology12.weekyears();
        int int17 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField18 = gregorianChronology12.days();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 35, periodType2, (org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField21 = lenientChronology20.weekOfWeekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str27 = fixedDateTimeZone26.toString();
        java.util.Locale locale29 = null;
        java.lang.String str30 = fixedDateTimeZone26.getName((long) '#', locale29);
        org.joda.time.LocalDateTime localDateTime31 = null;
        boolean boolean32 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime31);
        org.joda.time.Chronology chronology33 = lenientChronology20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DurationField durationField34 = lenientChronology20.weekyears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.001" + "'", str11.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.001" + "'", str30.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        long long7 = fixedDateTimeZone4.convertUTCToLocal((long) (byte) 1);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getName((long) (byte) 0, locale9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = cachedDateTimeZone11.isLocalDateTimeGap(localDateTime12);
        java.lang.String str14 = cachedDateTimeZone11.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) (short) 1, (-1));
        java.lang.String str5 = fixedDateTimeZone4.toString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getName((long) '#', locale7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DurationField durationField13 = gregorianChronology9.weekyears();
        int int14 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology9.days();
        org.joda.time.PeriodType periodType18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 100, (long) 'a', periodType18, chronology19);
        org.joda.time.Period period21 = period20.toPeriod();
        int int22 = period20.getDays();
        org.joda.time.Duration duration23 = period20.toStandardDuration();
        org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) period20);
        org.joda.time.format.PeriodFormatter periodFormatter25 = null;
        java.lang.String str26 = period24.toString(periodFormatter25);
        org.joda.time.DurationFieldType durationFieldType28 = period24.getFieldType(0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField29 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType28);
        long long32 = decoratedDurationField29.getMillis((long) (byte) 1, 0L);
        java.lang.String str33 = decoratedDurationField29.toString();
        long long36 = decoratedDurationField29.subtract((-4L), (int) (byte) 10);
        long long39 = decoratedDurationField29.getDifferenceAsLong((long) (-53), 45L);
        org.joda.time.DurationFieldType durationFieldType40 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField41 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) decoratedDurationField29, durationFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.001" + "'", str8.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PT-0.003S" + "'", str26.equals("PT-0.003S"));
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-864000004L) + "'", long36 == (-864000004L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }
}

