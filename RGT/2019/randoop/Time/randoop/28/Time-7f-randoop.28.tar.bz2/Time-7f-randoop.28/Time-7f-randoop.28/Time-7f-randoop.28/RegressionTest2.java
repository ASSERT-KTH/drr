import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        mutableDateTime4.setDayOfYear((int) ' ');
//        int int7 = mutableDateTime4.getHourOfDay();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
//        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology11);
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology11, locale13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket14.getZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 1);
//        boolean boolean21 = offsetDateTimeField20.isSupported();
//        int int23 = offsetDateTimeField20.get((long) 2);
//        boolean boolean24 = offsetDateTimeField20.isSupported();
//        java.lang.String str26 = offsetDateTimeField20.getAsShortText((long) 6);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology16, (org.joda.time.DateTimeField) offsetDateTimeField20);
//        int int29 = skipDateTimeField27.getMaximumValue(1560344975557L);
//        int int31 = skipDateTimeField27.get((long) 62);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47494 + "'", int8 == 47494);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 60 + "'", int29 == 60);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime0.withSecondOfMinute((int) (byte) 1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.clockhourOfDay();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology9);
//        mutableDateTime11.setDayOfYear((int) ' ');
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        boolean boolean15 = mutableDateTime11.isSupported(dateTimeFieldType14);
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology6, readableDateTime8, (org.joda.time.ReadableDateTime) mutableDateTime11);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology18);
//        mutableDateTime20.setDayOfYear((int) ' ');
//        int int23 = mutableDateTime20.getHourOfDay();
//        int int24 = mutableDateTime20.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        mutableDateTime20.setChronology((org.joda.time.Chronology) julianChronology27);
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology27, locale29);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTimeParserBucket30.getZone();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
//        long long36 = dateTimeZone31.getMillisKeepLocal(dateTimeZone33, 0L);
//        org.joda.time.Chronology chronology37 = limitChronology16.withZone(dateTimeZone33);
//        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology3, dateTimeZone33);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider40 = new org.joda.time.tz.DefaultNameProvider();
//        java.util.Locale locale41 = null;
//        java.lang.String str44 = defaultNameProvider40.getShortName(locale41, "", "1970-W01-4");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology45);
//        mutableDateTime47.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime47.centuryOfEra();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField52 = buddhistChronology51.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) (byte) 1);
//        boolean boolean55 = offsetDateTimeField54.isSupported();
//        int int57 = offsetDateTimeField54.get((long) 2);
//        boolean boolean58 = offsetDateTimeField54.isSupported();
//        java.lang.String str60 = offsetDateTimeField54.getAsShortText((long) 6);
//        long long62 = offsetDateTimeField54.roundHalfCeiling(0L);
//        java.lang.String str64 = offsetDateTimeField54.getAsShortText(0L);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField54.getAsText((long) 284160, locale66);
//        java.lang.String str69 = offsetDateTimeField54.getAsText(47374L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology71 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField72 = buddhistChronology71.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime73 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology71);
//        mutableDateTime73.setDayOfYear((int) ' ');
//        int int76 = mutableDateTime73.getHourOfDay();
//        int int77 = mutableDateTime73.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone79);
//        mutableDateTime73.setChronology((org.joda.time.Chronology) julianChronology80);
//        java.util.Locale locale82 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket83 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology80, locale82);
//        org.joda.time.DateTimeZone dateTimeZone84 = dateTimeParserBucket83.getZone();
//        dateTimeParserBucket83.setOffset((java.lang.Integer) (-100));
//        long long87 = dateTimeParserBucket83.computeMillis();
//        dateTimeParserBucket83.setPivotYear((java.lang.Integer) 2562);
//        long long91 = dateTimeParserBucket83.computeMillis(false);
//        long long92 = dateTimeParserBucket83.computeMillis();
//        java.util.Locale locale93 = dateTimeParserBucket83.getLocale();
//        int int94 = offsetDateTimeField54.getMaximumTextLength(locale93);
//        int int95 = property50.getMaximumTextLength(locale93);
//        java.lang.String str98 = defaultNameProvider40.getShortName(locale93, "26", "13:00:52.607");
//        java.lang.String str99 = dateTimeZone33.getShortName((long) 47386, locale93);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 47494 + "'", int24 == 47494);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(zonedChronology38);
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(mutableDateTime47);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1" + "'", str60.equals("1"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1" + "'", str64.equals("1"));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "5" + "'", str67.equals("5"));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1" + "'", str69.equals("1"));
//        org.junit.Assert.assertNotNull(buddhistChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(mutableDateTime73);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 13 + "'", int76 == 13);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 47494 + "'", int77 == 47494);
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(julianChronology80);
//        org.junit.Assert.assertNotNull(dateTimeZone84);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 100L + "'", long87 == 100L);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 100L + "'", long91 == 100L);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 100L + "'", long92 == 100L);
//        org.junit.Assert.assertNotNull(locale93);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2 + "'", int94 == 2);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 7 + "'", int95 == 7);
//        org.junit.Assert.assertNull(str98);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "UTC" + "'", str99.equals("UTC"));
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        java.lang.String str3 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.minuteOfHour();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = buddhistChronology7.years();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology7, locale9, (java.lang.Integer) (-100), 163);
        dateTimeParserBucket12.setOffset(1);
        java.lang.Integer int15 = dateTimeParserBucket12.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology16);
        mutableDateTime18.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime18.minuteOfDay();
        int int22 = mutableDateTime18.getEra();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime18.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime24 = property23.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology25);
        mutableDateTime27.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime27.minuteOfDay();
        int int31 = mutableDateTime27.getEra();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime27.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime33 = property32.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
        int int35 = mutableDateTime24.get(dateTimeFieldType34);
        java.util.Locale locale37 = null;
        dateTimeParserBucket12.saveField(dateTimeFieldType34, "minuteOfHour", locale37);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType34);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial40);
        int int42 = zeroIsMaxDateTimeField39.getMinimumValue();
        long long44 = zeroIsMaxDateTimeField39.remainder((long) 7);
        long long47 = zeroIsMaxDateTimeField39.add(1560345060000L, (long) 47391);
        long long49 = zeroIsMaxDateTimeField39.roundFloor(1560344975557L);
        org.joda.time.DurationField durationField50 = zeroIsMaxDateTimeField39.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-100) + "'", int15.equals((-100)));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2563 + "'", int35 == 2563);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 7L + "'", long44 == 7L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1563188520000L + "'", long47 == 1563188520000L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560344940000L + "'", long49 == 1560344940000L);
        org.junit.Assert.assertNull(durationField50);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        boolean boolean4 = offsetDateTimeField3.isSupported();
        int int6 = offsetDateTimeField3.get((long) 2);
        boolean boolean7 = offsetDateTimeField3.isSupported();
        java.lang.String str9 = offsetDateTimeField3.getAsShortText((long) 6);
        long long11 = offsetDateTimeField3.roundHalfCeiling(0L);
        java.lang.String str13 = offsetDateTimeField3.getAsShortText(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField3.getAsText((long) 284160, locale15);
        long long18 = offsetDateTimeField3.roundCeiling((long) 270);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5" + "'", str16.equals("5"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 60000L + "'", long18 == 60000L);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra(47352);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
//        java.lang.String str9 = dateTime7.toString();
//        org.joda.time.DateTime dateTime11 = dateTime7.withYearOfEra(47372);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345094925L + "'", long3 == 1560345094925L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "47352-06-12T13:11:34.925Z" + "'", str9.equals("47352-06-12T13:11:34.925Z"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1432762866694925L + "'", long12 == 1432762866694925L);
//    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test07");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateTime.Property property4 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime6 = dateTime2.withMillisOfSecond((int) (short) 10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = buddhistChronology8.years();
//        java.util.Locale locale10 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology8, locale10, (java.lang.Integer) (-100), 163);
//        dateTimeParserBucket13.setOffset(1);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfHour();
//        org.joda.time.DateTime dateTime18 = property17.withMinimumValue();
//        org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear(10);
//        org.joda.time.DateTime.Property property21 = dateTime20.weekyear();
//        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfDay(163);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology24);
//        mutableDateTime26.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime26.minuteOfDay();
//        int int30 = mutableDateTime26.getEra();
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime26.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime32 = property31.roundCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology33);
//        mutableDateTime35.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime35.minuteOfDay();
//        int int39 = mutableDateTime35.getEra();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime35.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime41 = property40.roundCeiling();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
//        int int43 = mutableDateTime32.get(dateTimeFieldType42);
//        int int44 = dateTime23.get(dateTimeFieldType42);
//        dateTimeParserBucket13.saveField(dateTimeFieldType42, 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology47.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType51);
//        int int54 = delegatedDateTimeField52.get((long) 0);
//        org.joda.time.ReadablePartial readablePartial55 = null;
//        int[] intArray57 = new int[] { 'a' };
//        int int58 = delegatedDateTimeField52.getMaximumValue(readablePartial55, intArray57);
//        java.lang.String str60 = delegatedDateTimeField52.getAsShortText(480000L);
//        org.joda.time.DurationField durationField61 = delegatedDateTimeField52.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField61);
//        boolean boolean63 = unsupportedDateTimeField62.isLenient();
//        boolean boolean64 = unsupportedDateTimeField62.isLenient();
//        try {
//            int int65 = dateTime2.get((org.joda.time.DateTimeField) unsupportedDateTimeField62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345094948L + "'", long3 == 1560345094948L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2563 + "'", int43 == 2563);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 60 + "'", int58 == 60);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9" + "'", str60.equals("9"));
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, 47381);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfEra(47391, 59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfMinute(0, 47381);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendYearOfEra(47391, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder10.appendYear(60, 47373);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder10.appendFractionOfDay(47457, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfMinute(0, 47381);
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendTwoDigitYear(47369, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder26.appendFractionOfHour(47356, 47416);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.append(dateTimeFormatter35);
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder33.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder10.append(dateTimeParser37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser37);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendTimeZoneOffset("2691-10-10T13:10:35.205", "GregorianChronology[UTC]", false, 0, 47451);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        mutableDateTime3.setDayOfYear((int) ' ');
//        int int6 = mutableDateTime3.getHourOfDay();
//        int int7 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology10);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology10, locale12);
//        java.lang.Integer int14 = dateTimeParserBucket13.getPivotYear();
//        int int15 = dateTimeParserBucket13.getOffset();
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 47495 + "'", int7 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNull(int14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology6);
        mutableDateTime8.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.minuteOfDay();
        int int12 = mutableDateTime8.getEra();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime14 = property13.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        int int16 = dateTime4.get(dateTimeFieldType15);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
//        mutableDateTime3.setDayOfYear((int) ' ');
//        int int6 = mutableDateTime3.getHourOfDay();
//        int int7 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
//        mutableDateTime3.setChronology((org.joda.time.Chronology) julianChronology10);
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology10, locale12);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeParserBucket13.getZone();
//        dateTimeParserBucket13.setOffset((java.lang.Integer) (-100));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType21);
//        java.util.Locale locale23 = null;
//        int int24 = offsetDateTimeField20.getMaximumShortTextLength(locale23);
//        boolean boolean25 = dateTimeParserBucket13.restoreState((java.lang.Object) offsetDateTimeField20);
//        boolean boolean27 = offsetDateTimeField20.isLeap(60L);
//        long long30 = offsetDateTimeField20.add((long) 47493, 0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 47495 + "'", int7 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 47493L + "'", long30 == 47493L);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        mutableDateTime2.setDayOfYear((int) ' ');
//        int int5 = mutableDateTime2.getHourOfDay();
//        int int6 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        mutableDateTime2.setChronology((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology13);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology16);
//        mutableDateTime18.setDayOfYear((int) ' ');
//        int int21 = mutableDateTime18.getHourOfDay();
//        int int22 = mutableDateTime18.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
//        mutableDateTime18.setChronology((org.joda.time.Chronology) julianChronology25);
//        java.util.Locale locale27 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket28 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology25, locale27);
//        org.joda.time.DateTimeZone dateTimeZone29 = dateTimeParserBucket28.getZone();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
//        long long34 = dateTimeZone29.getMillisKeepLocal(dateTimeZone31, 0L);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone31);
//        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime(dateTimeZone31);
//        org.joda.time.Chronology chronology37 = gJChronology13.withZone(dateTimeZone31);
//        org.joda.time.MutableDateTime mutableDateTime38 = org.joda.time.MutableDateTime.now(dateTimeZone31);
//        org.joda.time.chrono.ZonedChronology zonedChronology39 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology9, dateTimeZone31);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        try {
//            int[] intArray42 = julianChronology9.get(readablePeriod40, (long) 13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 47495 + "'", int6 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 47495 + "'", int22 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(julianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(julianChronology32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(zonedChronology39);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.plus(2100010L);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant0.minus(readableDuration3);
        org.joda.time.Chronology chronology5 = instant4.getChronology();
        org.joda.time.Instant instant7 = instant4.withMillis(0L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long8 = delegatedDateTimeField5.add((long) 791, (-47362));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField5, (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-170503199209L) + "'", long8 == (-170503199209L));
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-01-19T13:09:22.683Z");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalInstantException: 47361", "47361");
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException4);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime3 = dateTime0.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = dateTime6.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology1, locale3, (java.lang.Integer) (-100), 163);
        dateTimeParserBucket6.setOffset(1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
        org.joda.time.DateTime dateTime11 = property10.withMinimumValue();
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear(10);
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay(163);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology17);
        mutableDateTime19.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.minuteOfDay();
        int int23 = mutableDateTime19.getEra();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime19.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime25 = property24.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology26);
        mutableDateTime28.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime28.minuteOfDay();
        int int32 = mutableDateTime28.getEra();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime28.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime34 = property33.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        int int36 = mutableDateTime25.get(dateTimeFieldType35);
        int int37 = dateTime16.get(dateTimeFieldType35);
        dateTimeParserBucket6.saveField(dateTimeFieldType35, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, dateTimeFieldType44);
        int int47 = delegatedDateTimeField45.get((long) 0);
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 'a' };
        int int51 = delegatedDateTimeField45.getMaximumValue(readablePartial48, intArray50);
        java.lang.String str53 = delegatedDateTimeField45.getAsShortText(480000L);
        org.joda.time.DurationField durationField54 = delegatedDateTimeField45.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField54);
        int int58 = unsupportedDateTimeField55.getDifference((long) (byte) 100, 2725769584L);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = unsupportedDateTimeField55.getType();
        try {
            boolean boolean61 = unsupportedDateTimeField55.isLeap((long) 47362);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2563 + "'", int36 == 2563);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9" + "'", str53.equals("9"));
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-757) + "'", int58 == (-757));
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalInstantException: 47361", "47361");
        illegalFieldValueException2.prependMessage("JulianChronology[UTC]");
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        illegalFieldValueException2.prependMessage("T������");
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime3 = dateTime0.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.plus(11107L);
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("13:00:24.117");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("13:00:24.117");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        boolean boolean12 = delegatedDateTimeField10.isLeap(0L);
        java.lang.String str13 = delegatedDateTimeField10.toString();
        int int15 = delegatedDateTimeField10.getMaximumValue((long) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) int15);
        boolean boolean18 = jodaTimePermission1.equals((java.lang.Object) "13:00:52.704");
        org.joda.time.JodaTimePermission jodaTimePermission20 = new org.joda.time.JodaTimePermission("13:00:24.117");
        org.joda.time.JodaTimePermission jodaTimePermission22 = new org.joda.time.JodaTimePermission("13:00:24.117");
        boolean boolean23 = jodaTimePermission20.implies((java.security.Permission) jodaTimePermission22);
        boolean boolean24 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str13.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("BuddhistChronology[UTC]", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType4);
        long long8 = offsetDateTimeField3.set(0L, 2);
        long long11 = offsetDateTimeField3.add((long) 1, 2);
        long long14 = offsetDateTimeField3.add(1560344966492L, 47456);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 60000L + "'", long8 == 60000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 120001L + "'", long11 == 120001L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1563192326492L + "'", long14 == 1563192326492L);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("47352-06-12T13:10:18.184Z");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.plus(2100010L);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant0.minus(readableDuration3);
        org.joda.time.Chronology chronology5 = instant0.getChronology();
        org.joda.time.Instant instant7 = instant0.minus(93622255026229833L);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(instant7);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        mutableDateTime2.setDayOfYear((int) ' ');
//        int int5 = mutableDateTime2.getHourOfDay();
//        int int6 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        mutableDateTime2.setChronology((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField14 = buddhistChronology13.years();
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology13, locale15, (java.lang.Integer) (-100), 163);
//        dateTimeParserBucket18.setOffset(1);
//        java.lang.Integer int21 = dateTimeParserBucket18.getPivotYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology22);
//        mutableDateTime24.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime24.minuteOfDay();
//        int int28 = mutableDateTime24.getEra();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime24.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime30 = property29.roundCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime33 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology31);
//        mutableDateTime33.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime33.minuteOfDay();
//        int int37 = mutableDateTime33.getEra();
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime33.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime39 = property38.roundCeiling();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        int int41 = mutableDateTime30.get(dateTimeFieldType40);
//        java.util.Locale locale43 = null;
//        dateTimeParserBucket18.saveField(dateTimeFieldType40, "minuteOfHour", locale43);
//        int int45 = mutableDateTime11.get(dateTimeFieldType40);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 49476, "13:00:30.931");
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 47495 + "'", int6 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-100) + "'", int21.equals((-100)));
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2563 + "'", int41 == 2563);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        long long7 = dateTimeZone2.getMillisKeepLocal(dateTimeZone5, (long) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.Chronology chronology10 = gJChronology8.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        mutableDateTime4.setDayOfYear((int) ' ');
//        int int7 = mutableDateTime4.getHourOfDay();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
//        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology11);
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology11, locale13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket14.getZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 1);
//        boolean boolean21 = offsetDateTimeField20.isSupported();
//        int int23 = offsetDateTimeField20.get((long) 2);
//        boolean boolean24 = offsetDateTimeField20.isSupported();
//        java.lang.String str26 = offsetDateTimeField20.getAsShortText((long) 6);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField(chronology16, (org.joda.time.DateTimeField) offsetDateTimeField20);
//        int int30 = offsetDateTimeField20.getDifference((long) (short) 10, (long) 47456);
//        int int32 = offsetDateTimeField20.getLeapAmount(2100010L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47495 + "'", int8 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.clockhourOfDay();
        org.joda.time.ReadableDateTime readableDateTime6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology7);
        mutableDateTime9.setDayOfYear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = mutableDateTime9.isSupported(dateTimeFieldType12);
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology4, readableDateTime6, (org.joda.time.ReadableDateTime) mutableDateTime9);
        org.joda.time.DateTime dateTime15 = limitChronology14.getLowerLimit();
        org.joda.time.DateTime dateTime16 = limitChronology14.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.clockhourOfDay();
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology22);
        mutableDateTime24.setDayOfYear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = mutableDateTime24.isSupported(dateTimeFieldType27);
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology19, readableDateTime21, (org.joda.time.ReadableDateTime) mutableDateTime24);
        org.joda.time.DateTime dateTime30 = dateTime16.toDateTime((org.joda.time.Chronology) limitChronology29);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfHour();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime0, readableInstant2);
        org.joda.time.DateTime dateTime4 = dateTime0.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test33");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        mutableDateTime2.setDayOfYear((int) ' ');
//        int int5 = mutableDateTime2.getHourOfDay();
//        int int6 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        mutableDateTime2.setChronology((org.joda.time.Chronology) julianChronology9);
//        org.joda.time.Instant instant11 = mutableDateTime2.toInstant();
//        int int12 = mutableDateTime2.getDayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology15);
//        mutableDateTime17.setDayOfYear((int) ' ');
//        int int20 = mutableDateTime17.getHourOfDay();
//        int int21 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
//        mutableDateTime17.setChronology((org.joda.time.Chronology) julianChronology24);
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology24, locale26);
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeParserBucket27.getZone();
//        org.joda.time.Chronology chronology29 = gregorianChronology13.withZone(dateTimeZone28);
//        org.joda.time.Chronology chronology30 = gregorianChronology13.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        boolean boolean32 = gregorianChronology13.equals((java.lang.Object) gJChronology31);
//        mutableDateTime2.setChronology((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        try {
//            int[] intArray37 = gregorianChronology13.get(readablePeriod34, 19L, 274L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 47495 + "'", int6 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 47495 + "'", int21 == 47495);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("789", "2019-01-19T13:09:22.683Z");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-01-19T13:09:22.683Z" + "'", str4.equals("2019-01-19T13:09:22.683Z"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        java.lang.String str3 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.minuteOfHour();
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = buddhistChronology7.years();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology7, locale9, (java.lang.Integer) (-100), 163);
        dateTimeParserBucket12.setOffset(1);
        java.lang.Integer int15 = dateTimeParserBucket12.getPivotYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology16);
        mutableDateTime18.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime18.minuteOfDay();
        int int22 = mutableDateTime18.getEra();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime18.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime24 = property23.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology25);
        mutableDateTime27.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime27.minuteOfDay();
        int int31 = mutableDateTime27.getEra();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime27.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime33 = property32.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
        int int35 = mutableDateTime24.get(dateTimeFieldType34);
        java.util.Locale locale37 = null;
        dateTimeParserBucket12.saveField(dateTimeFieldType34, "minuteOfHour", locale37);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType34);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial40);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.LocalDateTime localDateTime44 = dateTimeFormatter42.parseLocalDateTime("2019-01-19T13:09:22.683Z");
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType49);
        int int52 = delegatedDateTimeField50.get((long) 0);
        org.joda.time.ReadablePartial readablePartial53 = null;
        int[] intArray55 = new int[] { 'a' };
        int int56 = delegatedDateTimeField50.getMaximumValue(readablePartial53, intArray55);
        int int57 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDateTime44, intArray55);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-100) + "'", int15.equals((-100)));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2563 + "'", int35 == 2563);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(localDateTime44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 60 + "'", int56 == 60);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 60 + "'", int57 == 60);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime3 = dateTime0.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
        org.joda.time.DateTime.Property property9 = dateTime6.monthOfYear();
        int int10 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test37");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfEra(47352);
//        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
//        org.joda.time.DateTime dateTime8 = property6.setCopy(3);
//        org.joda.time.DateTime dateTime10 = property6.addToCopy((long) 1);
//        int int11 = property6.getMinimumValueOverall();
//        int int12 = property6.getMaximumValueOverall();
//        org.joda.time.DateTime dateTime13 = property6.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345095958L + "'", long3 == 1560345095958L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime dateTime3 = dateTime0.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property4 = dateTime3.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.clockhourOfDay();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology14);
        mutableDateTime16.setDayOfYear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        boolean boolean20 = mutableDateTime16.isSupported(dateTimeFieldType19);
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology11, readableDateTime13, (org.joda.time.ReadableDateTime) mutableDateTime16);
        org.joda.time.DateTime dateTime22 = limitChronology21.getLowerLimit();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfHour();
        org.joda.time.DateTime dateTime25 = property24.withMinimumValue();
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear(10);
        org.joda.time.LocalDateTime localDateTime28 = dateTime25.toLocalDateTime();
        boolean boolean29 = limitChronology21.equals((java.lang.Object) localDateTime28);
        org.joda.time.DateTime dateTime30 = dateTime8.withChronology((org.joda.time.Chronology) limitChronology21);
        try {
            org.joda.time.DateTime dateTime32 = dateTime30.minusWeeks((-757));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 2019-01-19T13:11:35.999Z (JulianChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, 47381);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(47369, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfHour(47356, 47416);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter11.withOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeFormatter12);
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test40");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        mutableDateTime4.setDayOfYear((int) ' ');
//        int int7 = mutableDateTime4.getHourOfDay();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
//        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology11);
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology11, locale13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket14.getZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DurationField durationField18 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField19 = gregorianChronology0.seconds();
//        int int20 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47496 + "'", int8 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property6 = dateTime2.dayOfYear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, 514);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345096093L + "'", long3 == 1560345096093L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, 47381);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTwoDigitYear(47369, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfHour(47356, 47416);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter11.withOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.append(dateTimeFormatter12);
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatterBuilder10.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder10.appendMillisOfSecond((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendTwoDigitYear(13, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.appendMonthOfYear(47373);
        boolean boolean22 = dateTimeFormatterBuilder16.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(885);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withPivotYear(2000);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter6.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(dateTimeZone7);
    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology2);
//        mutableDateTime4.setDayOfYear((int) ' ');
//        int int7 = mutableDateTime4.getHourOfDay();
//        int int8 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
//        mutableDateTime4.setChronology((org.joda.time.Chronology) julianChronology11);
//        java.util.Locale locale13 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology11, locale13);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeParserBucket14.getZone();
//        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone(dateTimeZone15);
//        org.joda.time.Chronology chronology17 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology20);
//        mutableDateTime22.setDayOfYear((int) ' ');
//        int int25 = mutableDateTime22.getHourOfDay();
//        int int26 = mutableDateTime22.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
//        mutableDateTime22.setChronology((org.joda.time.Chronology) julianChronology29);
//        java.util.Locale locale31 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology29, locale31);
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeParserBucket32.getZone();
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime(dateTimeZone33);
//        org.joda.time.Chronology chronology35 = gregorianChronology0.withZone(dateTimeZone33);
//        org.joda.time.DurationField durationField36 = gregorianChronology0.halfdays();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 47496 + "'", int8 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 47496 + "'", int26 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(durationField36);
//    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
//        boolean boolean4 = offsetDateTimeField3.isSupported();
//        int int6 = offsetDateTimeField3.get((long) 2);
//        boolean boolean7 = offsetDateTimeField3.isSupported();
//        java.lang.String str9 = offsetDateTimeField3.getAsShortText((long) 6);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getLeapDurationField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) 1);
//        boolean boolean16 = offsetDateTimeField15.isSupported();
//        int int18 = offsetDateTimeField15.get((long) 2);
//        boolean boolean19 = offsetDateTimeField15.isSupported();
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField15.getAsShortText((-100), locale21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime.Property property24 = dateTime23.minuteOfHour();
//        org.joda.time.DateTime dateTime25 = property24.withMinimumValue();
//        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear(10);
//        org.joda.time.LocalDateTime localDateTime28 = dateTime25.toLocalDateTime();
//        int[] intArray29 = null;
//        int int30 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDateTime28, intArray29);
//        java.lang.String str31 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDateTime28);
//        int int32 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localDateTime28);
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        java.lang.String str36 = dateTimeZone34.getShortName((long) 62);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) (-1));
//        org.joda.time.DateTime dateTime41 = dateTime37.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.DateTime dateTime44 = dateTime42.plus(readablePeriod43);
//        org.joda.time.DateTime dateTime45 = dateTime42.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property46 = dateTime45.dayOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology47.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology47);
//        mutableDateTime49.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime49.minuteOfDay();
//        int int53 = mutableDateTime49.getEra();
//        org.joda.time.MutableDateTime.Property property54 = mutableDateTime49.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime55 = property54.roundCeiling();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property54.getFieldType();
//        int int57 = dateTime45.get(dateTimeFieldType56);
//        boolean boolean58 = dateTime41.isSupported(dateTimeFieldType56);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField59 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType56);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-100" + "'", str22.equals("-100"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13:00:36.250" + "'", str31.equals("13:00:36.250"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 60 + "'", int32 == 60);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UTC" + "'", str36.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute(0, 47381);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.clockhourOfDay();
        org.joda.time.ReadableDateTime readableDateTime4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology5);
        mutableDateTime7.setDayOfYear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = mutableDateTime7.isSupported(dateTimeFieldType10);
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology2, readableDateTime4, (org.joda.time.ReadableDateTime) mutableDateTime7);
        org.joda.time.DateTime dateTime13 = limitChronology12.getLowerLimit();
        org.joda.time.DateTime dateTime14 = limitChronology12.getLowerLimit();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertNull(dateTime13);
        org.junit.Assert.assertNull(dateTime14);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology1.years();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) buddhistChronology1, locale3, (java.lang.Integer) (-100), 163);
        dateTimeParserBucket6.setOffset(1);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
        org.joda.time.DateTime dateTime11 = property10.withMinimumValue();
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekOfWeekyear(10);
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay(163);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology17);
        mutableDateTime19.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.minuteOfDay();
        int int23 = mutableDateTime19.getEra();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime19.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime25 = property24.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology26);
        mutableDateTime28.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime28.minuteOfDay();
        int int32 = mutableDateTime28.getEra();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime28.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime34 = property33.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        int int36 = mutableDateTime25.get(dateTimeFieldType35);
        int int37 = dateTime16.get(dateTimeFieldType35);
        dateTimeParserBucket6.saveField(dateTimeFieldType35, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.minuteOfHour();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField43, dateTimeFieldType44);
        int int47 = delegatedDateTimeField45.get((long) 0);
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 'a' };
        int int51 = delegatedDateTimeField45.getMaximumValue(readablePartial48, intArray50);
        java.lang.String str53 = delegatedDateTimeField45.getAsShortText(480000L);
        org.joda.time.DurationField durationField54 = delegatedDateTimeField45.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField55 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField54);
        try {
            java.lang.String str57 = unsupportedDateTimeField55.getAsShortText(1730812161431L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2563 + "'", int36 == 2563);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9" + "'", str53.equals("9"));
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField55);
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test49");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology3);
//        mutableDateTime5.setDayOfYear((int) ' ');
//        int int8 = mutableDateTime5.getHourOfDay();
//        int int9 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
//        mutableDateTime5.setChronology((org.joda.time.Chronology) julianChronology12);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology12, locale14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeParserBucket15.getZone();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone18);
//        long long21 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, 0L);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime(dateTimeZone18);
//        org.joda.time.Chronology chronology24 = gJChronology0.withZone(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.clockhourOfDay();
//        org.joda.time.ReadableDateTime readableDateTime29 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology30);
//        mutableDateTime32.setDayOfYear((int) ' ');
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        boolean boolean36 = mutableDateTime32.isSupported(dateTimeFieldType35);
//        org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) julianChronology27, readableDateTime29, (org.joda.time.ReadableDateTime) mutableDateTime32);
//        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology27.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone39 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone38);
//        boolean boolean40 = cachedDateTimeZone39.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        java.lang.String str44 = dateTimeZone42.getShortName((long) 62);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone42);
//        org.joda.time.DateTime dateTime47 = dateTime45.withMillis((long) (-1));
//        org.joda.time.Instant instant48 = dateTime45.toInstant();
//        org.joda.time.DateTime dateTime49 = instant48.toDateTime();
//        org.joda.time.DateTime.Property property50 = dateTime49.secondOfMinute();
//        boolean boolean51 = cachedDateTimeZone39.equals((java.lang.Object) dateTime49);
//        long long53 = dateTimeZone18.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone39, 24L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 47496 + "'", int9 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(limitChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "UTC" + "'", str44.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(instant48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 24L + "'", long53 == 24L);
//    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(47365, 790, 9, 2562, 47416, 47427);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2562 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType4);
//        int int8 = delegatedDateTimeField5.getDifference((long) (-1), 11107L);
//        boolean boolean9 = delegatedDateTimeField5.isSupported();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider12 = new org.joda.time.tz.DefaultNameProvider();
//        java.util.Locale locale13 = null;
//        java.lang.String str16 = defaultNameProvider12.getShortName(locale13, "", "1970-W01-4");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology17);
//        mutableDateTime19.setDayOfYear((int) ' ');
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.centuryOfEra();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 1);
//        boolean boolean27 = offsetDateTimeField26.isSupported();
//        int int29 = offsetDateTimeField26.get((long) 2);
//        boolean boolean30 = offsetDateTimeField26.isSupported();
//        java.lang.String str32 = offsetDateTimeField26.getAsShortText((long) 6);
//        long long34 = offsetDateTimeField26.roundHalfCeiling(0L);
//        java.lang.String str36 = offsetDateTimeField26.getAsShortText(0L);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField26.getAsText((long) 284160, locale38);
//        java.lang.String str41 = offsetDateTimeField26.getAsText(47374L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime45 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology43);
//        mutableDateTime45.setDayOfYear((int) ' ');
//        int int48 = mutableDateTime45.getHourOfDay();
//        int int49 = mutableDateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology52 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone51);
//        mutableDateTime45.setChronology((org.joda.time.Chronology) julianChronology52);
//        java.util.Locale locale54 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology52, locale54);
//        org.joda.time.DateTimeZone dateTimeZone56 = dateTimeParserBucket55.getZone();
//        dateTimeParserBucket55.setOffset((java.lang.Integer) (-100));
//        long long59 = dateTimeParserBucket55.computeMillis();
//        dateTimeParserBucket55.setPivotYear((java.lang.Integer) 2562);
//        long long63 = dateTimeParserBucket55.computeMillis(false);
//        long long64 = dateTimeParserBucket55.computeMillis();
//        java.util.Locale locale65 = dateTimeParserBucket55.getLocale();
//        int int66 = offsetDateTimeField26.getMaximumTextLength(locale65);
//        int int67 = property22.getMaximumTextLength(locale65);
//        java.lang.String str70 = defaultNameProvider12.getShortName(locale65, "26", "13:00:52.607");
//        try {
//            long long71 = delegatedDateTimeField5.set((long) 47418, "2019-01-19T13:09:46.285Z", locale65);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-01-19T13:09:46.285Z\" for minuteOfHour is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1" + "'", str32.equals("1"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1" + "'", str36.equals("1"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "5" + "'", str39.equals("5"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 13 + "'", int48 == 13);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 47496 + "'", int49 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(julianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 100L + "'", long64 == 100L);
//        org.junit.Assert.assertNotNull(locale65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 7 + "'", int67 == 7);
//        org.junit.Assert.assertNull(str70);
//    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test52");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.years();
//        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 47416);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.minuteOfHour();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 1);
//        boolean boolean9 = offsetDateTimeField8.isSupported();
//        int int11 = offsetDateTimeField8.get((long) 2);
//        boolean boolean12 = offsetDateTimeField8.isSupported();
//        java.lang.String str14 = offsetDateTimeField8.getAsShortText((long) 6);
//        long long16 = offsetDateTimeField8.roundHalfCeiling(0L);
//        java.lang.String str18 = offsetDateTimeField8.getAsShortText(0L);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField8.getAsText((long) 284160, locale20);
//        java.lang.String str23 = offsetDateTimeField8.getAsText(47374L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology25);
//        mutableDateTime27.setDayOfYear((int) ' ');
//        int int30 = mutableDateTime27.getHourOfDay();
//        int int31 = mutableDateTime27.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
//        mutableDateTime27.setChronology((org.joda.time.Chronology) julianChronology34);
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology34, locale36);
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTimeParserBucket37.getZone();
//        dateTimeParserBucket37.setOffset((java.lang.Integer) (-100));
//        long long41 = dateTimeParserBucket37.computeMillis();
//        dateTimeParserBucket37.setPivotYear((java.lang.Integer) 2562);
//        long long45 = dateTimeParserBucket37.computeMillis(false);
//        long long46 = dateTimeParserBucket37.computeMillis();
//        java.util.Locale locale47 = dateTimeParserBucket37.getLocale();
//        int int48 = offsetDateTimeField8.getMaximumTextLength(locale47);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket(2100010L, (org.joda.time.Chronology) iSOChronology1, locale47, (java.lang.Integer) 47357, 0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5" + "'", str21.equals("5"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 47496 + "'", int31 == 47496);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
//        org.junit.Assert.assertNotNull(locale47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant0.withDurationAdded(readableDuration2, 47371);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        mutableDateTime2.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.minuteOfDay();
        int int6 = mutableDateTime2.getEra();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        mutableDateTime2.setZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("13:00:24.117");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("13:00:24.117");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        boolean boolean12 = delegatedDateTimeField10.isLeap(0L);
        java.lang.String str13 = delegatedDateTimeField10.toString();
        int int15 = delegatedDateTimeField10.getMaximumValue((long) 10);
        jodaTimePermission1.checkGuard((java.lang.Object) int15);
        java.security.PermissionCollection permissionCollection17 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[clockhourOfDay]" + "'", str13.equals("DateTimeField[clockhourOfDay]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
        org.junit.Assert.assertNotNull(permissionCollection17);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfHour();
        org.joda.time.DateTime dateTime3 = dateTime0.withMillis((long) 6);
        org.joda.time.DateTime dateTime5 = dateTime0.minusDays(47435);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "", 0, (int) (byte) 1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 0);
        long long8 = fixedDateTimeZone4.nextTransition(1560345018122L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560345018122L + "'", long8 == 1560345018122L);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(47360, 47355);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfDay(1, 47390);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfYear(47365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendLiteral("60");
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.DateTime dateTime14 = dateTime11.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology16);
        mutableDateTime18.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime18.minuteOfDay();
        int int22 = mutableDateTime18.getEra();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime18.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime24 = property23.roundCeiling();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        int int26 = dateTime14.get(dateTimeFieldType25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType25, 47417);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }
}

