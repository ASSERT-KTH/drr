import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560635225692L + "'", long0 == 1560635225692L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 1, (int) (short) 100, 1, (-1), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) ' ', (int) ' ', (int) (byte) -1, (int) (short) 100, (int) (byte) 10, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 10, (int) ' ', (int) (byte) 10, 0, (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType6, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,2922790]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            java.lang.String str4 = dateTime1.toString(dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, (java.lang.Number) 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod2, (long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays(21);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime1.toString("", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withTime((int) (byte) 0, 2000, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1969-365T16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-365T16:00:00-08:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField10 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.plusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, (java.lang.Number) 2000, (java.lang.Number) 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(0, 20, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("960");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"960\" is malformed at \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
        org.joda.time.DateTime dateTime7 = dateTime3.withEra(1);
        java.lang.String str9 = dateTime7.toString("-01:00");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-01:00" + "'", str9.equals("-01:00"));
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray13 = new int[] { (byte) 0, (byte) 0 };
//        try {
//            gregorianChronology2.validate(readablePartial10, intArray13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(intArray13);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
//        try {
//            long long8 = gregorianChronology0.getDateTimeMillis(57600, (int) ' ', 200, 20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(chronology3);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 'a', (int) (short) -1);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 98L + "'", long3 == 98L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value null for GregorianChronology[America/Los_Angeles] must be in the range [10,0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value null for GregorianChronology[America/Los_Angeles] must be in the range [10,0]"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "960");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(2000, (-1), 0, (int) ' ', 21, 0, 200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
        boolean boolean6 = dateTime1.isBefore((long) 2000);
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            int int8 = dateTime1.compareTo(readableInstant7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
//        int int12 = dateTime1.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 100, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) 10, 100, (int) ' ', (int) (short) 1, 20, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        java.lang.Appendable appendable3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = gregorianChronology0.set(readablePartial2, (long) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 2, (long) 10);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8L) + "'", long3 == (-8L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withDate((int) 'a', (int) (byte) 0, 200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969-365T16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str3 = gregorianChronology2.toString();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
//        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
//        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        int int15 = dateTime9.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime dateTime6 = dateTime1.minusDays((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withMonthOfYear(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfWeek();
//        java.lang.String str6 = property5.getAsShortText();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed" + "'", str6.equals("Wed"));
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str9 = gregorianChronology8.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
//        org.joda.time.Chronology chronology13 = gregorianChronology8.withZone(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = gregorianChronology8.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime7.toMutableDateTime(chronology14);
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime15.toMutableDateTime();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str9.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
//        org.joda.time.DurationFieldType durationFieldType4 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 1969);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(durationField3);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Class<?> wildcardClass5 = illegalFieldValueException4.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 10L, (java.lang.Number) 1, (java.lang.Number) 2000);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property2.getAsShortText(locale5);
//        java.lang.String str7 = property2.getAsText();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "960" + "'", str7.equals("960"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((long) (short) 10, 200, 100, 2, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) (byte) -1, (org.joda.time.Chronology) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) -1, (int) ' ', (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        try {
            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, 69, (int) (byte) 1, (int) (short) 100, 1, 20, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        java.lang.String str6 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime5);
//        java.lang.Appendable appendable7 = null;
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        try {
//            dateTimeFormatter4.printTo(appendable7, readablePartial8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-166T21:47:19Z" + "'", str6.equals("2019-166T21:47:19Z"));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime4.toCalendar(locale6);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(calendar7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        java.io.Writer writer3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(0);
        org.joda.time.DateTime dateTime11 = dateTime7.withEra(1);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType4, (int) (byte) 100, (int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [35,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        int int11 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 21 + "'", int11 == 21);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long8 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone6, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-100L) + "'", long8 == (-100L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("960");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"960/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-100L), (long) 200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-300L) + "'", long2 == (-300L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("1969-365T16:00:00-08:00", "GregorianChronology[America/Los_Angeles]");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        java.lang.Number number10 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "960");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-365T16:00:00-08:00", "GregorianChronology[America/Los_Angeles]");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
//        org.joda.time.DateTime dateTime21 = property19.setCopy(20);
//        org.joda.time.DateTime dateTime22 = property19.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) iSOChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.minuteOfHour();
//        int int29 = dateTime22.get(dateTimeField28);
//        boolean boolean30 = dateTime22.isAfterNow();
//        int int31 = dateTime22.getYearOfCentury();
//        org.joda.time.DateTime dateTime33 = dateTime22.plusMonths((int) (short) 0);
//        boolean boolean34 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime16.withYearOfEra((int) (short) 10);
//        java.util.GregorianCalendar gregorianCalendar37 = dateTime16.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(gregorianCalendar37);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DurationField durationField10 = gregorianChronology7.minutes();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(21, 10, 0, 59, 69, 0, (int) (byte) -1, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[]" + "'", str8.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-365T16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-365T16:00:00-08:00\" is malformed at \"5T16:00:00-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        long long4 = dateTimeZone1.convertUTCToLocal(100L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3599900L) + "'", long4 == (-3599900L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        int int5 = dateTime1.getEra();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withFieldAdded(durationFieldType6, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "887");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = property8.getDateTime();
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        int[] intArray14 = new int[] { (short) 100, '#', '4' };
        try {
            iSOChronology3.validate((org.joda.time.ReadablePartial) localDate10, intArray14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 21 + "'", int7 == 21);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(intArray14);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        java.lang.String str5 = property3.getAsString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "47" + "'", str5.equals("47"));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
//        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
//        int int12 = dateTime5.get(dateTimeField11);
//        boolean boolean13 = dateTime5.isAfterNow();
//        int int14 = dateTime5.getYearOfCentury();
//        java.lang.String str15 = dateTime5.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-15T00:00:22.780+00:00:00.100" + "'", str15.equals("2019-06-15T00:00:22.780+00:00:00.100"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        int int2 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
//        boolean boolean5 = dateTime4.isBeforeNow();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod2, 0L, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[]" + "'", str1.equals("ISOChronology[]"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '4');
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        long long5 = dateTimeZone2.convertLocalToUTC((long) 'a', false);
        java.lang.String str6 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-3L) + "'", long5 == (-3L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
        long long17 = dateTime5.getMillis();
        java.lang.Number number19 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number19, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number23 = illegalFieldValueException22.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = illegalFieldValueException22.getDateTimeFieldType();
        boolean boolean25 = dateTime5.equals((java.lang.Object) dateTimeFieldType24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) 10 + "'", number23.equals((byte) 10));
        org.junit.Assert.assertNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology10 = gregorianChronology5.withZone(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(69, (int) (short) 1, (int) '4', 47, 20, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[]" + "'", str6.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant3 = null;
        long long4 = property2.getDifferenceAsLong(readableInstant3);
        long long5 = property2.remainder();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 152L + "'", long5 == 152L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        int int3 = property2.getMinimumValue();
        org.joda.time.DateTime dateTime4 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("960");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"960\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 1560635225692L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 0, 0, 47, 2, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("ISOChronology[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withEra(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2000, 19, 22, (int) '4', 57600, 10, 57600, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
        long long17 = dateTime5.getMillis();
        boolean boolean18 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 78440644);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        boolean boolean19 = zeroIsMaxDateTimeField13.isLeap((long) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = dateTime4.toString("GregorianChronology[America/Los_Angeles]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) 86400);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) 2000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsShortText(locale7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(1, (int) (byte) 100, 21, 78440644);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long15 = fixedDateTimeZone13.nextTransition((long) (byte) 1);
        long long17 = fixedDateTimeZone13.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) dateTimeField8, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2000L + "'", long17 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType4, 2019, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 23359L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (-300L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 78440644, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        org.joda.time.DateTime dateTime8 = property6.setCopy(20);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
        int int16 = dateTime15.getCenturyOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        int int19 = dateTime13.get(dateTimeFieldType18);
        org.joda.time.DateTime.Property property20 = dateTime8.property(dateTimeFieldType18);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType18, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 69, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 78440644);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(23156L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23156 + "'", int1 == 23156);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        int int13 = dateTime12.getSecondOfMinute();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str15 = gregorianChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology19 = gregorianChronology14.withZone(dateTimeZone18);
        org.joda.time.Chronology chronology20 = gregorianChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology14.secondOfDay();
        int int22 = dateTime12.get(dateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[]" + "'", str15.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DurationField durationField4 = property2.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNull(durationField4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "org.joda.time.IllegalFieldValueException: Value null for GregorianChronology[America/Los_Angeles] must be in the range [10,0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime.Property property5 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property6 = dateTime1.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        int int6 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant12 = null;
        long long13 = property11.getDifferenceAsLong(readableInstant12);
        long long14 = property11.remainder();
        org.joda.time.DateTime dateTime15 = property11.roundHalfCeilingCopy();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime15);
        try {
            org.joda.time.DateTime dateTime18 = dateTime15.withMonthOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 152L + "'", long14 == 152L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) 'a', (int) 'a', (int) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(0L, 86399999, (int) (byte) 10, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 57600, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(69, (int) (byte) 0, (int) (short) -1, (int) (short) 100, 0, (int) (byte) 1, 0, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[]" + "'", str8.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long11 = fixedDateTimeZone9.nextTransition((long) (byte) 1);
        long long13 = fixedDateTimeZone9.nextTransition((long) 2000);
        long long15 = fixedDateTimeZone9.previousTransition((long) (short) 10);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            dateTimeFormatter2.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2000L + "'", long13 == 2000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumShortTextLength(locale11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = property4.setCopy(20);
        org.joda.time.DateTime dateTime7 = property4.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.minuteOfHour();
        int int14 = dateTime7.get(dateTimeField13);
        boolean boolean15 = dateTime7.isAfterNow();
        int int16 = dateTime7.getYearOfCentury();
        org.joda.time.DateTime dateTime18 = dateTime7.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTime.Property property21 = dateTime20.minuteOfDay();
        org.joda.time.DateTime dateTime23 = property21.setCopy(20);
        org.joda.time.DateTime dateTime24 = property21.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) iSOChronology28);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.minuteOfHour();
        int int31 = dateTime24.get(dateTimeField30);
        boolean boolean32 = dateTime24.isAfterNow();
        int int33 = dateTime24.getYearOfCentury();
        org.joda.time.DateTime dateTime35 = dateTime24.plusMonths((int) (short) 0);
        boolean boolean36 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime35);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 70 + "'", int16 == 70);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter6.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str13 = dateTimeZone11.getName((long) (-1));
        long long15 = dateTimeZone8.getMillisKeepLocal(dateTimeZone11, (long) (byte) 10);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(2, 69, 200, 200, (int) ' ', (int) (byte) 0, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:00" + "'", str13.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3600010L + "'", long15 == 3600010L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName((long) (byte) 100, locale4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.withHourOfDay(0);
        int int12 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.100" + "'", str5.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long15 = zeroIsMaxDateTimeField13.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime dateTime12 = dateTime6.toDateTime((org.joda.time.Chronology) iSOChronology10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime19 = dateTime13.withTime(2000, 0, 22, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        try {
            long long16 = zeroIsMaxDateTimeField13.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology10 = dateTime9.getChronology();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType5, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        long long10 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedDateTimeZone4.getClass();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 'a', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0.0d, (java.lang.Object) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod3, (long) 1, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, (int) (short) 1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime1.withDate(21, (int) (byte) 1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560808042990L, 23156);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36142071043476440L + "'", long2 == 36142071043476440L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays(21);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        long long3 = property2.remainder();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property2.setCopy("GregorianChronology[America/Los_Angeles]", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 152L + "'", long3 == 152L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-365T16:00:00-08:00", "GregorianChronology[America/Los_Angeles]");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 0, 0, (int) ' ', (int) (byte) 1, 86399999, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(0, 69, 1, 78440644, (int) (byte) 100, (int) (byte) -1, (int) (byte) 1, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78440644 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-8L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        int int13 = dateTime12.getDayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(78440644);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        int int12 = dateTime6.get(dateTimeFieldType11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
        try {
            long long22 = offsetDateTimeField16.set((long) '4', 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for minuteOfHour must be in the range [59,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(200);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
        try {
            long long17 = zeroIsMaxDateTimeField13.set(200020L, "org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMaximumValue();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(20);
        org.joda.time.DateTime dateTime12 = property9.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
        int int19 = dateTime12.get(dateTimeField18);
        boolean boolean20 = dateTime12.isAfterNow();
        int int21 = dateTime12.getYearOfCentury();
        org.joda.time.DateTime dateTime23 = dateTime12.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfDay();
        org.joda.time.DateTime dateTime28 = property26.setCopy(20);
        org.joda.time.DateTime dateTime29 = property26.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
        int int36 = dateTime29.get(dateTimeField35);
        boolean boolean37 = dateTime29.isAfterNow();
        int int38 = dateTime29.getYearOfCentury();
        org.joda.time.DateTime dateTime40 = dateTime29.plusMonths((int) (short) 0);
        boolean boolean41 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime40);
        int int42 = property3.compareTo((org.joda.time.ReadableInstant) dateTime23);
        java.util.Locale locale44 = null;
        try {
            org.joda.time.DateTime dateTime45 = property3.setCopy("GregorianChronology[]", locale44);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 70 + "'", int21 == 70);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        long long6 = dateTimeZone2.convertUTCToLocal((long) 200);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599800L) + "'", long6 == (-3599800L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMaximumValue();
        int int6 = property3.getLeapAmount();
        int int7 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
        org.joda.time.DateTime dateTime21 = property19.setCopy(20);
        org.joda.time.DateTime dateTime22 = property19.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.minuteOfHour();
        int int29 = dateTime22.get(dateTimeField28);
        boolean boolean30 = dateTime22.isAfterNow();
        int int31 = dateTime22.getYearOfCentury();
        org.joda.time.DateTime dateTime33 = dateTime22.plusMonths((int) (short) 0);
        boolean boolean34 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime16.plus((long) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 70 + "'", int31 == 70);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsText(locale7);
        org.joda.time.DateTime dateTime9 = property2.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime17.withCenturyOfEra(69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        org.joda.time.DateTime dateTime14 = dateTime5.plusMonths(86400);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str4 = gregorianChronology3.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology8 = gregorianChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology3.withUTC();
        org.joda.time.DateTime dateTime10 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMonths((int) (short) -1);
        boolean boolean15 = dateTime10.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property16 = dateTime10.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology22);
        int int24 = dateTime23.getCenturyOfEra();
        org.joda.time.DateTime.Property property25 = dateTime23.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        int int27 = dateTime21.get(dateTimeFieldType26);
        int int28 = dateTime10.get(dateTimeFieldType26);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[]" + "'", str4.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 20 + "'", int24 == 20);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime12 = property7.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getName((long) 100);
        java.lang.String str13 = cachedDateTimeZone9.getNameKey((long) (short) 10);
        long long15 = cachedDateTimeZone9.nextTransition((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "960" + "'", str13.equals("960"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.lang.String str6 = dateTimeFormatter4.print((org.joda.time.ReadableInstant) dateTime5);
        boolean boolean8 = dateTime5.isAfter((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-001T00:00:00Z" + "'", str6.equals("1970-001T00:00:00Z"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.secondOfDay();
        org.joda.time.DateTime dateTime14 = dateTime4.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime.Property property15 = dateTime4.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        long long18 = zeroIsMaxDateTimeField13.roundHalfCeiling((long) '4');
        java.util.Locale locale21 = null;
        try {
            long long22 = zeroIsMaxDateTimeField13.set((-1L), "", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-100L) + "'", long18 == (-100L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 2000L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 1, 86399999, (-10), 0, 86400, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(86399999, 1439, 2, 22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        int int11 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
        org.joda.time.DateTime dateTime19 = property17.setCopy(20);
        org.joda.time.DateTime dateTime20 = property17.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
        int int27 = dateTime20.get(dateTimeField26);
        boolean boolean28 = dateTime20.isAfterNow();
        int int29 = dateTime20.getYearOfCentury();
        org.joda.time.DateTime dateTime31 = dateTime20.plusMonths((int) (short) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) dateTime31);
        java.lang.String str34 = fixedDateTimeZone4.getNameKey(35L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 70 + "'", int29 == 70);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "960" + "'", str34.equals("960"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        boolean boolean7 = fixedDateTimeZone5.isStandardOffset((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMaximumValue();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(20);
        org.joda.time.DateTime dateTime12 = property9.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
        int int19 = dateTime12.get(dateTimeField18);
        boolean boolean20 = dateTime12.isAfterNow();
        int int21 = dateTime12.getYearOfCentury();
        org.joda.time.DateTime dateTime23 = dateTime12.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfDay();
        org.joda.time.DateTime dateTime28 = property26.setCopy(20);
        org.joda.time.DateTime dateTime29 = property26.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
        int int36 = dateTime29.get(dateTimeField35);
        boolean boolean37 = dateTime29.isAfterNow();
        int int38 = dateTime29.getYearOfCentury();
        org.joda.time.DateTime dateTime40 = dateTime29.plusMonths((int) (short) 0);
        boolean boolean41 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime40);
        int int42 = property3.compareTo((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.DateTime.Property property47 = dateTime46.minuteOfDay();
        org.joda.time.DateTime dateTime49 = dateTime46.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        int int52 = dateTime51.getCenturyOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        int int55 = dateTime49.get(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, dateTimeFieldType54, 59, (int) (short) -1, (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException63 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, (java.lang.Number) (short) 10);
        org.joda.time.DateTime.Property property64 = dateTime23.property(dateTimeFieldType54);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology65);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str68 = gregorianChronology67.toString();
        org.joda.time.DateTimeZone dateTimeZone69 = gregorianChronology67.getZone();
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology72 = gregorianChronology67.withZone(dateTimeZone71);
        org.joda.time.Chronology chronology73 = gregorianChronology67.withUTC();
        org.joda.time.DateTime dateTime74 = dateTime66.withChronology((org.joda.time.Chronology) gregorianChronology67);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
        org.joda.time.DateTime dateTime78 = dateTime76.plusMonths((int) (short) -1);
        boolean boolean79 = dateTime74.isAfter((org.joda.time.ReadableInstant) dateTime76);
        org.joda.time.DateTime.Property property80 = dateTime74.hourOfDay();
        boolean boolean82 = property80.equals((java.lang.Object) 2000);
        org.joda.time.DateTime dateTime83 = property80.roundHalfEvenCopy();
        java.util.Locale locale84 = null;
        java.util.Calendar calendar85 = dateTime83.toCalendar(locale84);
        boolean boolean86 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime83);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 70 + "'", int21 == 70);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "GregorianChronology[]" + "'", str68.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(calendar85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology3.weekyears();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((long) (short) -1, true, (long) 1969);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-101L) + "'", long12 == (-101L));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology0.millis();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(23156, (int) 'a', 57600, 200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.appendFractionOfHour((-10), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod5, 200020L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = zeroIsMaxDateTimeField13.getAsShortText(readablePartial15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        long long19 = zeroIsMaxDateTimeField13.roundHalfCeiling((-2880L));
        java.lang.String str21 = zeroIsMaxDateTimeField13.getAsShortText((long) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str23 = gregorianChronology22.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology27 = gregorianChronology22.withZone(dateTimeZone26);
        org.joda.time.Chronology chronology28 = gregorianChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology22.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        int int32 = dateTime31.getCenturyOfEra();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField29, dateTimeFieldType34);
        long long38 = zeroIsMaxDateTimeField35.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
        int int41 = dateTime40.getCenturyOfEra();
        org.joda.time.DateTime.Property property42 = dateTime40.minuteOfHour();
        org.joda.time.DateTime dateTime43 = property42.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay44 = dateTime43.toYearMonthDay();
        java.util.Locale locale46 = null;
        java.lang.String str47 = zeroIsMaxDateTimeField35.getAsText((org.joda.time.ReadablePartial) yearMonthDay44, 1970, locale46);
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = zeroIsMaxDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay44, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3100L) + "'", long19 == (-3100L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "86400" + "'", str21.equals("86400"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[]" + "'", str23.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 200020L + "'", long38 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(yearMonthDay44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970" + "'", str47.equals("1970"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(0);
        int int20 = dateTime19.getMillisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime7 = property2.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.DateTime.Property property3 = dateTime1.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod2, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
        int int16 = dateTime15.getCenturyOfEra();
        org.joda.time.DateTime.Property property17 = dateTime15.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType18);
        org.joda.time.DateTime.Property property20 = dateTime4.property(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 20 + "'", int16 == 20);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.withWeekyear(200);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime dateTime6 = dateTime1.minusDays((int) (byte) 1);
        int int7 = dateTime6.getDayOfWeek();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        boolean boolean14 = zeroIsMaxDateTimeField13.isLenient();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str16 = gregorianChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology20 = gregorianChronology15.withZone(dateTimeZone19);
        org.joda.time.Chronology chronology21 = gregorianChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
        int int25 = dateTime24.getCenturyOfEra();
        org.joda.time.DateTime.Property property26 = dateTime24.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField22, dateTimeFieldType27);
        long long31 = zeroIsMaxDateTimeField28.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
        int int34 = dateTime33.getCenturyOfEra();
        org.joda.time.DateTime.Property property35 = dateTime33.minuteOfHour();
        org.joda.time.DateTime dateTime36 = property35.getDateTime();
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        int[] intArray41 = new int[] { 20, 69 };
        int[] intArray43 = zeroIsMaxDateTimeField28.add((org.joda.time.ReadablePartial) localDate37, (-10), intArray41, (int) (short) 0);
        int[] intArray49 = new int[] { 2, 1439, 'a', '#' };
        try {
            int[] intArray51 = zeroIsMaxDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDate37, 59, intArray49, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[]" + "'", str16.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 200020L + "'", long31 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 20 + "'", int34 == 20);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
        org.joda.time.DateTime.Property property18 = dateTime17.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", (java.lang.Number) 10.0f, (java.lang.Number) 0, (java.lang.Number) 4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime5.withTimeAtStartOfDay();
        int int16 = dateTime15.getDayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str18 = gregorianChronology17.toString();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology22 = gregorianChronology17.withZone(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gregorianChronology17.weeks();
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime15.toMutableDateTime((org.joda.time.Chronology) gregorianChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[]" + "'", str18.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        long long19 = zeroIsMaxDateTimeField13.roundHalfCeiling((-2880L));
        java.lang.String str21 = zeroIsMaxDateTimeField13.getAsShortText((long) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str23 = gregorianChronology22.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology27 = gregorianChronology22.withZone(dateTimeZone26);
        org.joda.time.Chronology chronology28 = gregorianChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology22.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        int int32 = dateTime31.getCenturyOfEra();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField29, dateTimeFieldType34);
        long long38 = zeroIsMaxDateTimeField35.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
        int int41 = dateTime40.getCenturyOfEra();
        org.joda.time.DateTime.Property property42 = dateTime40.minuteOfHour();
        org.joda.time.DateTime dateTime43 = property42.getDateTime();
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        int[] intArray48 = new int[] { 20, 69 };
        int[] intArray50 = zeroIsMaxDateTimeField35.add((org.joda.time.ReadablePartial) localDate44, (-10), intArray48, (int) (short) 0);
        int[] intArray55 = new int[] { 1970, (byte) 100, ' ' };
        try {
            int[] intArray57 = zeroIsMaxDateTimeField13.addWrapField((org.joda.time.ReadablePartial) localDate44, 200, intArray55, 152);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 200");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3100L) + "'", long19 == (-3100L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "86400" + "'", str21.equals("86400"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[]" + "'", str23.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 200020L + "'", long38 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        int int10 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks(59);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        int int7 = dateTime1.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology4.getZone();
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone6.getName(1560556821716L, locale8);
        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[]" + "'", str5.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
        boolean boolean6 = dateTime1.isBefore((long) 2000);
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
        int int9 = dateTime1.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long16 = fixedDateTimeZone14.nextTransition((long) (byte) 1);
        long long18 = fixedDateTimeZone14.nextTransition((long) 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) '4');
        int int24 = fixedDateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime23);
        long long26 = fixedDateTimeZone14.convertUTCToLocal((long) 2);
        org.joda.time.DateTime dateTime27 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime29 = dateTime27.withSecondOfMinute(21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2000L + "'", long18 == 2000L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 102L + "'", long26 == 102L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1970, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        int int15 = zeroIsMaxDateTimeField13.getLeapAmount((long) 78440644);
        boolean boolean17 = zeroIsMaxDateTimeField13.isLeap((long) 21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DurationField durationField10 = property7.getDurationField();
        org.joda.time.DateTime dateTime11 = property7.roundHalfCeilingCopy();
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = dateTime11.toString("org.joda.time.IllegalFieldValueException: Value \"GregorianChronology[America/Los_Angeles]\" for 1969-365T16:00:00-08:00 is not supported", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
        int int5 = dateTime4.getMillisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 152 + "'", int5 == 152);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime5.plus(readableDuration13);
        int int15 = dateTime14.getMillisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 152 + "'", int15 == 152);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfEra(57600, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeParser46);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.nextTransition((long) (byte) 1);
        long long11 = fixedDateTimeZone7.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        int int14 = dateTime13.getCenturyOfEra();
        org.joda.time.DateTime dateTime16 = dateTime13.withYearOfEra((int) 'a');
        boolean boolean17 = fixedDateTimeZone7.equals((java.lang.Object) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfDay();
        org.joda.time.DateTime dateTime22 = property20.setCopy(20);
        org.joda.time.DateTime dateTime23 = property20.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.minuteOfHour();
        int int30 = dateTime23.get(dateTimeField29);
        boolean boolean31 = dateTime23.isAfterNow();
        int int32 = dateTime23.getYearOfCentury();
        org.joda.time.DateTime dateTime34 = dateTime23.plusMonths((int) (short) 0);
        boolean boolean35 = fixedDateTimeZone7.equals((java.lang.Object) dateTime34);
        long long38 = fixedDateTimeZone7.adjustOffset((-2880L), true);
        long long41 = fixedDateTimeZone7.adjustOffset(0L, true);
        long long43 = fixedDateTimeZone7.nextTransition((long) (byte) 10);
        org.joda.time.Chronology chronology44 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.util.Locale locale46 = null;
        java.lang.String str47 = fixedDateTimeZone7.getShortName(21000L, locale46);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 70 + "'", int32 == 70);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-2880L) + "'", long38 == (-2880L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.100" + "'", str47.equals("+00:00:00.100"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology13 = gregorianChronology8.withZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gregorianChronology8.withUTC();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime7.toMutableDateTime(chronology14);
        int int16 = dateTime7.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime7.plus(readablePeriod17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter2.parseDateTime("+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.100\" is malformed at \":00:00.100\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[America/Los_Angeles]", number1, (java.lang.Number) (byte) 10, (java.lang.Number) 0);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType8);
        org.junit.Assert.assertNull(dateTimeFieldType9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        int int19 = dateTime18.getCenturyOfEra();
        org.joda.time.DateTime.Property property20 = dateTime18.minuteOfHour();
        org.joda.time.DateTime dateTime21 = property20.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
        java.util.Locale locale24 = null;
        java.lang.String str25 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) yearMonthDay22, 1970, locale24);
        long long28 = zeroIsMaxDateTimeField13.add((long) (short) 0, 21);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
        int int31 = dateTime30.getCenturyOfEra();
        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
        org.joda.time.DateTime dateTime33 = property32.getDateTime();
        org.joda.time.LocalDate localDate34 = dateTime33.toLocalDate();
        int int35 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.DurationField durationField36 = zeroIsMaxDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 21000L + "'", long28 == 21000L);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 86400 + "'", int35 == 86400);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        int int10 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology2.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded((long) 19, (int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        int int10 = dateTime4.get(dateTimeFieldType9);
        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str13 = gregorianChronology12.toString();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
        int int22 = dateTime21.getCenturyOfEra();
        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
        long long29 = preciseDateTimeField27.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.lang.String str5 = property3.getAsShortText();
        org.joda.time.DateTime dateTime6 = property3.getDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getName((long) 100);
        java.lang.String str13 = cachedDateTimeZone9.getNameKey((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        boolean boolean21 = fixedDateTimeZone19.isStandardOffset((long) (short) -1);
        boolean boolean22 = cachedDateTimeZone9.equals((java.lang.Object) boolean21);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "960" + "'", str13.equals("960"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        int int12 = dateTime11.getCenturyOfEra();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        int int15 = dateTime9.get(dateTimeFieldType14);
        org.joda.time.DateTime.Property property16 = dateTime4.property(dateTimeFieldType14);
        org.joda.time.DateTime dateTime18 = dateTime4.withYear(2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.DateTime dateTime6 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
        int int15 = zeroIsMaxDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology0.add(readablePeriod7, (long) (short) 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str12 = gregorianChronology11.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology16 = gregorianChronology11.withZone(dateTimeZone15);
        org.joda.time.Chronology chronology17 = gregorianChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology11.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        int int21 = dateTime20.getCenturyOfEra();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType23);
        long long27 = zeroIsMaxDateTimeField24.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
        int int30 = dateTime29.getCenturyOfEra();
        org.joda.time.DateTime.Property property31 = dateTime29.minuteOfHour();
        org.joda.time.DateTime dateTime32 = property31.getDateTime();
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        int[] intArray37 = new int[] { 20, 69 };
        int[] intArray39 = zeroIsMaxDateTimeField24.add((org.joda.time.ReadablePartial) localDate33, (-10), intArray37, (int) (short) 0);
        int[] intArray40 = null;
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate33, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[]" + "'", str12.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 200020L + "'", long27 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 20 + "'", int30 == 20);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("94", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"94/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        int int5 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) (short) -1);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsText(locale7);
        int int9 = property2.getMinimumValue();
        org.joda.time.DateTime dateTime10 = property2.roundHalfCeilingCopy();
        int int11 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1439 + "'", int11 == 1439);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis(0L);
        int int7 = dateTime6.getSecondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.DurationField durationField6 = property2.getDurationField();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.nextTransition((long) (byte) 1);
        long long11 = fixedDateTimeZone7.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        int int14 = dateTime13.getCenturyOfEra();
        org.joda.time.DateTime dateTime16 = dateTime13.withYearOfEra((int) 'a');
        boolean boolean17 = fixedDateTimeZone7.equals((java.lang.Object) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfDay();
        org.joda.time.DateTime dateTime22 = property20.setCopy(20);
        org.joda.time.DateTime dateTime23 = property20.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.minuteOfHour();
        int int30 = dateTime23.get(dateTimeField29);
        boolean boolean31 = dateTime23.isAfterNow();
        int int32 = dateTime23.getYearOfCentury();
        org.joda.time.DateTime dateTime34 = dateTime23.plusMonths((int) (short) 0);
        boolean boolean35 = fixedDateTimeZone7.equals((java.lang.Object) dateTime34);
        long long38 = fixedDateTimeZone7.adjustOffset((-2880L), true);
        long long41 = fixedDateTimeZone7.adjustOffset(0L, true);
        long long43 = fixedDateTimeZone7.nextTransition((long) (byte) 10);
        org.joda.time.Chronology chronology44 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1439");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 70 + "'", int32 == 70);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-2880L) + "'", long38 == (-2880L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(chronology44);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(86399999, 20, (int) '4', 0, (int) '4', (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        int int10 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime12 = dateTime9.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime14 = dateTime12.minusWeeks((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone17 = dateTimeZone16.toTimeZone();
        org.joda.time.DateTime dateTime18 = dateTime14.withZoneRetainFields(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long9 = fixedDateTimeZone7.nextTransition((long) (byte) 1);
        long long11 = fixedDateTimeZone7.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        int int14 = dateTime13.getCenturyOfEra();
        org.joda.time.DateTime dateTime16 = dateTime13.withYearOfEra((int) 'a');
        boolean boolean17 = fixedDateTimeZone7.equals((java.lang.Object) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfDay();
        org.joda.time.DateTime dateTime22 = property20.setCopy(20);
        org.joda.time.DateTime dateTime23 = property20.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.minuteOfHour();
        int int30 = dateTime23.get(dateTimeField29);
        boolean boolean31 = dateTime23.isAfterNow();
        int int32 = dateTime23.getYearOfCentury();
        org.joda.time.DateTime dateTime34 = dateTime23.plusMonths((int) (short) 0);
        boolean boolean35 = fixedDateTimeZone7.equals((java.lang.Object) dateTime34);
        long long38 = fixedDateTimeZone7.adjustOffset((-2880L), true);
        long long41 = fixedDateTimeZone7.adjustOffset(0L, true);
        long long43 = fixedDateTimeZone7.nextTransition((long) (byte) 10);
        org.joda.time.Chronology chronology44 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology45 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 70 + "'", int32 == 70);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-2880L) + "'", long38 == (-2880L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long3 = dateTimeZone1.convertUTCToLocal(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology3.weekyears();
        org.joda.time.DurationField durationField7 = iSOChronology3.eras();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology10 = gregorianChronology5.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology11 = gregorianChronology5.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter4.withChronology(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[]" + "'", str6.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        int int16 = dateTime9.getYear();
        org.joda.time.DateTime dateTime18 = dateTime9.minusMonths(19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        java.lang.String str18 = zeroIsMaxDateTimeField13.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str20 = gregorianChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology24 = gregorianChronology19.withZone(dateTimeZone23);
        org.joda.time.Chronology chronology25 = gregorianChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology19.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
        int int29 = dateTime28.getCenturyOfEra();
        org.joda.time.DateTime.Property property30 = dateTime28.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField26, dateTimeFieldType31);
        long long35 = zeroIsMaxDateTimeField32.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
        int int38 = dateTime37.getCenturyOfEra();
        org.joda.time.DateTime.Property property39 = dateTime37.minuteOfHour();
        org.joda.time.DateTime dateTime40 = property39.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        java.util.Locale locale43 = null;
        java.lang.String str44 = zeroIsMaxDateTimeField32.getAsText((org.joda.time.ReadablePartial) yearMonthDay41, 1970, locale43);
        long long47 = zeroIsMaxDateTimeField32.add((long) (short) 0, 21);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology48);
        int int50 = dateTime49.getCenturyOfEra();
        org.joda.time.DateTime.Property property51 = dateTime49.minuteOfHour();
        org.joda.time.DateTime dateTime52 = property51.getDateTime();
        org.joda.time.LocalDate localDate53 = dateTime52.toLocalDate();
        int int54 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDate53);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str57 = gregorianChronology56.toString();
        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology56.getZone();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology61 = gregorianChronology56.withZone(dateTimeZone60);
        org.joda.time.Chronology chronology62 = gregorianChronology56.withUTC();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology56.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology64);
        int int66 = dateTime65.getCenturyOfEra();
        org.joda.time.DateTime.Property property67 = dateTime65.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property67.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField69 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField63, dateTimeFieldType68);
        long long72 = zeroIsMaxDateTimeField69.addWrapField((long) 20, 200);
        int int73 = zeroIsMaxDateTimeField69.getMaximumValue();
        java.lang.String str74 = zeroIsMaxDateTimeField69.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
        int int77 = dateTime76.getCenturyOfEra();
        org.joda.time.DateTime.Property property78 = dateTime76.minuteOfHour();
        org.joda.time.DateTime dateTime79 = property78.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay80 = dateTime79.toYearMonthDay();
        int[] intArray81 = new int[] {};
        int int82 = zeroIsMaxDateTimeField69.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay80, intArray81);
        try {
            int[] intArray84 = zeroIsMaxDateTimeField13.set((org.joda.time.ReadablePartial) localDate53, 10, intArray81, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "minuteOfHour" + "'", str18.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GregorianChronology[]" + "'", str20.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 200020L + "'", long35 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 20 + "'", int38 == 20);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970" + "'", str44.equals("1970"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 21000L + "'", long47 == 21000L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 20 + "'", int50 == 20);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 86400 + "'", int54 == 86400);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[]" + "'", str57.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 20 + "'", int66 == 20);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 200020L + "'", long72 == 200020L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 86400 + "'", int73 == 86400);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "minuteOfHour" + "'", str74.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 20 + "'", int77 == 20);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(yearMonthDay80);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 86400 + "'", int82 == 86400);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        int int6 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.joda.time.DateTime.Property property6 = dateTime4.era();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withDurationAdded(readableDuration7, 20);
        org.joda.time.DateTime dateTime11 = dateTime4.withMillisOfDay(52);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        boolean boolean14 = zeroIsMaxDateTimeField13.isLenient();
        long long16 = zeroIsMaxDateTimeField13.roundHalfFloor((long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        int int19 = dateTime18.getCenturyOfEra();
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfEra((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withChronology((org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTime dateTime27 = dateTime21.toDateTime((org.joda.time.Chronology) iSOChronology25);
        java.util.GregorianCalendar gregorianCalendar28 = dateTime27.toGregorianCalendar();
        org.joda.time.TimeOfDay timeOfDay29 = dateTime27.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology36 = gregorianChronology31.withZone(dateTimeZone35);
        org.joda.time.Chronology chronology37 = gregorianChronology31.withUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
        int int41 = dateTime40.getCenturyOfEra();
        org.joda.time.DateTime.Property property42 = dateTime40.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField38, dateTimeFieldType43);
        long long47 = zeroIsMaxDateTimeField44.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology48);
        int int50 = dateTime49.getCenturyOfEra();
        org.joda.time.DateTime.Property property51 = dateTime49.minuteOfHour();
        org.joda.time.DateTime dateTime52 = property51.getDateTime();
        org.joda.time.LocalDate localDate53 = dateTime52.toLocalDate();
        int[] intArray57 = new int[] { 20, 69 };
        int[] intArray59 = zeroIsMaxDateTimeField44.add((org.joda.time.ReadablePartial) localDate53, (-10), intArray57, (int) (short) 0);
        try {
            int[] intArray61 = zeroIsMaxDateTimeField13.addWrapField((org.joda.time.ReadablePartial) timeOfDay29, (int) (byte) 1, intArray57, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-100L) + "'", long16 == (-100L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianCalendar28);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[]" + "'", str32.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 200020L + "'", long47 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 20 + "'", int50 == 20);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDate53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        dateTimeFormatterBuilder50.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder50.appendMinuteOfDay(2019);
        boolean boolean54 = dateTimeFormatterBuilder53.canBuildParser();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.plus(readablePeriod6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsText(locale7);
        int int9 = property2.getMinimumValue();
        org.joda.time.DateTime dateTime10 = property2.roundHalfCeilingCopy();
        int int11 = dateTime10.getMillisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology6 = gregorianChronology1.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfWeek();
        org.joda.time.DurationField durationField9 = gregorianChronology1.seconds();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[]" + "'", str2.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        boolean boolean9 = dateTime7.isEqual((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 0);
        org.joda.time.DateTime dateTime18 = dateTime5.plusMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
        org.joda.time.DateTime.Property property12 = dateTime1.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        java.lang.String str8 = dateTime7.toString();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withDayOfMonth((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.052Z" + "'", str8.equals("1970-01-01T00:00:00.052Z"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("1307");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1307\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsText(locale7);
        java.lang.String str9 = property2.getAsShortText();
        org.joda.time.DateTime dateTime11 = property2.addWrapFieldToCopy((int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology0.add(readablePeriod7, (long) (short) 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfDay();
        org.joda.time.DateTime dateTime15 = property13.setCopy(20);
        org.joda.time.DateTime dateTime17 = property13.addWrapFieldToCopy((int) '4');
        boolean boolean18 = gregorianChronology0.equals((java.lang.Object) property13);
        org.joda.time.DateTime dateTime19 = property13.roundFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 194 + "'", int2 == 194);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder48.append(dateTimeFormatter49);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.year();
        int int54 = dateTimeFormatter53.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter53.withDefaultYear(0);
        org.joda.time.format.DateTimeParser dateTimeParser57 = dateTimeFormatter53.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder48.append(dateTimeParser57);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2000 + "'", int54 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(dateTimeParser57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 52, (java.lang.Number) (short) 10, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMaximumValue();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(20);
        org.joda.time.DateTime dateTime12 = property9.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
        int int19 = dateTime12.get(dateTimeField18);
        boolean boolean20 = dateTime12.isAfterNow();
        int int21 = dateTime12.getYearOfCentury();
        org.joda.time.DateTime dateTime23 = dateTime12.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfDay();
        org.joda.time.DateTime dateTime28 = property26.setCopy(20);
        org.joda.time.DateTime dateTime29 = property26.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
        int int36 = dateTime29.get(dateTimeField35);
        boolean boolean37 = dateTime29.isAfterNow();
        int int38 = dateTime29.getYearOfCentury();
        org.joda.time.DateTime dateTime40 = dateTime29.plusMonths((int) (short) 0);
        boolean boolean41 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime40);
        int int42 = property3.compareTo((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str46 = gregorianChronology45.toString();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology50 = gregorianChronology45.withZone(dateTimeZone49);
        org.joda.time.Chronology chronology51 = gregorianChronology45.withUTC();
        org.joda.time.DateTime dateTime52 = dateTime44.withChronology((org.joda.time.Chronology) gregorianChronology45);
        int int53 = dateTime52.getSecondOfMinute();
        org.joda.time.DateTime dateTime55 = dateTime52.minus((long) (short) 100);
        org.joda.time.DateTime.Property property56 = dateTime52.weekyear();
        org.joda.time.MutableDateTime mutableDateTime57 = dateTime52.toMutableDateTimeISO();
        boolean boolean58 = property3.equals((java.lang.Object) mutableDateTime57);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 70 + "'", int21 == 70);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "GregorianChronology[]" + "'", str46.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(mutableDateTime57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant3 = null;
        long long4 = property2.getDifferenceAsLong(readableInstant3);
        long long5 = property2.remainder();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        int int7 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 152L + "'", long5 == 152L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 10, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        int int12 = dateTime6.get(dateTimeFieldType11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
        long long21 = offsetDateTimeField16.remainder((long) 4);
        long long24 = offsetDateTimeField16.getDifferenceAsLong(10L, 200020L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str26 = gregorianChronology25.toString();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology30 = gregorianChronology25.withZone(dateTimeZone29);
        org.joda.time.Chronology chronology31 = gregorianChronology25.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology25.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology33);
        int int35 = dateTime34.getCenturyOfEra();
        org.joda.time.DateTime.Property property36 = dateTime34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField38 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField32, dateTimeFieldType37);
        long long41 = zeroIsMaxDateTimeField38.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
        int int44 = dateTime43.getCenturyOfEra();
        org.joda.time.DateTime.Property property45 = dateTime43.minuteOfHour();
        org.joda.time.DateTime dateTime46 = property45.getDateTime();
        org.joda.time.LocalDate localDate47 = dateTime46.toLocalDate();
        int[] intArray51 = new int[] { 20, 69 };
        int[] intArray53 = zeroIsMaxDateTimeField38.add((org.joda.time.ReadablePartial) localDate47, (-10), intArray51, (int) (short) 0);
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDate47, 23156, locale55);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-200010L) + "'", long24 == (-200010L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[]" + "'", str26.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 20 + "'", int35 == 20);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 200020L + "'", long41 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 20 + "'", int44 == 20);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "23156" + "'", str56.equals("23156"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = cachedDateTimeZone9.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        long long15 = dateTimeZone12.getMillisKeepLocal(dateTimeZone13, 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("ISOChronology[]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property5 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        int int7 = property5.getMaximumValue();
        org.joda.time.DurationField durationField8 = property5.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfDay();
        org.joda.time.DateTime dateTime13 = property11.setCopy(20);
        org.joda.time.DateTime dateTime14 = property11.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.minuteOfHour();
        int int21 = dateTime14.get(dateTimeField20);
        boolean boolean22 = dateTime14.isAfterNow();
        int int23 = dateTime14.getYearOfCentury();
        org.joda.time.DateTime dateTime25 = dateTime14.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.DateTime.Property property28 = dateTime27.minuteOfDay();
        org.joda.time.DateTime dateTime30 = property28.setCopy(20);
        org.joda.time.DateTime dateTime31 = property28.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) iSOChronology35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.minuteOfHour();
        int int38 = dateTime31.get(dateTimeField37);
        boolean boolean39 = dateTime31.isAfterNow();
        int int40 = dateTime31.getYearOfCentury();
        org.joda.time.DateTime dateTime42 = dateTime31.plusMonths((int) (short) 0);
        boolean boolean43 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime42);
        int int44 = property5.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property5.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder1.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear(0, false);
        boolean boolean52 = gregorianChronology0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 70 + "'", int23 == 70);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 70 + "'", int40 == 70);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology8);
        int int11 = dateTime4.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        boolean boolean14 = zeroIsMaxDateTimeField13.isLenient();
        int int17 = zeroIsMaxDateTimeField13.getDifference((long) 4, 98L);
        long long19 = zeroIsMaxDateTimeField13.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100L) + "'", long19 == (-100L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField8 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.100\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 1969, (java.lang.Number) (byte) 100, (java.lang.Number) (short) 10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        long long12 = fixedDateTimeZone4.convertLocalToUTC((long) (short) -1, true, (long) 1969);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        boolean boolean14 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-101L) + "'", long12 == (-101L));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DurationField durationField14 = zeroIsMaxDateTimeField13.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str16 = gregorianChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology20 = gregorianChronology15.withZone(dateTimeZone19);
        org.joda.time.Chronology chronology21 = gregorianChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
        int int25 = dateTime24.getCenturyOfEra();
        org.joda.time.DateTime.Property property26 = dateTime24.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField22, dateTimeFieldType27);
        long long31 = zeroIsMaxDateTimeField28.addWrapField((long) 20, 200);
        int int32 = zeroIsMaxDateTimeField28.getMaximumValue();
        java.lang.String str33 = zeroIsMaxDateTimeField28.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
        int int36 = dateTime35.getCenturyOfEra();
        org.joda.time.DateTime.Property property37 = dateTime35.minuteOfHour();
        org.joda.time.DateTime dateTime38 = property37.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay39 = dateTime38.toYearMonthDay();
        int[] intArray40 = new int[] {};
        int int41 = zeroIsMaxDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay39, intArray40);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str43 = gregorianChronology42.toString();
        org.joda.time.DateTimeZone dateTimeZone44 = gregorianChronology42.getZone();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology47 = gregorianChronology42.withZone(dateTimeZone46);
        org.joda.time.Chronology chronology48 = gregorianChronology42.withUTC();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology42.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        int int52 = dateTime51.getCenturyOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField55 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField49, dateTimeFieldType54);
        long long58 = zeroIsMaxDateTimeField55.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology59);
        int int61 = dateTime60.getCenturyOfEra();
        org.joda.time.DateTime.Property property62 = dateTime60.minuteOfHour();
        org.joda.time.DateTime dateTime63 = property62.getDateTime();
        org.joda.time.LocalDate localDate64 = dateTime63.toLocalDate();
        int[] intArray68 = new int[] { 20, 69 };
        int[] intArray70 = zeroIsMaxDateTimeField55.add((org.joda.time.ReadablePartial) localDate64, (-10), intArray68, (int) (short) 0);
        int int71 = zeroIsMaxDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay39, intArray70);
        int int73 = zeroIsMaxDateTimeField13.get((-3L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[]" + "'", str16.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 200020L + "'", long31 == 200020L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86400 + "'", int32 == 86400);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "minuteOfHour" + "'", str33.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 20 + "'", int36 == 20);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(yearMonthDay39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 86400 + "'", int41 == 86400);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "GregorianChronology[]" + "'", str43.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 200020L + "'", long58 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 20 + "'", int61 == 20);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 86400 + "'", int73 == 86400);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime5 = property2.addToCopy((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMonths(86400);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        java.util.Locale locale16 = null;
        long long17 = zeroIsMaxDateTimeField13.set(36142071043476440L, "960", locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 36142071005760440L + "'", long17 == 36142071005760440L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.minusDays(21);
        int int5 = dateTime4.getSecondOfDay();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded(readableDuration6, (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        dateTimeFormatterBuilder50.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder50.appendMinuteOfDay(2019);
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology54);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str57 = gregorianChronology56.toString();
        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology56.getZone();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology61 = gregorianChronology56.withZone(dateTimeZone60);
        org.joda.time.Chronology chronology62 = gregorianChronology56.withUTC();
        org.joda.time.DateTime dateTime63 = dateTime55.withChronology((org.joda.time.Chronology) gregorianChronology56);
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology64);
        org.joda.time.DateTime dateTime67 = dateTime65.plusMonths((int) (short) -1);
        boolean boolean68 = dateTime63.isAfter((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.DateTime.Property property69 = dateTime63.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology70);
        org.joda.time.DateTime.Property property72 = dateTime71.minuteOfDay();
        org.joda.time.DateTime dateTime74 = dateTime71.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
        int int77 = dateTime76.getCenturyOfEra();
        org.joda.time.DateTime.Property property78 = dateTime76.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property78.getFieldType();
        int int80 = dateTime74.get(dateTimeFieldType79);
        int int81 = dateTime63.get(dateTimeFieldType79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder53.appendFraction(dateTimeFieldType79, 19, 194);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder53.appendDayOfYear((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[]" + "'", str57.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 20 + "'", int77 == 20);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendMinuteOfHour(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant3 = null;
        long long4 = property2.getDifferenceAsLong(readableInstant3);
        long long5 = property2.remainder();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime8.plusDays(2);
        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str16 = gregorianChronology15.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology20 = gregorianChronology15.withZone(dateTimeZone19);
        org.joda.time.Chronology chronology21 = gregorianChronology15.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology15.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
        int int25 = dateTime24.getCenturyOfEra();
        org.joda.time.DateTime.Property property26 = dateTime24.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField22, dateTimeFieldType27);
        int int29 = dateTime12.get((org.joda.time.DateTimeField) zeroIsMaxDateTimeField28);
        java.lang.String str30 = dateTime12.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 152L + "'", long5 == 152L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2880L) + "'", long13 == (-2880L));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GregorianChronology[]" + "'", str16.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 20 + "'", int25 == 20);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400 + "'", int29 == 86400);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970-01-03T00:00:00.152+00:00:00.100" + "'", str30.equals("1970-01-03T00:00:00.152+00:00:00.100"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
        int int18 = dateTime5.getSecondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsText(locale7);
        int int9 = property2.getMinimumValue();
        int int10 = property2.getLeapAmount();
        org.joda.time.DateTime dateTime12 = property2.setCopy(70);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DurationField durationField10 = property7.getDurationField();
        org.joda.time.DateTime dateTime11 = property7.roundHalfCeilingCopy();
        org.joda.time.ReadableInstant readableInstant12 = null;
        boolean boolean13 = dateTime11.isBefore(readableInstant12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        int int23 = dateTime22.getCenturyOfEra();
        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        int int26 = dateTime20.get(dateTimeFieldType25);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, dateTimeFieldType25, 59, (int) (short) -1, (int) (short) 1);
        boolean boolean31 = dateTime11.isSupported(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.field.FieldUtils.verifyValueBounds("887", (int) ' ', (int) (short) 1, 52);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime4.minusHours(0);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        long long12 = dateTime11.getMillis();
        org.joda.time.Instant instant13 = dateTime11.toInstant();
        int int14 = property9.getDifference((org.joda.time.ReadableInstant) instant13);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        boolean boolean14 = zeroIsMaxDateTimeField13.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime8 = property6.setCopy((int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfEra(4);
        boolean boolean8 = dateTime4.isBefore((long) 86400);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(52L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        int int10 = dateTime4.get(dateTimeFieldType9);
        org.joda.time.DurationField durationField11 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str13 = gregorianChronology12.toString();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology17 = gregorianChronology12.withZone(dateTimeZone16);
        org.joda.time.Chronology chronology18 = gregorianChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
        int int22 = dateTime21.getCenturyOfEra();
        org.joda.time.DateTime.Property property23 = dateTime21.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType24);
        org.joda.time.DurationField durationField26 = zeroIsMaxDateTimeField25.getRangeDurationField();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField27 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField11, durationField26);
        long long30 = preciseDateTimeField27.getDifferenceAsLong(0L, 52L);
        long long32 = preciseDateTimeField27.roundFloor((long) 4);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTime.Property property37 = dateTime36.minuteOfDay();
        org.joda.time.DateTime dateTime39 = dateTime36.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology40);
        int int42 = dateTime41.getCenturyOfEra();
        org.joda.time.DateTime.Property property43 = dateTime41.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        int int45 = dateTime39.get(dateTimeFieldType44);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType44, 59, (int) (short) -1, (int) (short) 1);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField49.getAsShortText(35L, locale51);
        long long54 = offsetDateTimeField49.roundHalfFloor((-3100L));
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str56 = gregorianChronology55.toString();
        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology55.getZone();
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology60 = gregorianChronology55.withZone(dateTimeZone59);
        org.joda.time.Chronology chronology61 = gregorianChronology55.withUTC();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology55.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology63);
        int int65 = dateTime64.getCenturyOfEra();
        org.joda.time.DateTime.Property property66 = dateTime64.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField62, dateTimeFieldType67);
        long long71 = zeroIsMaxDateTimeField68.addWrapField((long) 20, 200);
        int int72 = zeroIsMaxDateTimeField68.getMaximumValue();
        java.lang.String str73 = zeroIsMaxDateTimeField68.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology74);
        int int76 = dateTime75.getCenturyOfEra();
        org.joda.time.DateTime.Property property77 = dateTime75.minuteOfHour();
        org.joda.time.DateTime dateTime78 = property77.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay79 = dateTime78.toYearMonthDay();
        int[] intArray80 = new int[] {};
        int int81 = zeroIsMaxDateTimeField68.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay79, intArray80);
        int int82 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay79);
        int[] intArray88 = new int[] { 4, (byte) 10, (byte) 0, 200 };
        try {
            int[] intArray90 = preciseDateTimeField27.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay79, (int) '4', intArray88, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[]" + "'", str13.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20 + "'", int22 == 20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-52L) + "'", long30 == (-52L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4L + "'", long32 == 4L);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 20 + "'", int42 == 20);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "94" + "'", str52.equals("94"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-3100L) + "'", long54 == (-3100L));
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "GregorianChronology[]" + "'", str56.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 20 + "'", int65 == 20);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 200020L + "'", long71 == 200020L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 86400 + "'", int72 == 86400);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "minuteOfHour" + "'", str73.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 20 + "'", int76 == 20);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(yearMonthDay79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 86400 + "'", int81 == 86400);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 59 + "'", int82 == 59);
        org.junit.Assert.assertNotNull(intArray88);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        org.joda.time.DurationField durationField10 = property7.getDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField13 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType11, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfDay();
        org.joda.time.DateTime dateTime5 = property3.setCopy(20);
        org.joda.time.DateTime dateTime6 = property3.withMinimumValue();
        long long7 = property3.remainder();
        boolean boolean8 = iSOChronology0.equals((java.lang.Object) long7);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 152L + "'", long7 == 152L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        dateTimeFormatterBuilder50.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder50.appendMinuteOfDay(2019);
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology54);
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str57 = gregorianChronology56.toString();
        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology56.getZone();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology61 = gregorianChronology56.withZone(dateTimeZone60);
        org.joda.time.Chronology chronology62 = gregorianChronology56.withUTC();
        org.joda.time.DateTime dateTime63 = dateTime55.withChronology((org.joda.time.Chronology) gregorianChronology56);
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology64);
        org.joda.time.DateTime dateTime67 = dateTime65.plusMonths((int) (short) -1);
        boolean boolean68 = dateTime63.isAfter((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.DateTime.Property property69 = dateTime63.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology70);
        org.joda.time.DateTime.Property property72 = dateTime71.minuteOfDay();
        org.joda.time.DateTime dateTime74 = dateTime71.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
        int int77 = dateTime76.getCenturyOfEra();
        org.joda.time.DateTime.Property property78 = dateTime76.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property78.getFieldType();
        int int80 = dateTime74.get(dateTimeFieldType79);
        int int81 = dateTime63.get(dateTimeFieldType79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder53.appendFraction(dateTimeFieldType79, 19, 194);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder84.appendDayOfMonth(57600);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[]" + "'", str57.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 20 + "'", int77 == 20);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime4.minusHours(0);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.minus(readableDuration9);
        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime13 = dateTime5.minusMinutes((int) 'a');
        try {
            org.joda.time.DateTime dateTime15 = dateTime5.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 172800052L + "'", long11 == 172800052L);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter1.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-8L), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime1.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        java.lang.String str18 = zeroIsMaxDateTimeField13.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        int int21 = dateTime20.getCenturyOfEra();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int[] intArray25 = new int[] {};
        int int26 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay24, intArray25);
        boolean boolean27 = zeroIsMaxDateTimeField13.isLenient();
        long long29 = zeroIsMaxDateTimeField13.roundCeiling(100L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "minuteOfHour" + "'", str18.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86400 + "'", int26 == 86400);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 900L + "'", long29 == 900L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime11.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
        org.joda.time.DateTime dateTime7 = dateTime3.withEra(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) 1);
        java.util.Locale locale10 = null;
        java.util.Calendar calendar11 = dateTime7.toCalendar(locale10);
        org.joda.time.DateMidnight dateMidnight12 = dateTime7.toDateMidnight();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(calendar11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 21, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[-01:00]", "Wed");
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
        int int12 = dateTime1.getYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendFractionOfSecond((-10), 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        int int12 = dateTime11.getCenturyOfEra();
        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType14);
        long long18 = zeroIsMaxDateTimeField15.addWrapField((long) 20, 200);
        int int19 = zeroIsMaxDateTimeField15.getMaximumValue();
        java.lang.String str20 = zeroIsMaxDateTimeField15.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        int int23 = dateTime22.getCenturyOfEra();
        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
        org.joda.time.DateTime dateTime25 = property24.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime25.toYearMonthDay();
        int[] intArray27 = new int[] {};
        int int28 = zeroIsMaxDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay26, intArray27);
        boolean boolean29 = zeroIsMaxDateTimeField15.isLenient();
        long long32 = zeroIsMaxDateTimeField15.add((long) (byte) 0, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str34 = gregorianChronology33.toString();
        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology33.getZone();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology38 = gregorianChronology33.withZone(dateTimeZone37);
        org.joda.time.Chronology chronology39 = gregorianChronology33.withUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology33.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology41);
        int int43 = dateTime42.getCenturyOfEra();
        org.joda.time.DateTime.Property property44 = dateTime42.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField40, dateTimeFieldType45);
        long long49 = zeroIsMaxDateTimeField46.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        int int52 = dateTime51.getCenturyOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.minuteOfHour();
        org.joda.time.DateTime dateTime54 = property53.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
        java.util.Locale locale57 = null;
        java.lang.String str58 = zeroIsMaxDateTimeField46.getAsText((org.joda.time.ReadablePartial) yearMonthDay55, 1970, locale57);
        long long61 = zeroIsMaxDateTimeField46.add((long) (short) 0, 21);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology62);
        int int64 = dateTime63.getCenturyOfEra();
        org.joda.time.DateTime.Property property65 = dateTime63.minuteOfHour();
        org.joda.time.DateTime dateTime66 = property65.getDateTime();
        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
        int int68 = zeroIsMaxDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) localDate67);
        int int69 = zeroIsMaxDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate67);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 200020L + "'", long18 == 200020L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86400 + "'", int19 == 86400);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "minuteOfHour" + "'", str20.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86400 + "'", int28 == 86400);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1000L) + "'", long32 == (-1000L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[]" + "'", str34.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 20 + "'", int43 == 20);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 200020L + "'", long49 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(yearMonthDay55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970" + "'", str58.equals("1970"));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 21000L + "'", long61 == 21000L);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 20 + "'", int64 == 20);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 86400 + "'", int68 == 86400);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser52 = dateTimeFormatter51.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder50.append(dateTimeParser52);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeParser52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant3 = null;
        long long4 = property2.getDifferenceAsLong(readableInstant3);
        long long5 = property2.remainder();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime8.plusDays(2);
        long long13 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
        boolean boolean14 = dateTime12.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 152L + "'", long5 == 152L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2880L) + "'", long13 == (-2880L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime17 = dateTime5.plus((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plus((long) (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.lang.String str5 = property3.getAsShortText();
        int int6 = property3.getLeapAmount();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = cachedDateTimeZone9.nextTransition(0L);
        boolean boolean12 = cachedDateTimeZone9.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone13.getUncachedZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime1.plusDays(2);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 20, (int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant12 = null;
        long long13 = property11.getDifferenceAsLong(readableInstant12);
        long long14 = property11.remainder();
        org.joda.time.DateTime dateTime15 = property11.roundHalfCeilingCopy();
        int int16 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.minusMinutes(0);
        boolean boolean19 = dateTime18.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 152L + "'", long14 == 152L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        org.joda.time.DurationField durationField5 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.dayOfWeek();
        org.joda.time.DurationField durationField14 = gregorianChronology6.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField15 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType4, durationField5, durationField14);
        int int16 = preciseDateTimeField15.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 999 + "'", int16 == 999);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime4.withWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(900L, (-3L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 897L + "'", long2 == 897L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod5, 200020L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str47 = gregorianChronology46.toString();
        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology46.getZone();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology51 = gregorianChronology46.withZone(dateTimeZone50);
        org.joda.time.Chronology chronology52 = gregorianChronology46.withUTC();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        long long56 = gregorianChronology46.add(readablePeriod53, (long) (short) 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology57);
        org.joda.time.DateTime.Property property59 = dateTime58.minuteOfDay();
        org.joda.time.DateTime dateTime61 = property59.setCopy(20);
        org.joda.time.DateTime dateTime63 = property59.addWrapFieldToCopy((int) '4');
        boolean boolean64 = gregorianChronology46.equals((java.lang.Object) property59);
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology46.hourOfDay();
        try {
            org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder0, (org.joda.time.Chronology) gregorianChronology46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "GregorianChronology[]" + "'", str47.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(dateTimeField65);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        int int11 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
        long long18 = fixedDateTimeZone4.convertLocalToUTC(35L, false, (long) 47);
        java.util.TimeZone timeZone19 = fixedDateTimeZone4.toTimeZone();
        long long21 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-65L) + "'", long18 == (-65L));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        int int7 = dateTime6.getCenturyOfEra();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = property8.getDateTime();
        org.joda.time.LocalDate localDate10 = dateTime9.toLocalDate();
        int[] intArray12 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate10, (-3L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Chronology chronology5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2, (int) 'a', 999, (int) (byte) 0, (int) (short) 10, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) '#', (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 23156);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(152);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        long long18 = zeroIsMaxDateTimeField13.roundHalfCeiling((long) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str20 = gregorianChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology24 = gregorianChronology19.withZone(dateTimeZone23);
        org.joda.time.Chronology chronology25 = gregorianChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology19.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
        int int29 = dateTime28.getCenturyOfEra();
        org.joda.time.DateTime.Property property30 = dateTime28.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField26, dateTimeFieldType31);
        long long35 = zeroIsMaxDateTimeField32.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
        int int38 = dateTime37.getCenturyOfEra();
        org.joda.time.DateTime.Property property39 = dateTime37.minuteOfHour();
        org.joda.time.DateTime dateTime40 = property39.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime40.toYearMonthDay();
        java.util.Locale locale43 = null;
        java.lang.String str44 = zeroIsMaxDateTimeField32.getAsText((org.joda.time.ReadablePartial) yearMonthDay41, 1970, locale43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
        int int47 = dateTime46.getCenturyOfEra();
        org.joda.time.DateTime.Property property48 = dateTime46.minuteOfHour();
        org.joda.time.DateTime dateTime49 = property48.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay50 = dateTime49.toYearMonthDay();
        int int51 = zeroIsMaxDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay50);
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str53 = gregorianChronology52.toString();
        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology52.getZone();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology57 = gregorianChronology52.withZone(dateTimeZone56);
        org.joda.time.Chronology chronology58 = gregorianChronology52.withUTC();
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology52.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology60);
        int int62 = dateTime61.getCenturyOfEra();
        org.joda.time.DateTime.Property property63 = dateTime61.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField65 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField59, dateTimeFieldType64);
        long long68 = zeroIsMaxDateTimeField65.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology69);
        int int71 = dateTime70.getCenturyOfEra();
        org.joda.time.DateTime.Property property72 = dateTime70.minuteOfHour();
        org.joda.time.DateTime dateTime73 = property72.getDateTime();
        org.joda.time.LocalDate localDate74 = dateTime73.toLocalDate();
        int[] intArray78 = new int[] { 20, 69 };
        int[] intArray80 = zeroIsMaxDateTimeField65.add((org.joda.time.ReadablePartial) localDate74, (-10), intArray78, (int) (short) 0);
        int int81 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay50, intArray80);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-100L) + "'", long18 == (-100L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GregorianChronology[]" + "'", str20.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 20 + "'", int29 == 20);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 200020L + "'", long35 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 20 + "'", int38 == 20);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970" + "'", str44.equals("1970"));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 20 + "'", int47 == 20);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(yearMonthDay50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 86400 + "'", int51 == 86400);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "GregorianChronology[]" + "'", str53.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 20 + "'", int62 == 20);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 200020L + "'", long68 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 20 + "'", int71 == 20);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 86400 + "'", int81 == 86400);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        try {
            long long9 = iSOChronology3.getDateTimeMillis((long) (-1), 0, (int) (byte) 1, 78440644, 86400);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 78440644 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        java.lang.String str3 = property2.getAsString();
        org.joda.time.DateTime dateTime5 = property2.addToCopy((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withEra(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withPeriodAdded(readablePeriod2, (int) '4');
        boolean boolean6 = dateTime1.isBefore((long) 2000);
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withFieldAdded(durationFieldType9, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(calendar8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology8);
        boolean boolean12 = dateTime4.isBefore((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime7.withDurationAdded(readableDuration14, 69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.joda.time.DateTime dateTime12 = dateTime7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        int int13 = dateTime12.getSecondOfMinute();
        org.joda.time.ReadableInstant readableInstant14 = null;
        try {
            int int15 = dateTime12.compareTo(readableInstant14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime10.withEra(1);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) 1);
        boolean boolean17 = fixedDateTimeZone4.equals((java.lang.Object) dateTime14);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        long long2 = dateTime1.getMillis();
        org.joda.time.LocalDateTime localDateTime3 = dateTime1.toLocalDateTime();
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTime1.toString("960", locale5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "960" + "'", str6.equals("960"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime17 = dateTime15.withMillis((long) (byte) 0);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        java.lang.String str18 = zeroIsMaxDateTimeField13.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        int int21 = dateTime20.getCenturyOfEra();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay24 = dateTime23.toYearMonthDay();
        int[] intArray25 = new int[] {};
        int int26 = zeroIsMaxDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay24, intArray25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DateTime.Property property29 = dateTime28.minuteOfDay();
        org.joda.time.DateTime dateTime31 = property29.setCopy(20);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTime.Property property34 = dateTime33.minuteOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology37);
        int int39 = dateTime38.getCenturyOfEra();
        org.joda.time.DateTime.Property property40 = dateTime38.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        int int42 = dateTime36.get(dateTimeFieldType41);
        org.joda.time.DateTime.Property property43 = dateTime31.property(dateTimeFieldType41);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField13, dateTimeFieldType41, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "minuteOfHour" + "'", str18.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(yearMonthDay24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86400 + "'", int26 == 86400);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 20 + "'", int39 == 20);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(property43);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra((int) 'a');
        org.joda.time.Chronology chronology5 = dateTime1.getChronology();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder48.append(dateTimeFormatter49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder48.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder48.append(dateTimeFormatter54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusMonths((int) (short) -1);
        int int20 = property15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        boolean boolean22 = dateTime19.isAfter(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        try {
            long long5 = dateTimeFormatter0.parseMillis("minuteOfHour");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"minuteOfHour\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(chronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str9 = gregorianChronology8.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            int int16 = dateTime13.get(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[]" + "'", str9.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (short) 1, 1969, 1439, 999, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        int int12 = dateTime6.get(dateTimeFieldType11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
        long long21 = offsetDateTimeField16.roundHalfFloor((-3100L));
        org.joda.time.DurationField durationField22 = offsetDateTimeField16.getLeapDurationField();
        int int23 = offsetDateTimeField16.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3100L) + "'", long21 == (-3100L));
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        int int16 = dateTime9.getYear();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) int16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("960", "960");
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        boolean boolean17 = property15.equals((java.lang.Object) 2000);
        org.joda.time.DateTime dateTime18 = property15.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfEra((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime20.withChronology((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.Instant instant28 = dateTime20.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[]" + "'", str22.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(instant28);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, number2, (java.lang.Number) 98L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder45.append(dateTimeFormatter47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder45.appendTimeZoneId();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.Interval interval4 = property3.toInterval();
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval4);
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(readableInterval5);
        org.junit.Assert.assertNotNull(readableInterval6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears((int) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long17 = fixedDateTimeZone15.nextTransition((long) (byte) 1);
        long long19 = fixedDateTimeZone15.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        long long22 = cachedDateTimeZone20.nextTransition(0L);
        boolean boolean23 = cachedDateTimeZone20.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime8.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2000L + "'", long19 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
        int int5 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str14 = gregorianChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        int int23 = dateTime22.getCenturyOfEra();
        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        int int32 = dateTime31.getCenturyOfEra();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
        org.joda.time.DateTime dateTime34 = property33.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
        java.util.Locale locale37 = null;
        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
        java.util.Locale locale45 = null;
        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
        int int49 = dateTime48.getCenturyOfEra();
        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str54 = gregorianChronology53.toString();
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
        int int68 = dividedDateTimeField9.getDifference((long) 1970, 52L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(yearMonthDay35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) 2000);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = cachedDateTimeZone9.getName((long) 100);
        int int13 = cachedDateTimeZone9.getOffsetFromLocal((long) 22);
        int int15 = cachedDateTimeZone9.getStandardOffset((long) 1969);
        java.util.Locale locale17 = null;
        java.lang.String str18 = cachedDateTimeZone9.getShortName((-3599900L), locale17);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2000L + "'", long8 == 2000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.100" + "'", str11.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.100" + "'", str18.equals("+00:00:00.100"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology21 = gregorianChronology16.withZone(dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        int int26 = dateTime25.getCenturyOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField23, dateTimeFieldType28);
        long long32 = zeroIsMaxDateTimeField29.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology33);
        int int35 = dateTime34.getCenturyOfEra();
        org.joda.time.DateTime.Property property36 = dateTime34.minuteOfHour();
        org.joda.time.DateTime dateTime37 = property36.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay38 = dateTime37.toYearMonthDay();
        java.util.Locale locale40 = null;
        java.lang.String str41 = zeroIsMaxDateTimeField29.getAsText((org.joda.time.ReadablePartial) yearMonthDay38, 1970, locale40);
        try {
            int int42 = property15.compareTo((org.joda.time.ReadablePartial) yearMonthDay38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[]" + "'", str17.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 200020L + "'", long32 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 20 + "'", int35 == 20);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(yearMonthDay38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970" + "'", str41.equals("1970"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        boolean boolean17 = property15.equals((java.lang.Object) 2000);
        org.joda.time.DateTime dateTime18 = property15.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfEra((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime20.withChronology((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant31 = null;
        long long32 = property30.getDifferenceAsLong(readableInstant31);
        long long33 = property30.remainder();
        org.joda.time.DateTime dateTime34 = property30.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTime dateTime38 = dateTime36.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime40 = dateTime36.plusDays(2);
        long long41 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime40);
        boolean boolean42 = gregorianChronology21.equals((java.lang.Object) property30);
        long long46 = gregorianChronology21.add((-3599800L), 21000L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[]" + "'", str22.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 152L + "'", long33 == 152L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2880L) + "'", long41 == (-2880L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-3578800L) + "'", long46 == (-3578800L));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay(0);
        org.joda.time.DateTime dateTime7 = dateTime3.withEra(1);
        org.joda.time.Instant instant8 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology21 = gregorianChronology16.withZone(dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        int int26 = dateTime25.getCenturyOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField23, dateTimeFieldType28);
        org.joda.time.DateTime.Property property30 = dateTime5.property(dateTimeFieldType28);
        java.lang.String str31 = property30.getAsString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[]" + "'", str17.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatter48.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.append(dateTimeParser49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder50.appendHalfdayOfDayText();
        boolean boolean52 = dateTimeFormatterBuilder51.canBuildFormatter();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        int int15 = zeroIsMaxDateTimeField13.getLeapAmount((long) 78440644);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology21 = gregorianChronology16.withZone(dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        int int26 = dateTime25.getCenturyOfEra();
        org.joda.time.DateTime.Property property27 = dateTime25.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField23, dateTimeFieldType28);
        org.joda.time.DurationField durationField30 = zeroIsMaxDateTimeField29.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology36 = gregorianChronology31.withZone(dateTimeZone35);
        org.joda.time.Chronology chronology37 = gregorianChronology31.withUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
        int int41 = dateTime40.getCenturyOfEra();
        org.joda.time.DateTime.Property property42 = dateTime40.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField38, dateTimeFieldType43);
        long long47 = zeroIsMaxDateTimeField44.addWrapField((long) 20, 200);
        int int48 = zeroIsMaxDateTimeField44.getMaximumValue();
        java.lang.String str49 = zeroIsMaxDateTimeField44.getName();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        int int52 = dateTime51.getCenturyOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.minuteOfHour();
        org.joda.time.DateTime dateTime54 = property53.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
        int[] intArray56 = new int[] {};
        int int57 = zeroIsMaxDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay55, intArray56);
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str59 = gregorianChronology58.toString();
        org.joda.time.DateTimeZone dateTimeZone60 = gregorianChronology58.getZone();
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology63 = gregorianChronology58.withZone(dateTimeZone62);
        org.joda.time.Chronology chronology64 = gregorianChronology58.withUTC();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology58.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology66);
        int int68 = dateTime67.getCenturyOfEra();
        org.joda.time.DateTime.Property property69 = dateTime67.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField65, dateTimeFieldType70);
        long long74 = zeroIsMaxDateTimeField71.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
        int int77 = dateTime76.getCenturyOfEra();
        org.joda.time.DateTime.Property property78 = dateTime76.minuteOfHour();
        org.joda.time.DateTime dateTime79 = property78.getDateTime();
        org.joda.time.LocalDate localDate80 = dateTime79.toLocalDate();
        int[] intArray84 = new int[] { 20, 69 };
        int[] intArray86 = zeroIsMaxDateTimeField71.add((org.joda.time.ReadablePartial) localDate80, (-10), intArray84, (int) (short) 0);
        int int87 = zeroIsMaxDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay55, intArray86);
        int int88 = zeroIsMaxDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay55);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[]" + "'", str17.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20 + "'", int26 == 20);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[]" + "'", str32.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20 + "'", int41 == 20);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 200020L + "'", long47 == 200020L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 86400 + "'", int48 == 86400);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "minuteOfHour" + "'", str49.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(yearMonthDay55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 86400 + "'", int57 == 86400);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "GregorianChronology[]" + "'", str59.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 20 + "'", int68 == 20);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 200020L + "'", long74 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 20 + "'", int77 == 20);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(localDate80);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        try {
            long long7 = iSOChronology0.getDateTimeMillis((-10), (int) (byte) -1, (int) (byte) 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTime.Property property4 = dateTime3.minuteOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        int int12 = dateTime6.get(dateTimeFieldType11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType11, 59, (int) (short) -1, (int) (short) 1);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField16.getAsShortText(35L, locale18);
        long long21 = offsetDateTimeField16.remainder((long) 4);
        long long24 = offsetDateTimeField16.getDifferenceAsLong(10L, 200020L);
        int int25 = offsetDateTimeField16.getMaximumValue();
        long long27 = offsetDateTimeField16.remainder((-1L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "94" + "'", str19.equals("94"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-200010L) + "'", long24 == (-200010L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "960", (int) (byte) 100, (int) (byte) -1);
        long long6 = fixedDateTimeZone4.nextTransition((long) (byte) 1);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        int int11 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.withYearOfEra((int) 'a');
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTime.Property property17 = dateTime16.minuteOfDay();
        org.joda.time.DateTime dateTime19 = property17.setCopy(20);
        org.joda.time.DateTime dateTime20 = property17.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.minuteOfHour();
        int int27 = dateTime20.get(dateTimeField26);
        boolean boolean28 = dateTime20.isAfterNow();
        int int29 = dateTime20.getYearOfCentury();
        org.joda.time.DateTime dateTime31 = dateTime20.plusMonths((int) (short) 0);
        boolean boolean32 = fixedDateTimeZone4.equals((java.lang.Object) dateTime31);
        long long35 = fixedDateTimeZone4.adjustOffset((-2880L), true);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 70 + "'", int29 == 70);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2880L) + "'", long35 == (-2880L));
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(2000L, dateTimeZone2);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withDurationAdded(readableDuration5, (int) '4');
        org.joda.time.DateTime dateTime10 = dateTime4.withDurationAdded(0L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(194);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
        int int5 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str14 = gregorianChronology13.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology18 = gregorianChronology13.withZone(dateTimeZone17);
        org.joda.time.Chronology chronology19 = gregorianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        int int23 = dateTime22.getCenturyOfEra();
        org.joda.time.DateTime.Property property24 = dateTime22.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType25);
        long long29 = zeroIsMaxDateTimeField26.addWrapField((long) 20, 200);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        int int32 = dateTime31.getCenturyOfEra();
        org.joda.time.DateTime.Property property33 = dateTime31.minuteOfHour();
        org.joda.time.DateTime dateTime34 = property33.getDateTime();
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
        java.util.Locale locale37 = null;
        java.lang.String str38 = zeroIsMaxDateTimeField26.getAsText((org.joda.time.ReadablePartial) yearMonthDay35, 1970, locale37);
        long long41 = zeroIsMaxDateTimeField26.add((long) (short) 0, 21);
        int int43 = zeroIsMaxDateTimeField26.getMaximumValue((long) 69);
        java.util.Locale locale45 = null;
        java.lang.String str46 = zeroIsMaxDateTimeField26.getAsShortText((long) 152, locale45);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
        int int49 = dateTime48.getCenturyOfEra();
        org.joda.time.DateTime.Property property50 = dateTime48.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        org.joda.time.DurationField durationField52 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str54 = gregorianChronology53.toString();
        org.joda.time.DateTimeZone dateTimeZone55 = gregorianChronology53.getZone();
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology58 = gregorianChronology53.withZone(dateTimeZone57);
        org.joda.time.Chronology chronology59 = gregorianChronology53.withUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology53.dayOfWeek();
        org.joda.time.DurationField durationField61 = gregorianChronology53.seconds();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField62 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType51, durationField52, durationField61);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField26, dateTimeFieldType51, 69);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField9, dateTimeFieldType51);
        try {
            long long68 = dividedDateTimeField9.addWrapField(0L, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[]" + "'", str14.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200020L + "'", long29 == 200020L);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 20 + "'", int32 == 20);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(yearMonthDay35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21000L + "'", long41 == 21000L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400 + "'", int43 == 86400);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "86400" + "'", str46.equals("86400"));
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 20 + "'", int49 == 20);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "GregorianChronology[]" + "'", str54.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(durationField61);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder47.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter49.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder48.append(dateTimeFormatter49);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendPattern("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = property2.setCopy(20);
        org.joda.time.DateTime dateTime5 = property2.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        int int12 = dateTime5.get(dateTimeField11);
        boolean boolean13 = dateTime5.isAfterNow();
        int int14 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime5.minus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(0);
        org.joda.time.DateTime dateTime21 = dateTime19.withYearOfCentury((int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        int int5 = property3.getMaximumValue();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(20);
        org.joda.time.DateTime dateTime12 = property9.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.minuteOfHour();
        int int19 = dateTime12.get(dateTimeField18);
        boolean boolean20 = dateTime12.isAfterNow();
        int int21 = dateTime12.getYearOfCentury();
        org.joda.time.DateTime dateTime23 = dateTime12.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfDay();
        org.joda.time.DateTime dateTime28 = property26.setCopy(20);
        org.joda.time.DateTime dateTime29 = property26.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.minuteOfHour();
        int int36 = dateTime29.get(dateTimeField35);
        boolean boolean37 = dateTime29.isAfterNow();
        int int38 = dateTime29.getYearOfCentury();
        org.joda.time.DateTime dateTime40 = dateTime29.plusMonths((int) (short) 0);
        boolean boolean41 = dateTime23.isEqual((org.joda.time.ReadableInstant) dateTime40);
        int int42 = property3.compareTo((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.DateTime.Property property47 = dateTime46.minuteOfDay();
        org.joda.time.DateTime dateTime49 = dateTime46.withYearOfEra(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        int int52 = dateTime51.getCenturyOfEra();
        org.joda.time.DateTime.Property property53 = dateTime51.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        int int55 = dateTime49.get(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, dateTimeFieldType54, 59, (int) (short) -1, (int) (short) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException63 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, (java.lang.Number) (short) 10);
        org.joda.time.DateTime.Property property64 = dateTime23.property(dateTimeFieldType54);
        org.joda.time.DateTime dateTime65 = property64.getDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 59 + "'", int5 == 59);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 70 + "'", int21 == 70);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 20 + "'", int52 == 20);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        int int8 = property7.get();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(19, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3800 + "'", int2 == 3800);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '4');
        java.lang.String str4 = dateTimeFormatter2.print((long) (short) 0);
        java.lang.StringBuffer stringBuffer5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology11 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withUTC();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(chronology12);
        java.lang.String str14 = dateTime13.toString();
        try {
            dateTimeFormatter2.printTo(stringBuffer5, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-001T00:00:00+00:00:00.100" + "'", str4.equals("1970-001T00:00:00+00:00:00.100"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.052Z" + "'", str14.equals("1970-01-01T00:00:00.052Z"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime11.withPeriodAdded(readablePeriod15, 21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "47", 2019, 20);
        java.lang.String str5 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0, false);
        dateTimeFormatterBuilder50.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder50.appendMinuteOfDay(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder50.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        int int6 = property4.getMaximumValue();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = property10.setCopy(20);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfHour();
        int int20 = dateTime13.get(dateTimeField19);
        boolean boolean21 = dateTime13.isAfterNow();
        int int22 = dateTime13.getYearOfCentury();
        org.joda.time.DateTime dateTime24 = dateTime13.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        boolean boolean42 = dateTime24.isEqual((org.joda.time.ReadableInstant) dateTime41);
        int int43 = property4.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
        int int5 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
        int int12 = dividedDateTimeField9.getDifference(70L, (long) 86399999);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime9.hourOfDay();
        boolean boolean17 = property15.equals((java.lang.Object) 2000);
        org.joda.time.DateTime dateTime18 = property15.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfEra((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime20.withChronology((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTime.Property property30 = dateTime29.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant31 = null;
        long long32 = property30.getDifferenceAsLong(readableInstant31);
        long long33 = property30.remainder();
        org.joda.time.DateTime dateTime34 = property30.roundHalfCeilingCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
        org.joda.time.DateTime dateTime38 = dateTime36.plusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime40 = dateTime36.plusDays(2);
        long long41 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime40);
        boolean boolean42 = gregorianChronology21.equals((java.lang.Object) property30);
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField44 = iSOChronology43.minutes();
        boolean boolean45 = property30.equals((java.lang.Object) iSOChronology43);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[]" + "'", str22.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 152L + "'", long33 == 152L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2880L) + "'", long41 == (-2880L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeField46);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(1);
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(0);
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(2);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsShortText(locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        boolean boolean15 = zeroIsMaxDateTimeField13.isLeap(1560556821716L);
        long long18 = zeroIsMaxDateTimeField13.add(0L, (long) 3800);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3800000L + "'", long18 == 3800000L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        int int10 = dateTime9.getCenturyOfEra();
        org.joda.time.DateTime.Property property11 = dateTime9.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType12);
        long long16 = zeroIsMaxDateTimeField13.addWrapField((long) 20, 200);
        int int17 = zeroIsMaxDateTimeField13.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = zeroIsMaxDateTimeField13.getAsShortText(0L, locale19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str22 = gregorianChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology26 = gregorianChronology21.withZone(dateTimeZone25);
        org.joda.time.Chronology chronology27 = gregorianChronology21.withUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology21.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
        int int31 = dateTime30.getCenturyOfEra();
        org.joda.time.DateTime.Property property32 = dateTime30.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType33);
        boolean boolean35 = zeroIsMaxDateTimeField34.isLenient();
        int int38 = zeroIsMaxDateTimeField34.getDifference((long) 4, 98L);
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
        long long41 = dateTime40.getMillis();
        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
        java.util.Locale locale44 = null;
        java.lang.String str45 = zeroIsMaxDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDateTime42, 86400, locale44);
        int[] intArray47 = null;
        try {
            int[] intArray49 = zeroIsMaxDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDateTime42, 3800, intArray47, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200020L + "'", long16 == 200020L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86400 + "'", int17 == 86400);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "86400" + "'", str20.equals("86400"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[]" + "'", str22.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20 + "'", int31 == 20);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "86400" + "'", str45.equals("86400"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
        int int5 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType7, (int) '#');
        long long12 = dividedDateTimeField9.add(900L, (long) (byte) -1);
        org.joda.time.DurationField durationField13 = dividedDateTimeField9.getDurationField();
        long long16 = dividedDateTimeField9.add((long) 52, (long) 78440644);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
        int int20 = dateTime19.getCenturyOfEra();
        org.joda.time.DateTime.Property property21 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime22 = property21.roundHalfFloorCopy();
        int int23 = property21.getMaximumValue();
        org.joda.time.DurationField durationField24 = property21.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTime.Property property27 = dateTime26.minuteOfDay();
        org.joda.time.DateTime dateTime29 = property27.setCopy(20);
        org.joda.time.DateTime dateTime30 = property27.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter33.withChronology((org.joda.time.Chronology) iSOChronology34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.minuteOfHour();
        int int37 = dateTime30.get(dateTimeField36);
        boolean boolean38 = dateTime30.isAfterNow();
        int int39 = dateTime30.getYearOfCentury();
        org.joda.time.DateTime dateTime41 = dateTime30.plusMonths((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.DateTime.Property property44 = dateTime43.minuteOfDay();
        org.joda.time.DateTime dateTime46 = property44.setCopy(20);
        org.joda.time.DateTime dateTime47 = property44.withMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter48.withPivotYear((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = dateTimeFormatter50.withChronology((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.minuteOfHour();
        int int54 = dateTime47.get(dateTimeField53);
        boolean boolean55 = dateTime47.isAfterNow();
        int int56 = dateTime47.getYearOfCentury();
        org.joda.time.DateTime dateTime58 = dateTime47.plusMonths((int) (short) 0);
        boolean boolean59 = dateTime41.isEqual((org.joda.time.ReadableInstant) dateTime58);
        int int60 = property21.compareTo((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType61);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder17.appendDayOfMonth(21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder64.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = dateTimeFormatter66.withPivotYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder65.append(dateTimeFormatter66);
        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology70);
        int int72 = dateTime71.getCenturyOfEra();
        org.joda.time.DateTime.Property property73 = dateTime71.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = property73.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder69.appendFixedDecimal(dateTimeFieldType74, 2);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField9, dateTimeFieldType74, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[]" + "'", str1.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-92015999100L) + "'", long12 == (-92015999100L));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 7219763942860800052L + "'", long16 == 7219763942860800052L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 70 + "'", int39 == 70);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 70 + "'", int56 == 70);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertNotNull(dateTimeFormatter68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
        org.junit.Assert.assertNotNull(gregorianChronology70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 20 + "'", int72 == 20);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.String str3 = dateTimeFormatter0.print((-3599800L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-W01-3T23:00:00.300+00:00:00.100" + "'", str3.equals("1970-W01-3T23:00:00.300+00:00:00.100"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        java.lang.String str3 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property3 = dateTime1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsShortText(locale6);
        int int8 = property5.getLeapAmount();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime1.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((-10));
        int int14 = dateTime11.getSecondOfDay();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.minus(readableDuration15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.Chronology chronology7 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withUTC();
        org.joda.time.DateTime dateTime9 = dateTime1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) -1);
        boolean boolean14 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusMonths((int) (short) -1);
        int int20 = property15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = property15.addToCopy(0);
        int int23 = dateTime22.getYearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[]" + "'", str3.equals("GregorianChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadableInstant readableInstant3 = null;
        long long4 = property2.getDifferenceAsLong(readableInstant3);
        long long5 = property2.remainder();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property2.getAsText(locale6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 152L + "'", long5 == 152L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-300L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("47");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '47' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(152);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour(70);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }
}

